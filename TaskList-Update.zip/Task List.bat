@echo off
rem Task List launcher — V1.9.19: local-mirror launch, code only.
rem V1.9.84: pushd "%~dp0" at start (a UNC cwd is refused by
rem cmd, which silently defaults to the Windows directory);
rem every robocopy runs under a hard wall-clock budget via
rem :bounded_copy (a read that never returns on a sick Offline
rem Files share stalled the old unbounded copy at 0% forever --
rem field, 2026-11-19); on a copy timeout/failure the launch
rem falls back to the existing mirror when its code set is
rem still coherent, else to the share, and says so either way.
rem V1.9.19 launch fixes (the still-30s+ launch the user reported):
rem  - SKIP_PYTHON never fired: the old block compared %HAVE_RUNTIME%
rem    INSIDE a parenthesized block, where cmd expands %VAR% at parse
rem    time — before the set /p ran — so the comparison always saw the
rem    empty value and python\ was re-copied on EVERY mirror run.
rem    Replaced with a findstr exact-line check (no expansion trap).
rem  - Version gate compared BYTES (fc /B): any trailing-newline
rem    difference in version.txt (unzip tools add one) failed the gate
rem    and forced a full mirror on every launch. The gate now compares
rem    version CONTENT via set /p, which strips the line ending.
rem  - The gate outcome is now logged (bat gate need_mirror=0/1) so the
rem    next slow launch is diagnosable from startup.log in one look.
rem
rem V1.9.18 launch cuts (the 30s+ launch the user reported): the old bat
rem re-copied the whole python\ runtime on EVERY patch, because the only
rem gate was the app version — and a patch bumps the app version even
rem when the runtime did not change. The runtime now has its own marker
rem (mirror\runtime.ver, content RUNTIME_VER): patch launches copy ONLY
rem the small tasklist\ code + root files and skip python\ entirely.
rem python\ is also copied WITHOUT the Qt QML tree and translations,
rem which this app never imports (no QtQuick/QML anywhere in tasklist\)
rem — thousands of small files that only cost share round-trips.
rem
rem WHY: this app is interpreted Python + Qt (~100MB of DLLs, hundreds of
rem small files). Loading all of that from a network share on every launch
rem pays per-file share + security-scan latency, cold, every time — while
rem his compiled apps load a handful of files and start in seconds. The
rem code therefore runs from a LOCAL mirror; only the DATA (tasks.db,
rem attachments, startup.log) stays on the share, so every machine still
rem shares one database.
rem
rem HOW (every launch):
rem  - If the local mirror's version matches this folder's version, launch
rem    the mirror immediately (two tiny file reads — no copy, no scan).
rem  - Otherwise mirror once with robocopy (python\ + tasklist\ + the
rem    root launch files ONLY — data\ stays on the share, and tests/,
rem    notes/, READMEs and anything else co-located are never copied,
rem    which is what made V1.9.16 patch launches re-copy far more than
rem    the app), then launch the mirror. The first launch after a patch
rem    is the slow one (a one-time copy); every launch after that runs
rem    locally.
rem  - If ANY mirror step fails, fall back to launching from this folder
rem    exactly as before — a mirror failure never blocks a launch.
rem  - The bat never waits for the app: it hands off to pythonw and exits.
rem  - Bat-phase timing: one timestamped line is appended to
rem    data\startup.log at bat start, plus mirror/launch-path lines, so
rem    the log covers the double-click -> interpreter phase that no app
rem    marker could see, and proves which path actually launched.
rem
rem The launcher stays dumb: it checks files exist, mirrors when the
rem version differs, and starts the app. It never closes silently — a
rem missing python or missing app file gets a visible MessageBox.
rem
rem Portable bundle rule: never pick up the system Python's packages.

setlocal
rem V1.9.84: take the script's own folder as the working
rem directory via pushd -- on a UNC share (this install lives
rem in a redirected folder) cmd refuses a UNC cwd and defaults
rem to the Windows directory; pushd maps the share and cds
rem there properly. Every path below is %~dp0-absolute anyway;
rem this makes the working directory match them.
pushd "%~dp0"
set PYTHONNOUSERSITE=1
set "SHARE_DIR=%~dp0"
set "MIRROR=%LOCALAPPDATA%\TaskListMirror"
set "NEED_MIRROR=1"
rem Runtime marker: bump ONLY when the python\ runtime itself changes
rem (new Python/Qt build). App patches must NOT bump this, or every
rem patch pays for a full runtime re-copy again.
set "RUNTIME_VER=1"

rem Bat-phase timing marker (guarded: no data\ yet on a fresh folder).
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat start >> "%SHARE_DIR%data\startup.log"
rem Mirror location, so a slow launch can be traced to a redirected
rem (non-local) mirror instead of guessed at.
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat mirror dir=%MIRROR% >> "%SHARE_DIR%data\startup.log"

if "%LOCALAPPDATA%"=="" goto :launch_share
if not exist "%MIRROR%\python\pythonw.exe" goto :do_mirror
if exist "%SHARE_DIR%version.txt" goto :have_share_ver
if not exist "%MIRROR%\tasklist\app.py" goto :do_mirror
fc /B "%SHARE_DIR%tasklist\app.py" "%MIRROR%\tasklist\app.py" >nul 2>&1
if not errorlevel 1 set "NEED_MIRROR=0"
goto :mirror_done
:have_share_ver
if not exist "%MIRROR%\version.txt" goto :do_mirror
rem V1.9.19: compare version CONTENT, not bytes — fc /B failed the gate
rem whenever the two files differed by a trailing newline (unzip tools
rem add one), forcing a full mirror on every launch. set /p strips the
rem line ending, so "1.9.18" matches "1.9.18" with or without one.
rem These lines are sequential (not in a block), so %VAR% expands after
rem each set /p has run — no delayed-expansion trap here.
set "SHARE_VER="
set /p "SHARE_VER=" < "%SHARE_DIR%version.txt"
set "MIRROR_VER="
set /p "MIRROR_VER=" < "%MIRROR%\version.txt"
if "%SHARE_VER%"=="%MIRROR_VER%" set "NEED_MIRROR=0"
goto :mirror_done
:do_mirror
set "NEED_MIRROR=1"
:mirror_done
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat gate need_mirror=%NEED_MIRROR% >> "%SHARE_DIR%data\startup.log"

if "%NEED_MIRROR%"=="0" goto :launch_mirror
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat mirror start >> "%SHARE_DIR%data\startup.log"
rem V1.9.18: mirror CODE ONLY — the old whole-folder copy also dragged
rem tests/, notes/, READMEs and anything else co-located on the share.
rem tasklist\ (code + bundled assets/fonts) plus the root launch files
rem copy on every patch; data\ never leaves the share. /MT:8 parallel.
rem python\ copies ONLY when its own marker differs: the runtime is
rem thousands of small files and re-copying it on an app-only patch is
rem what made patch launches crawl. The QML tree and translations are
rem never copied at all (no QtQuick/QML imports in tasklist\).
rem V1.9.19: the old block compared %HAVE_RUNTIME% INSIDE the
rem parenthesized block, where cmd expands %VAR% at parse time — before
rem the set /p ran — so the comparison always saw the empty value and
rem python\ was re-copied on EVERY mirror run. findstr reads the file
rem directly: exact-line match, no expansion trap.
set "SKIP_PYTHON=0"
if exist "%MIRROR%\python\pythonw.exe" if exist "%MIRROR%\runtime.ver" findstr /X /C:"%RUNTIME_VER%" "%MIRROR%\runtime.ver" >nul 2>&1 && set "SKIP_PYTHON=1"
rem V1.9.84: every copy below runs through :bounded_copy --
rem robocopy's /R:1 /W:1 bound its RETRIES, but a single read
rem that never returns (a file on a sick Offline Files share)
rem stalls it at that file forever: the 2026-11-19 field hang,
rem the console sitting at 0% with no error and no fallback.
rem :bounded_copy gives each step a hard wall-clock budget;
rem on timeout the copy is killed, the timeout is SAID (log +
rem console), and the launch falls back -- to the existing
rem mirror when the code set there is still coherent (the
rem tasklist and root steps did not fail), else to the share,
rem exactly as a plain copy failure always has.
set "RC_PY=0"
set "RC_TL=0"
set "RC_ROOT=0"
rem (Sequential lines, no parenthesized block: %TL_RC% must
rem expand AFTER :bounded_copy runs -- the V1.9.19 parse-time
rem expansion trap this file's header documents.)
if "%SKIP_PYTHON%"=="1" goto :skip_py
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat mirror copy python runtime_ver=%RUNTIME_VER% >> "%SHARE_DIR%data\startup.log"
set "TL_CSRC=%SHARE_DIR%python"
set "TL_CDST=%MIRROR%\python"
set "TL_CFILES="
set "TL_CSW=/E /XD __pycache__ qml translations /MT:8 /R:1 /W:1 /NJH /NJS /NDL /NFL"
set "TL_CBUDGET=300000"
call :bounded_copy
set "RC_PY=%TL_RC%"
if %TL_RC% LSS 8 echo %RUNTIME_VER% > "%MIRROR%\runtime.ver"
goto :py_done
:skip_py
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat mirror skip python runtime_ver=%RUNTIME_VER% >> "%SHARE_DIR%data\startup.log"
:py_done
set "TL_CSRC=%SHARE_DIR%tasklist"
set "TL_CDST=%MIRROR%\tasklist"
set "TL_CFILES="
set "TL_CSW=/E /XD __pycache__ /MT:8 /R:1 /W:1 /NJH /NJS /NDL /NFL"
set "TL_CBUDGET=120000"
call :bounded_copy
set "RC_TL=%TL_RC%"
set "TL_CSRC=%SHARE_DIR%"
set "TL_CDST=%MIRROR%"
set "TL_CFILES=Task List.pyw;version.txt;Task List.bat"
set "TL_CSW=/MT:8 /R:1 /W:1 /NJH /NJS /NDL /NFL"
set "TL_CBUDGET=60000"
call :bounded_copy
set "RC_ROOT=%TL_RC%"
set "RC=%RC_PY%"
if %RC_TL% GTR %RC% set "RC=%RC_TL%"
if %RC_ROOT% GTR %RC% set "RC=%RC_ROOT%"
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat mirror done rc=%RC% >> "%SHARE_DIR%data\startup.log"
rem The code set decides the fallback: if the tasklist + root
rem steps completed, the mirror is coherent -- launch it (on a
rem timeout elsewhere it is the last known good copy). If a
rem code step failed or timed out, the mirror may be mixed;
rem the share launch is the honest fallback, as before.
if %RC_TL% GEQ 8 goto :launch_share
if %RC_ROOT% GEQ 8 goto :launch_share
goto :launch_mirror

:launch_mirror
rem V1.9.17: the gate requires the app entry point too — a mirror with
rem pythonw + the .pyw but a missing tasklist\app.py used to be
rem launched anyway and died silently inside pythonw.
if exist "%MIRROR%\python\pythonw.exe" if exist "%MIRROR%\Task List.pyw" if exist "%MIRROR%\tasklist\app.py" (
  if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat launch mirror >> "%SHARE_DIR%data\startup.log"
  set "TASKLIST_DATA_DIR=%SHARE_DIR%data"
  start "" "%MIRROR%\python\pythonw.exe" "%MIRROR%\Task List.pyw"
  exit /b 0
)
rem Gate failed: if we skipped the mirror on a version match, try one
rem re-mirror; if we already mirrored, fall back to the share.
if "%NEED_MIRROR%"=="1" goto :launch_share
goto :do_mirror

:launch_share
if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat launch share >> "%SHARE_DIR%data\startup.log"
if not exist "%SHARE_DIR%python\pythonw.exe" (
  powershell -NoProfile -NonInteractive -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Task List could not start: python\pythonw.exe was not found in the app folder.', 'Task List', 'OK', 'Error')"
  exit /b 1
)
if not exist "%SHARE_DIR%Task List.pyw" (
  powershell -NoProfile -NonInteractive -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Task List could not start: Task List.pyw was not found in the app folder.', 'Task List', 'OK', 'Error')"
  exit /b 1
)
set "TASKLIST_DATA_DIR=%SHARE_DIR%data"
start "" "%SHARE_DIR%python\pythonw.exe" "%SHARE_DIR%Task List.pyw"
exit /b 0

rem ------------------------------------------------------------
rem :bounded_copy (V1.9.84) -- robocopy under a hard wall-clock
rem budget. Inputs (environment): TL_CSRC, TL_CDST, TL_CFILES
rem (';'-separated file list, may be empty), TL_CSW (switches),
rem TL_CBUDGET (milliseconds). Output: TL_RC = robocopy's exit
rem code, 16 on timeout, 24 when the copy could not be started
rem at all. Robocopy itself has no per-file I/O timeout, so the
rem bound comes from PowerShell's WaitForExit (PowerShell is
rem already this script's message-box dependency); without
rem PowerShell the plain unbounded call runs, as before.
:bounded_copy
set "TL_RC=16"
where powershell >nul 2>&1
if errorlevel 1 goto :bc_plain
powershell -NoProfile -NonInteractive -Command "try { $a = @($env:TL_CSRC, $env:TL_CDST); if ($env:TL_CFILES) { $a += $env:TL_CFILES -split ';' }; $a += $env:TL_CSW -split ' '; $p = Start-Process -FilePath robocopy -ArgumentList $a -PassThru -NoNewWindow } catch { exit 24 }; if (-not $p.WaitForExit([int]$env:TL_CBUDGET)) { try { $p.Kill() } catch {}; exit 16 }; exit $p.ExitCode"
set "TL_RC=%ERRORLEVEL%"
if "%TL_RC%"=="16" (
  echo Task List: a file copy from the network folder timed out and was stopped.
  if exist "%SHARE_DIR%data" echo %DATE% %TIME% bat mirror copy TIMEOUT budget_ms=%TL_CBUDGET% src=%TL_CSRC% >> "%SHARE_DIR%data\startup.log"
)
goto :eof
:bc_plain
if "%TL_CFILES%"=="" (
  robocopy "%TL_CSRC%" "%TL_CDST%" %TL_CSW%
) else (
  robocopy "%TL_CSRC%" "%TL_CDST%" "Task List.pyw" "version.txt" "Task List.bat" %TL_CSW%
)
set "TL_RC=%ERRORLEVEL%"
goto :eof
