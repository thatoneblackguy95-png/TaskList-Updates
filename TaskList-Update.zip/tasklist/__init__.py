"""Task List — a desktop app for tracking quotes, CAD, Configura and more."""

__version__ = "1.4.5"
