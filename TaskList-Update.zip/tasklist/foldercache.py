"""Quote-folder cache (V1.9.50): a local working set of quote
folders so they open with no network at all.

Design (the user's, 2026-11-12): he picks the quote-folder
ROOTS once in Settings (the 2025 and 2026 folders); the cache
then fills itself -- no hand-picking individual folders. It
keeps the most recently used folders (folders of open tasks
first, then newest-edited under the roots) inside an adjustable
budget (default 5 GB), evicting least-recently-used first.

Layout: ``%LOCALAPPDATA%\\TaskList\\foldercache\\files\\<key>``
mirrors one source folder's contents; ``manifest.json`` maps
key -> {source, size, files, last_used, filled_at}. Per-machine
state (datahome), never in the database. Stdlib only; every
public function is guarded and never raises.
"""

import hashlib
import json
import os
import shutil
import sqlite3
import time
from pathlib import Path

from . import datahome

_SKIP_SUFFIXES = (".tmp", ".bak", "~")


def _log(message):
    try:
        from .startup_log import log_startup_event
        log_startup_event("foldercache: " + message)
    except Exception:
        pass


def cache_key(source):
    norm = os.path.normpath(str(source)).lower()
    return hashlib.sha1(norm.encode("utf-8", "replace")).hexdigest()


def _manifest_path():
    return datahome.folder_cache_dir() / "manifest.json"


def read_manifest():
    try:
        data = json.loads(_manifest_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_manifest(manifest):
    try:
        _manifest_path().write_text(json.dumps(manifest, indent=1),
                                    encoding="utf-8")
    except Exception:
        pass


def entry_dir(key):
    return datahome.folder_cache_dir() / "files" / key


def total_size(manifest=None):
    if manifest is None:
        manifest = read_manifest()
    return sum(int(e.get("size", 0)) for e in manifest.values())


def _dir_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except Exception:
                pass
    return total


def cached_copy(source):
    """The local copy of a source folder, or None. Touches the
    entry's last_used on a hit."""
    try:
        key = cache_key(source)
        manifest = read_manifest()
        entry = manifest.get(key)
        if not entry:
            return None
        d = entry_dir(key)
        if not d.is_dir():
            return None
        entry["last_used"] = time.time()
        _write_manifest(manifest)
        return d
    except Exception:
        return None


def cache_folder(source):
    """Copy one folder into the cache (refresh in place).
    Returns the entry dir or None."""
    try:
        src = Path(source)
        if not src.is_dir():
            return None
        cfg = datahome.read_cache_config()
        if not cfg.get("enabled", True):
            return None
        key = cache_key(src)
        dst = entry_dir(key)
        tmp = dst.with_name(dst.name + ".tmp")
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)
        n_files = 0
        for root, _dirs, files in os.walk(src):
            rel = Path(root).relative_to(src)
            for name in files:
                if name.endswith(_SKIP_SUFFIXES):
                    continue
                s = Path(root) / name
                t = tmp / rel / name
                try:
                    t.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(s, t)
                    n_files += 1
                except Exception:
                    pass
        if dst.exists():
            shutil.rmtree(dst, ignore_errors=True)
        tmp.replace(dst)
        manifest = read_manifest()
        manifest[key] = {
            "source": str(src),
            "size": _dir_size(dst),
            "files": n_files,
            "last_used": time.time(),
            "filled_at": time.time(),
        }
        _write_manifest(manifest)
        evict_to_budget()
        return dst
    except Exception as exc:  # noqa: BLE001
        _log(f"cache_folder failed for {source}: {exc}")
        return None


def evict_to_budget():
    """Drop least-recently-used entries until the cache fits
    the configured budget."""
    try:
        cfg = datahome.read_cache_config()
        budget = float(cfg.get("budget_gb", 5)) * (1024 ** 3)
        manifest = read_manifest()
        total = total_size(manifest)
        if total <= budget:
            return
        by_age = sorted(manifest.items(),
                        key=lambda kv: kv[1].get("last_used", 0))
        for key, entry in by_age:
            if total <= budget:
                break
            shutil.rmtree(entry_dir(key), ignore_errors=True)
            total -= int(entry.get("size", 0))
            manifest.pop(key, None)
            _log(f"evicted {entry.get('source')}")
        _write_manifest(manifest)
    except Exception:
        pass


def clear_cache():
    try:
        root = datahome.folder_cache_dir() / "files"
        shutil.rmtree(root, ignore_errors=True)
        _write_manifest({})
        return True
    except Exception:
        return False


def _under_roots(path, roots):
    try:
        p = os.path.normpath(str(path)).lower()
        for root in roots:
            r = os.path.normpath(str(root)).lower()
            if p == r or p.startswith(r + os.sep):
                return True
    except Exception:
        pass
    return False


def working_set_folders(db_path):
    """Candidate folders, best first: folders of open tasks
    (newest task first), then folders under the configured
    roots by newest edit. De-duplicated, existing dirs only."""
    cfg = datahome.read_cache_config()
    roots = cfg.get("roots") or []
    out, seen = [], set()

    def _add(p):
        try:
            key = os.path.normpath(str(p)).lower()
            if key not in seen and Path(p).is_dir():
                seen.add(key)
                out.append(str(p))
        except Exception:
            pass

    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            rows = conn.execute(
                "SELECT folder_path FROM tasks "
                "WHERE status != 'completed' "
                "AND TRIM(COALESCE(folder_path, '')) != '' "
                "ORDER BY id DESC").fetchall()
            for (fp,) in rows:
                _add(fp)
        finally:
            conn.close()
    except Exception:
        pass
    root_folders = []
    for root in roots:
        try:
            base = Path(root)
            if not base.is_dir():
                continue
            for child in base.iterdir():
                if child.is_dir():
                    try:
                        root_folders.append(
                            (child.stat().st_mtime, str(child)))
                    except Exception:
                        pass
        except Exception:
            pass
    for _mtime, p in sorted(root_folders, reverse=True):
        _add(p)
    return out


def fill_working_set(db_path):
    """Fill/refresh the cache toward the budget with the
    working set. Skips entries already fresh (same newest
    mtime). Runs on a background thread by the caller."""
    try:
        cfg = datahome.read_cache_config()
        if not cfg.get("enabled", True):
            return
        budget = float(cfg.get("budget_gb", 5)) * (1024 ** 3)
        manifest = read_manifest()
        for folder in working_set_folders(db_path):
            key = cache_key(folder)
            entry = manifest.get(key)
            try:
                newest = max(
                    (f.stat().st_mtime for f in Path(folder).rglob("*")
                     if f.is_file()), default=0)
            except Exception:
                newest = 0
            if entry and entry.get("filled_at", 0) >= newest:
                continue
            if entry is None and total_size(manifest) >= budget * 0.95:
                break
            cache_folder(folder)
            manifest = read_manifest()
        _log("working-set fill pass done")
    except Exception as exc:  # noqa: BLE001
        _log(f"fill pass failed: {exc}")


def resolve_folder(source):
    """Where to open a quote folder from: the live folder when
    it exists, else its cached copy, else None."""
    try:
        if source and Path(source).is_dir():
            return Path(source)
    except Exception:
        pass
    if source:
        return cached_copy(source)
    return None
