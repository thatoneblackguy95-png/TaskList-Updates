"""Quote-folder cache (V1.9.50): a local working set of quote
folders so they open with no network at all.

Design (the user's, 2026-11-12): he picks the quote-folder
ROOTS once in Settings (the 2025 and 2026 folders); the cache
then fills itself -- no hand-picking individual folders. It
keeps the most recently used folders (folders of open tasks
first, then newest-edited under the roots) inside an adjustable
budget (default 5 GB), evicting least-recently-used first.

Layout: ``%LOCALAPPDATA%\\TaskList\\foldercache\\files\\<key>``
mirrors one source folder's contents; ``manifest.json`` maps
key -> {source, size, files, last_used, filled_at}. Per-machine
state (datahome), never in the database. Stdlib only; every
public function is guarded and never raises.
"""

import hashlib
import json
import os
import shutil
import socket
import sqlite3
import time
from pathlib import Path

from . import datahome

_SKIP_SUFFIXES = (".tmp", ".bak", "~")


# ------------------------------------------------------------------
# V1.9.71 (workstream L): the cache is under the same
# no-overwrite discipline as the database. Per FILE, newest
# wins decided by CONTENT HASH against a recorded base
# snapshot (the manifest entry's ``hashes``/``stats``), never
# by timestamps alone: a cached edit uploads on reconnect, a
# network edit downloads, a file changed on BOTH sides is
# never silently overwritten -- the network version stays
# canonical (the DB conflicts stance) and the cached version
# is preserved as a clearly named conflict copy in BOTH
# folders and recorded in the manifest for review.
# ------------------------------------------------------------------

def _hash_file(path):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _walk_files(root):
    """{relative posix path: Path} for real files under root,
    honouring the skip suffixes."""
    out = {}
    try:
        for r, _dirs, files in os.walk(root):
            for name in files:
                if name.endswith(_SKIP_SUFFIXES):
                    continue
                p = Path(r) / name
                try:
                    rel = p.relative_to(root).as_posix()
                except Exception:
                    continue
                out[rel] = p
    except Exception:
        pass
    return out


def _stat_sig(path):
    try:
        s = path.stat()
        return [int(s.st_size), int(s.st_mtime_ns)]
    except Exception:
        return None


def _conflict_name(rel):
    stem, dot, ext = rel.rpartition(".")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    host = (socket.gethostname() or "pc").replace(" ", "-")
    if dot and "/" not in ext and len(ext) <= 8:
        return f"{stem}.conflict-{host}-{stamp}.{ext}"
    return f"{rel}.conflict-{host}-{stamp}"


def sync_folder(source):
    """Three-way per-file sync between a source folder and
    its cache entry, against the recorded base snapshot.

    Returns a report dict {uploaded, downloaded, conflicts,
    deleted} (lists of relative paths), or None when the
    source is unusable / the cache is disabled. Never raises.
    Post-sync, the manifest's base snapshot describes the
    agreed state both sides were left in."""
    report = {"uploaded": [], "downloaded": [],
              "conflicts": [], "deleted": []}
    try:
        src = Path(source)
        if not src.is_dir():
            return None
        cfg = datahome.read_cache_config()
        if not cfg.get("enabled", True):
            return None
        key = cache_key(src)
        dst = entry_dir(key)
        manifest = read_manifest()
        entry = manifest.get(key) or {}
        base_hashes = entry.get("hashes") or {}
        base_stats = entry.get("stats") or {}
        src_files = _walk_files(src)
        dst_files = _walk_files(dst) if dst.is_dir() else {}
        conflicts = list(entry.get("conflicts") or [])
        new_hashes, new_stats = {}, {}

        def _content_hash(side_files, rel, base_rel_stats):
            """Hash a side's file, with the rsync-style quick
            screen: a file whose (size, mtime) still equals
            the base stat is treated as base content without
            re-reading it. Any stat difference forces a real
            hash -- timestamps never DECIDE, they only screen.
            """
            p = side_files[rel]
            sig = _stat_sig(p)
            bs = base_rel_stats
            if (sig is not None and bs is not None
                    and list(bs) == sig
                    and rel in base_hashes):
                return base_hashes[rel], sig
            try:
                return _hash_file(p), sig
            except Exception:
                return None, sig

        rels = set(base_hashes) | set(src_files) | set(dst_files)
        for rel in sorted(rels):
            hb = base_hashes.get(rel)
            hs = hc = None
            sig_s = sig_c = None
            if rel in src_files:
                hs, sig_s = _content_hash(
                    src_files, rel, base_stats.get(rel))
            if rel in dst_files:
                hc, sig_c = _content_hash(
                    dst_files, rel, base_stats.get(rel))
            if hs == hc:
                # Agree (including both absent and the
                # timestamp-only case: identical content is
                # never copied, never a conflict).
                if hs is not None:
                    new_hashes[rel] = hs
                    new_stats[rel] = sig_s or sig_c
                continue
            s_changed = hs != hb
            c_changed = hc != hb
            if s_changed and not c_changed:
                # Network side moved (edit, create, delete):
                # it flows DOWN into the cache.
                if hs is None:
                    try:
                        dst_files[rel].unlink()
                    except Exception:
                        pass
                    report["deleted"].append(rel)
                else:
                    t = dst / rel
                    try:
                        t.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src_files[rel], t)
                        new_hashes[rel] = hs
                        new_stats[rel] = _stat_sig(t) or sig_s
                    except Exception:
                        continue
                    report["downloaded"].append(rel)
                continue
            if c_changed and not s_changed:
                # Only the cached copy moved (an offline edit,
                # create, or delete): it flows UP.
                if hc is None:
                    try:
                        src_files[rel].unlink()
                    except Exception:
                        pass
                    report["deleted"].append(rel)
                else:
                    t = src / rel
                    try:
                        t.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(dst_files[rel], t)
                        new_hashes[rel] = hc
                        new_stats[rel] = _stat_sig(t) or sig_c
                    except Exception:
                        continue
                    report["uploaded"].append(rel)
                continue
            # Both sides moved, differently (or delete-vs-edit).
            if hs is not None and hc is not None:
                # Preserve the cached version as a named
                # conflict copy in BOTH folders; the network
                # version stays canonical in both (mirrors the
                # DB rule: network in place, the other kept for
                # review). Neither version is lost.
                cname = _conflict_name(rel)
                try:
                    for root in (src, dst):
                        cp = root / cname
                        cp.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(dst_files[rel], cp)
                    t = dst / rel
                    t.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_files[rel], t)
                    new_hashes[rel] = hs
                    new_stats[rel] = _stat_sig(t) or sig_s
                    conflicts.append({"file": rel, "copy": cname,
                                      "at": time.time()})
                    report["conflicts"].append(rel)
                    _log(f"folder conflict kept both versions: "
                         f"{rel} (cached copy saved as {cname})")
                except Exception:
                    continue
            elif hs is None and hc is not None:
                # Deleted on the network side, edited in the
                # cache: the edit survives (restored to the
                # source), the collision is recorded -- never
                # a silent win for the deletion.
                try:
                    t = src / rel
                    t.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dst_files[rel], t)
                    new_hashes[rel] = hc
                    new_stats[rel] = _stat_sig(t) or sig_c
                    conflicts.append({"file": rel,
                                      "copy": None,
                                      "at": time.time(),
                                      "kind": "delete-vs-edit"})
                    report["conflicts"].append(rel)
                    _log(f"folder delete-vs-edit kept the edit: {rel}")
                except Exception:
                    continue
            elif hc is None and hs is not None:
                # Deleted in the cache, edited on the network
                # side: the network edit survives (restored to
                # the cache), collision recorded.
                try:
                    t = dst / rel
                    t.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_files[rel], t)
                    new_hashes[rel] = hs
                    new_stats[rel] = _stat_sig(t) or sig_s
                    conflicts.append({"file": rel,
                                      "copy": None,
                                      "at": time.time(),
                                      "kind": "delete-vs-edit"})
                    report["conflicts"].append(rel)
                    _log(f"folder delete-vs-edit kept the edit: {rel}")
                except Exception:
                    continue
        manifest[key] = {
            "source": str(src),
            "size": _dir_size(dst) if dst.is_dir() else 0,
            "files": len(new_hashes),
            "last_used": time.time(),
            "filled_at": time.time(),
            "hashes": new_hashes,
            "stats": new_stats,
            "conflicts": conflicts[-50:],
        }
        _write_manifest(manifest)
        evict_to_budget()
        return report
    except Exception as exc:  # noqa: BLE001
        _log(f"sync_folder failed for {source}: {exc}")
        return None


def _log(message):
    try:
        from .startup_log import log_startup_event
        log_startup_event("foldercache: " + message)
    except Exception:
        pass


def cache_key(source):
    norm = os.path.normpath(str(source)).lower()
    return hashlib.sha1(norm.encode("utf-8", "replace")).hexdigest()


def _manifest_path():
    return datahome.folder_cache_dir() / "manifest.json"


def read_manifest():
    try:
        data = json.loads(_manifest_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_manifest(manifest):
    # Atomic (tmp + replace): a crash mid-write used to leave
    # a corrupt manifest that read back as "cache empty" while
    # entry dirs sat orphaned on disk (matrix X-F4).
    try:
        path = _manifest_path()
        tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(manifest, indent=1))
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
    except Exception:
        pass


def entry_dir(key):
    return datahome.folder_cache_dir() / "files" / key


def total_size(manifest=None):
    if manifest is None:
        manifest = read_manifest()
    return sum(int(e.get("size", 0)) for e in manifest.values())


def _dir_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except Exception:
                pass
    return total


def cached_copy(source):
    """The local copy of a source folder, or None. Touches the
    entry's last_used on a hit."""
    try:
        key = cache_key(source)
        manifest = read_manifest()
        entry = manifest.get(key)
        if not entry:
            return None
        d = entry_dir(key)
        if not d.is_dir():
            return None
        entry["last_used"] = time.time()
        _write_manifest(manifest)
        return d
    except Exception:
        return None


def cache_folder(source):
    """Copy one folder into the cache (refresh in place).
    Returns the entry dir or None.

    V1.9.71 (workstream L): when a base snapshot exists this
    is no longer a wholesale replace -- the old code rebuilt
    the entry from the source unconditionally, silently
    destroying any edit made in the cached copy while
    offline. Refresh now goes through the three-way
    sync_folder; only a first fill (no base yet) is a pure
    download, and it records the base snapshot."""
    try:
        src = Path(source)
        if not src.is_dir():
            return None
        cfg = datahome.read_cache_config()
        if not cfg.get("enabled", True):
            return None
        key = cache_key(src)
        existing = read_manifest().get(key)
        if existing and existing.get("hashes") is not None:
            sync_folder(source)
            return entry_dir(key)
        dst = entry_dir(key)
        tmp = dst.with_name(dst.name + ".tmp")
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)
        n_files = 0
        for root, _dirs, files in os.walk(src):
            rel = Path(root).relative_to(src)
            for name in files:
                if name.endswith(_SKIP_SUFFIXES):
                    continue
                s = Path(root) / name
                t = tmp / rel / name
                try:
                    t.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(s, t)
                    n_files += 1
                except Exception:
                    pass
        if dst.exists():
            shutil.rmtree(dst, ignore_errors=True)
        tmp.replace(dst)
        # Record the base snapshot (content hashes + stats)
        # the three-way sync judges later edits against.
        hashes, stats = {}, {}
        for rel, p in _walk_files(dst).items():
            try:
                hashes[rel] = _hash_file(p)
                stats[rel] = _stat_sig(p)
            except Exception:
                pass
        manifest = read_manifest()
        manifest[key] = {
            "source": str(src),
            "size": _dir_size(dst),
            "files": n_files,
            "last_used": time.time(),
            "filled_at": time.time(),
            "hashes": hashes,
            "stats": stats,
            "conflicts": [],
        }
        _write_manifest(manifest)
        evict_to_budget()
        return dst
    except Exception as exc:  # noqa: BLE001
        _log(f"cache_folder failed for {source}: {exc}")
        return None


def evict_to_budget():
    """Drop least-recently-used entries until the cache fits
    the configured budget."""
    try:
        cfg = datahome.read_cache_config()
        budget = float(cfg.get("budget_gb", 5)) * (1024 ** 3)
        manifest = read_manifest()
        total = total_size(manifest)
        if total <= budget:
            return
        by_age = sorted(manifest.items(),
                        key=lambda kv: kv[1].get("last_used", 0))
        for key, entry in by_age:
            if total <= budget:
                break
            # V1.9.71 (workstream L): an entry holding edits
            # that have not synced up yet is never evicted --
            # dropping it would silently destroy offline work,
            # the exact loss this discipline exists to ban.
            if entry.get("source") and cache_has_unsynced_edits(
                    entry["source"]):
                _log(f"eviction skipped (unsynced edits): "
                     f"{entry.get('source')}")
                continue
            shutil.rmtree(entry_dir(key), ignore_errors=True)
            total -= int(entry.get("size", 0))
            manifest.pop(key, None)
            _log(f"evicted {entry.get('source')}")
        _write_manifest(manifest)
    except Exception:
        pass


def all_conflicts():
    """Every recorded file-level conflict across cached folders
    (newest last) -- the Settings sync page reports the count so
    the file-level merge story is visible in the app, not only
    in the manifest."""
    out = []
    try:
        for entry in (read_manifest() or {}).values():
            if isinstance(entry, dict):
                for rec in entry.get("conflicts") or []:
                    out.append(rec)
    except Exception:
        pass
    return out


def clear_cache():
    """V1.9.71 (L): clearing the cache must never destroy an
    unsynced edit -- entries whose cache holds changes that have
    not synced yet are KEPT (folder and manifest entry); the
    rest are removed. Returns (cleared, kept)."""
    cleared = 0
    kept = 0
    try:
        manifest = _read_manifest()
        folders = manifest.get("folders") or {}
        root = datahome.folder_cache_dir() / "files"
        for key in list(folders):
            entry = folders[key]
            src = entry.get("source")
            if src and cache_has_unsynced_edits(src):
                kept += 1
                continue
            dest = root / _cache_key(src) if src else None
            if dest is not None:
                shutil.rmtree(dest, ignore_errors=True)
            del folders[key]
            cleared += 1
        if not folders and kept == 0:
            shutil.rmtree(root, ignore_errors=True)
        _write_manifest(manifest)
    except Exception:
        pass
    return cleared, kept


def _under_roots(path, roots):
    try:
        p = os.path.normpath(str(path)).lower()
        for root in roots:
            r = os.path.normpath(str(root)).lower()
            if p == r or p.startswith(r + os.sep):
                return True
    except Exception:
        pass
    return False


def working_set_folders(db_path):
    """Candidate folders, best first: folders of open tasks
    (newest task first), then folders under the configured
    roots by newest edit. De-duplicated, existing dirs only."""
    cfg = datahome.read_cache_config()
    roots = cfg.get("roots") or []
    out, seen = [], set()

    def _add(p):
        try:
            key = os.path.normpath(str(p)).lower()
            if key not in seen and Path(p).is_dir():
                seen.add(key)
                out.append(str(p))
        except Exception:
            pass

    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            rows = conn.execute(
                "SELECT folder_path FROM tasks "
                "WHERE status != 'completed' "
                "AND TRIM(COALESCE(folder_path, '')) != '' "
                "ORDER BY id DESC").fetchall()
            for (fp,) in rows:
                _add(fp)
        finally:
            conn.close()
    except Exception:
        pass
    root_folders = []
    for root in roots:
        try:
            base = Path(root)
            if not base.is_dir():
                continue
            for child in base.iterdir():
                if child.is_dir():
                    try:
                        root_folders.append(
                            (child.stat().st_mtime, str(child)))
                    except Exception:
                        pass
        except Exception:
            pass
    for _mtime, p in sorted(root_folders, reverse=True):
        _add(p)
    return out


def fill_working_set(db_path):
    """Fill/refresh the cache toward the budget with the
    working set. Runs on a background thread by the caller.

    V1.9.71 (workstream L): freshness is no longer judged by
    mtime (``filled_at >= newest mtime`` skipped refreshes on
    timestamp evidence alone, and the refresh itself was a
    wholesale overwrite). Every working-set folder now goes
    through cache_folder, which three-way syncs by content
    hash when a base exists -- a clean folder costs one stat
    walk and no copies."""
    try:
        cfg = datahome.read_cache_config()
        if not cfg.get("enabled", True):
            return
        budget = float(cfg.get("budget_gb", 5)) * (1024 ** 3)
        manifest = read_manifest()
        for folder in working_set_folders(db_path):
            key = cache_key(folder)
            entry = manifest.get(key)
            if entry is None and total_size(manifest) >= budget * 0.95:
                break
            if entry is not None and not folder_needs_sync(folder):
                continue    # converged: no refresh churn (X-F3)
            cache_folder(folder)
            manifest = read_manifest()
        _log("working-set fill pass done")
    except Exception as exc:  # noqa: BLE001
        _log(f"fill pass failed: {exc}")


def folder_needs_sync(source):
    """Stat-level change screen for the fill pass: True when
    either side holds a file whose (size, mtime) differs from
    the recorded base stats, or a file the base never saw, or
    a base file has vanished from a side. Content hashes
    inside sync_folder make the final call -- this screen
    only decides whether a pass has anything to look at, so
    a converged cache costs zero sync calls (matrix X-F3)."""
    try:
        key = cache_key(source)
        entry = read_manifest().get(key)
        if not entry or entry.get("hashes") is None:
            return True
        base_stats = entry.get("stats") or {}
        for root in (Path(source), entry_dir(key)):
            try:
                files = _walk_files(root)
            except Exception:
                return True
            for rel, p in files.items():
                if rel not in base_stats:
                    return True
                if _stat_sig(p) != list(base_stats[rel]):
                    return True
            for rel in base_stats:
                if rel not in files:
                    return True
        return False
    except Exception:
        return True


def cache_has_unsynced_edits(source):
    """Cheap stat-level check: does the cached copy hold any
    file whose (size, mtime) differs from the base snapshot
    (an edit made against the cache that has not synced up
    yet), or a file the base never saw? No hashing -- this
    runs on the folder-open path and stays a local stat walk.
    """
    try:
        key = cache_key(source)
        entry = read_manifest().get(key)
        if not entry:
            return False
        base_stats = entry.get("stats") or {}
        d = entry_dir(key)
        if not d.is_dir():
            return False
        for rel, p in _walk_files(d).items():
            if rel not in base_stats:
                return True
            if _stat_sig(p) != list(base_stats[rel]):
                return True
        return False
    except Exception:
        return False


def resolve_folder(source):
    """Where to open a quote folder from.

    V1.9.71 (workstream L): the live folder is preferred when
    it exists AND the cache holds nothing newer -- the cache
    is a fallback, not a shadow master. But when the cache
    carries unsynced edits (work done against it offline), it
    is where the newest data lives, so it wins until the next
    sync carries those edits up."""
    try:
        if source and Path(source).is_dir():
            if cache_has_unsynced_edits(source):
                c = cached_copy(source)
                if c is not None:
                    return c
            return Path(source)
    except Exception:
        pass
    if source:
        return cached_copy(source)
    return None
