"""In-app updates for Task List — the Drawing Finder template
(user, 2026-11-11: "make Drawing Finder's update area kinda a
standard template... just do what you did with Drawing Finder").

How it works, same as Drawing Finder:
- Update zips publish as GitHub Releases on a PUBLIC, updates-only
  repo (the source repo stays private): ``TaskList-Updates``. The
  app reads ``releases/latest`` unauthenticated.
- A check compares the release tag with the running version; when
  newer, the zip downloads in the background and is STAGED in the
  data dir as ``pending_update.zip`` with a ``pending_update.json``
  version stamp.
- Applying needs the app closed (files in use), so a detached
  helper (``tasklist/apply_update.py``, run by the bundled python)
  waits for the app to exit, unpacks over the install folder,
  clears the stage only on success, and relaunches. Every step is
  logged to ``<data dir>/update.log``.
- The stamp is what stops the restart-offer loop: a staged zip
  that is not newer than the running version is discarded, never
  offered twice.

The pure functions here are Qt-free and unit-tested; the Qt side
(Settings section, launch flow, restart offer) lives in ui.py /
app.py and calls them.
"""
import hashlib
import json
import os
import re
import shutil
import time
import urllib.request
from pathlib import Path

UPDATE_REPO = "thatoneblackguy95-png/TaskList-Updates"
UPDATE_API = ("https://api.github.com/repos/" + UPDATE_REPO
              + "/releases/latest")
ASSET_NAME = "TaskList-Update.zip"
USER_AGENT = "TaskList"


def version_tuple(text):
    out = []
    for part in re.split(r"[^0-9]+", str(text or "")):
        if part:
            out.append(int(part))
    return tuple(out)


def current_version():
    """The running build's version: the version.txt at the install
    root (kept in lockstep with app.APP_VERSION by the release
    process; a test asserts they match)."""
    try:
        text = (Path(__file__).resolve().parent.parent
                / "version.txt").read_text(encoding="utf-8")
        return text.strip().lstrip("v")
    except OSError:
        return "0"


def pick_zip_asset(release):
    for asset in release.get("assets") or []:
        if str(asset.get("name", "")).lower().endswith(".zip"):
            return asset.get("browser_download_url")
    # Fallback (Drawing Finder's): the update zip also ships IN
    # the updates repo at the release's tag.
    tag = str(release.get("tag_name", "")).strip()
    if tag:
        return ("https://raw.githubusercontent.com/" + UPDATE_REPO
                + "/" + tag + "/" + ASSET_NAME)
    return None


def fetch_latest_release():
    req = urllib.request.Request(
        UPDATE_API, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.load(resp)
    except Exception:
        # The API rate-limits unauthenticated callers; fall back to
        # the releases/latest redirect, which is not API-limited —
        # it lands on the newest release's tag page, and the tag is
        # all the check needs (the download URL derives from it).
        req = urllib.request.Request(
            "https://github.com/" + UPDATE_REPO + "/releases/latest",
            headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as resp:
            final = resp.geturl()
        m = re.search(r"/tag/(v?[0-9][^/]*)$", final)
        if not m:
            raise
        return {"tag_name": m.group(1), "assets": []}


def stage_update(url, data_dir, tag=""):
    """Download the release zip to <data_dir>/pending_update.zip
    (through a .part file, renamed into place when complete) and
    stamp it with its version: pending_update.json."""
    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    part = data_dir / "pending_update.zip.part"
    final = data_dir / "pending_update.zip"
    req = urllib.request.Request(
        url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp, \
            open(part, "wb") as fh:
        shutil.copyfileobj(resp, fh, 1 << 16)
    os.replace(part, final)
    try:
        (data_dir / "pending_update.json").write_text(
            json.dumps({"tag": str(tag).lstrip("v")}),
            encoding="utf-8")
    except OSError:
        pass
    return str(final)


def pending_update_tag(data_dir):
    """The staged update's version, '' when unstamped."""
    try:
        data = json.loads(
            (Path(data_dir) / "pending_update.json").read_text(
                encoding="utf-8"))
        return str(data.get("tag", "")).lstrip("v")
    except Exception:
        return ""


def clear_pending_update(data_dir):
    data_dir = Path(data_dir)
    for name in ("pending_update.zip", "pending_update.json",
                 "pending_update.zip.part"):
        try:
            os.remove(data_dir / name)
        except OSError:
            pass


def pending_offer(data_dir, version):
    """Decide what a launch does with a staged update:
    ('none', '') — nothing staged; ('clear', tag) — staged but
    unstamped, or not newer than the running version: discard it
    instead of offering it forever; ('offer', tag) — genuinely
    newer, offer the restart once."""
    if not (Path(data_dir) / "pending_update.zip").is_file():
        return ("none", "")
    tag = pending_update_tag(data_dir)
    if not tag or version_tuple(tag) <= version_tuple(version):
        return ("clear", tag)
    return ("offer", tag)


def upd_log(msg, data_dir):
    """One line in <data dir>/update.log — the apply path's black
    box. Silent when even the log cannot be written."""
    try:
        with open(Path(data_dir) / "update.log", "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except OSError:
        pass


# ---- self-heal (V1.9.69): verify + repair the install -----------
# The launcher heals the local MIRROR at launch (it verifies the
# mirror against files.manifest.json and restores bad files from
# the install folder). The functions here are the in-app half: they
# verify the INSTALL folder itself -- including "Task List.exe",
# which the launcher cannot check for itself -- and repair it.
# Repair NEVER copies the running app's own files: it re-downloads
# the CURRENT official package through the exact update machinery
# (fetch_latest_release / pick_zip_asset / stage_update) and
# extracts it over the install with apply_update._extract_update,
# which by construction never extracts anything under data/ (the
# user's database) or python/ (the bundled runtime is not update
# payload). Healing therefore restores the official bytes or
# nothing -- the same trust path as an update.

MANIFEST_NAME = "files.manifest.json"


def _default_install_root():
    """The app root: the folder holding tasklist/ + version.txt
    (same resolution current_version() uses)."""
    return Path(__file__).resolve().parent.parent


def _hash_file(path):
    h = hashlib.sha256()
    size = 0
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(1 << 16)
            if not chunk:
                break
            h.update(chunk)
            size += len(chunk)
    return h.hexdigest(), size


def _file_matches(path, meta):
    try:
        if not Path(path).is_file():
            return False
        if Path(path).stat().st_size != int(meta.get("size", -1)):
            return False
        digest, _ = _hash_file(path)
        return digest == str(meta.get("sha256", ""))
    except Exception:
        return False


def _safe_rel(rel):
    """A manifest relpath is usable only if it stays inside the
    install root and never names data/ (user data is not program
    payload and is never verified or repaired)."""
    parts = [p for p in str(rel).replace("\\", "/").split("/")
             if p not in ("", ".")]
    if not parts or ".." in parts:
        return None
    if parts[0].lower() == "data":
        return None
    return parts


def verify_install(install_root=None):
    """Relative paths of install files that are missing or whose
    size/sha256 differ from files.manifest.json at the install
    root (default: the app root). Covers every manifest ``files``
    entry (tasklist/, "Task List.exe", "Task List.pyw",
    version.txt) plus the python/ runtime via its key files; a
    python/ file-count mismatch is reported as the single entry
    ``"python/"`` (individual non-key runtime files are not
    named in the manifest by design). No manifest present
    (pre-1.9.69 install) -> []: there is nothing to verify
    against, which is NOT damage. Never raises."""
    root = Path(install_root) if install_root is not None \
        else _default_install_root()
    try:
        manifest = json.loads(
            (root / MANIFEST_NAME).read_text(encoding="utf-8"))
    except Exception:
        return []
    damaged = []
    for rel, meta in (manifest.get("files") or {}).items():
        parts = _safe_rel(rel)
        if parts is None or parts[0].lower() == "python":
            continue
        if not _file_matches(root.joinpath(*parts), meta or {}):
            damaged.append("/".join(parts))
    py = manifest.get("python") or {}
    key_files = py.get("key_files") or {}
    for rel, meta in key_files.items():
        parts = _safe_rel(rel)
        if parts is None:
            continue
        if not _file_matches(root.joinpath(*parts), meta or {}):
            damaged.append("/".join(parts))
    count = py.get("count")
    if count and key_files:
        python_dir = root / "python"
        actual = 0
        if python_dir.is_dir():
            actual = sum(1 for p in python_dir.rglob("*")
                         if p.is_file())
        if actual != int(count):
            damaged.append("python/")
    return sorted(set(damaged))


def _mirror_root():
    """%LOCALAPPDATA%\\TaskListMirror when it exists, else None."""
    try:
        base = os.environ.get("LOCALAPPDATA", "").strip()
        if base:
            mirror = Path(base) / "TaskListMirror"
            if mirror.is_dir():
                return mirror
    except Exception:
        pass
    return None


def verify_install_combined(install_root=None, mirror_root=None):
    """V1.9.72: verify BOTH program trees against the manifest.

    verify_install() alone checks ONE root, resolved as the
    code root -- under the mirror layout that is the mirror,
    checked with install-shaped expectations (it reported a
    healthy mirror's host exe as damage and could never see
    the install at all), while the launch-time caller passed
    the DATA dir as the root, where no manifest exists, so the
    repair offer could never fire. This is the root-correct
    verdict both callers now use:

    * the INSTALL (launcher_root(): the folder the user
      launches from) is verified verbatim by verify_install();
    * the MIRROR (%LOCALAPPDATA%\\TaskListMirror -- the tree
      the app actually executes) is verified with the mirror's
      own layout: the manifest's "host/Task List.exe" entry is
      checked at the mirror ROOT (that is where the launcher
      plants the host), the launcher entry itself is not
      expected in the mirror, and the python anchors
      (pythonw.exe / python3.dll -- the launch-critical files
      the update manifest's empty python section leaves
      uncovered) must be present and byte-match the install's
      copies.

    Mirror damage is reported as "<rel> (local mirror)".
    Returns [] when both trees verify (or when no manifest
    exists anywhere to verify against). Never raises.
    """
    try:
        if install_root is not None:
            install = Path(install_root)
        else:
            install = None
            try:
                from . import taskbar as _tb
                install = Path(_tb.launcher_root())
            except Exception:
                install = None
            if install is None:
                install = _default_install_root()
        damaged = list(verify_install(install))
        mirror = Path(mirror_root) if mirror_root is not None \
            else _mirror_root()
        if mirror is None or not mirror.is_dir() \
                or mirror == install:
            return damaged
        # The manifest to verify the mirror against: the
        # install's, falling back to the mirror's own copy.
        manifest = None
        for base in (install, mirror):
            try:
                manifest = json.loads(
                    (base / MANIFEST_NAME).read_text(
                        encoding="utf-8"))
                break
            except Exception:
                continue
        if manifest is None:
            return damaged
        seen = set(damaged)
        for rel, meta in (manifest.get("files") or {}).items():
            parts = _safe_rel(rel)
            if parts is None or parts[0].lower() == "python":
                continue
            joined = "/".join(parts)
            if joined == "Task List.exe":
                # The launcher itself is not mirrored; the
                # mirror's root exe slot belongs to the host.
                continue
            if joined == "host/Task List.exe":
                target = mirror / "Task List.exe"
                label = "Task List.exe (local mirror)"
            else:
                target = mirror.joinpath(*parts)
                label = f"{joined} (local mirror)"
            if not _file_matches(target, meta or {}):
                if label not in seen:
                    damaged.append(label)
                    seen.add(label)
        for anchor in ("python/pythonw.exe", "python/python3.dll"):
            mpath = mirror.joinpath(*anchor.split("/"))
            ipath = install.joinpath(*anchor.split("/"))
            label = f"{anchor} (local mirror)"
            bad = not mpath.is_file()
            if not bad and ipath.is_file():
                try:
                    bad = _hash_file(mpath)[0] != _hash_file(ipath)[0]
                except Exception:
                    bad = False
            if bad and label not in seen:
                damaged.append(label)
                seen.add(label)
        return sorted(damaged)
    except Exception:
        return []


def integrity_status(data_dir=None, install_root=None):
    """("ok" | "damaged" | "unknown", damaged_list) for the
    install: "unknown" when no manifest exists to verify against
    (pre-1.9.69 install), "damaged" with the verify_install list
    when any file is missing/corrupt, else "ok". ``data_dir``
    follows the pending_offer/stage_update pattern: when given,
    a damaged verdict is recorded in update.log."""
    root = Path(install_root) if install_root is not None \
        else _default_install_root()
    if not (root / MANIFEST_NAME).is_file():
        return ("unknown", [])
    damaged = verify_install(root)
    if not damaged:
        return ("ok", [])
    if data_dir is not None:
        upd_log("integrity: damaged files: " + ", ".join(damaged),
                data_dir)
    return ("damaged", damaged)


def repair_install(data_dir, install_root=None):
    """Repair the install by STAGING the current official
    package through the normal update path (V1.9.72 rework).

    The pre-1.9.72 body extracted the package over the code
    root -- which under the mirror layout is the RUNNING
    mirror, not the install -- and then cleared the stage, so
    the detached helper (which applies over the install once
    the app has exited) found nothing to apply and the install
    kept its damage. Staging only is the contract app.py's
    _apply_repair_and_restart was already written against: the
    caller restarts, the helper extracts the staged package
    over the install with the app closed (never data/ or
    python/), and the launcher re-mirrors + heals from the
    restored install on the next launch.

    Returns the verify_install_combined() list the repair was
    staged for ([] when the install already verifies clean --
    nothing was staged). On any failure the still-damaged list
    is returned and the failure is logged; restored bytes come
    only from the official package, never from the running
    app's own files.
    """
    try:
        damaged = verify_install_combined(install_root)
        if not damaged:
            upd_log("repair: install verifies clean; "
                    "nothing staged", data_dir)
            return []
        release = fetch_latest_release()
        tag = str(release.get("tag_name", "")).lstrip("v")
        url = pick_zip_asset(release)
        if not url:
            raise RuntimeError("release has no zip asset")
        stage_update(url, data_dir, tag)
        upd_log(f"repair: staged release {tag} to restore "
                f"{len(damaged)} file(s); applies on restart",
                data_dir)
        return damaged
    except Exception as exc:
        upd_log(f"repair: failed: {exc!r}", data_dir)
        return verify_install_combined(install_root)


# ---- the startup-check preference (QSettings, like layout_mode) --
def check_updates_enabled():
    from PySide6.QtCore import QSettings
    val = QSettings("TaskListApp", "TaskList").value(
        "check_updates_on_startup", True)
    return val is True or str(val).lower() in ("true", "1", "yes")


def set_check_updates_enabled(on):
    from PySide6.QtCore import QSettings
    QSettings("TaskListApp", "TaskList").setValue(
        "check_updates_on_startup", bool(on))
