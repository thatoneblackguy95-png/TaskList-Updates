"""In-app updates for Task List — the Drawing Finder template
(user, 2026-11-11: "make Drawing Finder's update area kinda a
standard template... just do what you did with Drawing Finder").

How it works, same as Drawing Finder:
- Update zips publish as GitHub Releases on a PUBLIC, updates-only
  repo (the source repo stays private): ``TaskList-Updates``. The
  app reads ``releases/latest`` unauthenticated.
- A check compares the release tag with the running version; when
  newer, the zip downloads in the background and is STAGED in the
  data dir as ``pending_update.zip`` with a ``pending_update.json``
  version stamp.
- Applying needs the app closed (files in use), so a detached
  helper (``tasklist/apply_update.py``, run by the bundled python)
  waits for the app to exit, unpacks over the install folder,
  clears the stage only on success, and relaunches. Every step is
  logged to ``<data dir>/update.log``.
- The stamp is what stops the restart-offer loop: a staged zip
  that is not newer than the running version is discarded, never
  offered twice.

The pure functions here are Qt-free and unit-tested; the Qt side
(Settings section, launch flow, restart offer) lives in ui.py /
app.py and calls them.
"""
import json
import os
import re
import shutil
import time
import urllib.request
from pathlib import Path

UPDATE_REPO = "thatoneblackguy95-png/TaskList-Updates"
UPDATE_API = ("https://api.github.com/repos/" + UPDATE_REPO
              + "/releases/latest")
ASSET_NAME = "TaskList-Update.zip"
USER_AGENT = "TaskList"


def version_tuple(text):
    out = []
    for part in re.split(r"[^0-9]+", str(text or "")):
        if part:
            out.append(int(part))
    return tuple(out)


def current_version():
    """The running build's version: the version.txt at the install
    root (kept in lockstep with app.APP_VERSION by the release
    process; a test asserts they match)."""
    try:
        text = (Path(__file__).resolve().parent.parent
                / "version.txt").read_text(encoding="utf-8")
        return text.strip().lstrip("v")
    except OSError:
        return "0"


def pick_zip_asset(release):
    for asset in release.get("assets") or []:
        if str(asset.get("name", "")).lower().endswith(".zip"):
            return asset.get("browser_download_url")
    # Fallback (Drawing Finder's): the update zip also ships IN
    # the updates repo at the release's tag.
    tag = str(release.get("tag_name", "")).strip()
    if tag:
        return ("https://raw.githubusercontent.com/" + UPDATE_REPO
                + "/" + tag + "/" + ASSET_NAME)
    return None


def fetch_latest_release():
    req = urllib.request.Request(
        UPDATE_API, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.load(resp)
    except Exception:
        # The API rate-limits unauthenticated callers; fall back to
        # the releases/latest redirect, which is not API-limited —
        # it lands on the newest release's tag page, and the tag is
        # all the check needs (the download URL derives from it).
        req = urllib.request.Request(
            "https://github.com/" + UPDATE_REPO + "/releases/latest",
            headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as resp:
            final = resp.geturl()
        m = re.search(r"/tag/(v?[0-9][^/]*)$", final)
        if not m:
            raise
        return {"tag_name": m.group(1), "assets": []}


def stage_update(url, data_dir, tag=""):
    """Download the release zip to <data_dir>/pending_update.zip
    (through a .part file, renamed into place when complete) and
    stamp it with its version: pending_update.json."""
    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    part = data_dir / "pending_update.zip.part"
    final = data_dir / "pending_update.zip"
    req = urllib.request.Request(
        url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp, \
            open(part, "wb") as fh:
        shutil.copyfileobj(resp, fh, 1 << 16)
    os.replace(part, final)
    try:
        (data_dir / "pending_update.json").write_text(
            json.dumps({"tag": str(tag).lstrip("v")}),
            encoding="utf-8")
    except OSError:
        pass
    return str(final)


def pending_update_tag(data_dir):
    """The staged update's version, '' when unstamped."""
    try:
        data = json.loads(
            (Path(data_dir) / "pending_update.json").read_text(
                encoding="utf-8"))
        return str(data.get("tag", "")).lstrip("v")
    except Exception:
        return ""


def clear_pending_update(data_dir):
    data_dir = Path(data_dir)
    for name in ("pending_update.zip", "pending_update.json",
                 "pending_update.zip.part"):
        try:
            os.remove(data_dir / name)
        except OSError:
            pass


def pending_offer(data_dir, version):
    """Decide what a launch does with a staged update:
    ('none', '') — nothing staged; ('clear', tag) — staged but
    unstamped, or not newer than the running version: discard it
    instead of offering it forever; ('offer', tag) — genuinely
    newer, offer the restart once."""
    if not (Path(data_dir) / "pending_update.zip").is_file():
        return ("none", "")
    tag = pending_update_tag(data_dir)
    if not tag or version_tuple(tag) <= version_tuple(version):
        return ("clear", tag)
    return ("offer", tag)


def upd_log(msg, data_dir):
    """One line in <data dir>/update.log — the apply path's black
    box. Silent when even the log cannot be written."""
    try:
        with open(Path(data_dir) / "update.log", "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except OSError:
        pass


# ---- the startup-check preference (QSettings, like layout_mode) --
def check_updates_enabled():
    from PySide6.QtCore import QSettings
    val = QSettings("TaskListApp", "TaskList").value(
        "check_updates_on_startup", True)
    return val is True or str(val).lower() in ("true", "1", "yes")


def set_check_updates_enabled(on):
    from PySide6.QtCore import QSettings
    QSettings("TaskListApp", "TaskList").setValue(
        "check_updates_on_startup", bool(on))
