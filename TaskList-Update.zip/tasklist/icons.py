"""Hand-drawn SVG icons (stroke style, Lucide-inspired). No emojis anywhere.

Icons are rendered at runtime from SVG strings so they can be recolored for
the active theme. Use svg_icon() for a single color, nav_icon() for sidebar
buttons that need a distinct active color.
"""
from PySide6.QtCore import Qt, QByteArray, QSize, QRectF
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer
from functools import lru_cache

# 24x24 stroke icons. {c} is substituted with the stroke color.
_SVGS = {
    # attention / hot-task indicator: circled exclamation mark (Lucide circle-alert)
    "alert": (
        '<circle cx="12" cy="12" r="10"/>'
        '<line x1="12" x2="12" y1="8" y2="12"/>'
        '<line x1="12" x2="12.01" y1="16" y2="16"/>'
    ),
    # table: grid for note tables (Lucide)
    "table": (
        '<path d="M12 3v18"/>'
        '<rect width="18" height="18" x="3" y="3" rx="2"/>'
        '<path d="M3 9h18"/>'
        '<path d="M3 15h18"/>'
    ),
    # task list: list with bullets
    "list": (
        '<line x1="8" y1="6" x2="21" y2="6"/>'
        '<line x1="8" y1="12" x2="21" y2="12"/>'
        '<line x1="8" y1="18" x2="21" y2="18"/>'
        '<line x1="3" y1="6" x2="3.01" y2="6"/>'
        '<line x1="3" y1="12" x2="3.01" y2="12"/>'
        '<line x1="3" y1="18" x2="3.01" y2="18"/>'
    ),
    # end users / distributors: two people
    "users": (
        '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>'
        '<circle cx="9" cy="7" r="4"/>'
        '<path d="M22 21v-2a4 4 0 0 0-3-3.87"/>'
        '<path d="M16 3.13a4 4 0 0 1 0 7.75"/>'
    ),
    # queue: kanban board
    "kanban": (
        '<rect x="3" y="3" width="18" height="18" rx="2"/>'
        '<path d="M9 3v18"/>'
        '<path d="M15 3v18"/>'
    ),
    # paragraph alignment (V1.9.2 notes toolbar)
    "align-left": (
        '<path d="M3 6h18"/><path d="M3 10h12"/>'
        '<path d="M3 14h18"/><path d="M3 18h12"/>'
    ),
    "align-center": (
        '<path d="M3 6h18"/><path d="M6 10h12"/>'
        '<path d="M3 14h18"/><path d="M6 18h12"/>'
    ),
    "align-right": (
        '<path d="M3 6h18"/><path d="M9 10h12"/>'
        '<path d="M3 14h18"/><path d="M9 18h12"/>'
    ),
    # indent / outdent: text lines + direction chevron
    "indent": (
        '<path d="M11 6h10"/><path d="M11 12h10"/><path d="M11 18h10"/>'
        '<path d="m3 8 4 4-4 4"/>'
    ),
    "outdent": (
        '<path d="M11 6h10"/><path d="M11 12h10"/><path d="M11 18h10"/>'
        '<path d="m7 8-4 4 4 4"/>'
    ),
    # insert image (Lucide image)
    "image": (
        '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>'
        '<circle cx="9" cy="9" r="2"/>'
        '<path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>'
    ),
    # insert link (Lucide link)
    "link": (
        '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>'
        '<path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>'
    ),
    # find bar steppers (Lucide chevrons)
    "chevron-up": '<path d="m18 15-6-6-6 6"/>',
    "chevron-down": '<path d="m6 9 6 6 6-6"/>',
    # add
    "plus": '<path d="M5 12h14"/><path d="M12 5v14"/>',
    # close / remove
    "x": '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    # confirm / save -- same stroke family as "x"
    "check": '<path d="M20 6 9 17l-5-5"/>',
    # window chrome: minimize / maximize / restore — same stroke as "x" so
    # the title-bar buttons render uniformly (no more odd glyphs)
    "minus": '<path d="M5 12h14"/>',
    "square": '<rect x="4.5" y="4.5" width="15" height="15" rx="2"/>',
    "restore": (
        '<rect x="9" y="9" width="12" height="12" rx="2"/>'
        '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'
    ),
    # rename
    "pencil": (
        '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>'
        '<path d="m15 5 4 4"/>'
    ),
    # drag handle: six filled dots
    "grip": (
        '<g fill="{c}" stroke="none">'
        '<circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/>'
        '<circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/>'
        '<circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/>'
        "</g>"
    ),
    # inbox: pull tasks in
    "inbox": (
        '<path d="M22 12h-6l-2 3h-4l-2-3H2"/>'
        '<path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>'
    ),
    # folder: open quote folder
    "folder": (
        '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>'
    ),
    # sun: switch to light mode
    "sun": (
        '<circle cx="12" cy="12" r="4"/>'
        '<path d="M12 2v2"/>'
        '<path d="M12 20v2"/>'
        '<path d="m4.93 4.93 1.41 1.41"/>'
        '<path d="m17.66 17.66 1.41 1.41"/>'
        '<path d="M2 12h2"/>'
        '<path d="M20 12h2"/>'
        '<path d="m6.34 17.66-1.41 1.41"/>'
        '<path d="m19.07 4.93-1.41 1.41"/>'
    ),
    # moon: switch to dark mode
    "moon": '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    # chart: dashboard sidebar icon (bar chart)
    "chart": (
        '<path d="M3 3v18h18"/>'
        '<path d="M7 15v3"/><path d="M12 10v8"/><path d="M17 5v13"/>'
    ),
    # notebook: notes sidebar icon
    "notebook": (
        '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>'
    ),
    # pin: pinned notes
    "pin": (
        '<path d="M12 17v5"/>'
        '<path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12'
        'a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V5h1a2 2 0 0 0 0-4H8'
        'a2 2 0 0 0 0 4h1v5.76Z"/>'
    ),
    # search: notes search field
    "search": (
        '<circle cx="11" cy="11" r="8"/>'
        '<path d="m21 21-4.3-4.3"/>'
    ),
    # download: export notes
    "download": (
        '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>'
        '<polyline points="7 10 12 15 17 10"/>'
        '<line x1="12" x2="12" y1="15" y2="3"/>'
    ),
    # list-ordered: numbered list in the notes editor
    "list-ordered": (
        '<line x1="10" x2="21" y1="6" y2="6"/>'
        '<line x1="10" x2="21" y1="12" y2="12"/>'
        '<line x1="10" x2="21" y1="18" y2="18"/>'
        '<path d="M4 6h1v4"/>'
        '<path d="M4 10h2"/>'
        '<path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>'
    ),
    # trash can: per-row attachment delete
    "trash": (
        '<path d="M3 6h18"/>'
        '<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>'
        '<path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'
        '<line x1="10" y1="11" x2="10" y2="17"/>'
        '<line x1="14" y1="11" x2="14" y2="17"/>'
    ),
}


@lru_cache(maxsize=256)
def _render(name, color, size):
    """Render one SVG to a pixmap, cached by (name, color, size).

    V1.9.8: this used to re-rasterize on every call — with ~2600 task cards
    each requesting 4-5 icons, startup was doing ~13,000 SVG renders
    (~10s). The pixmap is immutable after render, so sharing it is safe.
    """
    body = _SVGS[name].format(c=color)
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
        f'stroke="{color}" stroke-width="2" stroke-linecap="round" '
        f'stroke-linejoin="round">{body}</svg>'
    )
    renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
    pix = QPixmap(size * 2, size * 2)
    pix.setDevicePixelRatio(2)
    pix.fill(Qt.transparent)
    painter = QPainter(pix)
    # Explicit logical bounds: without them, render() mis-scales the viewBox
    # on HiDPI pixmaps and icons come out zoomed/cropped.
    renderer.render(painter, QRectF(0, 0, size, size))
    painter.end()
    return pix


def svg_icon(name, color="#9ba1ab", size=16):
    """A QIcon for a single-color SVG icon."""
    icon = QIcon()
    icon.addPixmap(_render(name, color, size), QIcon.Normal, QIcon.Off)
    return icon


def nav_icon(name, normal_color, active_color, size=20):
    """Sidebar icon: gray at rest, white when its tab is active.

    V1.9.16 (user spec): the active sidebar icon is white, not
    accent-tinted and not blue — the caller passes the active color.
    """
    icon = QIcon()
    icon.addPixmap(_render(name, normal_color, size), QIcon.Normal, QIcon.Off)
    icon.addPixmap(_render(name, active_color, size), QIcon.Normal, QIcon.On)
    return icon


def icon_size(size):
    return QSize(size, size)
