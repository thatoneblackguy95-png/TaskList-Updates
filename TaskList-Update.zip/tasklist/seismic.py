"""Seismic Design Category (SDC) estimates from the user's Seismic_Map.pdf.

The map is COARSE — every result this module produces is an estimate, and
the UI must always label it as such ("Est. SDC D", tooltip "Estimated from
seismic map — confirm with engineering"). Never present it as authoritative.

Estimate table (from the map; A=white "seismic won't govern", B=light blue
"rarely affects rack design", C=green, D=yellow/orange/red, E=dark red):

State defaults:
  A: ND SD NE KS MN IA WI MI TX
  B: ME NH MA CT RI NY NJ PA DE MD DC VA NC GA FL SC OH IN IL MO KY AR LA MS
     AL OK NM AZ CO NV ID OR WA
  C: TN
  D: CA AK HI

City overrides (city -> SDC, within the listed state):
  CA: Los Angeles, San Francisco, Oakland, San Jose, Long Beach, Anaheim,
      San Diego -> E
  OR: Portland, Salem, Eugene, Corvallis, Beaverton, Hillsboro, Gresham,
      Newport, Coos Bay, Astoria -> D; Bend, Medford -> C
  WA: Seattle, Tacoma, Bellevue, Everett, Olympia, Vancouver -> D
  NV: Reno, Sparks, Carson City -> D (map shows yellow here)
  UT: Salt Lake City, Ogden, Provo, Orem, West Valley City -> D
  ID: Idaho Falls, Pocatello, Rexburg -> C
  MT: Missoula, Bozeman, Butte, Helena -> C
  WY: Jackson -> C
  TN: Memphis, Millington, Bartlett, Germantown, Collierville (Memphis
      metro) + Nashville, Lebanon, Murfreesboro, Franklin, Brentwood,
      Hendersonville, Gallatin, Smyrna, Columbia, Spring Hill (Nashville
      metro) + Jackson -> D. Lebanon = D per user correction 2026-09-25
      (user relies on this flag); Knoxville/Chattanooga/Clarksville stay C.
  MO: New Madrid -> E (dark-red bullseye core on the map); Sikeston, Cape
      Girardeau, Poplar Bluff, Kennett, Caruthersville -> D
  AR: West Memphis, Blytheville -> D; Jonesboro -> C
  KY: Paducah -> C
  MS: Tupelo, Oxford, Southaven -> C
  AL: Huntsville -> C
  OK: Oklahoma City -> C (green dot on the map)
  SC: Charleston, North Charleston, Mount Pleasant, Summerville -> D
  VT: Burlington -> C; NY: Plattsburgh, Massena -> C
  AK: Anchorage -> E (NOT shown on source map - conservative estimate)

No schema change for the estimate itself: SDC is computed on the fly from
location text. A per-task manual override (seismic_override column, NULL =
Auto) is resolved by resolve_sdc() and wins over the estimate everywhere.
"""

import re

# ------------------------------------------------------------------ tables

#: State abbreviation -> default SDC estimate.
STATE_DEFAULT = {
    # A: seismic won't govern
    "ND": "A", "SD": "A", "NE": "A", "KS": "A", "MN": "A", "IA": "A",
    "WI": "A", "MI": "A", "TX": "A",
    # B: rarely affects rack design
    "ME": "B", "NH": "B", "MA": "B", "CT": "B", "RI": "B", "NY": "B",
    "NJ": "B", "PA": "B", "DE": "B", "MD": "B", "DC": "B", "VA": "B",
    "NC": "B", "GA": "B", "FL": "B", "SC": "B", "OH": "B", "IN": "B",
    "IL": "B", "MO": "B", "KY": "B", "AR": "B", "LA": "B", "MS": "B",
    "AL": "B", "OK": "B", "NM": "B", "AZ": "B", "CO": "B", "NV": "B",
    "ID": "B", "OR": "B", "WA": "B",
    # C
    "TN": "C",
    # D
    "CA": "D",
    # AK/HI are NOT shown on the source map - conservative estimates.
    "AK": "D", "HI": "D",
    # States not on the map's table keep no default -> unknown.
    # (UT, MT, WY, VT have only city overrides below.)
}

#: (state abbr, city lower) -> SDC estimate override.
_CITY_OVERRIDES = {}


def _add_overrides(state, sdc, cities):
    for city in cities:
        _CITY_OVERRIDES[(state, city.strip().lower())] = sdc


_add_overrides("CA", "E", ["Los Angeles", "San Francisco", "Oakland",
                           "San Jose", "Long Beach", "Anaheim", "San Diego"])
_add_overrides("OR", "D", ["Portland", "Salem", "Eugene", "Corvallis",
                           "Beaverton", "Hillsboro", "Gresham", "Newport",
                           "Coos Bay", "Astoria"])
_add_overrides("OR", "C", ["Bend", "Medford"])
_add_overrides("WA", "D", ["Seattle", "Tacoma", "Bellevue", "Everett",
                           "Olympia", "Vancouver"])
_add_overrides("NV", "D", ["Reno", "Sparks", "Carson City"])
_add_overrides("UT", "D", ["Salt Lake City", "Ogden", "Provo", "Orem",
                           "West Valley City"])
_add_overrides("ID", "C", ["Idaho Falls", "Pocatello", "Rexburg"])
_add_overrides("MT", "C", ["Missoula", "Bozeman", "Butte", "Helena"])
_add_overrides("WY", "C", ["Jackson"])
_add_overrides("TN", "D", ["Memphis", "Millington", "Bartlett",
                           "Germantown", "Collierville",
                           # Nashville metro (Lebanon = D per user
                           # correction 2026-09-25 - relied-upon flag).
                           "Nashville", "Lebanon", "Murfreesboro",
                           "Franklin", "Brentwood", "Hendersonville",
                           "Gallatin", "Smyrna", "Columbia", "Spring Hill",
                           "Jackson"])
_add_overrides("MO", "E", ["New Madrid"])
_add_overrides("MO", "D", ["Sikeston", "Cape Girardeau",
                           "Poplar Bluff", "Kennett", "Caruthersville"])
_add_overrides("AR", "D", ["West Memphis", "Blytheville"])
_add_overrides("AR", "C", ["Jonesboro"])
_add_overrides("KY", "C", ["Paducah"])
_add_overrides("MS", "C", ["Tupelo", "Oxford", "Southaven"])
_add_overrides("AL", "C", ["Huntsville"])
_add_overrides("OK", "C", ["Oklahoma City"])
_add_overrides("SC", "D", ["Charleston", "North Charleston",
                           "Mount Pleasant", "Summerville"])
_add_overrides("VT", "C", ["Burlington"])
_add_overrides("NY", "C", ["Plattsburgh", "Massena"])
# Anchorage: NOT shown on the source map - conservative estimate.
_add_overrides("AK", "E", ["Anchorage"])

#: Full state name (lower) -> abbreviation, for "Austin, Texas" style input.
_STATE_NAMES = {
    "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR",
    "california": "CA", "colorado": "CO", "connecticut": "CT",
    "delaware": "DE", "district of columbia": "DC", "florida": "FL",
    "georgia": "GA", "hawaii": "HI", "idaho": "ID", "illinois": "IL",
    "indiana": "IN", "iowa": "IA", "kansas": "KS", "kentucky": "KY",
    "louisiana": "LA", "maine": "ME", "maryland": "MD",
    "massachusetts": "MA", "michigan": "MI", "minnesota": "MN",
    "mississippi": "MS", "missouri": "MO", "montana": "MT",
    "nebraska": "NE", "nevada": "NV", "new hampshire": "NH",
    "new jersey": "NJ", "new mexico": "NM", "new york": "NY",
    "north carolina": "NC", "north dakota": "ND", "ohio": "OH",
    "oklahoma": "OK", "oregon": "OR", "pennsylvania": "PA",
    "rhode island": "RI", "south carolina": "SC", "south dakota": "SD",
    "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT",
    "virginia": "VA", "washington": "WA", "west virginia": "WV",
    "wisconsin": "WI", "wyoming": "WY",
}

# ------------------------------------------------------------------ parsing

# "City, ST" with a 2-letter abbreviation or a full state name.
_LOCATION_RE = re.compile(
    r"^\s*(?P<city>[A-Za-z][A-Za-z .'\-]*?)\s*,\s*"
    r"(?P<state>[A-Za-z][A-Za-z .]*?)\s*$"
)


def parse_location(text):
    """Parse "Company - City, ST" into (city, state_abbr).

    Splits on the LAST " - " (company names may contain dashes), then
    matches "City, ST" where ST is a 2-letter abbreviation or a full
    state name. Returns (city, STATE) or (None, None) when unparseable
    (including bare company names like "Acme Corp").
    """
    if not text or not isinstance(text, str):
        return (None, None)
    # Company prefix: split on the last " - ".
    loc_part = text.rsplit(" - ", 1)[-1].strip()
    m = _LOCATION_RE.match(loc_part)
    if not m:
        return (None, None)
    city = m.group("city").strip()
    state_raw = m.group("state").strip()
    if not city:
        return (None, None)
    if len(state_raw) == 2 and state_raw.isalpha():
        state = state_raw.upper()
    else:
        state = _STATE_NAMES.get(state_raw.lower())
        if not state:
            return (None, None)
    return (city, state)


def lookup_sdc(city, state):
    """SDC estimate letter for a city/state, or None when unknown.

    City override within the state wins; otherwise the state default.
    """
    if not city or not state:
        return None
    state = state.upper()
    hit = _CITY_OVERRIDES.get((state, city.strip().lower()))
    if hit:
        return hit
    return STATE_DEFAULT.get(state)


def estimate_for_text(text):
    """Convenience: parse free text then look up. Returns letter or None."""
    city, state = parse_location(text)
    if not city:
        return None
    return lookup_sdc(city, state)


def resolve_sdc(override, city=None, state=None, text=None):
    """(letter, is_override) for a task.

    Resolution order (v1.4.0 item 15a): the per-task manual override wins
    (``seismic_override`` column, NULL = Auto); otherwise the linked CRM
    contact's city/state; otherwise the parsed free-text location.
    Returns (None, False) when nothing resolves - the UI shows no badge.
    Never raises on junk input.
    """
    try:
        ov = (override or "").strip().upper()
    except Exception:
        ov = ""
    if ov in ("A", "B", "C", "D", "E"):
        return (ov, True)
    try:
        if city and state:
            letter = lookup_sdc(city, state)
            if letter:
                return (letter, False)
        if text:
            letter = estimate_for_text(text)
            if letter:
                return (letter, False)
    except Exception:
        pass
    return (None, False)


# ------------------------------------------------------------------ UI helpers

#: Badge styling per SDC: (objectName suffix, tooltip).
_SDC_BADGE_TIP = "Estimated from seismic map \u2014 confirm with engineering"


def sdc_badge_text(letter, is_override=False):
    """Badge text: 'SDC D' for a manual override, 'Est. SDC D' otherwise.

    The estimate label keeps the map's coarseness honest; a manual
    override is the user's own determination, so it drops the 'Est.'.
    """
    return f"SDC {letter}" if is_override else f"Est. SDC {letter}"


def sdc_tooltip(is_override=False):
    """Tooltip matching the badge text's honesty level."""
    if is_override:
        return "Set manually for this task"
    return _SDC_BADGE_TIP


def sdc_severity(letter):
    """'low' (A), 'watch' (B/C), 'high' (D/E) — drives badge coloring."""
    if letter in ("D", "E"):
        return "high"
    if letter in ("B", "C"):
        return "watch"
    return "low"
