"""Offline seed + journaled merge (V1.9.50).

The live database can live on a network share (the user's data
was trapped in a redirected Documents folder whose offline-files
cache poisoned its WAL sidecars -- the 2026-11-13 "disk I/O
error" lockout). The seed is a LOCAL copy of the whole database
plus attachments, kept in ``%LOCALAPPDATA%\\TaskList\\seed``:

- While the live database opens, the seed is refreshed from it
  (launch + close), and a per-row hash BASE of that refresh is
  recorded in the seed metadata.
- When the live database cannot be opened at all (IO-class
  failure) and a seed exists, the app opens the SEED instead and
  the session is marked offline-dirty in the metadata.
- On the next successful live open, the merge replays the
  offline session against the live database using the base:
  rows only the seed changed are applied; rows only live
  changed are kept; rows BOTH changed become conflicts --
  the live row is kept, the offline row is stored for review
  in Settings -> Offline, and nothing is silently overwritten.

Stdlib only (sqlite3), no Qt. Every public function is guarded:
offline machinery must never take the app down with it.
"""

import hashlib
import json
import os
import shutil
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from . import datahome

# Parents first: a child row's foreign key may need the remap
# a parent insert produced.
MERGE_TABLES = ("notebooks", "tasks", "directory", "attachments",
                "notes", "queue", "task_revisions")
# child table -> {fk column: parent table}
FK_REMAP = {
    "attachments": {"task_id": "tasks"},
    "notes": {"notebook_id": "notebooks"},
    "queue": {"task_id": "tasks"},
    "task_revisions": {"task_id": "tasks"},
    "tasks": {"parent_task_id": "tasks"},
}
CONFLICTS_SETTING = "offline_conflicts_v1"


def _log(message):
    try:
        from .startup_log import log_startup_event
        log_startup_event("offline: " + message)
    except Exception:
        pass


def _columns(conn, table):
    try:
        return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
    except Exception:
        return []


def _row_hash(values):
    h = hashlib.sha1()
    h.update(repr(tuple(values)).encode("utf-8", "replace"))
    return h.hexdigest()


def snapshot_hashes(db_path):
    """{table: {pk-as-str: row hash}} for every merge table.

    Read-only and tolerant: a missing table or unreadable file
    yields whatever could be read ({} at worst)."""
    out = {}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except Exception:
        return out
    try:
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        for table in MERGE_TABLES:
            if table not in tables:
                continue
            cols = _columns(conn, table)
            if "id" not in cols:
                continue
            rows = {}
            for row in conn.execute(f"SELECT * FROM {table}"):
                d = dict(zip(cols, row))
                rows[str(d["id"])] = _row_hash(row)
            out[table] = rows
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return out


def _read_rows(db_path, table):
    """{pk-as-str: {column: value}} for one table (read-only)."""
    out = {}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            cols = _columns(conn, table)
            if "id" not in cols:
                return out
            for row in conn.execute(f"SELECT * FROM {table}"):
                d = dict(zip(cols, row))
                out[str(d["id"])] = d
        finally:
            conn.close()
    except Exception:
        pass
    return out


def _attachment_should_copy(src, dst):
    """Keep-newer copy rule for attachment files (V1.9.69).

    Attachment files are immutable in practice (uniquified
    stored names), so the conservative rule in BOTH mirror
    directions is: copy only when the target is missing, or the
    source is strictly newer by mtime (size mismatch at equal
    mtime counts as changed, as a sanity tiebreak). A newer
    target is NEVER overwritten."""
    try:
        if not dst.exists():
            return True
        s = src.stat()
        d = dst.stat()
        if s.st_mtime_ns > d.st_mtime_ns:
            return True
        if s.st_mtime_ns == d.st_mtime_ns and s.st_size != d.st_size:
            return True
    except Exception:
        pass
    return False


def _mirror_attachments_between(src_root, dst_root):
    """Recursively mirror attachment files src -> dst,
    preserving the relative <task_id>/<stored> layout (files
    live in per-task subfolders; a flat iterdir copies NOTHING
    -- the V1.9.68 bug this replaces). Per-file keep-newer rule
    (see _attachment_should_copy). NO deletions are propagated:
    orphan files are harmless, and row deletions already travel
    through the database merge. Plain file copies only; never
    raises."""
    try:
        src_root = Path(src_root)
        dst_root = Path(dst_root)
        if not src_root.is_dir():
            return
        for f in src_root.rglob("*"):
            try:
                if not f.is_file():
                    continue
                target = dst_root / f.relative_to(src_root)
                if _attachment_should_copy(f, target):
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, target)
            except Exception:
                pass
    except Exception:
        pass


def refresh_seed(primary_db):
    """Copy the live database + attachments into the local seed
    and record the per-row hash base. Returns True on success."""
    try:
        seed_db = datahome.seed_db_path()
        tmp = seed_db.with_suffix(".tmp.db")
        dst = sqlite3.connect(str(tmp))
        try:
            primary_db.conn.backup(dst)
        finally:
            dst.close()
        tmp.replace(seed_db)
        # Mirror attachments RECURSIVELY (files live in
        # <task_id>/<stored> subfolders), keep-newer per file,
        # no deletion propagation (V1.9.69; see
        # _mirror_attachments_between).
        _mirror_attachments_between(
            primary_db.path.parent / "attachments",
            datahome.seed_attachments_dir())
        meta = datahome.read_seed_meta()
        meta.update({
            "refreshed_at": datetime.now().isoformat(timespec="seconds"),
            "base": snapshot_hashes(seed_db),
            "offline_dirty": False,
        })
        datahome.write_seed_meta(meta)
        _log("seed refreshed")
        return True
    except Exception as exc:  # noqa: BLE001
        _log(f"seed refresh failed: {exc}")
        return False


def mark_offline_dirty():
    try:
        meta = datahome.read_seed_meta()
        meta["offline_dirty"] = True
        datahome.write_seed_meta(meta)
        _log("session marked offline-dirty")
    except Exception:
        pass


def seed_is_dirty():
    try:
        return bool(datahome.read_seed_meta().get("offline_dirty"))
    except Exception:
        return False


def load_conflicts(primary_db):
    try:
        raw = primary_db.get_setting(CONFLICTS_SETTING, "")
        data = json.loads(raw) if raw else []
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _store_conflicts(primary_db, conflicts):
    try:
        primary_db.set_setting(CONFLICTS_SETTING,
                               json.dumps(conflicts))
    except Exception:
        pass


def _upsert_row(conn, table, cols, row):
    names = [c for c in cols if c in row]
    sql = (f"INSERT OR REPLACE INTO {table} "
           f"({', '.join(names)}) VALUES "
           f"({', '.join('?' for _ in names)})")
    conn.execute(sql, [row[c] for c in names])


def _copy_attachment_file(stored, task_id=None):
    """Locate one attachment file on the seed side
    (merge/resolution). Files live at
    seed_attachments/<task_id>/<stored>; the flat
    <stored> lookup is kept only as a legacy fallback."""
    try:
        root = datahome.seed_attachments_dir()
        if task_id is not None:
            cand = root / str(task_id) / stored
            if cand.is_file():
                return cand
        cand = root / stored
        if cand.is_file():
            return cand
    except Exception:
        pass
    return None


def _merge_file_into(primary_db, source_path, base,
                     source_wins=False):
    """Core three-way merge: fold the changes in the SOURCE
    database file (relative to the BASE per-row hashes) into
    the OPEN primary database. Rows only the source changed
    are applied; rows only the primary changed are kept; rows
    BOTH changed become conflicts -- the primary row is kept,
    the source row is stored on the primary for review in
    Settings -> Offline. Returns {"applied": n, "conflicts": m}.
    The source is only ever READ, through read-only connections
    and row snapshots; the primary is written through its own
    connection.

    source_wins (the pull direction: source = network copy,
    primary = this PC's working copy) flips conflict
    resolution: the source version is the one in place, and
    the primary's version becomes the stored alternative --
    see the conflict branch.

    DELETION SEMANTICS (V1.9.69 audit -- every case verified
    against the loop below; sv/bv/pv are the source/base/
    primary hashes for a row, None = row absent):
    * In base, gone on the SOURCE, unchanged on the primary
      (bv set, sv None, pv == bv): intentional deletion --
      the pv == bv branch DELETEs it from the primary, so
      the deletion propagates.
    * In base, gone on the PRIMARY, unchanged on the source
      (bv set, pv None, sv == bv): the sv == bv check skips
      it -- the primary's deletion stands in the merged
      result, and reaches the other side through the
      whole-file push. It is never re-added: after the merge
      the caller records as the new base the state actually
      merged (pulled hashes on a pull, pushed hashes on a
      push), and the generation gate + raced-push refusal
      stop a stale copy from reintroducing the row later.
    * In base, deleted on one side and EDITED on the other
      (sv/pv one None, the other != bv): falls through to
      the conflict branch -- stored in offline_conflicts_v1
      for review, in-place state kept, NEVER silently
      resolved for either side.
    * Absent from the base entirely (bv None): NOT a
      deletion -- the row simply never arrived here. A
      source-only row is imported (pv == bv branch); a
      primary-only row is kept (sv == bv skip).
    * Gone on BOTH sides (sv == pv == None): the sv == pv
      check skips it; it stays deleted and drops out of the
      new base, so repeated sync cycles cannot resurrect it.
    """
    result = {"applied": 0, "conflicts": 0}
    base = base or {}
    seed_db = Path(source_path)
    seed_hashes = snapshot_hashes(seed_db)
    live_hashes = snapshot_hashes(primary_db.path)
    remap = {t: {} for t in MERGE_TABLES}   # table -> {old id: new id}
    conflicts = load_conflicts(primary_db)
    conn = primary_db.conn
    live_att_dir = primary_db.path.parent / "attachments"
    for table in MERGE_TABLES:
        cols = _columns(conn, table)
        if "id" not in cols:
            continue
        b = base.get(table, {})
        s_hashes = seed_hashes.get(table, {})
        p_hashes = live_hashes.get(table, {})
        # Fresh ids for collision remaps start ABOVE every id in
        # play for this table. An AUTOINCREMENT id can land on a
        # seed id this same pass still has to upsert -- the
        # upsert then silently REPLACEs the just-remapped row
        # (caught in testing: the remapped row vanished).
        _all_pks = [int(k) for k in
                    set(b) | set(s_hashes) | set(p_hashes)
                    if k.isdigit()]
        next_fresh = max(_all_pks, default=0)
        seed_rows = None          # lazy: only read when needed
        # Per-row case map (see the docstring's DELETION
        # SEMANTICS): sv == bv -> source untouched (primary's
        # own state, including its deletions, stands);
        # pv == bv -> apply the source state, including a
        # source deletion; sv == pv -> both sides agree;
        # bv None + both present -> id collision remap;
        # anything else -> conflict for review (delete-vs-edit
        # crossings land here and are never silently resolved).
        for pk in sorted(set(b) | set(s_hashes) | set(p_hashes),
                         key=lambda v: int(v) if v.isdigit() else 0):
            sv, bv, pv = s_hashes.get(pk), b.get(pk), p_hashes.get(pk)
            if sv == bv:
                continue            # offline session didn't touch it
            if seed_rows is None:
                seed_rows = _read_rows(seed_db, table)
            srow = seed_rows.get(pk)
            # Translate foreign keys through any parent remap.
            if srow is not None:
                srow = dict(srow)
                for fk, parent in FK_REMAP.get(table, {}).items():
                    if fk in srow and srow[fk] is not None:
                        new = remap[parent].get(str(srow[fk]))
                        if new is not None:
                            srow[fk] = new
            if pv == bv:
                # Live didn't change it (or never had it, and the
                # base didn't either): apply the offline state.
                if srow is None:
                    # Row is in the base, gone on the source,
                    # untouched here: an intentional deletion --
                    # propagate it, never keep the row.
                    conn.execute(f"DELETE FROM {table} WHERE id=?",
                                 (int(pk),))
                    result["applied"] += 1
                    continue
                if bv is None and pv is not None:
                    pass  # id taken by a different new live row: remap below
                else:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow, srow.get("task_id"))
                    continue
            if sv == pv:
                continue            # both made the same change
            if bv is None and pv is not None and srow is not None:
                if source_wins:
                    # Pull direction: the source keeps the id
                    # (it is the canonical network row); the
                    # primary's own row moves to a fresh id
                    # and its children in the primary follow.
                    # Both rows survive.
                    next_fresh += 1
                    conn.execute(
                        f"UPDATE {table} SET id=? WHERE id=?",
                        (next_fresh, int(pk)))
                    for _child, _fks in FK_REMAP.items():
                        for _fk, _parent in _fks.items():
                            if _parent == table and \
                                    _fk in _columns(conn, _child):
                                conn.execute(
                                    f"UPDATE {_child} SET {_fk}=? "
                                    f"WHERE {_fk}=?",
                                    (next_fresh, int(pk)))
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow, srow.get("task_id"))
                    continue
                # Both sides created a row with the same id.
                # The offline row moves to a fresh id (explicit,
                # above every id in play -- see next_fresh);
                # children pick the new id up through the remap.
                next_fresh += 1
                fresh = dict(srow)
                fresh["id"] = next_fresh
                _upsert_row(conn, table, cols, fresh)
                remap[table][pk] = next_fresh
                result["applied"] += 1
                if table == "attachments":
                    _place_attachment(primary_db, live_att_dir, srow,
                                      srow.get("task_id"))
                continue
            # Both changed the same row differently: conflict.
            # Live wins in place; the offline row is kept for
            # review in Settings -> Offline. (Read through the
            # live connection: earlier merge writes in this same
            # pass are not on disk yet.) Delete-vs-edit crossings
            # (one side deleted a base row the other side edited)
            # also land here: they are stored as conflicts and
            # NEVER silently resolved for either side.
            live_row = None
            try:
                cur = conn.execute(
                    f"SELECT * FROM {table} WHERE id=?", (int(pk),))
                got = cur.fetchone()
                if got is not None:
                    live_row = dict(zip(cols, got))
            except Exception:
                pass
            if source_wins:
                # Pull direction: the SOURCE (network) version
                # is the one in place. Both-edited: it is
                # upserted over the primary's row, and the
                # primary's version becomes the stored
                # alternative. Delete/edit crossings keep the
                # in-place state and store the other side as
                # the alternative (a stored seed of None
                # applies as a delete if the user switches --
                # see resolve_conflict).
                if srow is not None and live_row is not None:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow, srow.get("task_id"))
                    conflicts.append({
                        "table": table, "id": pk,
                        "seed": live_row, "live": srow,
                        "at": datetime.now().isoformat(
                            timespec="seconds"),
                    })
                elif srow is not None:
                    conflicts.append({
                        "table": table, "id": pk,
                        "seed": srow, "live": None,
                        "at": datetime.now().isoformat(
                            timespec="seconds"),
                    })
                else:
                    conflicts.append({
                        "table": table, "id": pk,
                        "seed": None, "live": live_row,
                        "at": datetime.now().isoformat(
                            timespec="seconds"),
                    })
            else:
                conflicts.append({
                    "table": table, "id": pk,
                    "seed": srow, "live": live_row,
                    "at": datetime.now().isoformat(
                        timespec="seconds"),
                })
            result["conflicts"] += 1
    try:
        conn.commit()
    except Exception:
        pass
    _store_conflicts(primary_db, conflicts)
    _log(f"merge done: {result['applied']} applied, "
         f"{result['conflicts']} conflicts")
    return result


def merge_seed_into(primary_db):
    """Replay the offline session into the live database.

    Returns {"applied": n, "conflicts": m}. Live rows win
    conflicts; the offline version is stored for review.
    Afterwards the seed is refreshed from the merged live
    database (new base, dirty flag cleared)."""
    result = {"applied": 0, "conflicts": 0}
    if not datahome.seed_exists():
        return result
    meta = datahome.read_seed_meta()
    result = _merge_file_into(
        primary_db, datahome.seed_db_path(), meta.get("base") or {})
    refresh_seed(primary_db)
    return result



def _place_attachment(primary_db, live_att_dir, row, task_id=None):
    """Place one merged attachment's file beside the primary
    database, at <live_att_dir>/<task_id>/<stored> (the per-task
    layout the app reads). ``task_id`` defaults to the row's own
    (already FK-remapped by the merge) task_id. Keep-newer rule:
    an existing newer file is never overwritten."""
    try:
        stored = row.get("stored")
        if not stored:
            return
        tid = task_id if task_id is not None else row.get("task_id")
        src = _copy_attachment_file(stored, tid)
        if src is not None:
            target_dir = (Path(live_att_dir) / str(tid)
                          if tid is not None else Path(live_att_dir))
            target_dir.mkdir(parents=True, exist_ok=True)
            target = target_dir / stored
            if _attachment_should_copy(src, target):
                shutil.copy2(src, target)
    except Exception:
        pass


def resolve_conflict(primary_db, index, use_offline):
    """Apply one stored conflict decision. use_offline replaces
    the live row with the offline one; otherwise the offline
    version is discarded. Either way the entry is removed."""
    conflicts = load_conflicts(primary_db)
    if not (0 <= index < len(conflicts)):
        return False
    entry = conflicts.pop(index)
    ok = True
    if use_offline:
        try:
            table = entry["table"]
            srow = entry.get("seed")
            if srow is None:
                primary_db.conn.execute(
                    f"DELETE FROM {table} WHERE id=?",
                    (int(entry["id"]),))
            else:
                cols = _columns(primary_db.conn, table)
                _upsert_row(primary_db.conn, table, cols, srow)
                if table == "attachments":
                    _place_attachment(
                        primary_db,
                        primary_db.path.parent / "attachments", srow,
                        srow.get("task_id"))
            primary_db.conn.commit()
        except Exception as exc:  # noqa: BLE001
            _log(f"conflict resolution failed: {exc}")
            ok = False
    _store_conflicts(primary_db, conflicts)
    return ok


# ------------------------------------------------------------------
# V1.9.68 FILESYNC (user, 2026-11-14: "THIS HAS TO WORK AND STAY
# UP TO DATE ON BOTH MACHINES. Without OFFLINE ERRORS AND SYNC
# ERRORS"): the session ALWAYS runs on the local working copy
# (the seed file). The network database is NEVER opened by
# SQLite -- not for reading, not for writing. It moves only as
# whole-file copies:
#
# - PULL: copy the network db + its -wal into a local temp,
#   three-way-merge the copy into the working copy (base = the
#   last network state both sides agreed on).
# - PUSH: snapshot the working copy locally, then -- under a
#   lock file, after a generation check -- replace the network
#   file with the snapshot in one rename and bump the stamp.
#
# Whole-file copies are the one thing the redirected-folder
# cache and the share do reliably; SQLite opens only ever
# happen on a local disk, so the "disk I/O error" class cannot
# occur. There is no offline mode and nothing to surface to
# the user: sync runs at launch, in the background while the
# app runs, and at close; a missed cycle retries on the next.
# ------------------------------------------------------------------
STAMP_NAME = "tasks.sync.json"
LOCK_NAME = "tasks.db.sync-lock"
LOCK_STALE_SECONDS = 180


def _meta_update(**kw):
    try:
        meta = datahome.read_seed_meta()
        meta.update(kw)
        datahome.write_seed_meta(meta)
    except Exception:
        pass


def _live_sig(live_path):
    """Cheap change signature of the network file set (stat
    only, never an open): db + wal mtimes/sizes, or None when
    the database file itself is not there."""
    try:
        live = Path(live_path)
        st = live.stat()
        sig = f"{st.st_mtime_ns}:{st.st_size}"
        wal = Path(str(live) + "-wal")
        try:
            wst = wal.stat()
            sig += f":{wst.st_mtime_ns}:{wst.st_size}"
        except Exception:
            sig += ":0:0"
        return sig
    except Exception:
        return None


def _read_stamp(live_path):
    try:
        return json.loads((Path(live_path).parent / STAMP_NAME
                           ).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_stamp(live_path, gen):
    try:
        import socket
        (Path(live_path).parent / STAMP_NAME).write_text(
            json.dumps({"gen": gen,
                        "by": socket.gethostname(),
                        "at": datetime.now().isoformat(
                            timespec="seconds")}),
            encoding="utf-8")
    except Exception:
        pass


def _copy_live_snapshot(live_path, dest_dir):
    """Copy the network db (+ its -wal, never the -shm) into a
    LOCAL folder and verify the copy opens. Returns the copied
    db path, or None. Two attempts: a copy torn by a concurrent
    checkpoint fails verification and is retried."""
    live = Path(live_path)
    dest_dir = Path(dest_dir)
    for _attempt in range(2):
        try:
            if dest_dir.exists():
                shutil.rmtree(dest_dir, ignore_errors=True)
            dest_dir.mkdir(parents=True, exist_ok=True)
            dst = dest_dir / "tasks.db"
            shutil.copy2(live, dst)
            wal = Path(str(live) + "-wal")
            if wal.is_file():
                shutil.copy2(wal, dest_dir / "tasks.db-wal")
            conn = sqlite3.connect(str(dst))
            try:
                conn.execute(
                    "SELECT COUNT(*) FROM sqlite_master").fetchone()
            finally:
                conn.close()
            return dst
        except Exception as exc:  # noqa: BLE001
            _log(f"live copy failed: {exc!r}")
    return None


def _install_working_file(src_db):
    """Replace the local working file with src_db's content and
    drop the working file's own sidecars. Pre-session only: no
    connection is open on it, and its sidecars belong to the
    content being replaced."""
    working = datahome.seed_db_path()
    tmp = working.with_suffix(".install.db")
    shutil.copy2(src_db, tmp)
    tmp.replace(working)
    for suffix in ("-wal", "-shm"):
        try:
            Path(str(working) + suffix).unlink()
        except Exception:
            pass


def _mirror_attachments_from(live_db_path):
    """Mirror a live candidate's attachments folder into the
    local seed attachments, RECURSIVELY over the per-task
    <task_id>/<stored> layout, keep-newer per file, no deletion
    propagation (V1.9.69; the old flat iterdir copied nothing
    because the top level holds only task_id directories)."""
    _mirror_attachments_between(
        Path(live_db_path).parent / "attachments",
        datahome.seed_attachments_dir())


def _mirror_attachments_to(live_db_path):
    """Mirror the local seed attachments INTO a live
    candidate's folder (the push direction), same recursive
    keep-newer rule: a newer file on the live side is never
    overwritten, and nothing is ever deleted."""
    _mirror_attachments_between(
        datahome.seed_attachments_dir(),
        Path(live_db_path).parent / "attachments")


# ------------------------------------------------------------------
# Dual live candidates (V1.9.69): the live folder may be spelled
# two ways (direct network path; redirected/CSC path) reaching
# the same share -- or, split-brain, two divergent copies.
# Selection: highest stamp generation wins; ties prefer a
# candidate proven to be the SAME copy (identical stamp
# (gen, at, by) AND identical db size AND identical snapshot
# content hashes), else the primary. Divergent candidates are
# never settled whole-file winner-takes-all: a candidate whose
# rows diverge from both the base and the selected candidate
# is folded in through the same three-way row merge.
# ------------------------------------------------------------------

def _resolve_candidates(live_path, candidates=None):
    """Ordered live DB paths: the passed live_path is the
    primary; explicit ``candidates`` (dirs or db paths) and the
    configured alternate from datahome are unioned in after it.
    This is what lets the old single-path call signatures engage
    the dual-path logic from configuration alone."""
    primary = Path(live_path)
    out = [primary]
    seen = {os.path.normcase(str(primary))}

    def _add_db(p):
        try:
            key = os.path.normcase(str(p))
            if key not in seen:
                seen.add(key)
                out.append(Path(p))
        except Exception:
            pass

    for entry in (candidates or []):
        try:
            e = Path(entry)
            if e.suffix.lower() == ".db":
                _add_db(e)
            else:
                _add_db(e / primary.name)
        except Exception:
            pass
    try:
        for d in datahome.live_candidate_dirs(primary.parent):
            _add_db(Path(d) / primary.name)
    except Exception:
        pass
    return out


def live_attachment_roots(live_path=None):
    """Every live candidate's attachments folder, in candidate
    order (primary first) -- for the UI's attachment resolver,
    which must look in each spelling's folder. With no
    live_path, the configured candidates alone are used."""
    roots = []
    try:
        if live_path is not None:
            for c in _resolve_candidates(live_path):
                roots.append(c.parent / "attachments")
        else:
            for d in datahome.live_candidate_dirs():
                roots.append(Path(d) / "attachments")
    except Exception:
        pass
    return roots


def _stamp_tuple(live_path):
    try:
        st = _read_stamp(live_path)
        return (st.get("gen") or 0, st.get("at"), st.get("by"))
    except Exception:
        return (0, None, None)


def _quick_stamp_gate(cands, stored_gen):
    """Cheap gen-only freshness gate (stamp reads, no copies).

    Returns the primary's stamp gen when a pull/launch has
    NOTHING to do, else None. The generation stamp is the only
    freshness authority: a signature change is never, on its
    own, evidence of new work, because CSC can serve a stale
    copy with a fresh-looking time -- if the primary's gen is
    not newer than the gen the seed meta has already merged,
    there is nothing to pull even if the signature changed.
    The gate only trips when every other EXISTING candidate is
    indistinguishable from the primary -- identical stamp tuple
    AND identical file signature, i.e. the same underlying
    file. Any disagreement (a divergent candidate carrying the
    same gen with different content) forces a full probe,
    where content hashes -- never signatures -- decide."""
    try:
        if stored_gen is None:
            return None
        primary = Path(cands[0])
        if not primary.is_file():
            return None
        pt = _stamp_tuple(primary)
        if pt[0] > stored_gen:
            return None
        psig = _live_sig(primary)
        for other in cands[1:]:
            try:
                if Path(other).is_file() and (
                        _stamp_tuple(other) != pt
                        or _live_sig(other) != psig):
                    return None
            except Exception:
                return None
        return pt[0]
    except Exception:
        return None


def _probe_one(db_path, idx):
    """Snapshot-copy one candidate and describe it:
    {path, gen, stamp, size, sig, snap, hashes}, or None when
    the file is missing/unreadable. A signature change during
    the copy (concurrent checkpoint/push) retries the copy
    once, mirroring pull's torn-copy guard."""
    try:
        p = Path(db_path)
        if not p.is_file():
            return None
        sig = _live_sig(p)
        snap = _copy_live_snapshot(
            p, datahome.seed_dir() / f"sync_tmp_{idx}")
        if snap is None:
            return None
        if _live_sig(p) != sig:
            sig = _live_sig(p)
            snap = _copy_live_snapshot(
                p, datahome.seed_dir() / f"sync_tmp_{idx}")
            if snap is None:
                return None
        stamp = _read_stamp(p)
        try:
            size = p.stat().st_size
        except Exception:
            size = -1
        return {"path": p, "gen": stamp.get("gen") or 0,
                "stamp": stamp, "size": size, "sig": sig,
                "snap": snap, "hashes": snapshot_hashes(snap)}
    except Exception:
        return None


def _probe_candidates(cands, launch=False, meta=None):
    """Probe every candidate (snapshot + hashes). At launch the
    last-known-good candidate is probed first (synchronously),
    and every other candidate must first pass a CHEAP stat --
    if its folder/file stat fails fast it is skipped for this
    launch, so a dead UNC path cannot hang startup; no sleeps
    or waits are added anywhere. Background probes stat nothing
    extra: a missing file simply yields no probe."""
    probes = []
    try:
        ordered = list(cands)
        if launch:
            last_good = str((meta or {}).get(
                "last_good_candidate") or "")
            if last_good:
                ordered.sort(key=lambda p: 0 if str(p.parent)
                             == last_good else 1)
        for idx, path in enumerate(ordered):
            if launch and idx > 0:
                try:
                    if not Path(path).parent.is_dir():
                        continue
                    if not Path(path).is_file():
                        continue
                except Exception:
                    continue
            probe = _probe_one(path, idx)
            if probe is not None:
                probes.append(probe)
    except Exception:
        pass
    return probes


def _same_copy(a, b):
    """Same-copy detection: identical stamp (gen, at, by) AND
    identical db size AND identical snapshot content hashes --
    two spellings of one underlying share."""
    try:
        return (a["gen"] == b["gen"]
                and a["stamp"].get("at") == b["stamp"].get("at")
                and a["stamp"].get("by") == b["stamp"].get("by")
                and a["size"] == b["size"]
                and a["hashes"] == b["hashes"])
    except Exception:
        return False


def _has_unique_work(hashes, base, selected_hashes):
    """True when a candidate holds row state that is neither
    the agreed base nor the selected candidate's state -- i.e.
    divergent work (edits or deletions) that only a three-way
    merge can fold in without loss."""
    try:
        base = base or {}
        for table in set(hashes) | set(base) | set(selected_hashes):
            h = hashes.get(table, {})
            b = base.get(table, {})
            s = selected_hashes.get(table, {})
            for pk in set(h) | set(b) | set(s):
                hv = h.get(pk)
                if hv != b.get(pk) and hv != s.get(pk):
                    return True
    except Exception:
        pass
    return False


def _select_candidate(probes, primary_path, base):
    """(selected, extras_to_merge) from probed candidates.

    Same-copy duplicates collapse (primary spelling kept).
    Selected = highest stamp gen, primary preferred on ties.
    Extras = remaining candidates carrying unique work versus
    both base and selected; they are merged three-way, never
    taken whole-file."""
    if not probes:
        return None, []
    ordered = sorted(
        probes,
        key=lambda pr: 0 if pr["path"] == Path(primary_path) else 1)
    uniq = []
    for pr in ordered:
        if any(_same_copy(pr, u) for u in uniq):
            continue
        uniq.append(pr)
    best_gen = max(pr["gen"] for pr in uniq)
    selected = next(pr for pr in uniq if pr["gen"] == best_gen)
    extras = [pr for pr in uniq
              if pr is not selected
              and _has_unique_work(pr["hashes"], base,
                                   selected["hashes"])]
    return selected, extras


def launch_sync(live_path, candidates=None):
    """Pre-session: make the local working copy current with
    the network database and return the working path. Never
    raises; never opens SQLite on the network path. When the
    network file cannot be read, the existing working copy is
    used exactly as it stands.

    Freshness is gated on the generation stamp ALONE (V1.9.69):
    when the selected candidate's gen is not newer than the gen
    the seed meta has already merged, there is nothing to pull
    -- even if the file signature changed, because CSC can
    serve a stale copy with a fresh-looking time. The gate is
    checked cheaply (stamp reads) before any snapshot copy, and
    launch probing never blocks on an alternate candidate: the
    last-known-good candidate is probed synchronously and an
    alternate whose folder stat fails fast is skipped for this
    launch (see _probe_candidates)."""
    working = datahome.seed_db_path()
    try:
        cands = _resolve_candidates(live_path, candidates)
        meta = datahome.read_seed_meta()
        stored_gen = meta.get("live_gen")
        base = meta.get("base") or {}
        if working.exists() and _quick_stamp_gate(
                cands, stored_gen) is not None:
            return working      # gen gate: nothing newer to pull
        probes = _probe_candidates(cands, launch=True, meta=meta)
        if not probes:
            return working
        selected, extras = _select_candidate(
            probes, cands[0], base)
        if selected is None:
            return working
        if (working.exists() and stored_gen is not None
                and selected["gen"] <= stored_gen and not extras):
            return working      # gen gate after full probe
        live = selected["path"]
        snap = selected["snap"]
        pulled = selected["hashes"]
        from .db import TaskDatabase
        if not working.exists():
            _install_working_file(snap)
            if extras:
                # Fold divergent candidates into the installed
                # copy against the ORIGINAL base (see pull).
                for extra in extras:
                    _mirror_attachments_from(extra["path"])
                wdb = TaskDatabase(working)
                try:
                    for extra in extras:
                        _merge_file_into(wdb, extra["snap"], base,
                                         source_wins=True)
                finally:
                    wdb.conn.close()
        elif snapshot_hashes(working) == pulled and not extras:
            pass  # already current
        elif snapshot_hashes(working) == base:
            _install_working_file(snap)   # clean: take theirs
            if extras:
                for extra in extras:
                    _mirror_attachments_from(extra["path"])
                wdb = TaskDatabase(working)
                try:
                    for extra in extras:
                        _merge_file_into(wdb, extra["snap"], base,
                                         source_wins=True)
                finally:
                    wdb.conn.close()
        else:
            # Divergent copies: extras merge FIRST (against the
            # original base), the selected candidate LAST, so
            # the canonical highest-gen state wins in place and
            # every other version is kept as a stored conflict.
            for extra in extras:
                _mirror_attachments_from(extra["path"])
            _mirror_attachments_from(live)
            wdb = TaskDatabase(working)
            try:
                for extra in extras:
                    _merge_file_into(wdb, extra["snap"], base,
                                     source_wins=True)
                _merge_file_into(wdb, snap, base,
                                 source_wins=True)
            finally:
                wdb.conn.close()
        for extra in extras:
            _mirror_attachments_from(extra["path"])
        _mirror_attachments_from(live)
        now = datetime.now().isoformat(timespec="seconds")
        _meta_update(
            base=pulled,
            # Record the gen actually merged -- never a fresher
            # gen re-read afterwards, whose content this pass
            # has NOT merged (the gen gate would skip it next
            # cycle and its changes would be lost).
            live_gen=selected["gen"],
            live_sig=selected["sig"],
            last_good_candidate=str(live.parent),
            refreshed_at=now, last_sync_at=now,
            last_sync_ok=True,
            offline_dirty=(
                snapshot_hashes(working) != pulled))
    except Exception as exc:  # noqa: BLE001
        _log(f"launch sync failed: {exc!r}")
    return working


def pull_into_open(working_db, live_path, candidates=None):
    """Fold the network database's changes into a working
    database. The working_db passed in must belong to the
    calling thread (callers on a worker thread open their own
    connection to the working file; SQLite serializes the
    writers). Returns a result dict (with "live_path": the
    candidate actually pulled from); never raises.

    GENERATION GATE (V1.9.69): the pull is gated on the stamp
    generation ALONE. The old shortcut also required the file
    signature to match, which meant a CHANGED signature at an
    unchanged gen still triggered a pull -- but CSC can serve a
    stale copy with a fresh-looking time, so a sig change at a
    gen the seed meta has already merged is not evidence of new
    work. If the selected candidate's gen is not newer than the
    recorded live_gen, there is nothing to pull, whatever the
    signature says."""
    out = {"ok": False, "changed": False,
           "applied": 0, "conflicts": 0,
           "live_path": str(live_path)}
    try:
        cands = _resolve_candidates(live_path, candidates)
        meta = datahome.read_seed_meta()
        stored_gen = meta.get("live_gen")
        base = meta.get("base") or {}
        if _quick_stamp_gate(cands, stored_gen) is not None:
            out["ok"] = True
            return out
        probes = _probe_candidates(cands, launch=False, meta=meta)
        if not probes:
            return out
        selected, extras = _select_candidate(
            probes, cands[0], base)
        if selected is None:
            return out
        live = selected["path"]
        out["live_path"] = str(live)
        if (stored_gen is not None
                and selected["gen"] <= stored_gen and not extras):
            out["ok"] = True
            return out          # gen gate: nothing newer to pull
        pulled = selected["hashes"]
        for extra in extras:
            _mirror_attachments_from(extra["path"])
        _mirror_attachments_from(live)
        # Divergent extras merge first (original base); the
        # selected candidate merges last so its state wins in
        # place, with other versions kept as stored conflicts.
        total = {"applied": 0, "conflicts": 0}
        for extra in extras:
            r = _merge_file_into(working_db, extra["snap"], base,
                                 source_wins=True)
            total["applied"] += r.get("applied", 0)
            total["conflicts"] += r.get("conflicts", 0)
        res = _merge_file_into(working_db, selected["snap"], base,
                               source_wins=True)
        total["applied"] += res.get("applied", 0)
        total["conflicts"] += res.get("conflicts", 0)
        now = datetime.now().isoformat(timespec="seconds")
        _meta_update(
            base=pulled,
            # The gen actually merged, never a fresher re-read:
            # recording an unmerged gen would make the gate
            # skip its content on the next cycle.
            live_gen=selected["gen"],
            live_sig=selected["sig"],
            last_good_candidate=str(live.parent),
            refreshed_at=now, last_sync_at=now,
            last_sync_ok=True,
            offline_dirty=(
                snapshot_hashes(working_db.path) != pulled))
        out.update({"ok": True, "changed": True, **total})
    except Exception as exc:  # noqa: BLE001
        _log(f"pull failed: {exc!r}")
    return out


def push_from_open(working_db, live_path, candidates=None):
    """Replace the network database with a snapshot of the
    working copy, under the lock + generation protocol.
    Returns "pushed", "clean" (nothing to send), "deferred"
    (lock held, a legacy in-place session has the file open,
    or the network is unreachable) or "raced" (the other PC
    pushed first -- pull, then retry). Never raises.

    The push goes ONLY to one candidate: the one this cycle
    pulled from / selected (sync_once passes it in as
    live_path; standalone callers get the recorded
    last-known-good candidate when it is among the configured
    candidates, else the live_path passed). After a successful
    database replace, attachments are mirrored working -> that
    candidate under the keep-newer rule."""
    try:
        meta = datahome.read_seed_meta()
        cands = _resolve_candidates(live_path, candidates)
        live = Path(live_path)
        last_good = str(meta.get("last_good_candidate") or "")
        if last_good:
            for cand in cands:
                if str(cand.parent) == last_good:
                    live = cand
                    break
        if not live.is_file():
            return "deferred"
        base = meta.get("base") or {}
        if snapshot_hashes(working_db.path) == base:
            # Nothing to send in the DB; still top up any
            # attachment file that never made it across.
            _mirror_attachments_to(live)
            return "clean"
        wal = Path(str(live) + "-wal")
        try:
            if wal.is_file() and wal.stat().st_size > 0:
                _log("push deferred: network database has a live "
                     "journal (an in-place session has it open)")
                return "deferred"
        except Exception:
            pass
        lock = live.parent / LOCK_NAME
        have_lock = False
        for _attempt in range(2):
            try:
                fd = os.open(str(lock),
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, json.dumps({
                    "pid": os.getpid(),
                    "at": datetime.now().isoformat(
                        timespec="seconds")}).encode())
                os.close(fd)
                have_lock = True
                break
            except FileExistsError:
                try:
                    age = time.time() - lock.stat().st_mtime
                except Exception:
                    age = LOCK_STALE_SECONDS + 1
                if age > LOCK_STALE_SECONDS:
                    try:
                        lock.unlink()
                    except Exception:
                        pass
                    continue
                return "deferred"
            except Exception:
                return "deferred"
        if not have_lock:
            return "deferred"
        try:
            gen = _read_stamp(live).get("gen") or 0
            if gen != (meta.get("live_gen") or 0):
                return "raced"
            snap_tmp = datahome.seed_dir() / "push_tmp.db"
            try:
                snap_tmp.unlink()
            except Exception:
                pass
            dst = sqlite3.connect(str(snap_tmp))
            try:
                working_db.conn.backup(dst)
            finally:
                dst.close()
            new_hashes = snapshot_hashes(snap_tmp)
            upload = live.parent / "tasks.db.new"
            shutil.copy2(snap_tmp, upload)
            os.replace(upload, live)
            for suffix in ("-wal", "-shm"):
                try:
                    Path(str(live) + suffix).unlink()
                except Exception:
                    pass
            _write_stamp(live, gen + 1)
            # DB replace landed: mirror attachments working ->
            # this candidate (recursive, keep-newer, no
            # deletions) so files follow the database.
            _mirror_attachments_to(live)
            now = datetime.now().isoformat(timespec="seconds")
            _meta_update(
                base=new_hashes, live_gen=gen + 1,
                live_sig=_live_sig(live),
                last_good_candidate=str(live.parent),
                refreshed_at=now, last_sync_at=now,
                last_sync_ok=True,
                offline_dirty=(
                    snapshot_hashes(working_db.path) != new_hashes))
            _log(f"pushed (gen {gen + 1})")
            return "pushed"
        finally:
            try:
                lock.unlink()
            except Exception:
                pass
    except Exception as exc:  # noqa: BLE001
        _log(f"push failed: {exc!r}")
        return "deferred"


def sync_once(working_db, live_path, candidates=None):
    """One background cycle: pull, then push. The push targets
    ONLY the candidate the pull selected in this same cycle.
    Never raises."""
    out = {"ok": False, "pulled": None, "pushed": None}
    try:
        out["pulled"] = pull_into_open(
            working_db, live_path, candidates=candidates)
        target = (out["pulled"] or {}).get("live_path") or live_path
        out["pushed"] = push_from_open(
            working_db, target, candidates=candidates)
        out["ok"] = bool(
            (out["pulled"] or {}).get("ok")
            and out["pushed"] in ("pushed", "clean"))
        _meta_update(
            last_sync_at=datetime.now().isoformat(timespec="seconds"),
            last_sync_ok=out["ok"])
    except Exception as exc:  # noqa: BLE001
        _log(f"sync cycle failed: {exc!r}")
    return out
