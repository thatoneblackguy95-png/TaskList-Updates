"""Offline seed + journaled merge (V1.9.50).

The live database can live on a network share (the user's data
was trapped in a redirected Documents folder whose offline-files
cache poisoned its WAL sidecars -- the 2026-11-13 "disk I/O
error" lockout). The seed is a LOCAL copy of the whole database
plus attachments, kept in ``%LOCALAPPDATA%\\TaskList\\seed``:

- While the live database opens, the seed is refreshed from it
  (launch + close), and a per-row hash BASE of that refresh is
  recorded in the seed metadata.
- When the live database cannot be opened at all (IO-class
  failure) and a seed exists, the app opens the SEED instead and
  the session is marked offline-dirty in the metadata.
- On the next successful live open, the merge replays the
  offline session against the live database using the base:
  rows only the seed changed are applied; rows only live
  changed are kept; rows BOTH changed become conflicts --
  the live row is kept, the offline row is stored for review
  in Settings -> Offline, and nothing is silently overwritten.

Stdlib only (sqlite3), no Qt. Every public function is guarded:
offline machinery must never take the app down with it.
"""

import hashlib
import json
import os
import shutil
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path

from . import datahome

# Parents first: a child row's foreign key may need the remap
# a parent insert produced.
MERGE_TABLES = ("notebooks", "tasks", "directory", "attachments",
                "notes", "queue", "task_revisions")
# child table -> {fk column: parent table}
FK_REMAP = {
    "attachments": {"task_id": "tasks"},
    "notes": {"notebook_id": "notebooks"},
    "queue": {"task_id": "tasks"},
    "task_revisions": {"task_id": "tasks"},
    "tasks": {"parent_task_id": "tasks"},
}
CONFLICTS_SETTING = "offline_conflicts_v1"


def _log(message):
    try:
        from .startup_log import log_startup_event
        log_startup_event("offline: " + message)
    except Exception:
        pass


def _columns(conn, table):
    try:
        return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
    except Exception:
        return []


def _row_hash(values):
    h = hashlib.sha1()
    h.update(repr(tuple(values)).encode("utf-8", "replace"))
    return h.hexdigest()


def _canonical_cols(conn, table):
    """The table's columns in one FIXED (alphabetical) order.

    V1.9.71 (research checklist 1.5): row hashes used to be
    computed over SELECT * -- the PHYSICAL column order -- so
    two PCs whose schemas differ in column order (or an added
    column) hashed identical logical rows differently and
    manufactured phantom conflicts. Hashing and reading over
    a canonical order makes the hash a function of the row's
    content; the schema signature (see _schema_sig) gates
    merges across genuinely different column SETS."""
    return sorted(_columns(conn, table))


def snapshot_hashes(db_path):
    """{table: {pk-as-str: row hash}} for every merge table,
    or None when the file cannot be read COMPLETELY.

    V1.9.71 (checklist 1.6 / matrix PF-1): all-or-nothing.
    The old contract returned PARTIAL hashes on any error --
    and in a base-diff merge an unread row is indistinguishable
    from a deleted row, so one unreadable table could
    mass-delete healthy rows on the other side and bake the
    deletion into the master. Any failure now invalidates
    the whole snapshot: callers must treat None as "unknown"
    and never merge from it."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except Exception:
        return None
    try:
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        out = {}
        for table in MERGE_TABLES:
            if table not in tables:
                continue
            cols = _canonical_cols(conn, table)
            if "id" not in cols:
                continue
            rows = {}
            for row in conn.execute(
                    f"SELECT {', '.join(cols)} FROM {table}"):
                d = dict(zip(cols, row))
                rows[str(d["id"])] = _row_hash(
                    tuple(d[c] for c in cols))
            out[table] = rows
        return out
    except Exception:
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _read_rows(db_path, table):
    """{pk-as-str: {column: value}} for one table (read-only),
    or None when the table cannot be read completely -- a
    failed read must abort a merge, never masquerade as an
    empty table (checklist 1.6)."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            cols = _canonical_cols(conn, table)
            if "id" not in cols:
                return {}
            out = {}
            for row in conn.execute(
                    f"SELECT {', '.join(cols)} FROM {table}"):
                d = dict(zip(cols, row))
                out[str(d["id"])] = d
            return out
        finally:
            conn.close()
    except Exception:
        return None


def _content_subset(sub, sup):
    """True when every (table, pk) -> digest in ``sub`` appears
    identically in ``sup`` (sub's content is contained in sup)."""
    if sub is None or sup is None:
        return False
    for key, digest in sub.items():
        if sup.get(key) != digest:
            return False
    return True


def _content_covered(live_hashes, base, working_hashes):
    """True when pushing the working copy cannot lose anything
    the live file holds: every live row either appears
    identically in the working copy (folded in / unchanged), or
    appears identically in the recorded BASE and is absent from
    the working copy -- an intentional local deletion of a base
    row, which the push correctly keeps deleted. A live row
    that is in neither (new or edited elsewhere, not yet
    folded) makes it False."""
    if live_hashes is None or base is None or working_hashes is None:
        return False
    for key, digest in live_hashes.items():
        if working_hashes.get(key) == digest:
            continue
        if key not in working_hashes and base.get(key) == digest:
            continue
        return False
    # And no resurrections: a row the working copy still holds
    # from the BASE but the live file no longer has was deleted
    # elsewhere after the base was recorded. Pushing would
    # silently undo that deletion -- the fold must judge it
    # against the base first, so this push is not covered.
    for key in working_hashes:
        if key not in live_hashes and key in base:
            return False
    return True


def hashes_digest(hashes):
    """One digest attesting a whole hash set -- the content
    attestation the generation stamp carries (checklist 2.3).
    """
    h = hashlib.sha256()
    try:
        for table in sorted(hashes or {}):
            rows = hashes[table]
            for pk in sorted(rows, key=lambda v: (len(v), v)):
                h.update(f"{table}:{pk}:{rows[pk]}\n".encode())
    except Exception:
        pass
    return h.hexdigest()


def _schema_sig(db_path):
    """Signature of the merge tables' column SETS in one file.
    Merges across different schema signatures are refused
    (checklist 1.5; matrix X-R5c)."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            h = hashlib.sha256()
            for table in MERGE_TABLES:
                cols = _canonical_cols(conn, table)
                h.update(f"{table}({','.join(cols)});".encode())
            return h.hexdigest()
        finally:
            conn.close()
    except Exception:
        return None


DB_GEN_SETTING = "sync_gen_v1"


def read_db_gen(db_path):
    """The generation recorded INSIDE a database file (its
    settings store), or None. The in-DB generation travels
    atomically with the content -- push builds the snapshot
    through the backup API and stamps the gen into it BEFORE
    hashing -- so unlike the sibling stamp file it can never
    be desynced from the content by per-file caching (CSC)
    or a torn multi-file transport (checklist 2.3/4.4). Only
    ever called on LOCAL files (snapshots, working copies):
    SQLite never opens a network path."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            row = conn.execute(
                "SELECT value FROM settings WHERE key=?",
                (DB_GEN_SETTING,)).fetchone()
            return int(row[0]) if row else None
        finally:
            conn.close()
    except Exception:
        return None


def _write_db_gen(db_path, gen):
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            conn.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (DB_GEN_SETTING, str(int(gen))))
            conn.commit()
        finally:
            conn.close()
        return True
    except Exception:
        return False


def _hash_file_bytes(path):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _attachment_should_copy(src, dst):
    """Copy rule for attachment files.

    V1.9.71 (workstream L): decided by CONTENT, never by
    timestamps -- the V1.9.69 rule compared mtimes, and times
    lie across machines and CSC (a stale copy can carry a
    fresh-looking mtime; a real edit can carry an old one).
    Copy when the target is missing, or when sizes differ, or
    when the content hashes differ. Identical content under
    different timestamps is NOT copied. (Size is a content
    fact, not a timestamp; equal-size files are hashed.)"""
    try:
        if not dst.exists():
            return True
        if src.stat().st_size != dst.stat().st_size:
            return True
        return _hash_file_bytes(src) != _hash_file_bytes(dst)
    except Exception:
        return False


def _preserve_differing_target(src, dst):
    """When a mirror copy is about to replace a target whose
    content DIFFERS from the source, the existing target
    version is first preserved beside it under a clearly
    named conflict copy (V1.9.71 workstream L: both-sides
    changes are never silently overwritten, at file level
    too). Identical content is not preserved (nothing is
    being lost)."""
    try:
        if not dst.exists():
            return
        if (src.stat().st_size == dst.stat().st_size
                and _hash_file_bytes(src) == _hash_file_bytes(dst)):
            return
        stamp = time.strftime("%Y%m%d-%H%M%S")
        keep = dst.with_name(dst.name + f".conflict-copy-{stamp}")
        n = 1
        while keep.exists():
            n += 1
            keep = dst.with_name(
                dst.name + f".conflict-copy-{stamp}-{n}")
        shutil.copy2(dst, keep)
        _log(f"attachment versions differed; kept the replaced "
             f"one as {keep.name}")
    except Exception:
        pass


def _mirror_attachments_between(src_root, dst_root):
    """Recursively mirror attachment files src -> dst,
    preserving the relative <task_id>/<stored> layout (files
    live in per-task subfolders; a flat iterdir copies NOTHING
    -- the V1.9.68 bug this replaces). Per-file keep-newer rule
    (see _attachment_should_copy). NO deletions are propagated:
    orphan files are harmless, and row deletions already travel
    through the database merge. Plain file copies only; never
    raises."""
    try:
        src_root = Path(src_root)
        dst_root = Path(dst_root)
        if not src_root.is_dir():
            return
        for f in src_root.rglob("*"):
            try:
                if not f.is_file():
                    continue
                target = dst_root / f.relative_to(src_root)
                if _attachment_should_copy(f, target):
                    _preserve_differing_target(f, target)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, target)
            except Exception:
                pass
    except Exception:
        pass


def refresh_seed(primary_db):
    """Copy the live database + attachments into the local seed
    and record the per-row hash base. Returns True on success."""
    try:
        seed_db = datahome.seed_db_path()
        tmp = seed_db.with_suffix(".tmp.db")
        dst = sqlite3.connect(str(tmp))
        try:
            primary_db.conn.backup(dst)
        finally:
            dst.close()
        tmp.replace(seed_db)
        # Mirror attachments RECURSIVELY (files live in
        # <task_id>/<stored> subfolders), keep-newer per file,
        # no deletion propagation (V1.9.69; see
        # _mirror_attachments_between).
        _mirror_attachments_between(
            primary_db.path.parent / "attachments",
            datahome.seed_attachments_dir())
        _base = snapshot_hashes(seed_db)
        if _base is None:
            _log("seed refresh: snapshot unreadable; base kept")
            return False
        meta = datahome.read_seed_meta()
        meta.update({
            "refreshed_at": datetime.now().isoformat(timespec="seconds"),
            "base": _base,
            "base_digest": hashes_digest(_base),
            "offline_dirty": False,
        })
        datahome.write_seed_meta(meta)
        _log("seed refreshed")
        return True
    except Exception as exc:  # noqa: BLE001
        _log(f"seed refresh failed: {exc}")
        return False


def mark_offline_dirty():
    try:
        with _META_LOCK:
            meta = datahome.read_seed_meta()
            meta["offline_dirty"] = True
            datahome.write_seed_meta(meta)
        _log("session marked offline-dirty")
    except Exception:
        pass


def seed_is_dirty():
    try:
        return bool(datahome.read_seed_meta().get("offline_dirty"))
    except Exception:
        return False


def _dict_digest(row):
    """Stable digest of a row dict (or None) -- conflict
    identity and freshness checks."""
    try:
        return hashlib.sha256(json.dumps(
            row, sort_keys=True, default=str).encode(
            "utf-8", "replace")).hexdigest()
    except Exception:
        return "?"


def _conflict_key(entry):
    return (entry.get("table"), str(entry.get("id")),
            _dict_digest(entry.get("seed")),
            _dict_digest(entry.get("live")))


def _dedupe_conflicts(conflicts):
    seen = set()
    out = []
    for entry in conflicts or []:
        try:
            key = _conflict_key(entry)
        except Exception:
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(entry)
    return out


def load_conflicts(primary_db):
    """Stored merge conflicts for review.

    V1.9.71 (checklist 1.8 / matrix PF-9): the store moved
    OUT of the synced database. It used to live in a settings
    key INSIDE the database file, but settings are not a
    merge table -- every whole-file push carried the pusher's
    list wholesale, so one machine's push silently erased
    the other's stored conflicts. The store is now a
    per-machine file beside the seed (datahome), written
    atomically. Legacy entries still sitting in the database
    setting are unioned in (deduped by content) until a
    store clears the setting for good.

    V1.9.71 (checklist 1.7 / matrix X-L1/X-L2): entries are
    deduped by (table, id, both versions' content) -- a
    crash between merge-commit and meta-write replays the
    merge next cycle, and the replay must recreate each
    conflict EXACTLY once, never a duplicate."""
    out = []
    try:
        out.extend(datahome.read_seed_conflicts())
    except Exception:
        pass
    try:
        raw = primary_db.get_setting(CONFLICTS_SETTING, "")
        data = json.loads(raw) if raw else []
        if isinstance(data, list):
            out.extend(data)
    except Exception:
        pass
    return _dedupe_conflicts(out)


def _store_conflicts(primary_db, conflicts):
    try:
        datahome.write_seed_conflicts(_dedupe_conflicts(conflicts))
    except Exception:
        pass
    try:
        # The database copy of the store is legacy: keep it
        # emptied so whole-file pushes stop carrying (and
        # clobbering) conflict lists.
        if primary_db.get_setting(CONFLICTS_SETTING, "") not in (
                "", "[]"):
            primary_db.set_setting(CONFLICTS_SETTING, "[]")
    except Exception:
        pass


def _upsert_row(conn, table, cols, row):
    names = [c for c in cols if c in row]
    sql = (f"INSERT OR REPLACE INTO {table} "
           f"({', '.join(names)}) VALUES "
           f"({', '.join('?' for _ in names)})")
    conn.execute(sql, [row[c] for c in names])


def _copy_attachment_file(stored, task_id=None):
    """Locate one attachment file on the seed side
    (merge/resolution). Files live at
    seed_attachments/<task_id>/<stored>; the flat
    <stored> lookup is kept only as a legacy fallback."""
    try:
        root = datahome.seed_attachments_dir()
        if task_id is not None:
            cand = root / str(task_id) / stored
            if cand.is_file():
                return cand
        cand = root / stored
        if cand.is_file():
            return cand
    except Exception:
        pass
    return None


class _MergeAborted(Exception):
    """A merge refused to run (unreadable snapshot, or the
    regression circuit breaker): nothing was applied and the
    caller records the reason as the cycle's failure class."""


def _merge_file_into(primary_db, source_path, base,
                     source_wins=False, guard_deletions=False,
                     suppress_new_rows=False):
    """Core three-way merge: fold the changes in the SOURCE
    database file (relative to the BASE per-row hashes) into
    the OPEN primary database. Rows only the source changed
    are applied; rows only the primary changed are kept; rows
    BOTH changed become conflicts -- the primary row is kept,
    the source row is stored on the primary for review in
    Settings -> Offline. Returns {"applied": n, "conflicts": m}.
    The source is only ever READ, through read-only connections
    and row snapshots; the primary is written through its own
    connection.

    source_wins (the pull direction: source = network copy,
    primary = this PC's working copy) flips conflict
    resolution: the source version is the one in place, and
    the primary's version becomes the stored alternative --
    see the conflict branch.

    DELETION SEMANTICS (V1.9.69 audit -- every case verified
    against the loop below; sv/bv/pv are the source/base/
    primary hashes for a row, None = row absent):
    * In base, gone on the SOURCE, unchanged on the primary
      (bv set, sv None, pv == bv): intentional deletion --
      the pv == bv branch DELETEs it from the primary, so
      the deletion propagates.
    * In base, gone on the PRIMARY, unchanged on the source
      (bv set, pv None, sv == bv): the sv == bv check skips
      it -- the primary's deletion stands in the merged
      result, and reaches the other side through the
      whole-file push. It is never re-added: after the merge
      the caller records as the new base the state actually
      merged (pulled hashes on a pull, pushed hashes on a
      push), and the generation gate + raced-push refusal
      stop a stale copy from reintroducing the row later.
    * In base, deleted on one side and EDITED on the other
      (sv/pv one None, the other != bv): falls through to
      the conflict branch -- stored in offline_conflicts_v1
      for review, in-place state kept, NEVER silently
      resolved for either side.
    * Absent from the base entirely (bv None): NOT a
      deletion -- the row simply never arrived here. A
      source-only row is imported (pv == bv branch); a
      primary-only row is kept (sv == bv skip).
    * Gone on BOTH sides (sv == pv == None): the sv == pv
      check skips it; it stays deleted and drops out of the
      new base, so repeated sync cycles cannot resurrect it.
    """
    result = {"applied": 0, "conflicts": 0}
    base = base or {}
    seed_db = Path(source_path)
    seed_hashes = snapshot_hashes(seed_db)
    live_hashes = snapshot_hashes(primary_db.path)
    if seed_hashes is None or live_hashes is None:
        # Checklist 1.6 / PF-1: a snapshot that cannot be
        # read COMPLETELY is never merged -- partial hashes
        # would read as mass deletions.
        raise _MergeAborted("snapshot_unreadable")
    remap = {t: {} for t in MERGE_TABLES}   # table -> {old id: new id}
    conflicts = load_conflicts(primary_db)
    conn = primary_db.conn
    live_att_dir = primary_db.path.parent / "attachments"
    _deletions = [0]     # circuit-breaker counter (per merge)

    def _mk_conflict(table, pk, seed_row, live_row):
        # "inplace" = digest of the version left IN PLACE
        # (always the entry's "live" side in the current
        # construction); resolve_conflict refuses to apply a
        # decision when the in-place row has moved on since
        # (matrix PF-12).
        return {"table": table, "id": pk,
                "seed": seed_row, "live": live_row,
                "at": datetime.now().isoformat(timespec="seconds"),
                "inplace": _dict_digest(live_row)}
    for table in MERGE_TABLES:
        cols = _columns(conn, table)
        if "id" not in cols:
            continue
        b = base.get(table, {})
        s_hashes = seed_hashes.get(table, {})
        p_hashes = live_hashes.get(table, {})
        # Fresh ids for collision remaps start ABOVE every id in
        # play for this table. An AUTOINCREMENT id can land on a
        # seed id this same pass still has to upsert -- the
        # upsert then silently REPLACEs the just-remapped row
        # (caught in testing: the remapped row vanished).
        _all_pks = [int(k) for k in
                    set(b) | set(s_hashes) | set(p_hashes)
                    if k.isdigit()]
        next_fresh = max(_all_pks, default=0)
        seed_rows = None          # lazy: only read when needed
        # Per-row case map (see the docstring's DELETION
        # SEMANTICS): sv == bv -> source untouched (primary's
        # own state, including its deletions, stands);
        # pv == bv -> apply the source state, including a
        # source deletion; sv == pv -> both sides agree;
        # bv None + both present -> id collision remap;
        # anything else -> conflict for review (delete-vs-edit
        # crossings land here and are never silently resolved).
        for pk in sorted(set(b) | set(s_hashes) | set(p_hashes),
                         key=lambda v: int(v) if v.isdigit() else 0):
            sv, bv, pv = s_hashes.get(pk), b.get(pk), p_hashes.get(pk)
            if sv == bv:
                continue            # offline session didn't touch it
            if seed_rows is None:
                seed_rows = _read_rows(seed_db, table)
                if seed_rows is None:
                    raise _MergeAborted("snapshot_unreadable")
            srow = seed_rows.get(pk)
            # Translate foreign keys through any parent remap.
            if srow is not None:
                srow = dict(srow)
                for fk, parent in FK_REMAP.get(table, {}).items():
                    if fk in srow and srow[fk] is not None:
                        new = remap[parent].get(str(srow[fk]))
                        if new is not None:
                            srow[fk] = new
            if pv == bv:
                # Live didn't change it (or never had it, and the
                # base didn't either): apply the offline state.
                if srow is None:
                    # Row is in the base, gone on the source,
                    # untouched here: an intentional deletion --
                    # propagate it, never keep the row.
                    conn.execute(f"DELETE FROM {table} WHERE id=?",
                                 (int(pk),))
                    result["applied"] += 1
                    _deletions[0] += 1
                    continue
                if bv is None and pv is not None:
                    pass  # id taken by a different new live row: remap below
                elif bv is None and pv is None \
                        and suppress_new_rows:
                    # Crossed wires: this source is a STALE
                    # route (lower generation than the state
                    # already folded). A row the newer state
                    # has never seen is not adopted from the
                    # stale copy -- it reaches the master
                    # through its own machine's next dual sync,
                    # judged against the real common base.
                    continue
                else:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow, srow.get("task_id"))
                    continue
            if sv == pv:
                continue            # both made the same change
            if bv is None and pv is not None and srow is not None:
                if source_wins:
                    # Pull direction: the source keeps the id
                    # (it is the canonical network row); the
                    # primary's own row moves to a fresh id
                    # and its children in the primary follow.
                    # Both rows survive.
                    next_fresh += 1
                    conn.execute(
                        f"UPDATE {table} SET id=? WHERE id=?",
                        (next_fresh, int(pk)))
                    for _child, _fks in FK_REMAP.items():
                        for _fk, _parent in _fks.items():
                            if _parent == table and \
                                    _fk in _columns(conn, _child):
                                conn.execute(
                                    f"UPDATE {_child} SET {_fk}=? "
                                    f"WHERE {_fk}=?",
                                    (next_fresh, int(pk)))
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow, srow.get("task_id"))
                    continue
                # Both sides created a row with the same id.
                # The offline row moves to a fresh id (explicit,
                # above every id in play -- see next_fresh);
                # children pick the new id up through the remap.
                next_fresh += 1
                fresh = dict(srow)
                fresh["id"] = next_fresh
                _upsert_row(conn, table, cols, fresh)
                remap[table][pk] = next_fresh
                result["applied"] += 1
                if table == "attachments":
                    _place_attachment(primary_db, live_att_dir, srow,
                                      srow.get("task_id"))
                continue
            # Both changed the same row differently: conflict.
            # Live wins in place; the offline row is kept for
            # review in Settings -> Offline. (Read through the
            # live connection: earlier merge writes in this same
            # pass are not on disk yet.) Delete-vs-edit crossings
            # (one side deleted a base row the other side edited)
            # also land here: they are stored as conflicts and
            # NEVER silently resolved for either side.
            live_row = None
            try:
                cur = conn.execute(
                    f"SELECT * FROM {table} WHERE id=?", (int(pk),))
                got = cur.fetchone()
                if got is not None:
                    live_row = dict(zip(cols, got))
            except Exception:
                pass
            if source_wins:
                # Pull direction: the SOURCE (network) version
                # is the one in place. Both-edited: it is
                # upserted over the primary's row, and the
                # primary's version becomes the stored
                # alternative. Delete/edit crossings keep the
                # in-place state and store the other side as
                # the alternative (a stored seed of None
                # applies as a delete if the user switches --
                # see resolve_conflict).
                if srow is not None and live_row is not None:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow, srow.get("task_id"))
                    conflicts.append(_mk_conflict(
                        table, pk, live_row, srow))
                elif srow is not None:
                    conflicts.append(_mk_conflict(
                        table, pk, srow, None))
                else:
                    conflicts.append(_mk_conflict(
                        table, pk, None, live_row))
            else:
                conflicts.append(_mk_conflict(
                    table, pk, srow, live_row))
            result["conflicts"] += 1
        # Regression circuit breaker (checklist 1.1 / matrix
        # PF-7): when the caller guards (a fold that is NOT a
        # forward generation move), a source whose application
        # would delete a large share of a table's base rows is
        # not a divergent peer -- it is what a REVERTED master
        # looks like. Refuse the whole merge; nothing applies.
        if guard_deletions and _deletions[0] > max(
                10, int(0.25 * max(1, len(b)))):
            raise _MergeAborted("master_regressed")
        _deletions[0] = 0
    # FK repair (matrix X-D6): a parent deleted on one side
    # while a CHILD row was edited on the other leaves the
    # child pointing at nothing after the per-table passes.
    # An orphaned child that was CHANGED vs base is preserved
    # as a stored conflict before removal; an unchanged orphan
    # is part of the deleted subtree and goes with it. Silent
    # dangling children are the one outcome not allowed.
    try:
        _fk_rows = conn.execute(
            "PRAGMA foreign_key_check").fetchall()
    except Exception:
        _fk_rows = []
    for _fk in _fk_rows or []:
        try:
            _ctable, _crowid = _fk[0], _fk[1]
            if _ctable not in MERGE_TABLES:
                continue
            _ccols = _columns(conn, _ctable)
            _got = conn.execute(
                f"SELECT * FROM {_ctable} WHERE rowid=?",
                (_crowid,)).fetchone()
            if _got is None:
                continue
            _crow = dict(zip(_ccols, _got))
            _cpk = str(_crow.get("id"))
            _canon = _canonical_cols(conn, _ctable)
            _chash = _row_hash(tuple(_crow.get(c) for c in _canon))
            if (base.get(_ctable, {}).get(_cpk) != _chash):
                conflicts.append(_mk_conflict(
                    _ctable, _cpk, _crow, None))
                conflicts[-1]["kind"] = "fk_orphan"
                result["conflicts"] += 1
            conn.execute(
                f"DELETE FROM {_ctable} WHERE rowid=?", (_crowid,))
            result["applied"] += 1
        except Exception:
            pass
    try:
        conn.commit()
    except Exception:
        pass
    _store_conflicts(primary_db, conflicts)
    _log(f"merge done: {result['applied']} applied, "
         f"{result['conflicts']} conflicts")
    return result


def merge_seed_into(primary_db):
    """Replay the offline session into the live database.

    Returns {"applied": n, "conflicts": m}. Live rows win
    conflicts; the offline version is stored for review.
    Afterwards the seed is refreshed from the merged live
    database (new base, dirty flag cleared)."""
    result = {"applied": 0, "conflicts": 0}
    if not datahome.seed_exists():
        return result
    meta = datahome.read_seed_meta()
    try:
        result = _merge_file_into(
            primary_db, datahome.seed_db_path(),
            meta.get("base") or {})
    except _MergeAborted as exc:
        try:
            primary_db.conn.rollback()
        except Exception:
            pass
        _log(f"seed merge refused: {exc}")
        return {"applied": 0, "conflicts": 0,
                "aborted": str(exc)}
    refresh_seed(primary_db)
    return result



def _place_attachment(primary_db, live_att_dir, row, task_id=None):
    """Place one merged attachment's file beside the primary
    database, at <live_att_dir>/<task_id>/<stored> (the per-task
    layout the app reads). ``task_id`` defaults to the row's own
    (already FK-remapped by the merge) task_id. Keep-newer rule:
    an existing newer file is never overwritten."""
    try:
        stored = row.get("stored")
        if not stored:
            return
        tid = task_id if task_id is not None else row.get("task_id")
        src = _copy_attachment_file(stored, tid)
        if src is not None:
            target_dir = (Path(live_att_dir) / str(tid)
                          if tid is not None else Path(live_att_dir))
            target_dir.mkdir(parents=True, exist_ok=True)
            target = target_dir / stored
            if _attachment_should_copy(src, target):
                _preserve_differing_target(src, target)
                shutil.copy2(src, target)
    except Exception:
        pass


def resolve_conflict(primary_db, index, use_offline):
    """Apply one stored conflict decision. use_offline replaces
    the live row with the offline one; otherwise the offline
    version is discarded. Either way the entry is removed.

    V1.9.71 (matrix PF-12): freshness guard. A stored decision
    is only applied when the row still in place is the version
    the conflict was stored against (its "inplace" digest) --
    or already equals the chosen version. If the row was
    legitimately re-edited after the conflict was stored, the
    resolution REFUSES (entry kept, False returned) instead of
    silently killing the newer edit with a stale decision --
    including a stored deletion."""
    conflicts = load_conflicts(primary_db)
    if not (0 <= index < len(conflicts)):
        return False
    entry = conflicts[index]
    if use_offline and entry.get("inplace") is not None:
        # Only APPLYING the stored version needs the guard;
        # discarding it never touches the in-place row.
        try:
            table = entry["table"]
            cols = _canonical_cols(primary_db.conn, table)
            cur = primary_db.conn.execute(
                f"SELECT {', '.join(cols)} FROM {table} "
                f"WHERE id=?", (int(entry["id"]),)).fetchone()
            cur_row = (dict(zip(cols, cur)) if cur is not None
                       else None)
            if (_dict_digest(cur_row) != entry["inplace"]
                    and _dict_digest(cur_row)
                    != _dict_digest(entry.get("seed"))):
                _log("conflict resolution refused: the row "
                     "changed after the conflict was stored")
                return False
        except Exception:
            pass
    entry = conflicts.pop(index)
    ok = True
    if use_offline:
        try:
            table = entry["table"]
            srow = entry.get("seed")
            if srow is None:
                primary_db.conn.execute(
                    f"DELETE FROM {table} WHERE id=?",
                    (int(entry["id"]),))
            else:
                cols = _columns(primary_db.conn, table)
                _upsert_row(primary_db.conn, table, cols, srow)
                if table == "attachments":
                    _place_attachment(
                        primary_db,
                        primary_db.path.parent / "attachments", srow,
                        srow.get("task_id"))
            primary_db.conn.commit()
        except Exception as exc:  # noqa: BLE001
            _log(f"conflict resolution failed: {exc}")
            ok = False
    _store_conflicts(primary_db, conflicts)
    return ok


# ------------------------------------------------------------------
# V1.9.68 FILESYNC (user, 2026-11-14: "THIS HAS TO WORK AND STAY
# UP TO DATE ON BOTH MACHINES. Without OFFLINE ERRORS AND SYNC
# ERRORS"): the session ALWAYS runs on the local working copy
# (the seed file). The network database is NEVER opened by
# SQLite -- not for reading, not for writing. It moves only as
# whole-file copies:
#
# - PULL: copy the network db + its -wal into a local temp,
#   three-way-merge the copy into the working copy (base = the
#   last network state both sides agreed on).
# - PUSH: snapshot the working copy locally, then -- under a
#   lock file, after a generation check -- replace the network
#   file with the snapshot in one rename and bump the stamp.
#
# Whole-file copies are the one thing the redirected-folder
# cache and the share do reliably; SQLite opens only ever
# happen on a local disk, so the "disk I/O error" class cannot
# occur. There is no offline mode and nothing to surface to
# the user: sync runs at launch, in the background while the
# app runs, and at close; a missed cycle retries on the next.
# ------------------------------------------------------------------
STAMP_NAME = "tasks.sync.json"
LOCK_NAME = "tasks.db.sync-lock"
LOCK_STALE_SECONDS = 180


_META_LOCK = threading.Lock()


def _meta_update(**kw):
    # Serialized read-modify-write (matrix X-S2): the
    # background worker and the close-time sync run in
    # threads of one process; without the lock their meta
    # updates can lost-update each other and rewind the
    # recorded base/gen.
    try:
        with _META_LOCK:
            meta = datahome.read_seed_meta()
            meta.update(kw)
            datahome.write_seed_meta(meta)
    except Exception:
        pass


# V1.9.71 (forensic fix plan SS5): the failure CLASS of the
# current cycle, noted by whichever stage failed (pull/push),
# read and cleared by sync_once, and persisted in the seed
# meta as last_sync_fail so the Settings sync page can state
# the reason in plain words. The globe stays a truthful
# boolean; this is the WHY next to it. Classes:
# pull_unreachable, push_deferred_wal, push_deferred_lock,
# push_raced, worker_timeout (the last is noted by app.py's
# watchdog, not here).
_CYCLE_FAIL = {}


def _note_cycle_fail(stage, cls):
    try:
        _CYCLE_FAIL[stage] = cls
    except Exception:
        pass


def _stamp_missing(live_path):
    """The stamp is ABSENT for protocol purposes when the
    file is missing OR unparseable OR carries no integer
    generation (matrix PF-6: a corrupt stamp used to read as
    gen 0 and raced forever -- it is a missing stamp, and the
    content-based recovery applies identically)."""
    try:
        if not (Path(live_path).parent / STAMP_NAME).is_file():
            return True
        st = _read_stamp(live_path)
        return not isinstance(st.get("gen"), int)
    except Exception:
        return True


def _wal_is_stale(live, wal):
    """The stale-journal escape (V1.9.71, forensic H2b): a
    non-empty live -wal is a legacy artifact -- not a live
    session -- when it is older than the lock staleness bound,
    no sync lock is freshly held, and the database file itself
    is older still (nothing has written the database since the
    journal was left behind; a session mid-write would make
    the database at least as new as its journal). A FRESH
    -wal is never stale: a live session may be mid-write and
    the push still defers. The journal's rows are not lost by
    proceeding: the pull snapshot copies db + -wal together,
    so anything the journal held was folded in this cycle."""
    try:
        now = time.time()
        wal_mtime = wal.stat().st_mtime
        if now - wal_mtime <= LOCK_STALE_SECONDS:
            return False
        if Path(live).stat().st_mtime > wal_mtime:
            return False
        lock = Path(live).parent / LOCK_NAME
        try:
            if now - lock.stat().st_mtime <= LOCK_STALE_SECONDS:
                return False
        except Exception:
            pass
        return True
    except Exception:
        return False


def _live_sig(live_path):
    """Cheap change signature of the network file set (stat
    only, never an open): db + wal mtimes/sizes, or None when
    the database file itself is not there."""
    try:
        live = Path(live_path)
        st = live.stat()
        sig = f"{st.st_mtime_ns}:{st.st_size}"
        wal = Path(str(live) + "-wal")
        try:
            wst = wal.stat()
            sig += f":{wst.st_mtime_ns}:{wst.st_size}"
        except Exception:
            sig += ":0:0"
        return sig
    except Exception:
        return None


def _read_stamp(live_path):
    try:
        return json.loads((Path(live_path).parent / STAMP_NAME
                           ).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_stamp(live_path, gen, digest=None):
    """Write the generation stamp, now carrying a CONTENT
    attestation (checklist 2.3): the digest of the row-hash
    set the generation stands for. Returns True only when
    the stamp verifiably landed (matrix X-G6: a silent stamp
    failure must be detectable by the writer, not discovered
    as a self-race next cycle). Atomic tmp+replace like the
    local state files."""
    try:
        import socket
        target = Path(live_path).parent / STAMP_NAME
        payload = json.dumps({
            "gen": int(gen),
            "digest": digest,
            "by": socket.gethostname(),
            "at": datetime.now().isoformat(timespec="seconds")})
        tmp = target.with_name(
            target.name + f".tmp-{os.getpid()}")
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(payload)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        os.replace(tmp, target)
        back = _read_stamp(live_path)
        return back.get("gen") == int(gen)
    except Exception:
        return False


def _copy_live_snapshot(live_path, dest_dir):
    """Copy the network db (+ its -wal, never the -shm) into a
    LOCAL folder and verify the copy is a CONSISTENT database.
    Returns the copied db path, or None.

    V1.9.71 (checklist 3.3 / matrix PF-1): verification used
    to be one COUNT over sqlite_master -- a torn copy passes
    that while whole tables are unreadable, and the merge
    then treats unread rows as deletions. The copy must now
    pass PRAGMA integrity_check in full, and the caller
    re-verifies stability (signature across the copy, probe
    retries) before anything merges from it."""
    live = Path(live_path)
    dest_dir = Path(dest_dir)
    for _attempt in range(2):
        try:
            if dest_dir.exists():
                shutil.rmtree(dest_dir, ignore_errors=True)
            dest_dir.mkdir(parents=True, exist_ok=True)
            dst = dest_dir / "tasks.db"
            shutil.copy2(live, dst)
            wal = Path(str(live) + "-wal")
            if wal.is_file():
                shutil.copy2(wal, dest_dir / "tasks.db-wal")
            conn = sqlite3.connect(str(dst))
            try:
                rows = conn.execute(
                    "PRAGMA integrity_check").fetchall()
                if [r[0] for r in rows] != ["ok"]:
                    raise ValueError(
                        f"integrity_check: {rows[:2]}")
            finally:
                conn.close()
            return dst
        except Exception as exc:  # noqa: BLE001
            _log(f"live copy failed: {exc!r}")
    return None


def _install_working_file(src_db):
    """Replace the local working file with src_db's content and
    drop the working file's own sidecars. Pre-session only: no
    connection is open on it, and its sidecars belong to the
    content being replaced."""
    working = datahome.seed_db_path()
    tmp = working.with_suffix(".install.db")
    shutil.copy2(src_db, tmp)
    tmp.replace(working)
    for suffix in ("-wal", "-shm"):
        try:
            Path(str(working) + suffix).unlink()
        except Exception:
            pass


def _mirror_attachments_from(live_db_path):
    """Mirror a live candidate's attachments folder into the
    local seed attachments, RECURSIVELY over the per-task
    <task_id>/<stored> layout, keep-newer per file, no deletion
    propagation (V1.9.69; the old flat iterdir copied nothing
    because the top level holds only task_id directories)."""
    _mirror_attachments_between(
        Path(live_db_path).parent / "attachments",
        datahome.seed_attachments_dir())


def _mirror_attachments_to(live_db_path):
    """Mirror the local seed attachments INTO a live
    candidate's folder (the push direction), same recursive
    keep-newer rule: a newer file on the live side is never
    overwritten, and nothing is ever deleted."""
    _mirror_attachments_between(
        datahome.seed_attachments_dir(),
        Path(live_db_path).parent / "attachments")


# ------------------------------------------------------------------
# Dual live candidates (V1.9.69): the live folder may be spelled
# two ways (direct network path; redirected/CSC path) reaching
# the same share -- or, split-brain, two divergent copies.
# Selection: highest stamp generation wins; ties prefer a
# candidate proven to be the SAME copy (identical stamp
# (gen, at, by) AND identical db size AND identical snapshot
# content hashes), else the primary. Divergent candidates are
# never settled whole-file winner-takes-all: a candidate whose
# rows diverge from both the base and the selected candidate
# is folded in through the same three-way row merge.
# ------------------------------------------------------------------

def _resolve_candidates(live_path, candidates=None):
    """Ordered live DB paths: the passed live_path is the
    primary; explicit ``candidates`` (dirs or db paths) and the
    configured alternate from datahome are unioned in after it.
    This is what lets the old single-path call signatures engage
    the dual-path logic from configuration alone."""
    primary = Path(live_path)
    out = [primary]
    seen = {os.path.normcase(str(primary))}

    def _add_db(p):
        try:
            key = os.path.normcase(str(p))
            if key not in seen:
                seen.add(key)
                out.append(Path(p))
        except Exception:
            pass

    for entry in (candidates or []):
        try:
            e = Path(entry)
            if e.suffix.lower() == ".db":
                _add_db(e)
            else:
                _add_db(e / primary.name)
        except Exception:
            pass
    try:
        for d in datahome.live_candidate_dirs(primary.parent):
            _add_db(Path(d) / primary.name)
    except Exception:
        pass
    return out


def live_attachment_roots(live_path=None):
    """Every live candidate's attachments folder, in candidate
    order (primary first) -- for the UI's attachment resolver,
    which must look in each spelling's folder. With no
    live_path, the configured candidates alone are used."""
    roots = []
    try:
        if live_path is not None:
            for c in _resolve_candidates(live_path):
                roots.append(c.parent / "attachments")
        else:
            for d in datahome.live_candidate_dirs():
                roots.append(Path(d) / "attachments")
    except Exception:
        pass
    return roots


def _stamp_tuple(live_path):
    try:
        st = _read_stamp(live_path)
        return (st.get("gen") or 0, st.get("at"), st.get("by"))
    except Exception:
        return (0, None, None)


def _quick_stamp_gate(cands, stored_gen, base_digest=None,
                      recorded_sig=None):
    """Cheap freshness gate (stamp reads, no copies).

    Returns the primary's stamp gen when a pull/launch has
    NOTHING to do, else None. The generation stamp is the
    freshness authority: a signature change is never, on its
    own, evidence of new work, because CSC can serve a stale
    copy with a fresh-looking time.

    V1.9.71 (checklist 2.3/6.4): the gate may only skip when
    the content is accounted for -- every existing candidate
    attests (stamp digest) EXACTLY the recorded base content
    at a gen not newer than the recorded one. A candidate
    whose stamp is missing/corrupt, whose gen is ahead, or
    whose attested content differs from the recorded base
    (a divergent or regressed copy at an old gen -- the
    shapes the old gen-only gate sailed past) forces the
    full probe, where hashes decide."""
    try:
        if stored_gen is None:
            return None
        for cand in cands:
            try:
                if Path(cand).is_file() and _stamp_missing(cand):
                    return None
            except Exception:
                return None
        primary = Path(cands[0])
        if not primary.is_file():
            return None
        pt = _stamp_tuple(primary)
        if pt[0] > stored_gen:
            return None
        if base_digest is not None:
            for cand in cands:
                try:
                    if not Path(cand).is_file():
                        continue
                    st = _read_stamp(cand)
                    dg = st.get("digest")
                    # Legacy stamps carry no digest: their gen
                    # alone may gate (pre-attestation files).
                    if dg is not None and dg != base_digest:
                        return None
                except Exception:
                    return None
        psig = _live_sig(primary)
        if recorded_sig is not None and psig != recorded_sig:
            # The DB file itself changed since the merge the
            # meta recorded -- the stamp may be attesting a
            # file that is no longer there (PF-7: a whole-file
            # restore under an untouched stamp; the CSC
            # per-file desync is the same shape). The stamp's
            # claim is unverified: probe the content.
            return None
        for other in cands[1:]:
            try:
                if Path(other).is_file() and (
                        _stamp_tuple(other) != pt
                        or _live_sig(other) != psig):
                    return None
            except Exception:
                return None
        return pt[0]
    except Exception:
        return None


def _probe_one(db_path, idx):
    """Snapshot-copy one candidate and describe it, or None
    when the file is missing/unreadable/unstable.

    V1.9.71 (checklist 2.3/3.3, matrix X-P8/X-R3): the probe
    now ATTESTS the candidate. ``gen`` is the EFFECTIVE
    generation of the content actually snapshotted: the
    stamp's gen when the stamp attests this content (stamp
    gen == in-DB gen AND stamp digest == the snapshot's
    content digest), else the in-DB generation (which
    travels with the content), else the stamp's claim is
    worthless and the content is treated as lineage-unknown
    (gen from the DB or 0, ``attested`` False). A candidate
    whose schema signature differs from the working copy's
    is rejected outright. Stability: a signature change
    during the copy retries; after the third unstable
    attempt the probe DEFERS (None) rather than merging a
    possibly hybrid snapshot."""
    try:
        p = Path(db_path)
        if not p.is_file():
            return None
        snap = None
        sig = None
        for _attempt in range(3):
            sig_before = _live_sig(p)
            snap = _copy_live_snapshot(
                p, datahome.seed_dir() / f"sync_tmp_{idx}")
            if snap is None:
                return None
            sig = _live_sig(p)
            if sig == sig_before:
                break
        else:
            return None     # never stabilised: defer the cycle
        hashes = snapshot_hashes(snap)
        if hashes is None:
            return None
        stamp = _read_stamp(p)
        digest = hashes_digest(hashes)
        db_gen = read_db_gen(snap)
        stamp_gen = stamp.get("gen")
        attested = bool(
            isinstance(stamp_gen, int)
            and stamp_gen == db_gen
            and stamp.get("digest") == digest)
        if attested:
            gen = stamp_gen
        elif db_gen is not None:
            gen = db_gen
        elif isinstance(stamp_gen, int) and not stamp.get("digest"):
            gen = stamp_gen     # legacy stamp (pre-attestation)
            attested = True
        else:
            gen = 0
        try:
            size = p.stat().st_size
        except Exception:
            size = -1
        return {"path": p, "gen": gen, "stamp": stamp,
                "size": size, "sig": sig, "snap": snap,
                "hashes": hashes, "digest": digest,
                "db_gen": db_gen, "attested": attested,
                "schema": _schema_sig(snap)}
    except Exception:
        return None


def _probe_candidates(cands, launch=False, meta=None):
    """Probe every candidate (snapshot + hashes). At launch the
    last-known-good candidate is probed first (synchronously).
    Every candidate past the first must first pass a CHEAP
    stat -- if its folder/file stat fails fast it is skipped
    for this cycle, so a dead route cannot stall the cycle on
    network timeouts (V1.9.71: the pre-skip now applies to
    background cycles too, not just launch -- forensic H5)."""
    probes = []
    try:
        ordered = list(cands)
        if launch:
            last_good = str((meta or {}).get(
                "last_good_candidate") or "")
            if last_good:
                ordered.sort(key=lambda p: 0 if str(p.parent)
                             == last_good else 1)
        for idx, path in enumerate(ordered):
            if idx > 0:
                try:
                    if not Path(path).parent.is_dir():
                        continue
                    if not Path(path).is_file():
                        continue
                except Exception:
                    continue
            probe = _probe_one(path, idx)
            if probe is not None:
                probes.append(probe)
    except Exception:
        pass
    return probes


def _same_copy(a, b):
    """Same-copy detection: identical snapshot CONTENT. Two
    spellings serving the same rows are the same copy however
    their stamps differ -- V1.9.71 (matrix X-T4): the stamp's
    wall-clock `at`/`by` fields used to be compared verbatim,
    so one copy written by a skewed clock read as a false
    split-brain twin of itself."""
    try:
        return a["hashes"] == b["hashes"]
    except Exception:
        return False


def _has_unique_work(hashes, base, selected_hashes,
                     stale_gen=False):
    """True when a candidate holds row state that is neither
    the agreed base nor the selected candidate's state -- i.e.
    divergent work (edits or deletions) that only a three-way
    merge can fold in without loss.

    stale_gen (the candidate's generation is BEHIND the merged
    lineage): a row the candidate holds that NEITHER the base
    nor the selected state has ever seen is a superseded
    leftover of the older lineage, not unique work -- the
    newer generation already judged that row (deleted, or
    never adopted). Generation decides (crossed wires)."""
    try:
        base = base or {}
        for table in set(hashes) | set(base) | set(selected_hashes):
            h = hashes.get(table, {})
            b = base.get(table, {})
            s = selected_hashes.get(table, {})
            for pk in set(h) | set(b) | set(s):
                hv = h.get(pk)
                if hv != b.get(pk) and hv != s.get(pk):
                    if stale_gen and hv is not None \
                            and pk not in b and pk not in s:
                        continue    # superseded leftover row
                    return True
    except Exception:
        pass
    return False


def _is_unc(path):
    try:
        return str(path).startswith("\\\\")
    except Exception:
        return False


def _select_candidate(probes, primary_path, base):
    """(selected, extras_to_merge) from probed candidates.

    Same-copy duplicates collapse. Selected = highest stamp
    gen -- GENERATION decides content, never route speed or
    answer order (the crossed-wires rule: a stale route that
    answers first must never win). Ties prefer the network
    (UNC) spelling, then the primary: route priority orders
    ATTEMPTS and tie-breaks, it never outranks a generation.
    Extras = remaining candidates carrying unique work versus
    both base and selected; they are merged three-way, never
    taken whole-file."""
    if not probes:
        return None, []
    ordered = sorted(
        probes,
        key=lambda pr: (0 if _is_unc(pr["path"]) else 1,
                        0 if pr["path"] == Path(primary_path) else 1))
    uniq = []
    for pr in ordered:
        if any(_same_copy(pr, u) for u in uniq):
            continue
        uniq.append(pr)
    best_gen = max(pr["gen"] for pr in uniq)
    selected = next(pr for pr in uniq if pr["gen"] == best_gen)
    extras = [pr for pr in uniq
              if pr is not selected
              and _has_unique_work(pr["hashes"], base,
                                   selected["hashes"])]
    return selected, extras


def _pick_fold_base(meta, working_hashes, cand_hashes):
    """The base the next fold must be judged against.

    Normally the recorded base. But when routes diverged at
    the same generation, the recorded base may already BE one
    branch's state (this machine pushed it there) -- folding
    the other branch against it reads that branch's untouched
    rows as reverts and silently loses the first branch's
    edits (the crossed-wires failure). write_seed_meta
    archives outgoing bases in base_hist; the correct judge
    is the OLDEST recorded base that is still a true common
    ancestor: a base B qualifies when no row was changed by
    two sides in two different ways since B (every row's
    values across B, the working copy and all candidates
    contain at most one non-B value)."""
    current = meta.get("base") or {}
    hist = [h.get("hashes") or {}
            for h in (meta.get("base_hist") or [])
            if isinstance(h, dict)]
    chain = [current] + hist        # newest -> oldest
    sides = [working_hashes or {}] + list(cand_hashes or [])

    def _is_ancestor(b):
        keys = set(b)
        for s in sides:
            keys |= set(s)
        for table in keys:
            bt = b.get(table, {})
            rows = set(bt)
            for s in sides:
                rows |= set(s.get(table, {}))
            for pk in rows:
                bv = bt.get(pk)
                moved = set()
                for s in sides:
                    v = s.get(table, {}).get(pk)
                    if v != bv:
                        moved.add(v)
                if len(moved) > 1:
                    return False
        return True

    for b in reversed(chain):
        if _is_ancestor(b):
            return b
    return current


def launch_sync(live_path, candidates=None):
    """Pre-session: make the local working copy current with
    the network database and return the working path. Never
    raises; never opens SQLite on the network path. When the
    network file cannot be read, the existing working copy is
    used exactly as it stands.

    Freshness is gated on the generation stamp ALONE (V1.9.69):
    when the selected candidate's gen is not newer than the gen
    the seed meta has already merged, there is nothing to pull
    -- even if the file signature changed, because CSC can
    serve a stale copy with a fresh-looking time. The gate is
    checked cheaply (stamp reads) before any snapshot copy, and
    launch probing never blocks on an alternate candidate: the
    last-known-good candidate is probed synchronously and an
    alternate whose folder stat fails fast is skipped for this
    launch (see _probe_candidates)."""
    working = datahome.seed_db_path()
    try:
        # Matrix PF-10: a second live instance on this PC owns
        # the seed; this instance must not install over its
        # working file or interleave meta writes with it.
        if not datahome.acquire_instance_lock():
            _log("launch sync skipped: another instance holds "
                 "the seed lock")
            return working
        cands = _resolve_candidates(live_path, candidates)
        meta = datahome.read_seed_meta()
        stored_gen = meta.get("live_gen")
        base = meta.get("base") or {}
        if working.exists() and _quick_stamp_gate(
                cands, stored_gen,
                meta.get("base_digest"),
                recorded_sig=meta.get("live_sig")) is not None:
            return working      # gate: nothing newer to pull
        probes = _probe_candidates(cands, launch=True, meta=meta)
        if not probes:
            return working
        _wschema = _schema_sig(working) if working.exists() else None
        if _wschema is not None:
            probes = [pr for pr in probes
                      if pr.get("schema") in (None, _wschema)]
            if not probes:
                _note_cycle_fail("pull", "schema_mismatch")
                return working
        fold_base = _pick_fold_base(
            meta,
            snapshot_hashes(working) if working.exists()
            else None,
            [pr["hashes"] for pr in probes])
        selected, extras = _select_candidate(
            probes, cands[0], fold_base)
        if selected is None:
            return working
        stamp_missing = _stamp_missing(selected["path"])
        # The regression circuit breaker guards any fold that
        # is not a forward generation move.
        _guard = not (stored_gen is not None
                      and selected["gen"] > stored_gen)
        if meta.get("_meta_lost"):
            # PF-2 recovery: the recorded base is GONE (meta
            # corrupt beyond its backup). Re-baseline from the
            # master snapshot actually probed: deletions made
            # against the lost base become un-inferable for
            # this one recovery (degrade to keep-both, never
            # to delete -- checklist 1.1), local edits survive
            # as primary-side work, and sync continues from a
            # truthful base instead of an empty one.
            base = selected["hashes"]
            stored_gen = selected["gen"]
            _meta_update(
                base=base, live_gen=stored_gen,
                base_digest=selected["digest"],
                last_sync_fail="meta_recovered")
            _log("seed meta was lost; re-baselined from the "
                 "master snapshot")
        if (working.exists() and selected["hashes"] == base
                and not extras):
            if stamp_missing and stored_gen is not None:
                # Content is the recorded base: restore the
                # stamp at the recorded generation, attesting
                # the content it stands for.
                _write_stamp(selected["path"], stored_gen,
                             hashes_digest(base))
            return working      # content gate: nothing to fold
        live = selected["path"]
        snap = selected["snap"]
        pulled = selected["hashes"]
        from .db import TaskDatabase
        if not working.exists():
            _install_working_file(snap)
            if extras:
                # Fold divergent candidates into the installed
                # copy against the ORIGINAL base (see pull).
                for extra in extras:
                    _mirror_attachments_from(extra["path"])
                wdb = TaskDatabase(working)
                try:
                    for extra in extras:
                        _merge_file_into(wdb, extra["snap"], fold_base,
                                         source_wins=True,
                                         guard_deletions=_guard,
                                         suppress_new_rows=(
                                             extra["gen"] < selected["gen"]))
                finally:
                    wdb.conn.close()
        elif snapshot_hashes(working) == pulled and not extras:
            pass  # already current
        elif snapshot_hashes(working) == base:
            _install_working_file(snap)   # clean: take theirs
            if extras:
                for extra in extras:
                    _mirror_attachments_from(extra["path"])
                wdb = TaskDatabase(working)
                try:
                    for extra in extras:
                        _merge_file_into(wdb, extra["snap"], fold_base,
                                         source_wins=True,
                                         guard_deletions=_guard,
                                         suppress_new_rows=(
                                             extra["gen"] < selected["gen"]))
                finally:
                    wdb.conn.close()
        else:
            # Divergent copies: extras merge FIRST (against the
            # original base), the selected candidate LAST, so
            # the canonical highest-gen state wins in place and
            # every other version is kept as a stored conflict.
            for extra in extras:
                _mirror_attachments_from(extra["path"])
            _mirror_attachments_from(live)
            wdb = TaskDatabase(working)
            try:
                for extra in extras:
                    _merge_file_into(wdb, extra["snap"], fold_base,
                                     source_wins=True,
                                     suppress_new_rows=(
                                         extra["gen"] < selected["gen"]))
                _merge_file_into(wdb, snap, fold_base,
                                 source_wins=True,
                                 guard_deletions=_guard)
            finally:
                wdb.conn.close()
        for extra in extras:
            _mirror_attachments_from(extra["path"])
        _mirror_attachments_from(live)
        now = datetime.now().isoformat(timespec="seconds")
        # Record the gen actually merged -- the probe's
        # EFFECTIVE gen of the content folded (never a fresher
        # gen re-read afterwards, whose content this pass has
        # NOT merged: the gate would skip it next cycle and
        # its changes would be lost).
        _meta_update(
            base=pulled,
            live_gen=selected["gen"],
            base_digest=selected["digest"],
            live_sig=selected["sig"],
            last_good_candidate=str(live.parent),
            refreshed_at=now, last_sync_at=now,
            last_sync_ok=True,
            offline_dirty=(
                snapshot_hashes(working) != pulled))
        if stamp_missing:
            # The folded copy's stamp was absent/corrupt:
            # rewrite it attesting the content's own gen.
            _write_stamp(live, selected["gen"],
                         selected["digest"])
    except _MergeAborted as exc:
        _note_cycle_fail("pull", str(exc) or "master_regressed")
        _log(f"launch merge refused: {exc}")
    except Exception as exc:  # noqa: BLE001
        _log(f"launch sync failed: {exc!r}")
    return working


def pull_into_open(working_db, live_path, candidates=None):
    """Fold the network database's changes into a working
    database. The working_db passed in must belong to the
    calling thread (callers on a worker thread open their own
    connection to the working file; SQLite serializes the
    writers). Returns a result dict (with "live_path": the
    candidate actually pulled from); never raises.

    FRESHNESS (V1.9.71, checklist 2.3/6.4): content decides.
    The cheap gate may skip only when every candidate attests
    exactly the recorded base content; after probing, a
    candidate whose content EQUALS the recorded base has
    nothing to fold whatever its stamp claims, and a
    candidate whose content DIFFERS from the base is folded
    three-way even at an old generation (a regressed or
    desynced copy is reconciled by content, never gen-gated
    into a permanent stall -- the fold is guarded by the
    regression circuit breaker when it is not a forward
    generation move)."""
    out = {"ok": False, "changed": False,
           "applied": 0, "conflicts": 0,
           "live_path": str(live_path),
           "candidates": [], "answered": []}
    try:
        cands = _resolve_candidates(live_path, candidates)
        out["candidates"] = [str(c) for c in cands]
        meta = datahome.read_seed_meta()
        stored_gen = meta.get("live_gen")
        base = meta.get("base") or {}
        if _quick_stamp_gate(cands, stored_gen,
                             meta.get("base_digest"),
                             recorded_sig=meta.get("live_sig")) is not None:
            out["answered"] = [str(c) for c in cands
                               if Path(c).is_file()]
            out["ok"] = True
            return out
        probes = _probe_candidates(cands, launch=False, meta=meta)
        out["answered"] = [str(pr["path"]) for pr in probes]
        if not probes:
            _note_cycle_fail("pull", "pull_unreachable")
            return out
        _wschema = _schema_sig(working_db.path)
        if _wschema is not None:
            _kept = [pr for pr in probes
                     if pr.get("schema") in (None, _wschema)]
            if not _kept:
                _note_cycle_fail("pull", "schema_mismatch")
                return out
            probes = _kept
        # Crossed wires: judge the folds against the true
        # common ancestor, not a base one branch already
        # advanced past it (see _pick_fold_base).
        fold_base = _pick_fold_base(
            meta, snapshot_hashes(working_db.path),
            [pr["hashes"] for pr in probes])
        selected, extras = _select_candidate(
            probes, cands[0], fold_base)
        if selected is None:
            _note_cycle_fail("pull", "pull_unreachable")
            return out
        live = selected["path"]
        out["live_path"] = str(live)
        stamp_missing = _stamp_missing(live)
        if meta.get("_meta_lost"):
            # PF-2 re-baseline (as in launch_sync): never merge
            # against an empty base -- that is the shape that
            # resurrects deletions.
            base = selected["hashes"]
            stored_gen = selected["gen"]
            _meta_update(
                base=base, live_gen=stored_gen,
                base_digest=selected["digest"],
                last_sync_fail="meta_recovered")
            _log("seed meta was lost; re-baselined from the "
                 "master snapshot")
        if selected["hashes"] == base and not extras:
            if stamp_missing and stored_gen is not None:
                # Content IS the recorded base: restore the
                # stamp attesting exactly this state.
                _write_stamp(live, stored_gen,
                             hashes_digest(base))
            out["ok"] = True
            return out          # content gate: nothing to fold
        pulled = selected["hashes"]
        for extra in extras:
            _mirror_attachments_from(extra["path"])
        _mirror_attachments_from(live)
        # Divergent extras merge first (original base); the
        # selected candidate merges last so its state wins in
        # place, with other versions kept as stored conflicts.
        _guard = not (stored_gen is not None
                      and selected["gen"] > stored_gen)
        total = {"applied": 0, "conflicts": 0}
        try:
            for extra in extras:
                r = _merge_file_into(
                    working_db, extra["snap"], fold_base,
                    source_wins=True, guard_deletions=_guard,
                    suppress_new_rows=(
                        extra["gen"] < selected["gen"]))
                total["applied"] += r.get("applied", 0)
                total["conflicts"] += r.get("conflicts", 0)
            res = _merge_file_into(
                working_db, selected["snap"], fold_base,
                source_wins=True, guard_deletions=_guard)
            total["applied"] += res.get("applied", 0)
            total["conflicts"] += res.get("conflicts", 0)
        except _MergeAborted as exc:
            try:
                working_db.conn.rollback()
            except Exception:
                pass
            _note_cycle_fail("pull", str(exc) or "master_regressed")
            _log(f"pull merge refused: {exc}")
            return out
        now = datetime.now().isoformat(timespec="seconds")
        _meta_update(
            base=pulled,
            live_gen=selected["gen"],
            base_digest=selected["digest"],
            live_sig=selected["sig"],
            last_good_candidate=str(live.parent),
            refreshed_at=now, last_sync_at=now,
            last_sync_ok=True,
            offline_dirty=(
                snapshot_hashes(working_db.path) != pulled))
        if stamp_missing:
            _write_stamp(live, selected["gen"],
                         selected["digest"])
        out.update({"ok": True, "changed": True, **total})
    except Exception as exc:  # noqa: BLE001
        _log(f"pull failed: {exc!r}")
        _note_cycle_fail("pull", "pull_unreachable")
    return out


def _lock_owner_stale(lock):
    """Decide whether an existing sync lock may be broken.

    V1.9.71 (checklist 2.4/6.3, matrix PF-3): age alone is a
    wall-clock judgement across machines -- a skewed clock
    sees a LIVE lock as stale. When the lock names an owner
    on THIS host, liveness is judged by the owner's pid
    (alive = never stale, however old; dead = breakable at
    once). Foreign-host locks keep the age rule, backstopped
    by the in-lock generation re-check, unique staging
    names, and read-back verification: a wrongly broken lock
    degrades to a raced retry, never silent loss."""
    try:
        owner = json.loads(lock.read_text(encoding="utf-8"))
    except Exception:
        owner = {}
    try:
        import socket
        if owner.get("host") == socket.gethostname()                 and owner.get("pid"):
            return not datahome._pid_alive(owner.get("pid"))
    except Exception:
        pass
    try:
        age = time.time() - lock.stat().st_mtime
    except Exception:
        return True
    return age > LOCK_STALE_SECONDS


def _file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class _LockHeartbeat:
    """Keeps a held sync lock's mtime fresh while a slow push
    runs, so a legitimate 200-second push over a stalled
    share is never mistaken for a dead one (matrix X-T1)."""

    def __init__(self, lock):
        self._lock = lock
        self._stop = threading.Event()
        self._thread = None

    def __enter__(self):
        def _beat():
            while not self._stop.wait(30):
                try:
                    os.utime(self._lock, None)
                except Exception:
                    return
        self._thread = threading.Thread(target=_beat, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        return False


def push_from_open(working_db, live_path, candidates=None,
                   heal=False, pre_folded=False):
    """Replace the network database with a snapshot of the
    working copy, under the lock + generation protocol.
    Returns "pushed", "clean" (nothing to send), "deferred"
    (lock held, a legacy in-place session has the file open,
    or the network is unreachable), "raced" (the other PC
    pushed first -- pull, then retry) or "unverified" (the
    replace landed but read-back could not attest it; the
    base is NOT advanced). Never raises.

    V1.9.71 (checklist 3.4/3.5/6.2): the staging name is
    unique per writer; the staged bytes are verified in
    place (byte hash) before the replace; the new generation
    is written INSIDE the snapshot before hashing, and the
    stamp attests the pushed content digest; after the
    replace, the target is RE-PROBED and the local base/gen
    advance only when the destination verifiably holds the
    pushed content. heal=True additionally allows installing
    onto a route whose content is strictly behind (no unique
    work vs the base or the working copy) at its own gen --
    the split-brain route heal (matrix PF-8)."""
    try:
        meta = datahome.read_seed_meta()
        cands = _resolve_candidates(live_path, candidates)
        live = Path(live_path)
        # The last-known-good spelling may substitute for the
        # DEFAULT target only. A caller that passes an explicit
        # candidate list has chosen its routes -- retargeting
        # its push to the last-good route made the split-brain
        # heal "succeed" against the route that was already
        # current while the stale route was never touched
        # (crossed-wires suite, V1.9.71).
        last_good = str(meta.get("last_good_candidate") or "")
        if last_good and candidates is None:
            for cand in cands:
                if str(cand.parent) == last_good:
                    live = cand
                    break
        if not live.is_file():
            _note_cycle_fail("push", "pull_unreachable")
            return "deferred"
        base = meta.get("base") or {}
        working_hashes = snapshot_hashes(working_db.path)
        if working_hashes is None:
            _note_cycle_fail("push", "snapshot_unreadable")
            return "deferred"
        if working_hashes == base:
            # Nothing new versus the recorded base -- but the
            # TARGET route may still be behind (a stale
            # spelling whose copy never received the state the
            # base already describes). "Clean" is a statement
            # about the target, not about this machine: only a
            # target verifiably holding the working content is
            # clean. Otherwise fall through and let the locked
            # push decide (heal installs a strictly-behind
            # target; a diverged one races).
            _tp = _probe_one(live, 78)
            if _tp is not None and _tp["hashes"] == working_hashes:
                _mirror_attachments_to(live)
                return "clean"
            # Target diverges from the recorded base: fall
            # through to the locked push, whose content paths
            # decide (install / heal / raced) from evidence.
        wal = Path(str(live) + "-wal")
        try:
            if wal.is_file() and wal.stat().st_size > 0:
                if _wal_is_stale(live, wal):
                    _log("push: stale live -wal treated as a "
                         "legacy artifact; proceeding")
                else:
                    _log("push deferred: network database has a "
                         "live journal (an in-place session has "
                         "it open)")
                    _note_cycle_fail("push", "push_deferred_wal")
                    return "deferred"
        except Exception:
            pass
        lock = live.parent / LOCK_NAME
        have_lock = False
        for _attempt in range(2):
            try:
                fd = os.open(str(lock),
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                import socket
                os.write(fd, json.dumps({
                    "pid": os.getpid(),
                    "host": socket.gethostname(),
                    "at": datetime.now().isoformat(
                        timespec="seconds")}).encode())
                os.close(fd)
                have_lock = True
                break
            except FileExistsError:
                if _lock_owner_stale(lock):
                    try:
                        lock.unlink()
                    except Exception:
                        pass
                    continue
                _note_cycle_fail("push", "push_deferred_lock")
                return "deferred"
            except Exception:
                _note_cycle_fail("push", "push_deferred_lock")
                return "deferred"
        if not have_lock:
            _note_cycle_fail("push", "push_deferred_lock")
            return "deferred"
        try:
            with _LockHeartbeat(lock):
                return _push_locked(
                    working_db, live, meta, base,
                    working_hashes, heal=heal,
                    pre_folded=pre_folded)
        finally:
            try:
                lock.unlink()
            except Exception:
                pass
    except Exception as exc:  # noqa: BLE001
        _log(f"push failed: {exc!r}")
        return "deferred"


def _push_locked(working_db, live, meta, base, working_hashes,
                 heal=False, pre_folded=False):
    """The push body, run with the sync lock held (and its
    heartbeat running). See push_from_open for the contract."""
    meta_gen = meta.get("live_gen") or 0
    stamp = _read_stamp(live)
    stamp_gen = stamp.get("gen")
    gen = None
    if not _stamp_missing(live) and stamp.get("digest") is not None             and isinstance(stamp_gen, int):
        if stamp_gen == meta_gen:
            gen = stamp_gen
    if gen is None:
        # Stamp absent/corrupt/unattested, or a gen mismatch:
        # decide from CONTENT, never from the stamp alone.
        _probe = _probe_one(live, 77)
        if _probe is None:
            _note_cycle_fail("push", "pull_unreachable")
            return "deferred"
        if _probe["hashes"] == base:
            # The stamp attested exactly this state: rewrite
            # it at the recorded generation and proceed.
            _write_stamp(live, meta_gen, hashes_digest(base))
            gen = meta_gen
        elif _probe["hashes"] == working_hashes:
            # Our own earlier push whose stamp/meta update was
            # lost (crash or a silent stamp failure): the
            # content is ours -- re-attest it at its in-DB gen
            # and continue the lineage from there.
            gen = _probe["gen"]
            _write_stamp(live, gen, _probe["digest"])
            meta_gen = gen
        elif _content_covered(_probe["hashes"], base,
                               working_hashes):
            # The live content is entirely CONTAINED in the
            # working copy (this cycle's pull already folded
            # it in): pushing the working copy cannot lose
            # anything the live file holds. This is the
            # content-based exit from a lost stamp after a
            # fold -- without it the cycle deadlocks "raced"
            # even though the merge already happened.
            gen = max(_probe["gen"], meta_gen)
            _write_stamp(live, gen, _probe["digest"])
            meta_gen = gen
        elif heal and (pre_folded or not _has_unique_work(
                _probe["hashes"], base, working_hashes,
                stale_gen=_probe["gen"] < meta_gen)):
            # pre_folded: this cycle's pull already folded
            # this route's content into the working copy, so
            # every divergence left is the merge's own
            # resolution -- installing the merged state over
            # it loses nothing unadjudicated. Without a fold,
            # the unique-work gate stands.
            gen = _probe["gen"]  # strictly behind: heal it
        else:
            _note_cycle_fail("push", "push_raced")
            return "raced"
    snap_tmp = datahome.seed_dir() / "push_tmp.db"
    try:
        snap_tmp.unlink()
    except Exception:
        pass
    dst = sqlite3.connect(str(snap_tmp))
    try:
        working_db.conn.backup(dst)
    finally:
        dst.close()
    # The new generation travels INSIDE the snapshot (backup
    # copy), stamped before hashing so the stamp's digest and
    # the in-DB gen attest the exact bytes being pushed.
    if not _write_db_gen(snap_tmp, gen + 1):
        _note_cycle_fail("push", "snapshot_unreadable")
        return "deferred"
    new_hashes = snapshot_hashes(snap_tmp)
    if new_hashes is None:
        _note_cycle_fail("push", "snapshot_unreadable")
        return "deferred"
    digest = hashes_digest(new_hashes)
    import socket
    upload = live.parent / (
        f"tasks.db.new-{socket.gethostname()}-{os.getpid()}")
    shutil.copy2(snap_tmp, upload)
    try:
        staged_ok = _file_sha256(upload) == _file_sha256(snap_tmp)
    except Exception:
        staged_ok = False
    if not staged_ok:
        # The bytes that arrived are not the bytes we sent:
        # never install a torn upload as the master.
        try:
            upload.unlink()
        except Exception:
            pass
        _note_cycle_fail("push", "push_unverified")
        return "unverified"
    os.replace(upload, live)
    for suffix in ("-wal", "-shm"):
        try:
            Path(str(live) + suffix).unlink()
        except Exception:
            pass
    _write_stamp(live, gen + 1, digest)
    # Read-back verification: the base advances ONLY when the
    # destination verifiably holds the pushed content.
    back = _probe_one(live, 78)
    if back is None or back["hashes"] != new_hashes:
        _note_cycle_fail("push", "push_unverified")
        _log("push landed but read-back could not attest it; "
             "base not advanced")
        return "unverified"
    _mirror_attachments_to(live)
    now = datetime.now().isoformat(timespec="seconds")
    _meta_update(
        base=new_hashes, live_gen=gen + 1,
        base_digest=digest,
        live_sig=_live_sig(live),
        last_good_candidate=str(live.parent),
        refreshed_at=now, last_sync_at=now,
        last_sync_ok=True,
        offline_dirty=(
            snapshot_hashes(working_db.path) != new_hashes))
    _log(f"pushed (gen {gen + 1})")
    return "pushed"


# Cycle epoch (matrix X-S3): app.py's watchdog abandons an
# over-running cycle by bumping the epoch; the abandoned
# cycle's late meta write must not rewind state a newer
# cycle has since recorded.
_EPOCH = [0]


def begin_cycle():
    _EPOCH[0] += 1
    return _EPOCH[0]


def abandon_cycle():
    _EPOCH[0] += 1


def establish_network_copy(working_db, live_path):
    """V1.9.76 (FINAL SYNC MODEL, user 2026-11-16 09:19):
    seed a NEW network copy in a folder the user personally
    picked (the Q: folder) from the current working copy.

    The regular push refuses to create a missing live file
    (a missing file on an established route means
    "unreachable", not "start over"), so a fresh pick needs
    this explicit establishment. It follows the push
    protocol exactly: a snapshot of the working copy with
    the next generation written INSIDE it, staged + hash-
    verified in the destination folder, installed by
    replace, attested by the stamp, and the local base/gen
    advance only after a read-back probe verifies the
    destination holds the installed content. Attachments
    mirror across. Deletions are honoured from the moment
    of establishment onward: the installed content IS the
    recorded base, so a row absent from it is absent from
    the base and can never be resurrected from this copy.

    Returns "established", "exists" (a tasks.db is already
    there -- left untouched; the merge machinery converges
    it), "deferred" (folder unreachable/unwritable or the
    snapshot unreadable) or "unverified". Never raises."""
    try:
        live = Path(live_path)
        if live.is_file():
            return "exists"
        try:
            live.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            return "deferred"
        if not live.parent.is_dir():
            return "deferred"
        meta = datahome.read_seed_meta()
        working_hashes = snapshot_hashes(working_db.path)
        if working_hashes is None:
            _note_cycle_fail("push", "snapshot_unreadable")
            return "deferred"
        gen = (meta.get("live_gen") or 0) + 1
        snap_tmp = datahome.seed_dir() / "establish_tmp.db"
        try:
            snap_tmp.unlink()
        except Exception:
            pass
        dst = sqlite3.connect(str(snap_tmp))
        try:
            working_db.conn.backup(dst)
        finally:
            dst.close()
        if not _write_db_gen(snap_tmp, gen):
            _note_cycle_fail("push", "snapshot_unreadable")
            return "deferred"
        new_hashes = snapshot_hashes(snap_tmp)
        if new_hashes is None:
            _note_cycle_fail("push", "snapshot_unreadable")
            return "deferred"
        digest = hashes_digest(new_hashes)
        import socket
        upload = live.parent / (
            f"tasks.db.new-{socket.gethostname()}-{os.getpid()}")
        shutil.copy2(snap_tmp, upload)
        try:
            staged_ok = _file_sha256(upload) == _file_sha256(snap_tmp)
        except Exception:
            staged_ok = False
        if not staged_ok:
            try:
                upload.unlink()
            except Exception:
                pass
            _note_cycle_fail("push", "push_unverified")
            return "unverified"
        os.replace(upload, live)
        for suffix in ("-wal", "-shm"):
            try:
                Path(str(live) + suffix).unlink()
            except Exception:
                pass
        _write_stamp(live, gen, digest)
        back = _probe_one(live, 78)
        if back is None or back["hashes"] != new_hashes:
            _note_cycle_fail("push", "push_unverified")
            _log("establish landed but read-back could not "
                 "attest it; base not advanced")
            return "unverified"
        _mirror_attachments_to(live)
        now = datetime.now().isoformat(timespec="seconds")
        _meta_update(
            base=new_hashes, live_gen=gen,
            base_digest=digest,
            live_sig=_live_sig(live),
            last_good_candidate=str(live.parent),
            refreshed_at=now, last_sync_at=now,
            last_sync_ok=True, offline_dirty=False)
        _log(f"network copy established at {live} (gen {gen})")
        return "established"
    except Exception as exc:  # noqa: BLE001
        _log(f"establish failed: {exc!r}")
        return "deferred"


def sync_once(working_db, live_path, candidates=None, epoch=None):
    """One background cycle: pull, then push, then heal the
    other routes. Never raises.

    V1.9.71 verdicts are per-route: the cycle is OK when ANY
    route completes the pull+push; the meta records the
    outcome per route and the failure class, and the globe
    still gets the one truthful boolean.

    V1.9.71 (matrix PF-8): after the selected route is
    pushed, every OTHER answered route whose content is
    behind the merged state is healed with the same merged
    snapshot -- a divergent spelling is converged, not
    merely out-voted every cycle. If the push to the
    selected route fails because the route died mid-cycle
    (X-R6), the push re-selects the next answered route
    whose content the pull folded."""
    out = {"ok": False, "pulled": None, "pushed": None,
           "routes": [], "healed": []}
    _CYCLE_FAIL.clear()
    try:
        # V1.9.76 (final sync model): a personally picked
        # network-copy folder whose tasks.db does not exist
        # yet -- the pick was made while the drive was
        # unreachable, so the Settings flow could not seed it
        # -- is established from the working copy the first
        # cycle the folder answers. ONLY the picked folder
        # gets this: a missing file at the default location
        # keeps today's behaviour exactly (defer, never
        # create), so an unpicked setup is untouched.
        try:
            _picked = datahome.read_pointer_raw()
            if _picked and not Path(live_path).is_file() \
                    and os.path.normcase(str(Path(live_path).parent)) \
                    == os.path.normcase(str(Path(_picked))) \
                    and Path(_picked).is_dir():
                establish_network_copy(working_db, live_path)
        except Exception:
            pass
        cands = _resolve_candidates(live_path, candidates)
        out["pulled"] = pull_into_open(
            working_db, live_path, candidates=candidates)
        target = (out["pulled"] or {}).get("live_path") or live_path
        out["pushed"] = push_from_open(
            working_db, target, candidates=candidates)
        answered = [str(c) for c in cands
                    if str(c) in set(
                        (out["pulled"] or {}).get("answered") or [])]
        if out["pushed"] not in ("pushed", "clean"):
            # Re-select: another answered route the pull
            # folded may still complete the cycle.
            for other in answered:
                if other == str(target):
                    continue
                r = push_from_open(
                    working_db, other, candidates=candidates)
                if r in ("pushed", "clean"):
                    out["pushed"] = r
                    target = other
                    break
        if out["pushed"] in ("pushed", "clean"):
            # Heal the remaining answered routes that are
            # behind the merged state.
            for other in answered:
                if other == str(target):
                    continue
                r = push_from_open(
                    working_db, other, candidates=candidates,
                    heal=True, pre_folded=True)
                if r in ("pushed", "clean"):
                    out["healed"].append(other)
        out["ok"] = bool(
            (out["pulled"] or {}).get("ok")
            and out["pushed"] in ("pushed", "clean"))
        answered_set = set(
            (out["pulled"] or {}).get("answered") or [])
        routes = []
        for cand in cands:
            cs = str(cand)
            if cs not in answered_set:
                routes.append({"path": cs, "ok": False,
                               "fail": "unreachable"})
            elif cs == str(target) and out["pushed"] not in (
                    "pushed", "clean"):
                routes.append({
                    "path": cs, "ok": False,
                    "fail": _CYCLE_FAIL.get("push") or "deferred"})
            elif cs in out["healed"] or cs == str(target):
                routes.append({"path": cs, "ok": True,
                               "fail": None})
            else:
                routes.append({"path": cs, "ok": True,
                               "fail": None})
        out["routes"] = routes
        fail = None
        if not out["ok"]:
            fail = (_CYCLE_FAIL.get("push")
                    or _CYCLE_FAIL.get("pull")
                    or ("pull_unreachable"
                        if not (out["pulled"] or {}).get("ok")
                        else None))
        if epoch is None or epoch == _EPOCH[0]:
            _meta_update(
                last_sync_at=datetime.now().isoformat(
                    timespec="seconds"),
                last_sync_ok=out["ok"],
                last_sync_fail=fail,
                last_sync_routes=routes)
    except Exception as exc:  # noqa: BLE001
        _log(f"sync cycle failed: {exc!r}")
    return out
