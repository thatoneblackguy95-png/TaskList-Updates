"""Offline seed + journaled merge (V1.9.50).

The live database can live on a network share (the user's data
was trapped in a redirected Documents folder whose offline-files
cache poisoned its WAL sidecars -- the 2026-11-13 "disk I/O
error" lockout). The seed is a LOCAL copy of the whole database
plus attachments, kept in ``%LOCALAPPDATA%\\TaskList\\seed``:

- While the live database opens, the seed is refreshed from it
  (launch + close), and a per-row hash BASE of that refresh is
  recorded in the seed metadata.
- When the live database cannot be opened at all (IO-class
  failure) and a seed exists, the app opens the SEED instead and
  the session is marked offline-dirty in the metadata.
- On the next successful live open, the merge replays the
  offline session against the live database using the base:
  rows only the seed changed are applied; rows only live
  changed are kept; rows BOTH changed become conflicts --
  the live row is kept, the offline row is stored for review
  in Settings -> Offline, and nothing is silently overwritten.

Stdlib only (sqlite3), no Qt. Every public function is guarded:
offline machinery must never take the app down with it.
"""

import hashlib
import json
import os
import shutil
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from . import datahome

# Parents first: a child row's foreign key may need the remap
# a parent insert produced.
MERGE_TABLES = ("notebooks", "tasks", "directory", "attachments",
                "notes", "queue", "task_revisions")
# child table -> {fk column: parent table}
FK_REMAP = {
    "attachments": {"task_id": "tasks"},
    "notes": {"notebook_id": "notebooks"},
    "queue": {"task_id": "tasks"},
    "task_revisions": {"task_id": "tasks"},
    "tasks": {"parent_task_id": "tasks"},
}
CONFLICTS_SETTING = "offline_conflicts_v1"


def _log(message):
    try:
        from .startup_log import log_startup_event
        log_startup_event("offline: " + message)
    except Exception:
        pass


def _columns(conn, table):
    try:
        return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
    except Exception:
        return []


def _row_hash(values):
    h = hashlib.sha1()
    h.update(repr(tuple(values)).encode("utf-8", "replace"))
    return h.hexdigest()


def snapshot_hashes(db_path):
    """{table: {pk-as-str: row hash}} for every merge table.

    Read-only and tolerant: a missing table or unreadable file
    yields whatever could be read ({} at worst)."""
    out = {}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except Exception:
        return out
    try:
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        for table in MERGE_TABLES:
            if table not in tables:
                continue
            cols = _columns(conn, table)
            if "id" not in cols:
                continue
            rows = {}
            for row in conn.execute(f"SELECT * FROM {table}"):
                d = dict(zip(cols, row))
                rows[str(d["id"])] = _row_hash(row)
            out[table] = rows
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return out


def _read_rows(db_path, table):
    """{pk-as-str: {column: value}} for one table (read-only)."""
    out = {}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            cols = _columns(conn, table)
            if "id" not in cols:
                return out
            for row in conn.execute(f"SELECT * FROM {table}"):
                d = dict(zip(cols, row))
                out[str(d["id"])] = d
        finally:
            conn.close()
    except Exception:
        pass
    return out


def refresh_seed(primary_db):
    """Copy the live database + attachments into the local seed
    and record the per-row hash base. Returns True on success."""
    try:
        seed_db = datahome.seed_db_path()
        tmp = seed_db.with_suffix(".tmp.db")
        dst = sqlite3.connect(str(tmp))
        try:
            primary_db.conn.backup(dst)
        finally:
            dst.close()
        tmp.replace(seed_db)
        # Mirror attachments (copy new/changed, drop vanished).
        src_att = primary_db.path.parent / "attachments"
        dst_att = datahome.seed_attachments_dir()
        if src_att.is_dir():
            dst_att.mkdir(parents=True, exist_ok=True)
            seen = set()
            for f in src_att.iterdir():
                if not f.is_file():
                    continue
                seen.add(f.name)
                target = dst_att / f.name
                try:
                    if (not target.exists()
                            or target.stat().st_size != f.stat().st_size
                            or target.stat().st_mtime < f.stat().st_mtime):
                        shutil.copy2(f, target)
                except Exception:
                    pass
            for f in dst_att.iterdir():
                if f.is_file() and f.name not in seen:
                    try:
                        f.unlink()
                    except Exception:
                        pass
        meta = datahome.read_seed_meta()
        meta.update({
            "refreshed_at": datetime.now().isoformat(timespec="seconds"),
            "base": snapshot_hashes(seed_db),
            "offline_dirty": False,
        })
        datahome.write_seed_meta(meta)
        _log("seed refreshed")
        return True
    except Exception as exc:  # noqa: BLE001
        _log(f"seed refresh failed: {exc}")
        return False


def mark_offline_dirty():
    try:
        meta = datahome.read_seed_meta()
        meta["offline_dirty"] = True
        datahome.write_seed_meta(meta)
        _log("session marked offline-dirty")
    except Exception:
        pass


def seed_is_dirty():
    try:
        return bool(datahome.read_seed_meta().get("offline_dirty"))
    except Exception:
        return False


def load_conflicts(primary_db):
    try:
        raw = primary_db.get_setting(CONFLICTS_SETTING, "")
        data = json.loads(raw) if raw else []
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _store_conflicts(primary_db, conflicts):
    try:
        primary_db.set_setting(CONFLICTS_SETTING,
                               json.dumps(conflicts))
    except Exception:
        pass


def _upsert_row(conn, table, cols, row):
    names = [c for c in cols if c in row]
    sql = (f"INSERT OR REPLACE INTO {table} "
           f"({', '.join(names)}) VALUES "
           f"({', '.join('?' for _ in names)})")
    conn.execute(sql, [row[c] for c in names])


def _copy_attachment_file(stored):
    """Copy one attachment file seed -> live (merge/resolution)."""
    try:
        src = datahome.seed_attachments_dir() / stored
        if src.is_file():
            return src
    except Exception:
        pass
    return None


def _merge_file_into(primary_db, source_path, base,
                     source_wins=False):
    """Core three-way merge: fold the changes in the SOURCE
    database file (relative to the BASE per-row hashes) into
    the OPEN primary database. Rows only the source changed
    are applied; rows only the primary changed are kept; rows
    BOTH changed become conflicts -- the primary row is kept,
    the source row is stored on the primary for review in
    Settings -> Offline. Returns {"applied": n, "conflicts": m}.
    The source is only ever READ, through read-only connections
    and row snapshots; the primary is written through its own
    connection.

    source_wins (the pull direction: source = network copy,
    primary = this PC's working copy) flips conflict
    resolution: the source version is the one in place, and
    the primary's version becomes the stored alternative --
    see the conflict branch."""
    result = {"applied": 0, "conflicts": 0}
    base = base or {}
    seed_db = Path(source_path)
    seed_hashes = snapshot_hashes(seed_db)
    live_hashes = snapshot_hashes(primary_db.path)
    remap = {t: {} for t in MERGE_TABLES}   # table -> {old id: new id}
    conflicts = load_conflicts(primary_db)
    conn = primary_db.conn
    live_att_dir = primary_db.path.parent / "attachments"
    for table in MERGE_TABLES:
        cols = _columns(conn, table)
        if "id" not in cols:
            continue
        b = base.get(table, {})
        s_hashes = seed_hashes.get(table, {})
        p_hashes = live_hashes.get(table, {})
        # Fresh ids for collision remaps start ABOVE every id in
        # play for this table. An AUTOINCREMENT id can land on a
        # seed id this same pass still has to upsert -- the
        # upsert then silently REPLACEs the just-remapped row
        # (caught in testing: the remapped row vanished).
        _all_pks = [int(k) for k in
                    set(b) | set(s_hashes) | set(p_hashes)
                    if k.isdigit()]
        next_fresh = max(_all_pks, default=0)
        seed_rows = None          # lazy: only read when needed
        for pk in sorted(set(b) | set(s_hashes) | set(p_hashes),
                         key=lambda v: int(v) if v.isdigit() else 0):
            sv, bv, pv = s_hashes.get(pk), b.get(pk), p_hashes.get(pk)
            if sv == bv:
                continue            # offline session didn't touch it
            if seed_rows is None:
                seed_rows = _read_rows(seed_db, table)
            srow = seed_rows.get(pk)
            # Translate foreign keys through any parent remap.
            if srow is not None:
                srow = dict(srow)
                for fk, parent in FK_REMAP.get(table, {}).items():
                    if fk in srow and srow[fk] is not None:
                        new = remap[parent].get(str(srow[fk]))
                        if new is not None:
                            srow[fk] = new
            if pv == bv:
                # Live didn't change it (or never had it, and the
                # base didn't either): apply the offline state.
                if srow is None:
                    conn.execute(f"DELETE FROM {table} WHERE id=?",
                                 (int(pk),))
                    result["applied"] += 1
                    continue
                if bv is None and pv is not None:
                    pass  # id taken by a different new live row: remap below
                else:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow)
                    continue
            if sv == pv:
                continue            # both made the same change
            if bv is None and pv is not None and srow is not None:
                if source_wins:
                    # Pull direction: the source keeps the id
                    # (it is the canonical network row); the
                    # primary's own row moves to a fresh id
                    # and its children in the primary follow.
                    # Both rows survive.
                    next_fresh += 1
                    conn.execute(
                        f"UPDATE {table} SET id=? WHERE id=?",
                        (next_fresh, int(pk)))
                    for _child, _fks in FK_REMAP.items():
                        for _fk, _parent in _fks.items():
                            if _parent == table and \
                                    _fk in _columns(conn, _child):
                                conn.execute(
                                    f"UPDATE {_child} SET {_fk}=? "
                                    f"WHERE {_fk}=?",
                                    (next_fresh, int(pk)))
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow)
                    continue
                # Both sides created a row with the same id.
                # The offline row moves to a fresh id (explicit,
                # above every id in play -- see next_fresh);
                # children pick the new id up through the remap.
                next_fresh += 1
                fresh = dict(srow)
                fresh["id"] = next_fresh
                _upsert_row(conn, table, cols, fresh)
                remap[table][pk] = next_fresh
                result["applied"] += 1
                if table == "attachments":
                    _place_attachment(primary_db, live_att_dir, srow)
                continue
            # Both changed the same row differently: conflict.
            # Live wins in place; the offline row is kept for
            # review in Settings -> Offline. (Read through the
            # live connection: earlier merge writes in this same
            # pass are not on disk yet.)
            live_row = None
            try:
                cur = conn.execute(
                    f"SELECT * FROM {table} WHERE id=?", (int(pk),))
                got = cur.fetchone()
                if got is not None:
                    live_row = dict(zip(cols, got))
            except Exception:
                pass
            if source_wins:
                # Pull direction: the SOURCE (network) version
                # is the one in place. Both-edited: it is
                # upserted over the primary's row, and the
                # primary's version becomes the stored
                # alternative. Delete/edit crossings keep the
                # in-place state and store the other side as
                # the alternative (a stored seed of None
                # applies as a delete if the user switches --
                # see resolve_conflict).
                if srow is not None and live_row is not None:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow)
                    conflicts.append({
                        "table": table, "id": pk,
                        "seed": live_row, "live": srow,
                        "at": datetime.now().isoformat(
                            timespec="seconds"),
                    })
                elif srow is not None:
                    conflicts.append({
                        "table": table, "id": pk,
                        "seed": srow, "live": None,
                        "at": datetime.now().isoformat(
                            timespec="seconds"),
                    })
                else:
                    conflicts.append({
                        "table": table, "id": pk,
                        "seed": None, "live": live_row,
                        "at": datetime.now().isoformat(
                            timespec="seconds"),
                    })
            else:
                conflicts.append({
                    "table": table, "id": pk,
                    "seed": srow, "live": live_row,
                    "at": datetime.now().isoformat(
                        timespec="seconds"),
                })
            result["conflicts"] += 1
    try:
        conn.commit()
    except Exception:
        pass
    _store_conflicts(primary_db, conflicts)
    _log(f"merge done: {result['applied']} applied, "
         f"{result['conflicts']} conflicts")
    return result


def merge_seed_into(primary_db):
    """Replay the offline session into the live database.

    Returns {"applied": n, "conflicts": m}. Live rows win
    conflicts; the offline version is stored for review.
    Afterwards the seed is refreshed from the merged live
    database (new base, dirty flag cleared)."""
    result = {"applied": 0, "conflicts": 0}
    if not datahome.seed_exists():
        return result
    meta = datahome.read_seed_meta()
    result = _merge_file_into(
        primary_db, datahome.seed_db_path(), meta.get("base") or {})
    refresh_seed(primary_db)
    return result



def _place_attachment(primary_db, live_att_dir, row):
    try:
        stored = row.get("stored")
        if not stored:
            return
        src = _copy_attachment_file(stored)
        if src is not None:
            live_att_dir.mkdir(parents=True, exist_ok=True)
            target = live_att_dir / stored
            if not target.exists():
                shutil.copy2(src, target)
    except Exception:
        pass


def resolve_conflict(primary_db, index, use_offline):
    """Apply one stored conflict decision. use_offline replaces
    the live row with the offline one; otherwise the offline
    version is discarded. Either way the entry is removed."""
    conflicts = load_conflicts(primary_db)
    if not (0 <= index < len(conflicts)):
        return False
    entry = conflicts.pop(index)
    ok = True
    if use_offline:
        try:
            table = entry["table"]
            srow = entry.get("seed")
            if srow is None:
                primary_db.conn.execute(
                    f"DELETE FROM {table} WHERE id=?",
                    (int(entry["id"]),))
            else:
                cols = _columns(primary_db.conn, table)
                _upsert_row(primary_db.conn, table, cols, srow)
                if table == "attachments":
                    _place_attachment(
                        primary_db,
                        primary_db.path.parent / "attachments", srow)
            primary_db.conn.commit()
        except Exception as exc:  # noqa: BLE001
            _log(f"conflict resolution failed: {exc}")
            ok = False
    _store_conflicts(primary_db, conflicts)
    return ok


# ------------------------------------------------------------------
# V1.9.68 FILESYNC (user, 2026-11-14: "THIS HAS TO WORK AND STAY
# UP TO DATE ON BOTH MACHINES. Without OFFLINE ERRORS AND SYNC
# ERRORS"): the session ALWAYS runs on the local working copy
# (the seed file). The network database is NEVER opened by
# SQLite -- not for reading, not for writing. It moves only as
# whole-file copies:
#
# - PULL: copy the network db + its -wal into a local temp,
#   three-way-merge the copy into the working copy (base = the
#   last network state both sides agreed on).
# - PUSH: snapshot the working copy locally, then -- under a
#   lock file, after a generation check -- replace the network
#   file with the snapshot in one rename and bump the stamp.
#
# Whole-file copies are the one thing the redirected-folder
# cache and the share do reliably; SQLite opens only ever
# happen on a local disk, so the "disk I/O error" class cannot
# occur. There is no offline mode and nothing to surface to
# the user: sync runs at launch, in the background while the
# app runs, and at close; a missed cycle retries on the next.
# ------------------------------------------------------------------
STAMP_NAME = "tasks.sync.json"
LOCK_NAME = "tasks.db.sync-lock"
LOCK_STALE_SECONDS = 180


def _meta_update(**kw):
    try:
        meta = datahome.read_seed_meta()
        meta.update(kw)
        datahome.write_seed_meta(meta)
    except Exception:
        pass


def _live_sig(live_path):
    """Cheap change signature of the network file set (stat
    only, never an open): db + wal mtimes/sizes, or None when
    the database file itself is not there."""
    try:
        live = Path(live_path)
        st = live.stat()
        sig = f"{st.st_mtime_ns}:{st.st_size}"
        wal = Path(str(live) + "-wal")
        try:
            wst = wal.stat()
            sig += f":{wst.st_mtime_ns}:{wst.st_size}"
        except Exception:
            sig += ":0:0"
        return sig
    except Exception:
        return None


def _read_stamp(live_path):
    try:
        return json.loads((Path(live_path).parent / STAMP_NAME
                           ).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_stamp(live_path, gen):
    try:
        import socket
        (Path(live_path).parent / STAMP_NAME).write_text(
            json.dumps({"gen": gen,
                        "by": socket.gethostname(),
                        "at": datetime.now().isoformat(
                            timespec="seconds")}),
            encoding="utf-8")
    except Exception:
        pass


def _copy_live_snapshot(live_path, dest_dir):
    """Copy the network db (+ its -wal, never the -shm) into a
    LOCAL folder and verify the copy opens. Returns the copied
    db path, or None. Two attempts: a copy torn by a concurrent
    checkpoint fails verification and is retried."""
    live = Path(live_path)
    dest_dir = Path(dest_dir)
    for _attempt in range(2):
        try:
            if dest_dir.exists():
                shutil.rmtree(dest_dir, ignore_errors=True)
            dest_dir.mkdir(parents=True, exist_ok=True)
            dst = dest_dir / "tasks.db"
            shutil.copy2(live, dst)
            wal = Path(str(live) + "-wal")
            if wal.is_file():
                shutil.copy2(wal, dest_dir / "tasks.db-wal")
            conn = sqlite3.connect(str(dst))
            try:
                conn.execute(
                    "SELECT COUNT(*) FROM sqlite_master").fetchone()
            finally:
                conn.close()
            return dst
        except Exception as exc:  # noqa: BLE001
            _log(f"live copy failed: {exc!r}")
    return None


def _install_working_file(src_db):
    """Replace the local working file with src_db's content and
    drop the working file's own sidecars. Pre-session only: no
    connection is open on it, and its sidecars belong to the
    content being replaced."""
    working = datahome.seed_db_path()
    tmp = working.with_suffix(".install.db")
    shutil.copy2(src_db, tmp)
    tmp.replace(working)
    for suffix in ("-wal", "-shm"):
        try:
            Path(str(working) + suffix).unlink()
        except Exception:
            pass


def _mirror_attachments_from(live_db_path):
    """Mirror the network attachments folder into the local
    seed attachments (copy new or changed, drop vanished --
    the refresh_seed rule). Plain file copies only."""
    try:
        src_att = Path(live_db_path).parent / "attachments"
        dst_att = datahome.seed_attachments_dir()
        if not src_att.is_dir():
            return
        dst_att.mkdir(parents=True, exist_ok=True)
        seen = set()
        for f in src_att.iterdir():
            if not f.is_file():
                continue
            seen.add(f.name)
            target = dst_att / f.name
            try:
                if (not target.exists()
                        or target.stat().st_size != f.stat().st_size
                        or target.stat().st_mtime < f.stat().st_mtime):
                    shutil.copy2(f, target)
            except Exception:
                pass
        for f in dst_att.iterdir():
            if f.is_file() and f.name not in seen:
                try:
                    f.unlink()
                except Exception:
                    pass
    except Exception:
        pass


def launch_sync(live_path):
    """Pre-session: make the local working copy current with
    the network database and return the working path. Never
    raises; never opens SQLite on the network path. When the
    network file cannot be read, the existing working copy is
    used exactly as it stands."""
    working = datahome.seed_db_path()
    try:
        live = Path(live_path)
        if live.is_file():
            snap = _copy_live_snapshot(
                live, datahome.seed_dir() / "sync_tmp")
            if snap is not None:
                pulled = snapshot_hashes(snap)
                meta = datahome.read_seed_meta()
                base = meta.get("base") or {}
                if not working.exists():
                    _install_working_file(snap)
                elif snapshot_hashes(working) == pulled:
                    pass  # already current
                elif snapshot_hashes(working) == base:
                    _install_working_file(snap)   # clean: take theirs
                else:
                    _mirror_attachments_from(live)
                    from .db import TaskDatabase
                    wdb = TaskDatabase(working)
                    try:
                        _merge_file_into(wdb, snap, base,
                                         source_wins=True)
                    finally:
                        wdb.conn.close()
                _mirror_attachments_from(live)
                now = datetime.now().isoformat(timespec="seconds")
                _meta_update(
                    base=pulled,
                    live_gen=(_read_stamp(live).get("gen") or 0),
                    live_sig=_live_sig(live),
                    refreshed_at=now, last_sync_at=now,
                    last_sync_ok=True,
                    offline_dirty=(
                        snapshot_hashes(working) != pulled))
    except Exception as exc:  # noqa: BLE001
        _log(f"launch sync failed: {exc!r}")
    return working


def pull_into_open(working_db, live_path):
    """Fold the network database's changes into a working
    database. The working_db passed in must belong to the
    calling thread (callers on a worker thread open their own
    connection to the working file; SQLite serializes the
    writers). Returns a result dict; never raises."""
    out = {"ok": False, "changed": False,
           "applied": 0, "conflicts": 0}
    try:
        live = Path(live_path)
        if not live.is_file():
            return out
        meta = datahome.read_seed_meta()
        sig_before = _live_sig(live)
        gen = _read_stamp(live).get("gen") or 0
        if (sig_before is not None
                and sig_before == meta.get("live_sig")
                and gen == (meta.get("live_gen") or 0)):
            out["ok"] = True
            return out
        snap = _copy_live_snapshot(
            live, datahome.seed_dir() / "sync_tmp")
        if snap is None:
            return out
        if _live_sig(live) != sig_before:
            snap = _copy_live_snapshot(
                live, datahome.seed_dir() / "sync_tmp")
            if snap is None:
                return out
        pulled = snapshot_hashes(snap)
        _mirror_attachments_from(live)
        res = _merge_file_into(working_db, snap,
                               meta.get("base") or {},
                               source_wins=True)
        now = datetime.now().isoformat(timespec="seconds")
        _meta_update(
            base=pulled,
            live_gen=(_read_stamp(live).get("gen") or 0),
            live_sig=_live_sig(live),
            refreshed_at=now, last_sync_at=now,
            last_sync_ok=True,
            offline_dirty=(
                snapshot_hashes(working_db.path) != pulled))
        out.update({"ok": True, "changed": True, **res})
    except Exception as exc:  # noqa: BLE001
        _log(f"pull failed: {exc!r}")
    return out


def push_from_open(working_db, live_path):
    """Replace the network database with a snapshot of the
    working copy, under the lock + generation protocol.
    Returns "pushed", "clean" (nothing to send), "deferred"
    (lock held, a legacy in-place session has the file open,
    or the network is unreachable) or "raced" (the other PC
    pushed first -- pull, then retry). Never raises."""
    try:
        live = Path(live_path)
        if not live.is_file():
            return "deferred"
        meta = datahome.read_seed_meta()
        base = meta.get("base") or {}
        if snapshot_hashes(working_db.path) == base:
            return "clean"
        wal = Path(str(live) + "-wal")
        try:
            if wal.is_file() and wal.stat().st_size > 0:
                _log("push deferred: network database has a live "
                     "journal (an in-place session has it open)")
                return "deferred"
        except Exception:
            pass
        lock = live.parent / LOCK_NAME
        have_lock = False
        for _attempt in range(2):
            try:
                fd = os.open(str(lock),
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, json.dumps({
                    "pid": os.getpid(),
                    "at": datetime.now().isoformat(
                        timespec="seconds")}).encode())
                os.close(fd)
                have_lock = True
                break
            except FileExistsError:
                try:
                    age = time.time() - lock.stat().st_mtime
                except Exception:
                    age = LOCK_STALE_SECONDS + 1
                if age > LOCK_STALE_SECONDS:
                    try:
                        lock.unlink()
                    except Exception:
                        pass
                    continue
                return "deferred"
            except Exception:
                return "deferred"
        if not have_lock:
            return "deferred"
        try:
            gen = _read_stamp(live).get("gen") or 0
            if gen != (meta.get("live_gen") or 0):
                return "raced"
            snap_tmp = datahome.seed_dir() / "push_tmp.db"
            try:
                snap_tmp.unlink()
            except Exception:
                pass
            dst = sqlite3.connect(str(snap_tmp))
            try:
                working_db.conn.backup(dst)
            finally:
                dst.close()
            new_hashes = snapshot_hashes(snap_tmp)
            upload = live.parent / "tasks.db.new"
            shutil.copy2(snap_tmp, upload)
            os.replace(upload, live)
            for suffix in ("-wal", "-shm"):
                try:
                    Path(str(live) + suffix).unlink()
                except Exception:
                    pass
            _write_stamp(live, gen + 1)
            now = datetime.now().isoformat(timespec="seconds")
            _meta_update(
                base=new_hashes, live_gen=gen + 1,
                live_sig=_live_sig(live),
                refreshed_at=now, last_sync_at=now,
                last_sync_ok=True,
                offline_dirty=(
                    snapshot_hashes(working_db.path) != new_hashes))
            _log(f"pushed (gen {gen + 1})")
            return "pushed"
        finally:
            try:
                lock.unlink()
            except Exception:
                pass
    except Exception as exc:  # noqa: BLE001
        _log(f"push failed: {exc!r}")
        return "deferred"


def sync_once(working_db, live_path):
    """One background cycle: pull, then push. Never raises."""
    out = {"ok": False, "pulled": None, "pushed": None}
    try:
        out["pulled"] = pull_into_open(working_db, live_path)
        out["pushed"] = push_from_open(working_db, live_path)
        out["ok"] = bool(
            (out["pulled"] or {}).get("ok")
            and out["pushed"] in ("pushed", "clean"))
        _meta_update(
            last_sync_at=datetime.now().isoformat(timespec="seconds"),
            last_sync_ok=out["ok"])
    except Exception as exc:  # noqa: BLE001
        _log(f"sync cycle failed: {exc!r}")
    return out
