"""Offline seed + journaled merge (V1.9.50).

The live database can live on a network share (the user's data
was trapped in a redirected Documents folder whose offline-files
cache poisoned its WAL sidecars -- the 2026-11-13 "disk I/O
error" lockout). The seed is a LOCAL copy of the whole database
plus attachments, kept in ``%LOCALAPPDATA%\\TaskList\\seed``:

- While the live database opens, the seed is refreshed from it
  (launch + close), and a per-row hash BASE of that refresh is
  recorded in the seed metadata.
- When the live database cannot be opened at all (IO-class
  failure) and a seed exists, the app opens the SEED instead and
  the session is marked offline-dirty in the metadata.
- On the next successful live open, the merge replays the
  offline session against the live database using the base:
  rows only the seed changed are applied; rows only live
  changed are kept; rows BOTH changed become conflicts --
  the live row is kept, the offline row is stored for review
  in Settings -> Offline, and nothing is silently overwritten.

Stdlib only (sqlite3), no Qt. Every public function is guarded:
offline machinery must never take the app down with it.
"""

import hashlib
import json
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from . import datahome

# Parents first: a child row's foreign key may need the remap
# a parent insert produced.
MERGE_TABLES = ("notebooks", "tasks", "directory", "attachments",
                "notes", "queue", "task_revisions")
# child table -> {fk column: parent table}
FK_REMAP = {
    "attachments": {"task_id": "tasks"},
    "notes": {"notebook_id": "notebooks"},
    "queue": {"task_id": "tasks"},
    "task_revisions": {"task_id": "tasks"},
    "tasks": {"parent_task_id": "tasks"},
}
CONFLICTS_SETTING = "offline_conflicts_v1"


def _log(message):
    try:
        from .startup_log import log_startup_event
        log_startup_event("offline: " + message)
    except Exception:
        pass


def _columns(conn, table):
    try:
        return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
    except Exception:
        return []


def _row_hash(values):
    h = hashlib.sha1()
    h.update(repr(tuple(values)).encode("utf-8", "replace"))
    return h.hexdigest()


def snapshot_hashes(db_path):
    """{table: {pk-as-str: row hash}} for every merge table.

    Read-only and tolerant: a missing table or unreadable file
    yields whatever could be read ({} at worst)."""
    out = {}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except Exception:
        return out
    try:
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        for table in MERGE_TABLES:
            if table not in tables:
                continue
            cols = _columns(conn, table)
            if "id" not in cols:
                continue
            rows = {}
            for row in conn.execute(f"SELECT * FROM {table}"):
                d = dict(zip(cols, row))
                rows[str(d["id"])] = _row_hash(row)
            out[table] = rows
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return out


def _read_rows(db_path, table):
    """{pk-as-str: {column: value}} for one table (read-only)."""
    out = {}
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            cols = _columns(conn, table)
            if "id" not in cols:
                return out
            for row in conn.execute(f"SELECT * FROM {table}"):
                d = dict(zip(cols, row))
                out[str(d["id"])] = d
        finally:
            conn.close()
    except Exception:
        pass
    return out


def refresh_seed(primary_db):
    """Copy the live database + attachments into the local seed
    and record the per-row hash base. Returns True on success."""
    try:
        seed_db = datahome.seed_db_path()
        tmp = seed_db.with_suffix(".tmp.db")
        dst = sqlite3.connect(str(tmp))
        try:
            primary_db.conn.backup(dst)
        finally:
            dst.close()
        tmp.replace(seed_db)
        # Mirror attachments (copy new/changed, drop vanished).
        src_att = primary_db.path.parent / "attachments"
        dst_att = datahome.seed_attachments_dir()
        if src_att.is_dir():
            dst_att.mkdir(parents=True, exist_ok=True)
            seen = set()
            for f in src_att.iterdir():
                if not f.is_file():
                    continue
                seen.add(f.name)
                target = dst_att / f.name
                try:
                    if (not target.exists()
                            or target.stat().st_size != f.stat().st_size
                            or target.stat().st_mtime < f.stat().st_mtime):
                        shutil.copy2(f, target)
                except Exception:
                    pass
            for f in dst_att.iterdir():
                if f.is_file() and f.name not in seen:
                    try:
                        f.unlink()
                    except Exception:
                        pass
        meta = datahome.read_seed_meta()
        meta.update({
            "refreshed_at": datetime.now().isoformat(timespec="seconds"),
            "base": snapshot_hashes(seed_db),
            "offline_dirty": False,
        })
        datahome.write_seed_meta(meta)
        _log("seed refreshed")
        return True
    except Exception as exc:  # noqa: BLE001
        _log(f"seed refresh failed: {exc}")
        return False


def mark_offline_dirty():
    try:
        meta = datahome.read_seed_meta()
        meta["offline_dirty"] = True
        datahome.write_seed_meta(meta)
        _log("session marked offline-dirty")
    except Exception:
        pass


def seed_is_dirty():
    try:
        return bool(datahome.read_seed_meta().get("offline_dirty"))
    except Exception:
        return False


def load_conflicts(primary_db):
    try:
        raw = primary_db.get_setting(CONFLICTS_SETTING, "")
        data = json.loads(raw) if raw else []
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _store_conflicts(primary_db, conflicts):
    try:
        primary_db.set_setting(CONFLICTS_SETTING,
                               json.dumps(conflicts))
    except Exception:
        pass


def _upsert_row(conn, table, cols, row):
    names = [c for c in cols if c in row]
    sql = (f"INSERT OR REPLACE INTO {table} "
           f"({', '.join(names)}) VALUES "
           f"({', '.join('?' for _ in names)})")
    conn.execute(sql, [row[c] for c in names])


def _copy_attachment_file(stored):
    """Copy one attachment file seed -> live (merge/resolution)."""
    try:
        src = datahome.seed_attachments_dir() / stored
        if src.is_file():
            return src
    except Exception:
        pass
    return None


def merge_seed_into(primary_db):
    """Replay the offline session into the live database.

    Returns {"applied": n, "conflicts": m}. Live rows win
    conflicts; the offline version is stored for review.
    Afterwards the seed is refreshed from the merged live
    database (new base, dirty flag cleared)."""
    result = {"applied": 0, "conflicts": 0}
    if not datahome.seed_exists():
        return result
    meta = datahome.read_seed_meta()
    base = meta.get("base") or {}
    seed_db = datahome.seed_db_path()
    seed_hashes = snapshot_hashes(seed_db)
    live_hashes = snapshot_hashes(primary_db.path)
    remap = {t: {} for t in MERGE_TABLES}   # table -> {old id: new id}
    conflicts = load_conflicts(primary_db)
    conn = primary_db.conn
    live_att_dir = primary_db.path.parent / "attachments"
    for table in MERGE_TABLES:
        cols = _columns(conn, table)
        if "id" not in cols:
            continue
        b = base.get(table, {})
        s_hashes = seed_hashes.get(table, {})
        p_hashes = live_hashes.get(table, {})
        # Fresh ids for collision remaps start ABOVE every id in
        # play for this table. An AUTOINCREMENT id can land on a
        # seed id this same pass still has to upsert -- the
        # upsert then silently REPLACEs the just-remapped row
        # (caught in testing: the remapped row vanished).
        _all_pks = [int(k) for k in
                    set(b) | set(s_hashes) | set(p_hashes)
                    if k.isdigit()]
        next_fresh = max(_all_pks, default=0)
        seed_rows = None          # lazy: only read when needed
        for pk in sorted(set(b) | set(s_hashes) | set(p_hashes),
                         key=lambda v: int(v) if v.isdigit() else 0):
            sv, bv, pv = s_hashes.get(pk), b.get(pk), p_hashes.get(pk)
            if sv == bv:
                continue            # offline session didn't touch it
            if seed_rows is None:
                seed_rows = _read_rows(seed_db, table)
            srow = seed_rows.get(pk)
            # Translate foreign keys through any parent remap.
            if srow is not None:
                srow = dict(srow)
                for fk, parent in FK_REMAP.get(table, {}).items():
                    if fk in srow and srow[fk] is not None:
                        new = remap[parent].get(str(srow[fk]))
                        if new is not None:
                            srow[fk] = new
            if pv == bv:
                # Live didn't change it (or never had it, and the
                # base didn't either): apply the offline state.
                if srow is None:
                    conn.execute(f"DELETE FROM {table} WHERE id=?",
                                 (int(pk),))
                    result["applied"] += 1
                    continue
                if bv is None and pv is not None:
                    pass  # id taken by a different new live row: remap below
                else:
                    _upsert_row(conn, table, cols, srow)
                    result["applied"] += 1
                    if table == "attachments":
                        _place_attachment(primary_db, live_att_dir,
                                          srow)
                    continue
            if sv == pv:
                continue            # both made the same change
            if bv is None and pv is not None and srow is not None:
                # Both sides created a row with the same id.
                # The offline row moves to a fresh id (explicit,
                # above every id in play -- see next_fresh);
                # children pick the new id up through the remap.
                next_fresh += 1
                fresh = dict(srow)
                fresh["id"] = next_fresh
                _upsert_row(conn, table, cols, fresh)
                remap[table][pk] = next_fresh
                result["applied"] += 1
                if table == "attachments":
                    _place_attachment(primary_db, live_att_dir, srow)
                continue
            # Both changed the same row differently: conflict.
            # Live wins in place; the offline row is kept for
            # review in Settings -> Offline. (Read through the
            # live connection: earlier merge writes in this same
            # pass are not on disk yet.)
            live_row = None
            try:
                cur = conn.execute(
                    f"SELECT * FROM {table} WHERE id=?", (int(pk),))
                got = cur.fetchone()
                if got is not None:
                    live_row = dict(zip(cols, got))
            except Exception:
                pass
            conflicts.append({
                "table": table, "id": pk,
                "seed": srow, "live": live_row,
                "at": datetime.now().isoformat(timespec="seconds"),
            })
            result["conflicts"] += 1
    try:
        conn.commit()
    except Exception:
        pass
    _store_conflicts(primary_db, conflicts)
    _log(f"merge done: {result['applied']} applied, "
         f"{result['conflicts']} conflicts")
    refresh_seed(primary_db)
    return result


def _place_attachment(primary_db, live_att_dir, row):
    try:
        stored = row.get("stored")
        if not stored:
            return
        src = _copy_attachment_file(stored)
        if src is not None:
            live_att_dir.mkdir(parents=True, exist_ok=True)
            target = live_att_dir / stored
            if not target.exists():
                shutil.copy2(src, target)
    except Exception:
        pass


def resolve_conflict(primary_db, index, use_offline):
    """Apply one stored conflict decision. use_offline replaces
    the live row with the offline one; otherwise the offline
    version is discarded. Either way the entry is removed."""
    conflicts = load_conflicts(primary_db)
    if not (0 <= index < len(conflicts)):
        return False
    entry = conflicts.pop(index)
    ok = True
    if use_offline:
        try:
            table = entry["table"]
            srow = entry.get("seed")
            if srow is None:
                primary_db.conn.execute(
                    f"DELETE FROM {table} WHERE id=?",
                    (int(entry["id"]),))
            else:
                cols = _columns(primary_db.conn, table)
                _upsert_row(primary_db.conn, table, cols, srow)
                if table == "attachments":
                    _place_attachment(
                        primary_db,
                        primary_db.path.parent / "attachments", srow)
            primary_db.conn.commit()
        except Exception as exc:  # noqa: BLE001
            _log(f"conflict resolution failed: {exc}")
            ok = False
    _store_conflicts(primary_db, conflicts)
    return ok
