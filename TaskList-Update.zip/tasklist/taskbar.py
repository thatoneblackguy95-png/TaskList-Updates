"""Windows taskbar integration for Task List (v1.5.9).

Problem (user 2026-09-30): right-clicking the running Task List icon in the
taskbar offers no "Pin to taskbar". Root cause: the app is launched via
`Task List.bat` -> pythonw.exe, so Windows groups the window under the
generic "Python" host instead of under Task List itself.

Fix, two parts:
1. The app sets an explicit AppUserModelID
   ("TaskList.TaskList") at startup, before any window exists. Windows then
   treats the window as its own app: correct grouping, correct icon, and
   the Pin to taskbar verb appears.
2. `create_pinnable_shortcut()` builds `Task List.lnk` shortcuts (via
   IShellLink, pure ctypes -- no pywin32 needed) targeting the proven .bat,
   with the app icon and the SAME AppUserModelID stamped on each shortcut
   (IPropertyStore / PKEY_AppUserModelID):
   - Start Menu\\Programs\\Task List.lnk: the one Windows resolves when the
     user right-clicks the RUNNING app and chooses Pin to taskbar, so the
     pinned icon launches Task List correctly.
   - Task List.lnk next to the launcher: visible copy the user can drag
     straight onto the taskbar.
   A pinned shortcut whose AppUserModelID matches the running window groups
   correctly and launches the app when clicked.

All Windows API use is guarded: importing this module or calling its
functions on any other OS is a safe no-op returning False.

V1.9.16 pin fixes (user 2026-10-28: right-click on the running icon
still shows only "Close window"):
- The Start Menu shortcut is what Windows resolves for right-click ->
  Pin on the running app, but it was only created when the user found
  File -> Pin to Taskbar. It is now also created automatically at
  startup when missing (ensure_start_menu_shortcut), so right-click
  Pin appears without any menu hunting.
- File -> Pin to Taskbar now ALSO writes the shortcut straight into
  the pinned TaskBar folder, so it pins immediately instead of only
  preparing a shortcut and telling the user to right-click.
- Shortcut targets always point at the LAUNCHER folder (the share
  .bat), never at the local mirror: a mirror .bat would compare the
  mirror version against itself and launch stale code forever after a
  patch. launcher_root() resolves the share folder from
  TASKLIST_DATA_DIR when the app runs mirrored.
"""

import os
import sys
from pathlib import Path

APP_ID = "TaskList.TaskList"


def _is_windows():
    return sys.platform == "win32"


# ---------------------------------------------------------------- startup

def set_app_user_model_id(app_id=APP_ID):
    """Set the process AppUserModelID. Call before any window is created.

    Returns True if the ID was set, False on non-Windows or on failure.
    Never raises.
    """
    if not _is_windows():
        return False
    try:
        import ctypes
        from ctypes import wintypes
        shell32 = ctypes.windll.shell32
        shell32.SetCurrentProcessExplicitAppUserModelID.argtypes = [
            wintypes.LPCWSTR]
        shell32.SetCurrentProcessExplicitAppUserModelID.restype = \
            wintypes.HRESULT
        hr = shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
        if hr != 0:
            # V1.9.51: the user's startup.log showed this returning
            # False on EVERY launch with no reason recorded. Log the
            # raw HRESULT so the failing layer is named, not guessed.
            try:
                from .startup_log import log_startup_event
                log_startup_event(
                    f"taskbar: SetCurrentProcessExplicitAppUserModelID "
                    f"hr={hr & 0xFFFFFFFF:#010x}")
            except Exception:
                pass
        return hr == 0  # S_OK
    except Exception:
        return False


def register_app_identity(app_id=APP_ID, display_name="Task List"):
    """Register the AppUserModelID itself (V1.9.50).

    HKCU\\Software\\Classes\\AppUserModelId\\<id> with
    DisplayName + IconUri is the registration an installer
    normally writes; without it Windows has no name/icon to
    resolve for the ID, and the taskbar falls back to the host
    executable ("Python") for the running window's hover title
    and jump list -- exactly the user's screenshot, and the
    same failure Drawing Finder fixed this way in its v1.0.31.
    Written every launch (idempotent), read back to verify.
    Windows-only; never raises; returns True when the values
    are in place."""
    if not _is_windows():
        return False
    try:
        import winreg
        icon = ""
        try:
            target = launcher_target()
            if target.is_file():
                icon = str(target)
        except Exception:
            icon = ""
        key_path = rf"Software\Classes\AppUserModelId\{app_id}"
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, key_path,
                                0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "DisplayName", 0, winreg.REG_SZ,
                              display_name)
            if icon:
                winreg.SetValueEx(key, "IconUri", 0, winreg.REG_SZ,
                                  icon)
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path,
                            0, winreg.KEY_READ) as key:
            name, _ = winreg.QueryValueEx(key, "DisplayName")
        return name == display_name
    except Exception:
        return False


def _window_icon_resource():
    """Icon resource string ("<path>,0") for the relaunch stamp.

    V1.9.48: prefer the LAUNCHER EXE itself — it embeds the app
    icon, lives outside the mirrored code folder, and cannot go
    missing the way an .ico on the share (or inside a refreshed
    mirror) can; a relaunch icon pointing at a vanished file is
    one way the taskbar falls back to the Python identity.
    Falls back to the share tl_icon.ico, then the local copy.
    Returns "" when none exists.
    """
    try:
        target = launcher_target()
        if target.suffix.lower() == ".exe" and target.is_file():
            return f"{target},0"
        share_icon = (launcher_root() / "tasklist" / "assets"
                      / "tl_icon.ico")
        if share_icon.is_file():
            return f"{share_icon},0"
        local_icon = Path(__file__).resolve().parent / "assets" / "tl_icon.ico"
        if local_icon.is_file():
            return f"{local_icon},0"
    except Exception:
        pass
    return ""


def _window_relaunch_command():
    """RelaunchCommand string for the window stamp (V1.9.48).

    The command Windows uses for Pin to taskbar / jump-list
    relaunch: the real launcher exe, quoted. Without it the
    running window had an identity but nothing to relaunch AS,
    and the Pin verb stayed missing. Returns "" when the
    launcher cannot be found."""
    try:
        target = preferred_launcher_target()
        if target.is_file():
            return f'"{target}"'
    except Exception:
        pass
    return ""


def stamp_window_identity(hwnd, app_id=APP_ID):
    """Stamp a top-level window's OWN property store (V1.9.34).

    The taskbar button reads the WINDOW's property store first —
    before the process AppUserModelID and before any shortcut. The
    process-level ID alone was not enough on the user's machine
    (the running app's button said "Python", with the Python icon
    and no Pin to taskbar verb): with no per-window stamp, Windows
    resolved the button's name and icon from pythonw.exe. Stamping
    PKEY_AppUserModel_ID + PKEY_AppUserModel_RelaunchIconResource
    on the window itself pins its identity to Task List on every
    launch path; the display name then resolves from the Start
    Menu "Task List" shortcut that carries the same ID
    (ensure_start_menu_shortcut). Windows-only; never raises;
    returns True on success.
    """
    if not _is_windows() or not hwnd:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        GUID = _new_guid_struct(ctypes, wintypes)

        class PROPERTYKEY(ctypes.Structure):
            _fields_ = [("fmtid", GUID),
                        ("pid", wintypes.DWORD)]

        class PROPVARIANT(ctypes.Structure):
            _fields_ = [("vt", wintypes.USHORT),
                        ("wReserved1", wintypes.USHORT),
                        ("wReserved2", wintypes.USHORT),
                        ("wReserved3", wintypes.USHORT),
("pwszVal", wintypes.LPWSTR),
                        ("_pad", ctypes.c_ubyte * 8)]

        ole32 = ctypes.windll.ole32
        shell32 = ctypes.windll.shell32
        ole32.CoInitialize.argtypes = [ctypes.c_void_p]
        ole32.CoInitialize.restype = wintypes.HRESULT
        ole32.CoUninitialize.argtypes = []
        ole32.CoUninitialize.restype = None
        shell32.SHGetPropertyStoreForWindow.argtypes = [
            wintypes.HWND, ctypes.POINTER(GUID),
            ctypes.POINTER(ctypes.c_void_p)]
        shell32.SHGetPropertyStoreForWindow.restype = wintypes.HRESULT
        ole32.PropVariantClear.argtypes = [ctypes.POINTER(PROPVARIANT)]
        ole32.PropVariantClear.restype = wintypes.HRESULT

        IID_IPropertyStore = _guid_from_string(
            ole32, GUID, "{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF74}")
        # {9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}: pid 5 = AppUserModelID,
        # pid 3 = RelaunchIconResource.
        fmtid = _guid_from_string(
            ole32, GUID, "{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}")

        ole32.CoInitialize(None)
        try:
            store = ctypes.c_void_p()
            hr = shell32.SHGetPropertyStoreForWindow(
                wintypes.HWND(hwnd), ctypes.byref(IID_IPropertyStore),
                ctypes.byref(store))
            if hr != 0 or not store:
                # V1.9.51: name the failing step in startup.log --
                # "stamped: False" alone diagnosed nothing across
                # three releases of this fight.
                try:
                    from .startup_log import log_startup_event
                    log_startup_event(
                        f"taskbar: SHGetPropertyStoreForWindow "
                        f"hr={hr & 0xFFFFFFFF:#010x}")
                except Exception:
                    pass
                return False
            try:
                def _set(pid, text):
                    pv = PROPVARIANT()
                    pv.vt = 31  # VT_LPWSTR
                    buf = ctypes.create_unicode_buffer(text)
                    pv.pwszVal = ctypes.cast(buf, wintypes.LPWSTR)
                    key = PROPERTYKEY(fmtid, pid)
                    hr_ = _call_vtable(
                        ctypes, store, 6, wintypes.HRESULT,
                        [ctypes.POINTER(PROPERTYKEY),
                         ctypes.POINTER(PROPVARIANT)],
                        ctypes.byref(key), ctypes.byref(pv))
                    ole32.PropVariantClear(ctypes.byref(pv))
                    return hr_ == 0

                ok = _set(5, app_id)
                icon_res = _window_icon_resource()
                if icon_res:
                    ok = _set(3, icon_res) and ok
                # V1.9.48 (user: right-click STILL says Python and
                # Pin to taskbar is STILL gone on 1.9.47): the
                # stamp carried the ID and the icon but no
                # RelaunchCommand (pid 2) -- the jump list had
                # nothing to pin or relaunch as, so Windows fell
                # back to the host process identity. Set it, then
                # READ the ID back: a stamp that cannot be read
                # back did not land, and the caller logs the truth.
                cmd = _window_relaunch_command()
                if cmd:
                    ok = _set(2, cmd) and ok
                # V1.9.50 (user screenshot: the taskbar hover /
                # jump list STILL titled the window "Python").
                # The display name does NOT come from a window
                # property: pid 4 (RelaunchDisplayNameResource)
                # requires an indirect "@file,-id" resource
                # string -- a literal name there is invalid and
                # ignored (proven on Drawing Finder, same
                # machine, v1.0.31). The name resolves from the
                # AppUserModelID REGISTRATION instead --
                # register_app_identity() below writes it
                # (DisplayName + IconUri under HKCU Classes),
                # the layer an installer normally provides.
                if not ok:
                    try:
                        from .startup_log import log_startup_event
                        log_startup_event(
                            "taskbar: a stamp SetValue failed")
                    except Exception:
                        pass
                    return False
                # IPropertyStore::Commit = 7.
                hr = _call_vtable(ctypes, store, 7, wintypes.HRESULT, [])
                if hr != 0:
                    try:
                        from .startup_log import log_startup_event
                        log_startup_event(
                            f"taskbar: stamp Commit "
                            f"hr={hr & 0xFFFFFFFF:#010x}")
                    except Exception:
                        pass
                    return False
                pv = PROPVARIANT()
                hr = _call_vtable(
                    ctypes, store, 5, wintypes.HRESULT,
                    [ctypes.POINTER(PROPERTYKEY),
                     ctypes.POINTER(PROPVARIANT)],
                    ctypes.byref(PROPERTYKEY(fmtid, 5)),
                    ctypes.byref(pv))
                try:
                    landed = (hr == 0 and pv.vt == 31
                              and pv.pwszVal
                              and str(pv.pwszVal) == app_id)
                    if not landed:
                        # V1.9.51: record what the read-back actually
                        # saw (with the PROPVARIANT now its real 24
                        # bytes, this value is trustworthy).
                        try:
                            from .startup_log import log_startup_event
                            log_startup_event(
                                f"taskbar: stamp read-back mismatch "
                                f"(hr={hr & 0xFFFFFFFF:#010x}, "
                                f"vt={pv.vt}, "
                                f"value={pv.pwszVal!r})")
                        except Exception:
                            pass
                finally:
                    ole32.PropVariantClear(ctypes.byref(pv))
                return bool(landed)
            finally:
                _call_vtable(ctypes, store, 2, wintypes.ULONG, [])
        finally:
            ole32.CoUninitialize()
    except Exception:
        return False
    return False


# ------------------------------------------------- shortcut creation (win)

def _app_root():
    # tasklist/taskbar.py -> <portable root>
    return Path(__file__).resolve().parent.parent


def launcher_root():
    """Folder holding the app files the user launches (share root).

    Under the local-mirror launcher (bat through V1.9.28, the Go exe
    since V1.9.29) the code runs from %LOCALAPPDATA% but the launcher
    and data live on the share; TASKLIST_DATA_DIR points at the
    share's data folder, so its parent is the share root. Without the
    env var, the code folder IS the launcher folder. Never raises;
    falls back to the code folder.
    """
    try:
        data_dir = os.environ.get("TASKLIST_DATA_DIR", "").strip()
        if data_dir:
            parent = Path(data_dir).parent
            if any((parent / name).is_file() for name in
                   ("Task List.exe", "Task List.bat", "Task List.pyw")):
                return parent
    except Exception:
        pass
    return _app_root()


def launcher_target():
    """The file shortcuts should point at (V1.9.29).

    Preference order: the real exe OUTSIDE the files folder (the
    clean Drawing-Finder layout -- the exe sits next to "Task List
    Files"), then an exe inside the app folder, then the retired
    .bat. The exe carries the app icon and can be pinned; the .bat
    could not.
    """
    root = launcher_root()
    outside = root.parent / "Task List.exe"
    if outside.is_file():
        return outside
    inside = root / "Task List.exe"
    if inside.is_file():
        return inside
    return root / "Task List.bat"


def mirror_launcher():
    """The LOCAL launcher copy (%LOCALAPPDATA%\\TaskListMirror),
    or None. V1.9.57 (user, 2026-11-13: on his Surface, Windows
    itself refused to run the share's exe -- "Windows cannot
    access \\\\fileshare1\\Redirect\\...\\Task List.exe"
    -- while that folder's Offline-Files sync sat in Error, so
    the app could not start AT ALL even though a full local
    mirror existed): the Go launcher now plants a copy of
    itself in the mirror. Usable only when this process is
    actually running from that mirror (a dev/source layout
    must never be redirected at it)."""
    try:
        base = os.environ.get("LOCALAPPDATA", "").strip()
        if not base:
            return None
        mirror = Path(base) / "TaskListMirror"
        if _app_root() != mirror:
            return None
        exe = mirror / "Task List.exe"
        return exe if exe.is_file() else None
    except Exception:
        return None


def preferred_launcher_target():
    """Where launches should point: the local mirror copy when
    it exists, else the share launcher. Used by the shortcuts,
    the taskbar relaunch command and the update helper's
    relaunch -- every path that starts the app again."""
    return mirror_launcher() or launcher_target()


def shortcut_path():
    """Where the pinnable shortcut lives (next to the launcher --
    since V1.9.29 that is the folder holding the exe, which is one
    level UP from the app files in the clean layout)."""
    return launcher_target().parent / "Task List.lnk"


def _new_guid_struct(ctypes, wintypes):
    class GUID(ctypes.Structure):
        _fields_ = [("Data1", wintypes.DWORD),
                    ("Data2", wintypes.WORD),
                    ("Data3", wintypes.WORD),
                    ("Data4", wintypes.BYTE * 8)]
    return GUID


def _guid_from_string(ole32, GUID, text):
    g = GUID()
    # CLSIDFromString expects "{" braced "}".
    ole32.CLSIDFromString.argtypes = [wintypes.LPCWSTR,
                                     ctypes.POINTER(GUID)]
    ole32.CLSIDFromString.restype = wintypes.HRESULT
    hr = ole32.CLSIDFromString(text, ctypes.byref(g))
    if hr != 0:
        raise OSError(f"CLSIDFromString failed for {text}: {hr:#x}")
    return g


def _call_vtable(ctypes, iface_ptr, index, restype, argtypes, *args):
    """Call a COM method by vtable index. iface_ptr: c_void_p."""
    vtbl = ctypes.cast(iface_ptr,
                       ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))
    addr = vtbl.contents[index]
    proto = ctypes.WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)
    return proto(addr)(iface_ptr, *args)


def _create_lnk_via_shelllink(lnk_path, target, workdir, icon_path):
    """Create a .lnk with IShellLinkW + IPersistFile. Returns True/False."""
    import ctypes
    from ctypes import wintypes

    GUID = _new_guid_struct(ctypes, wintypes)
    ole32 = ctypes.windll.ole32
    ole32.CoInitialize.argtypes = [ctypes.c_void_p]
    ole32.CoInitialize.restype = wintypes.HRESULT
    ole32.CoUninitialize.argtypes = []
    ole32.CoUninitialize.restype = None
    ole32.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p,
                                      wintypes.DWORD, ctypes.POINTER(GUID),
                                      ctypes.POINTER(ctypes.c_void_p)]
    ole32.CoCreateInstance.restype = wintypes.HRESULT

    CLSID_ShellLink = _guid_from_string(
        ole32, GUID, "{00021401-0000-0000-C000-000000000046}")
    IID_IShellLinkW = _guid_from_string(
        ole32, GUID, "{000214F9-0000-0000-C000-000000000046}")
    IID_IPersistFile = _guid_from_string(
        ole32, GUID, "{0000010B-0000-0000-C000-000000000046}")

    ole32.CoInitialize(None)
    try:
        link = ctypes.c_void_p()
        hr = ole32.CoCreateInstance(ctypes.byref(CLSID_ShellLink), None, 1,
                                    ctypes.byref(IID_IShellLinkW),
                                    ctypes.byref(link))
        if hr != 0 or not link:
            return False
        try:
            # IShellLinkW vtable: SetPath=20, SetWorkingDirectory=9,
            # SetIconLocation=17, SetShowCmd=15 (after IUnknown 0..2).
            S_OK = 0
            if _call_vtable(ctypes, link, 20, wintypes.HRESULT,
                            [wintypes.LPCWSTR], target) != S_OK:
                return False
            if _call_vtable(ctypes, link, 9, wintypes.HRESULT,
                            [wintypes.LPCWSTR], workdir) != S_OK:
                return False
            if icon_path:
                # SetIconLocation(pszIconPath, iIcon=0)
                _call_vtable(ctypes, link, 17, wintypes.HRESULT,
                             [wintypes.LPCWSTR, ctypes.c_int],
                             icon_path, 0)
            # Show normal window.
            _call_vtable(ctypes, link, 15, wintypes.HRESULT,
                         [ctypes.c_int], 1)  # SW_SHOWNORMAL
            # IPersistFile::Save = vtable index 6.
            persist = ctypes.c_void_p()
            hr = _call_vtable(
                ctypes, link, 0, wintypes.HRESULT,
                [ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)],
                ctypes.byref(IID_IPersistFile), ctypes.byref(persist))
            # (index 0 = QueryInterface)
            if hr != 0 or not persist:
                return False
            try:
                hr = _call_vtable(ctypes, persist, 6, wintypes.HRESULT,
                                  [wintypes.LPCWSTR, wintypes.BOOL],
                                  str(lnk_path), True)
                return hr == 0
            finally:
                _call_vtable(ctypes, persist, 2, wintypes.ULONG, [])
        finally:
            _call_vtable(ctypes, link, 2, wintypes.ULONG, [])  # Release
    finally:
        ole32.CoUninitialize()
    return False


def _stamp_app_id_on_lnk(lnk_path, app_id=APP_ID):
    """Set PKEY_AppUserModelID on the .lnk via IPropertyStore."""
    import ctypes
    from ctypes import wintypes

    GUID = _new_guid_struct(ctypes, wintypes)

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", GUID),
                    ("pid", wintypes.DWORD)]

    class PROPVARIANT(ctypes.Structure):
        # 24 bytes on 64-bit: vt(2) + 3*WORD(6) + 16-byte union.
        # V1.9.51: the struct used to stop at pwszVal (16 bytes) --
        # Windows reads/writes the full 24-byte PROPVARIANT, so
        # GetValue wrote 8 bytes past the buffer. The _pad field
        # makes the allocation the real size.
        _fields_ = [("vt", wintypes.USHORT),
                    ("wReserved1", wintypes.USHORT),
                    ("wReserved2", wintypes.USHORT),
                    ("wReserved3", wintypes.USHORT),
("pwszVal", wintypes.LPWSTR),
                    ("_pad", ctypes.c_ubyte * 8)]

    ole32 = ctypes.windll.ole32
    shell32 = ctypes.windll.shell32
    ole32.CoInitialize.argtypes = [ctypes.c_void_p]
    ole32.CoInitialize.restype = wintypes.HRESULT
    ole32.CoUninitialize.argtypes = []
    ole32.CoUninitialize.restype = None
    shell32.SHGetPropertyStoreFromParsingName.argtypes = [
        wintypes.LPCWSTR, ctypes.c_void_p, wintypes.DWORD,
        ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
    shell32.SHGetPropertyStoreFromParsingName.restype = wintypes.HRESULT
    ole32.PropVariantClear.argtypes = [ctypes.POINTER(PROPVARIANT)]
    ole32.PropVariantClear.restype = wintypes.HRESULT

    IID_IPropertyStore = _guid_from_string(
        ole32, GUID, "{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF74}")
    # PKEY_AppUserModelID = {9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}, pid 5
    fmtid = _guid_from_string(
        ole32, GUID, "{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}")
    key = PROPERTYKEY(fmtid, 5)

    ole32.CoInitialize(None)
    try:
        store = ctypes.c_void_p()
        hr = shell32.SHGetPropertyStoreFromParsingName(
            str(lnk_path), None, 2,  # GPS_READWRITE (V1.9.17: GPS_DEFAULT
            # was read-only, so SetValue silently never persisted —
            # the reason right-click -> Pin never appeared)
            ctypes.byref(IID_IPropertyStore), ctypes.byref(store))
        if hr != 0 or not store:
            return False
        try:
            pv = PROPVARIANT()
            pv.vt = 31  # VT_LPWSTR
            # Keep a reference so the string is not GC'd mid-call.
            buf = ctypes.create_unicode_buffer(app_id)
            pv.pwszVal = ctypes.cast(buf, wintypes.LPWSTR)
            # IPropertyStore::SetValue = 6, Commit = 7.
            hr = _call_vtable(ctypes, store, 6, wintypes.HRESULT,
                              [ctypes.POINTER(PROPERTYKEY),
                               ctypes.POINTER(PROPVARIANT)],
                              ctypes.byref(key), ctypes.byref(pv))
            ole32.PropVariantClear(ctypes.byref(pv))
            if hr != 0:
                return False
            hr = _call_vtable(ctypes, store, 7, wintypes.HRESULT, [])
            return hr == 0
        finally:
            _call_vtable(ctypes, store, 2, wintypes.ULONG, [])  # Release
    finally:
        ole32.CoUninitialize()
    return False


def _read_app_id_from_lnk(lnk_path):
    """Read PKEY_AppUserModelID back from a .lnk, or None.

    V1.9.17: the verifier for ensure_start_menu_shortcut — an
    existing shortcut is only good if it actually carries the stamp.
    GetValue = IPropertyStore vtable index 5.
    """
    import ctypes
    from ctypes import wintypes

    GUID = _new_guid_struct(ctypes, wintypes)

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", GUID),
                    ("pid", wintypes.DWORD)]

    class PROPVARIANT(ctypes.Structure):
        _fields_ = [("vt", wintypes.USHORT),
                    ("wReserved1", wintypes.USHORT),
                    ("wReserved2", wintypes.USHORT),
                    ("wReserved3", wintypes.USHORT),
("pwszVal", wintypes.LPWSTR),
                    ("_pad", ctypes.c_ubyte * 8)]

    ole32 = ctypes.windll.ole32
    shell32 = ctypes.windll.shell32
    ole32.CoInitialize.argtypes = [ctypes.c_void_p]
    ole32.CoInitialize.restype = wintypes.HRESULT
    ole32.CoUninitialize.argtypes = []
    ole32.CoUninitialize.restype = None
    shell32.SHGetPropertyStoreFromParsingName.argtypes = [
        wintypes.LPCWSTR, ctypes.c_void_p, wintypes.DWORD,
        ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
    shell32.SHGetPropertyStoreFromParsingName.restype = wintypes.HRESULT
    ole32.PropVariantClear.argtypes = [ctypes.POINTER(PROPVARIANT)]
    ole32.PropVariantClear.restype = wintypes.HRESULT

    IID_IPropertyStore = _guid_from_string(
        ole32, GUID, "{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF74}")
    fmtid = _guid_from_string(
        ole32, GUID, "{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}")
    key = PROPERTYKEY(fmtid, 5)

    ole32.CoInitialize(None)
    try:
        store = ctypes.c_void_p()
        hr = shell32.SHGetPropertyStoreFromParsingName(
            str(lnk_path), None, 0,  # read-only is fine for GetValue
            ctypes.byref(IID_IPropertyStore), ctypes.byref(store))
        if hr != 0 or not store:
            return None
        try:
            pv = PROPVARIANT()
            hr = _call_vtable(ctypes, store, 5, wintypes.HRESULT,
                              [ctypes.POINTER(PROPERTYKEY),
                               ctypes.POINTER(PROPVARIANT)],
                              ctypes.byref(key), ctypes.byref(pv))
            if hr != 0 or pv.vt != 31 or not pv.pwszVal:
                return None
            value = str(pv.pwszVal)
            ole32.PropVariantClear(ctypes.byref(pv))
            return value
        finally:
            _call_vtable(ctypes, store, 2, wintypes.ULONG, [])  # Release
    finally:
        ole32.CoUninitialize()
    return None


def _log_pin(message):
    """Best-effort startup.log line for pin work (Qt-free module)."""
    try:
        from .startup_log import log_startup_event
        log_startup_event(f"pin: {message}")
    except Exception:  # noqa: BLE001 - logging must never break pinning
        pass


def _start_menu_programs_dir():
    """User's Start Menu Programs folder (where Windows resolves pins)."""
    import os
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    p = Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
    return p


def _desktop_dir():
    """The user's Desktop folder (V1.9.32).

    SHGetFolderPathW(CSIDL_DESKTOPDIRECTORY) so a redirected Desktop
    (OneDrive / roaming profile) resolves to the real one; falls back
    to ~/Desktop. None when neither works.
    """
    try:
        import ctypes
        from ctypes import wintypes
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        hr = ctypes.windll.shell32.SHGetFolderPathW(
            None, 0x10, None, 0, buf)  # 0x10 = CSIDL_DESKTOPDIRECTORY
        if hr == 0 and buf.value:
            return Path(buf.value)
    except Exception:
        pass
    try:
        return Path.home() / "Desktop"
    except Exception:
        return None


def _read_target_from_lnk(lnk_path):
    """Read a .lnk's target path back via IShellLinkW, or None.

    V1.9.32: the verifier for shortcut repair — an existing shortcut
    is only good if it still points at the CURRENT launcher (a
    .bat-era shortcut kept its target when only the stamp was
    checked). GetPath = IShellLinkW vtable index 3; the file is
    loaded through IPersistFile::Load (index 5).
    """
    import ctypes
    from ctypes import wintypes

    GUID = _new_guid_struct(ctypes, wintypes)
    ole32 = ctypes.windll.ole32
    ole32.CoInitialize.argtypes = [ctypes.c_void_p]
    ole32.CoInitialize.restype = wintypes.HRESULT
    ole32.CoUninitialize.argtypes = []
    ole32.CoUninitialize.restype = None
    ole32.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p,
                                       wintypes.DWORD, ctypes.POINTER(GUID),
                                       ctypes.POINTER(ctypes.c_void_p)]
    ole32.CoCreateInstance.restype = wintypes.HRESULT

    CLSID_ShellLink = _guid_from_string(
        ole32, GUID, "{00021401-0000-0000-C000-000000000046}")
    IID_IShellLinkW = _guid_from_string(
        ole32, GUID, "{000214F9-0000-0000-C000-000000000046}")
    IID_IPersistFile = _guid_from_string(
        ole32, GUID, "{0000010B-0000-0000-C000-000000000046}")

    ole32.CoInitialize(None)
    try:
        link = ctypes.c_void_p()
        hr = ole32.CoCreateInstance(ctypes.byref(CLSID_ShellLink), None, 1,
                                    ctypes.byref(IID_IShellLinkW),
                                    ctypes.byref(link))
        if hr != 0 or not link:
            return None
        try:
            persist = ctypes.c_void_p()
            hr = _call_vtable(
                ctypes, link, 0, wintypes.HRESULT,
                [ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)],
                ctypes.byref(IID_IPersistFile), ctypes.byref(persist))
            if hr != 0 or not persist:
                return None
            try:
                hr = _call_vtable(ctypes, persist, 5, wintypes.HRESULT,
                                  [wintypes.LPCWSTR, wintypes.BOOL],
                                  str(lnk_path), True)
                if hr != 0:
                    return None
            finally:
                _call_vtable(ctypes, persist, 2, wintypes.ULONG, [])
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            hr = _call_vtable(
                ctypes, link, 3, wintypes.HRESULT,
                [wintypes.LPWSTR, ctypes.c_int, ctypes.c_void_p,
                 wintypes.DWORD],
                buf, wintypes.MAX_PATH, None, 0)
            if hr != 0 or not buf.value:
                return None
            return buf.value
        finally:
            _call_vtable(ctypes, link, 2, wintypes.ULONG, [])  # Release
    finally:
        ole32.CoUninitialize()
    return None


def _shortcut_icon(root):
    """The icon a shortcut should carry (local copy, share-safe)."""
    icon = root / "tasklist" / "assets" / "tl_icon.ico"
    if not icon.is_file():
        icon = root / "tasklist" / "assets" / "tl_icon.png"
    if not icon.is_file():
        icon = _app_root() / "tasklist" / "assets" / "tl_icon.ico"
        if not icon.is_file():
            icon = _app_root() / "tasklist" / "assets" / "tl_icon.png"
    return _local_icon_copy(icon)


def _ensure_shortcut(lnk_path, label):
    """Create or repair one "Task List.lnk": it must exist, target
    the current launcher, and carry the AppUserModelID stamp.

    V1.9.32: target verification joins stamp verification — a stale
    target (retired .bat, moved install) is rebuilt in place instead
    of being left forever because a file existed. Never raises.
    """
    try:
        target = preferred_launcher_target()
        if not target.is_file():
            return False
        if lnk_path.is_file():
            current = _read_target_from_lnk(lnk_path)
            stamped = _read_app_id_from_lnk(lnk_path) == APP_ID
            if (current and stamped
                    and os.path.normcase(current)
                    == os.path.normcase(str(target))):
                _log_pin(f"{label} shortcut ok (target + stamp)")
                return True
            _log_pin(
                f"{label} shortcut stale (target={current!r}, "
                f"stamped={stamped}); rebuilding")
        root = launcher_root()
        icon = _shortcut_icon(root)
        lnk_path.parent.mkdir(parents=True, exist_ok=True)
        ok, _stamped = _build_shortcut(
            lnk_path, str(target), str(target.parent), icon)
        stamped = _read_app_id_from_lnk(lnk_path) == APP_ID
        if not stamped:
            stamped = _stamp_app_id_on_lnk(lnk_path)
        _log_pin(f"{label} shortcut ensured, stamp ok: {stamped}")
        return bool(ok and lnk_path.is_file() and stamped)
    except Exception:
        return False


def _build_shortcut(lnk_path, target, workdir, icon_path):
    """Create one .lnk and stamp the AppUserModelID. Returns (ok, stamped)."""
    ok = _create_lnk_via_shelllink(
        lnk_path, target, workdir,
        str(icon_path) if icon_path and icon_path.is_file() else None)
    if not ok or not lnk_path.is_file():
        return False, False
    stamped = _stamp_app_id_on_lnk(lnk_path)
    return True, stamped


def _local_icon_copy(icon):
    """Copy the icon to %LOCALAPPDATA%\\TaskList\\ and return that path.

    V1.9.12: a shortcut whose icon lives on the network share renders as
    a generic icon whenever Explorer reads it before the share has
    reconnected — and Explorer is slow to refresh it afterward, which is
    the "generic icon for ages, then correct" symptom. A local copy is
    always readable, so new pins render the right icon immediately even
    when the share is down. Falls back to the share path when the copy
    fails. Never raises.
    """
    try:
        if not icon or not icon.is_file():
            return icon
        local_dir = Path(os.environ.get("LOCALAPPDATA", "")) / "TaskList"
        if not os.environ.get("LOCALAPPDATA"):
            return icon
        local_dir.mkdir(parents=True, exist_ok=True)
        local = local_dir / icon.name
        try:
            if (not local.is_file()
                    or local.stat().st_mtime_ns < icon.stat().st_mtime_ns
                    or local.stat().st_size != icon.stat().st_size):
                import shutil
                shutil.copyfile(icon, local)
        except OSError:
            return icon
        return local if local.is_file() else icon
    except Exception:
        return icon


def create_pinnable_shortcut():
    """Create pinnable Task List shortcuts, verified by read-back.

    Two shortcuts, same target (the launcher .bat — see
    launcher_root, never the local mirror), same AppUserModelID:
    1. Start Menu\\Programs\\Task List.lnk -- this is the one Windows uses
       when the user right-clicks the RUNNING app and chooses Pin to
       taskbar. Pinning then pins this shortcut, so the pinned icon
       launches Task List correctly.
    2. Task List.lnk next to the launcher -- visible copy.

    V1.9.18 (user report: pin STILL broken): V1.9.16 also wrote a
    shortcut directly into the pinned TaskBar folder and reported
    "now pinned" — but Windows tracks pins in the registry (Taskband)
    and ignores/drops foreign files in that folder, so the message
    was false and no pin ever appeared. The folder is NO LONGER
    written to, and no message claims a pin exists until the user
    actually pins the running app. This function guarantees + verifies
    the Start Menu shortcut (exists, targets the launcher, carries
    the stamp) and says exactly which step failed when it cannot.

    Returns (ok, message). Never raises; non-Windows returns (False, ...).
    """
    if not _is_windows():
        return False, "Taskbar shortcuts are only available on Windows."
    try:
        root = launcher_root()
        bat = preferred_launcher_target()
        if not bat.is_file():
            return False, f"Launcher not found: {bat}"
        icon = root / "tasklist" / "assets" / "tl_icon.ico"
        if not icon.is_file():
            icon = root / "tasklist" / "assets" / "tl_icon.png"
        if not icon.is_file():
            # Mirrored run with a share icon that is temporarily
            # unreachable: fall back to the local code copy's icon.
            icon = _app_root() / "tasklist" / "assets" / "tl_icon.ico"
            if not icon.is_file():
                icon = _app_root() / "tasklist" / "assets" / "tl_icon.png"
        # V1.9.12: point new shortcuts at a LOCAL icon copy (see
        # _local_icon_copy) so they render even when the share is down.
        icon = _local_icon_copy(icon)

        made, stamped_any = [], False

        # 1. Start Menu (drives right-click -> Pin on the running app).
        sm_dir = _start_menu_programs_dir()
        if sm_dir is not None:
            try:
                sm_dir.mkdir(parents=True, exist_ok=True)
                sm_lnk = sm_dir / "Task List.lnk"
                ok, stamped = _build_shortcut(
                    sm_lnk, str(bat), str(bat.parent), icon)
                if ok:
                    made.append(sm_lnk)
                    stamped_any = stamped_any or stamped
            except OSError:
                pass

        # 2. Visible copy next to the launcher.
        try:
            local_lnk = shortcut_path()
            ok, stamped = _build_shortcut(local_lnk, str(bat),
                                          str(bat.parent), icon)
            if ok:
                made.append(local_lnk)
                stamped_any = stamped_any or stamped
        except OSError:
            pass

        # 3. V1.9.18: the pinned TaskBar folder is NOT written to
        # (see docstring — Windows ignores foreign files there).
        # Verify by read-back instead: the Start Menu shortcut must
        # exist, its target must exist, and it must carry the stamp.
        sm_lnk_path = None
        sm_ok = sm_stamped = False
        if sm_dir is not None:
            sm_lnk_path = sm_dir / "Task List.lnk"
            sm_ok = sm_lnk_path.is_file() and bat.is_file()
            sm_stamped = (sm_ok and
                          _read_app_id_from_lnk(sm_lnk_path) == APP_ID)
        _log_pin(f"pin verify: start_menu={sm_lnk_path} exists={sm_ok} "
                 f"stamp={sm_stamped} target={bat} "
                 f"target_exists={bat.is_file()}")
        if sm_ok and sm_stamped:
            return True, (
                "Taskbar shortcut is ready and verified (Start Menu "
                "shortcut points at the Task List launcher and carries the "
                "taskbar identity).\n\n"
                "To pin: right-click the Task List icon in the taskbar "
                "while the app is running, then choose Pin to taskbar. "
                "The pinned icon will launch Task List.")
        if sm_ok:
            return True, (
                "Shortcut created, but the taskbar identity could not "
                "be stamped on it — the Pin option may not group with "
                "the running app. Run File -> Pin to Taskbar again; "
                "if it still fails, the startup.log 'pin:' lines show "
                "which step failed.")
        if not made:
            return False, "Could not create the shortcut file."
        return True, (
            "Taskbar shortcut created next to the launcher, but the "
            "Start Menu shortcut is missing — right-click pinning on "
            "the running app needs it. Run File -> Pin to Taskbar "
            "again.")
    except Exception as exc:  # never break the app over a shortcut
        return False, f"Could not create the shortcut: {exc}"


# V1.9.18: the pinned TaskBar folder helper was removed here.
# Writing .lnk files into it never pinned anything (Windows tracks
# pins in the registry and ignores foreign files there) — see
# create_pinnable_shortcut. Do not re-add a direct-folder write.


def ensure_start_menu_shortcut():
    """Create the Start Menu shortcut if it is missing, and make sure
    it carries the AppUserModelID stamp.

    V1.9.16: this shortcut is what Windows resolves for right-click ->
    Pin on the running app. Creating it at startup (deferred, after
    first show) means the Pin verb appears without the user having to
    find File -> Pin to Taskbar first. Best-effort, never raises,
    non-Windows returns False. Returns True only if the shortcut
    exists AND carries the stamp afterward — V1.9.17: earlier versions
    returned True for any existing file, so an unstamped shortcut from
    an older build was never re-stamped and Pin never appeared.
    """
    if not _is_windows():
        return False
    sm_dir = _start_menu_programs_dir()
    if sm_dir is None:
        return False
    # V1.9.32: creation + target/stamp verification now live in
    # _ensure_shortcut (shared with the Desktop shortcut below). The
    # behavior this replaces checked only the stamp on an existing
    # file, so a shortcut left over from the .bat era kept pointing
    # at the retired .bat forever.
    return _ensure_shortcut(sm_dir / "Task List.lnk", "start menu")


def ensure_desktop_shortcut():
    """Create/repair the Desktop "Task List" shortcut (V1.9.32).

    The user launches from the raw launcher file, whose name shows
    as "Task List.exe" — installed apps (Outlook, Excel) show a
    clean name because they are launched from shortcuts. A Desktop
    shortcut named "Task List" gives him the same clean icon; the
    exe itself keeps its extension (it has to — that's what makes
    it runnable) in its own folder. Same ensure/repair contract as
    the Start Menu shortcut. Best-effort, never raises.
    """
    if not _is_windows():
        return False
    desk = _desktop_dir()
    if desk is None:
        return False
    return _ensure_shortcut(desk / "Task List.lnk", "desktop")
