"""Dashboard page: KPI cards, custom-painted charts, distributor stats, nudges.

Design language: true-black dark mode (#0b0c0e app bg), dark-gray cards
(#141518), Inter font, muted gray secondary text, accent #4f8cff.
All charts are hand-painted QWidget subclasses (QPainter) — no new deps.

Db contract (read-only helpers on the TaskDatabase instance):
    db.dashboard_kpis()   -> dict(total_completed, in_process, on_hold,
                                   completion_rate, avg_completion_days,
                                   avg_estimated_hours, main_distributor,
                                   main_distributor_count, quotes_this_month,
                                   total_quote_value, open_estimated_hours)
    db.quotes_per_month(12) -> [(yyyy_mm, count)]
    db.value_per_month(12)  -> [(yyyy_mm, total)]
    db.status_counts()      -> {status: n}
    db.top_distributors(5)  -> [(name, count)]
    db.distributor_stats()  -> [{name, quotes, completed, completion_pct,
                                 avg_days, avg_est_hours, last_quote, total_value}]
    db.nudge_candidates()   -> [{name, cadence_days, days_since_last, ratio}]
Every helper call is wrapped in try/except: if a helper (or the columns it
needs) is missing, the page degrades to "—" / muted placeholders.
"""
import math
from datetime import datetime, timedelta, date

from PySide6.QtCore import (Qt, QPointF, QRect, QRectF, QSize, QSettings, QTimer,
                             Signal, QEvent, QModelIndex, Property,
                             QPropertyAnimation, QEasingCurve)
from PySide6.QtGui import (QColor, QFont, QFontMetrics, QPainter,
                           QPainterPath, QPalette, QPen)
from tasklist.ui import (AnimatedSegControl, ContactDetailWindow,
                         FollowUpsWidget, SafeComboBox,
                         install_chrome, slide_swap, grab_without_scrollbars,
                         set_scroll_content_margins, _chip_font_tree,
                         _scope_info_json, parse_money_value,
                         parse_count_value, parse_week_range,
                         format_week_range, format_money_value, _fmt_num)
from tasklist.fonts import app_font
from tasklist.themes import saved_theme
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QButtonGroup,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLayout,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTabBar,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

try:
    from tasklist.db import STATUS_LABELS
except Exception:  # pragma: no cover - defensive; db.py always ships this
    STATUS_LABELS = {
        "in_process": "In Process",
        "on_hold": "On Hold",
        "completed": "Completed",
        "canceled": "Canceled",
    }

STATUS_ORDER = ["in_process", "on_hold", "completed", "canceled"]
STATUS_COLORS = {
    "in_process": "#7fb0ff",
    "on_hold": "#eec25e",
    "completed": "#6fdc9e",
    "canceled": "#9ba1ab",
}

# ---- palette tokens (mirror themes.py DARK / LIGHT) ----
# Kept as module globals read at PAINT time, so set_dash_theme() can
# reassign them and every chart repaints with the active theme's colors.
C_CARD = "#141518"
C_BORDER = "#23252b"
C_GRID = "#1d1f24"
C_TEXT = "#f4f5f7"
C_META = "#c6cbd3"
C_MUTED = "#9ba1ab"
C_FAINT = "#6b7078"
C_ACCENT = "#4f8cff"
C_MONEY = "#6fdc9e"
C_AMBER = "#eec25e"
C_TRACK = "#1d1f24"

_DASH_PALETTE_DARK = {
    "C_CARD": "#141518", "C_BORDER": "#23252b", "C_GRID": "#1d1f24",
    "C_TEXT": "#f4f5f7", "C_META": "#c6cbd3", "C_MUTED": "#9ba1ab",
    "C_FAINT": "#6b7078", "C_ACCENT": "#4f8cff", "C_MONEY": "#6fdc9e",
    "C_AMBER": "#eec25e", "C_TRACK": "#1d1f24",
}
_DASH_PALETTE_LIGHT = {
    "C_CARD": "#ffffff", "C_BORDER": "#e3e4e6", "C_GRID": "#e3e4e6",
    "C_TEXT": "#1c1f24", "C_META": "#3d4149", "C_MUTED": "#474c54",
    "C_FAINT": "#4e535b", "C_ACCENT": "#2f6fed", "C_MONEY": "#15803d",
    "C_AMBER": "#b45309", "C_TRACK": "#e3e4e6",
}
_STATUS_COLORS_DARK = {
    "in_process": "#7fb0ff", "on_hold": "#eec25e",
    "completed": "#6fdc9e", "canceled": "#9ba1ab",
}
_STATUS_COLORS_LIGHT = {
    "in_process": "#1d4ed8", "on_hold": "#b45309",
    "completed": "#15803d", "canceled": "#5f666b",
}

_dash_theme = "dark"


def set_dash_theme(name):
    """Reassign the dashboard paint palette to the active theme."""
    global _dash_theme
    light = (name == "light")
    palette = _DASH_PALETTE_LIGHT if light else _DASH_PALETTE_DARK
    g = globals()
    for key, value in palette.items():
        g[key] = value
    STATUS_COLORS.update(
        _STATUS_COLORS_LIGHT if light else _STATUS_COLORS_DARK)
    # V1.9.10 accent: painted accent elements follow the user's colour.
    from .themes import shifted_color
    g["C_ACCENT"] = shifted_color(palette["C_ACCENT"])
    STATUS_COLORS["in_process"] = shifted_color(
        STATUS_COLORS["in_process"])
    _dash_theme = "light" if light else "dark"

_DASH_QSS = """
QWidget#dashPage { background: #0b0c0e; }
QTabWidget#dashTabs::pane { border: none; background: #0b0c0e; }
QTabWidget#dashTabs QTabBar::tab {
    background: transparent; color: #9ba1ab;
    font-size: 13px; font-weight: 600;
    padding: 8px 22px; margin: 0px; border: none;
}
QTabWidget#dashTabs QTabBar::tab:selected { background: transparent; color: #f4f5f7; }
QTabWidget#dashTabs QTabBar::tab:hover:!selected { color: #e6e9ee; }
QFrame#dashCard {
    background: #141518; border: 1px solid #23252b;
    border-radius: 14px; border-top: 3px solid #2f6fed;
}
QFrame#dashCard[clickable="true"]:hover {
    border: 1px solid #4f8cff; border-top: 3px solid #4f8cff;
}
QPushButton#bucketBtn {
    background: transparent; color: #9ba1ab;
    border: 1px solid #23252b; border-radius: 8px;
    padding: 5px 12px; font-size: 11px; font-weight: 700;
}
QPushButton#bucketBtn:hover { color: #e6e9ee; border-color: #3a3e48; }
QPushButton#bucketBtn:checked {
    background: #1e2a44; color: #8fb4ff; border-color: #1e2a44;
}
QLabel#dashKpiLabel { color: #9ba1ab; font-size: 11px; font-weight: 700; }
QLabel#dashKpiValue { color: #f4f5f7; font-size: 26px; font-weight: 700; }
QLabel#dashKpiValueSm { color: #f4f5f7; font-size: 15px; font-weight: 700; }
QLabel#dashKpiSub { color: #6b7078; font-size: 11px; }
QLabel#dashSection { color: #6b7078; font-size: 11px; font-weight: 700; }
QLabel#dashChartTitle { color: #c6cbd3; font-size: 13px; font-weight: 700; }
QLabel#dashEmpty { color: #6b7078; font-size: 14px; padding: 6px 4px; }
QFrame#nudgeCard {
    background: #141518; border: 1px solid #23252b;
    border-radius: 12px; border-left: 4px solid #eec25e;
}
QLabel#nudgeTitle { color: #f4f5f7; font-size: 14px; font-weight: 700; }
QLabel#nudgeBody { color: #9ba1ab; font-size: 13px; }
QLabel#nudgeCheck { color: #6fdc9e; font-size: 34px; font-weight: 700; }
QPushButton#nudgeDismiss {
    background: transparent; border: none; color: #6b7078;
    font-size: 12px; font-weight: 600; padding: 4px 8px;
}
QPushButton#nudgeDismiss:hover { color: #f4f5f7; }
QTableWidget#dashTable {
    background: #0e0f12; border: 1px solid #23252b;
    border-radius: 12px; gridline-color: #1d1f24;
}
QTableWidget#dashTable::item { padding: 10px 8px; color: #d5d9e0; border: none; }
QTableWidget#dashTable::item:selected { background: #1a2c4e; color: #ffffff; }
/* clickable drill-down/distributor rows: subtle neutral hover, pointer cursor */
QTableWidget#dashTable::item:hover:!selected { background: #1b1e24; }
QTableWidget#dashTable QTableCornerButton::section {
    background: #141518; border: none;
}
QHeaderView#dashHeader::section {
    background: #141518; color: #9ba1ab; border: none;
    border-right: 1px solid #1d1f24; padding: 12px 10px;
    font-size: 12px; font-weight: 700;
}
QHeaderView#dashHeader::section:first {
    border-top-left-radius: 12px;
}
QHeaderView#dashHeader::section:last {
    border-top-right-radius: 12px;
}
QHeaderView#dashHeader {
    background: #141518;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}
QTableWidget#dashTable QTableCornerButton::section {
    border-top-left-radius: 12px;
}
"""

_DASH_QSS_LIGHT = """
QWidget#dashPage { background: #f5f5f6; }
QTabWidget#dashTabs::pane { border: none; background: #f5f5f6; }
QTabWidget#dashTabs QTabBar::tab {
    background: transparent; color: #474c54;
    font-size: 13px; font-weight: 600;
    padding: 8px 22px; margin: 0px; border: none;
}
QTabWidget#dashTabs QTabBar::tab:selected { background: transparent; color: #1c1f24; }
QTabWidget#dashTabs QTabBar::tab:hover:!selected { color: #1c1f24; }
QFrame#dashCard {
    background: #ffffff; border: 1px solid #e3e4e6;
    border-radius: 14px; border-top: 3px solid #2f6fed;
}
QFrame#dashCard[clickable="true"]:hover {
    border: 1px solid #2f6fed; border-top: 3px solid #2f6fed;
}
QPushButton#bucketBtn {
    background: transparent; color: #474c54;
    border: 1px solid #e3e4e6; border-radius: 8px;
    padding: 5px 12px; font-size: 11px; font-weight: 700;
}
QPushButton#bucketBtn:hover { color: #1c1f24; border-color: #ccd0d6; }
QPushButton#bucketBtn:checked {
    background: #e3e9f2; color: #1d4ed8; border-color: #e3e9f2;
}
QLabel#dashKpiLabel { color: #474c54; font-size: 11px; font-weight: 700; }
QLabel#dashKpiValue { color: #1c1f24; font-size: 26px; font-weight: 700; }
QLabel#dashKpiValueSm { color: #1c1f24; font-size: 15px; font-weight: 700; }
QLabel#dashKpiSub { color: #4e535b; font-size: 11px; }
QLabel#dashSection { color: #4e535b; font-size: 11px; font-weight: 700; }
QLabel#dashChartTitle { color: #3d4149; font-size: 13px; font-weight: 700; }
QLabel#dashEmpty { color: #4e535b; font-size: 14px; padding: 6px 4px; }
QFrame#nudgeCard {
    background: #ffffff; border: 1px solid #e3e4e6;
    border-radius: 12px; border-left: 4px solid #b45309;
}
QLabel#nudgeTitle { color: #1c1f24; font-size: 14px; font-weight: 700; }
QLabel#nudgeBody { color: #474c54; font-size: 13px; }
QLabel#nudgeCheck { color: #15803d; font-size: 34px; font-weight: 700; }
QPushButton#nudgeDismiss {
    background: transparent; border: none; color: #4e535b;
    font-size: 12px; font-weight: 600; padding: 4px 8px;
}
QPushButton#nudgeDismiss:hover { color: #1c1f24; }
QTableWidget#dashTable {
    background: #ffffff; border: 1px solid #e3e4e6;
    border-radius: 12px; gridline-color: #e3e4e6;
}
QTableWidget#dashTable::item { padding: 10px 8px; color: #1c1f24; border: none; }
QTableWidget#dashTable::item:selected { background: #e3e9f2; color: #1c1f24; }
QTableWidget#dashTable::item:hover:!selected { background: #ececee; }
QTableWidget#dashTable QTableCornerButton::section {
    background: #ffffff; border: none;
}
QHeaderView#dashHeader::section {
    background: #f7f7f8; color: #474c54; border: none;
    border-right: 1px solid #e3e4e6; padding: 12px 10px;
    font-size: 12px; font-weight: 700;
}
QHeaderView#dashHeader::section:first {
    border-top-left-radius: 12px;
}
QHeaderView#dashHeader::section:last {
    border-top-right-radius: 12px;
}
QHeaderView#dashHeader {
    background: #f7f7f8;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}
QTableWidget#dashTable QTableCornerButton::section {
    border-top-left-radius: 12px;
}
"""


def dash_qss():
    """Dashboard stylesheet for the active theme."""
    from .themes import apply_accent_shift
    qss = _DASH_QSS_LIGHT if _dash_theme == "light" else _DASH_QSS
    return apply_accent_shift(qss)


# --------------------------------------------------------------------------
# formatting helpers
# --------------------------------------------------------------------------
def _safe(fn, default):
    """Call a db helper; return default if it (or its columns) is missing."""
    try:
        return fn()
    except Exception:
        return default


def _money(v):
    if v is None:
        return "—"
    try:
        return "$" + f"{int(round(float(v))):,}"
    except (TypeError, ValueError):
        return "—"


def _days(v):
    if v is None:
        return "—"
    try:
        return f"{float(v):.1f} days"
    except (TypeError, ValueError):
        return "—"


def _hours(v):
    if v is None:
        return "—"
    try:
        return f"{float(v):.1f} h"
    except (TypeError, ValueError):
        return "—"


def _hours_compact(v):
    """Compact hours for the Workload KPI and its drill-down: '12.5h'.

    None / non-numeric -> '—' (same missing-data convention as _hours).
    """
    if v is None:
        return "—"
    try:
        return f"{float(v):.1f}h"
    except (TypeError, ValueError):
        return "—"


def _month_label(yyyy_mm):
    try:
        return datetime.strptime(str(yyyy_mm), "%Y-%m").strftime("%b '%y")
    except ValueError:
        return str(yyyy_mm)


def _int_fmt(v):
    try:
        f = float(v)
        return str(int(f)) if f.is_integer() else f"{f:.1f}"
    except (TypeError, ValueError):
        return "—"


# --------------------------------------------------------------------------
# table typography: larger body, hierarchy, tabular numerals
# --------------------------------------------------------------------------
_TNUM_TAG = None


def _tnum_tag():
    """OpenType 'tnum' feature tag (tabular figures), or None if unavailable."""
    global _TNUM_TAG
    if _TNUM_TAG is None:
        try:
            tag = QFont.Tag.fromString("tnum")
            _TNUM_TAG = tag if tag.isValid() else False
        except Exception:
            _TNUM_TAG = False
    return _TNUM_TAG or None


def _table_font(pt=13, weight=QFont.Normal, tabular=False):
    """Body font for data tables. tabular=True requests tabular figures
    (OpenType tnum) so digits line up in numeric columns.

    Built on the central app_font() so table text also gets grayscale
    (not subpixel) antialiasing — no fringe artifacts in table cells.
    """
    f = app_font()
    f.setPointSize(pt)
    f.setWeight(weight)
    if tabular:
        tag = _tnum_tag()
        if tag is not None:
            try:
                f.setFeature(tag, 1)
            except Exception:
                pass
    return f


def _font_has_tnum(font):
    """True when the font requests the tnum OpenType feature."""
    tag = _tnum_tag()
    if tag is None:
        return False
    try:
        return any(t.toString() == b"tnum" for t in font.featureTags())
    except Exception:
        return False


def _style_data_table(table):
    """Shared typographic treatment for dashboard data tables.

    Larger legible body, generous row padding (via QSS ::item padding plus a
    taller default section), refined letter-spaced headers. Zebra-free.
    """
    table.setFont(_table_font(13))
    table.verticalHeader().setDefaultSectionSize(46)
    hdr_font = table.horizontalHeader().font()
    hdr_font.setLetterSpacing(QFont.PercentageSpacing, 110)
    table.horizontalHeader().setFont(hdr_font)


def _short_date(iso):
    """'09/24/2026' from an ISO datetime string (the global
    Month/Day/Year display standard), '' when unparseable."""
    try:
        return datetime.fromisoformat(str(iso)).strftime("%m/%d/%Y")
    except (ValueError, TypeError):
        return ""


def _epoch(iso):
    """Sort key for an ISO datetime string (-1 when missing/unparseable)."""
    try:
        return datetime.fromisoformat(str(iso)).timestamp()
    except (ValueError, TypeError):
        return -1


def _fnum(v, default=-1):
    """Numeric sort key that never raises on odd DB values."""
    try:
        return default if v is None else float(v)
    except (TypeError, ValueError):
        return default


def _days_between(created_iso, completed_iso):
    """Elapsed days created -> completed, None when either end is missing."""
    try:
        start = datetime.fromisoformat(str(created_iso))
        end = datetime.fromisoformat(str(completed_iso))
    except (ValueError, TypeError):
        return None
    return (end - start).total_seconds() / 86400.0


# --------------------------------------------------------------------------
# chart re-bucketing: month / week / year over the same raw creation dates
# --------------------------------------------------------------------------
def _bucket_dates(dates, mode="month"):
    """Bucket ISO created_at stamps for the quotes chart.

    mode 'month': last 12 calendar months, zero-filled ("Sep '26").
    mode 'week':  last 12 weeks (Monday-start), zero-filled ("Sep 21").
    mode 'year':  every calendar year spanned, zero-filled ("2026").
    Returns [(label, count)] oldest -> newest. Unparseable stamps are skipped.
    """
    parsed = []
    for s in dates or []:
        try:
            parsed.append(datetime.fromisoformat(str(s)))
        except (ValueError, TypeError):
            continue
    today = datetime.now()
    if mode == "week":
        this_mon = (today - timedelta(days=today.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0)
        starts = [this_mon - timedelta(weeks=i) for i in range(11, -1, -1)]
        counts = {s: 0 for s in starts}
        for d in parsed:
            ws = (d - timedelta(days=d.weekday())).replace(
                hour=0, minute=0, second=0, microsecond=0)
            if ws in counts:
                counts[ws] += 1
        return [(s.strftime("%b %d"), counts[s]) for s in starts]
    if mode == "year":
        if not parsed:
            return []
        lo = min(d.year for d in parsed)
        hi = max(d.year for d in parsed)
        counts = {y: 0 for y in range(lo, hi + 1)}
        for d in parsed:
            counts[d.year] += 1
        return [(str(y), counts[y]) for y in range(lo, hi + 1)]
    # month (default)
    keys = []
    for i in range(11, -1, -1):
        idx = today.year * 12 + today.month - 1 - i
        y, m = divmod(idx, 12)
        keys.append((y, m + 1))
    counts = {k: 0 for k in keys}
    for d in parsed:
        k = (d.year, d.month)
        if k in counts:
            counts[k] += 1
    return [(_month_label(f"{y:04d}-{m:02d}"), counts[(y, m)])
            for y, m in keys]


def _bucket_values(pairs, mode="month"):
    """Bucket (created_at, value) pairs into summed series.

    Same windows and labels as _bucket_dates (last 12 weeks / months,
    or every spanned year); values are summed instead of counted.
    Returns [(label, total)] oldest -> newest.
    """
    parsed = []
    for s, v in pairs or []:
        try:
            parsed.append((datetime.fromisoformat(str(s)), float(v)))
        except (ValueError, TypeError):
            continue
    today = datetime.now()
    if mode == "week":
        this_mon = (today - timedelta(days=today.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0)
        starts = [this_mon - timedelta(weeks=i) for i in range(11, -1, -1)]
        sums = {s: 0.0 for s in starts}
        for d, v in parsed:
            ws = (d - timedelta(days=d.weekday())).replace(
                hour=0, minute=0, second=0, microsecond=0)
            if ws in sums:
                sums[ws] += v
        return [(s.strftime("%b %d"), sums[s]) for s in starts]
    if mode == "year":
        if not parsed:
            return []
        lo = min(d.year for d, _v in parsed)
        hi = max(d.year for d, _v in parsed)
        sums = {y: 0.0 for y in range(lo, hi + 1)}
        for d, v in parsed:
            sums[d.year] += v
        return [(str(y), sums[y]) for y in range(lo, hi + 1)]
    keys = []
    for i in range(11, -1, -1):
        idx = today.year * 12 + today.month - 1 - i
        y, m = divmod(idx, 12)
        keys.append((y, m + 1))
    sums = {k: 0.0 for k in keys}
    for d, v in parsed:
        k = (d.year, d.month)
        if k in sums:
            sums[k] += v
    return [(_month_label(f"{y:04d}-{m:02d}"), sums[(y, m)])
            for y, m in keys]


def _nice_ticks(m):
    """~3 y-axis ticks from 0 up to a rounded ceiling of m."""
    if m is None or m <= 0:
        return [0]
    if m <= 6:
        # small counts: integer ticks only ("0.5 quotes" looks broken)
        return list(range(0, int(math.ceil(m)) + 1))
    target = m / 2.0
    mag = 10 ** math.floor(math.log10(target))
    norm = target / mag
    if norm <= 1:
        step = mag
    elif norm <= 2:
        step = 2 * mag
    elif norm <= 2.5:
        step = 2.5 * mag
    elif norm <= 5:
        step = 5 * mag
    else:
        step = 10 * mag
    top = math.ceil(m / step) * step
    ticks, v = [], 0.0
    while v <= top + 1e-9:
        ticks.append(v)
        v += step
    return ticks


def _section_label(text):
    lbl = QLabel(text.upper())
    lbl.setObjectName("dashSection")
    f = lbl.font()
    f.setLetterSpacing(QFont.PercentageSpacing, 112)
    lbl.setFont(f)
    return lbl


def _draw_placeholder(painter, rect, text):
    painter.save()
    painter.setPen(QColor(C_FAINT))
    f = painter.font()
    f.setPointSize(12)
    painter.setFont(f)
    painter.drawText(rect, Qt.AlignCenter, text)
    painter.restore()


# --------------------------------------------------------------------------
# flow layout for the KPI card row (wrap-friendly)
# --------------------------------------------------------------------------
class _FlowLayout(QLayout):
    def __init__(self, parent=None, hspacing=12, vspacing=12,
                 balanced=False):
        super().__init__(parent)
        self._items = []
        self._h = hspacing
        self._v = vspacing
        # Balanced mode (Overview KPIs, V1.9.30 user): instead of
        # left-packing fixed-width cards and leaving the last row
        # ragged, choose a row count from the available width, split
        # the cards across rows as evenly as possible, and stretch
        # every row to the full width -- equal cards, even rows, no
        # dead space at the right edge.
        self._balanced = balanced

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, w):
        return self._do_layout(QRectF(0, 0, w, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(QRectF(rect), False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        s = QSize()
        for it in self._items:
            s = s.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        return s + QSize(m.left() + m.right(), m.top() + m.bottom())

    def _do_layout(self, rect, test):
        m = self.contentsMargins()
        area = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        if self._balanced and self._items and area.width() > 0:
            return self._do_balanced(area, rect, m, test)
        x, y, line_h = area.x(), area.y(), 0
        for it in self._items:
            hint = it.sizeHint()
            w = max(hint.width(), it.minimumSize().width())
            h = hint.height()
            if x + w > area.right() + 1 and line_h > 0:
                x, y, line_h = area.x(), y + line_h + self._v, 0
            if not test:
                it.setGeometry(QRectF(x, y, w, h).toRect())
            x += w + self._h
            line_h = max(line_h, h)
        return int(y + line_h - rect.y() + m.top() + m.bottom())

    def _do_balanced(self, area, rect, m, test):
        items = self._items
        n = len(items)
        # Capacity from the SMALLEST preferred card width (the
        # standard card): how many columns genuinely fit.
        base_w = min(it.sizeHint().width() for it in items)
        max_cols = max(1, min(
            n, int((area.width() + self._h) // (base_w + self._h))))
        rows = -(-n // max_cols)  # ceil
        per_row, extra = divmod(n, rows)
        counts = [per_row + 1] * extra + [per_row] * (rows - extra)
        row_h = max(it.sizeHint().height() for it in items)
        y = area.y()
        idx = 0
        for count in counts:
            if count <= 0:
                continue
            total_gaps = (count - 1) * self._h
            cell = (area.width() - total_gaps) / count
            x = area.x()
            for j in range(count):
                w = int(cell * (j + 1)) - int(cell * j)
                if not test:
                    items[idx].setGeometry(
                        QRect(int(round(x)), int(round(y)), w, row_h))
                x += w + self._h
                idx += 1
            y += row_h + self._v
        total_h = (y - self._v - area.y()) if rows else 0
        return int(total_h + m.top() + m.bottom())


class _KpiHost(QWidget):
    """Host for the KPI flow layout, with a width-aware size hint.

    _FlowLayout.sizeHint() is width-independent (it returns minimumSize()),
    so the default QWidget.sizeHint() -> QLayout.totalSizeHint() path
    evaluates heightForWidth() at the hint's narrow width and reports a
    far-too-tall host. The scroll area then sized its content to that
    phantom height and the Overview tab scrolled through blank space.
    This host reports the flow height for its ACTUAL width and re-announces
    its geometry whenever the width changes, so the scroll area settles on
    the true content height with no dead region.
    """

    def sizeHint(self):  # noqa: N802 (Qt virtual)
        lay = self.layout()
        w = self.width()
        if lay is not None and w > 0 and lay.hasHeightForWidth():
            return QSize(w, lay.heightForWidth(w))
        return super().sizeHint()

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        if event.oldSize().width() != event.size().width():
            self.updateGeometry()


# --------------------------------------------------------------------------
# KPI card
# --------------------------------------------------------------------------
class AnimatedTabBar(QTabBar):
    """Dashboard tab bar whose highlight SLIDES between tabs.

    V1.9.17 (user report): switching Overview / Freight & Lead-Time
    flashed the highlight from one option to the other. The bar paints
    the pill itself — under the tab text, over the transparent tab
    backgrounds (the dashTabs QSS selected background is transparent
    for this reason) — and animates its rect on currentChanged (180ms
    ease-out). The pill colour is the accent-shifted old selected
    background, so accent changes still flow through. Resize snaps
    the pill to the current tab without sliding.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pill_from = QRect()
        self._pill_to = QRect()
        self._pill_t = 1.0
        self._anim = QPropertyAnimation(self, b"pill_t")
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self.currentChanged.connect(self._on_current_changed)

    def _get_pill_t(self):
        return self._pill_t

    def _set_pill_t(self, value):
        self._pill_t = float(value)
        self.update()

    pill_t = Property(float, _get_pill_t, _set_pill_t)

    def _pill_rect(self):
        if self._pill_from.isEmpty() or self._pill_to.isEmpty():
            return self._pill_to
        t = self._pill_t
        f, g = self._pill_from, self._pill_to
        return QRect(
            int(round(f.x() + (g.x() - f.x()) * t)),
            int(round(f.y() + (g.y() - f.y()) * t)),
            int(round(f.width() + (g.width() - f.width()) * t)),
            int(round(f.height() + (g.height() - f.height()) * t)))

    def _on_current_changed(self, index):
        new = self.tabRect(index) if index >= 0 else QRect()
        if new.isEmpty():
            return
        cur = self._pill_rect()
        self._pill_from = cur if not cur.isEmpty() else new
        self._pill_to = new
        if self.isVisible() and self._pill_from != new:
            self._anim.stop()
            self._anim.setStartValue(0.0)
            self._anim.setEndValue(1.0)
            self._anim.start()
        else:
            self._pill_t = 1.0
            self.update()

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        idx = self.currentIndex()
        if idx >= 0:
            self._pill_from = self.tabRect(idx)
            self._pill_to = self.tabRect(idx)
            self._pill_t = 1.0

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        # V1.9.36 (user: the tab pattern goes GLOBAL -- Chrome tabs
        # everywhere, never button pills): the bar paints the strip
        # hairline across its bottom, and the current tab as a
        # TONGUE in the pane colour outlined on top and sides, its
        # fill covering the hairline segment beneath it so it reads
        # attached to the pane. The slide animation now moves the
        # tongue instead of the old navy pill (#1e2a44 -- the same
        # blue the user rejected on the CRM tabs and dropdowns).
        dark = saved_theme() != "light"
        pane = QColor("#0b0c0e" if dark else "#f5f5f6")
        line = QColor("#23252b" if dark else "#e3e4e6")
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(QPen(line, 1))
        p.drawLine(0, self.height() - 1, self.width(), self.height() - 1)
        rect = self._pill_rect()
        if not rect.isEmpty():
            r = QRectF(rect.adjusted(0, 1, 0, 1))
            rad = 8.0
            path = QPainterPath()
            path.moveTo(r.left(), r.bottom())
            path.lineTo(r.left(), r.top() + rad)
            path.arcTo(r.left(), r.top(), rad * 2, rad * 2, 180, -90)
            path.lineTo(r.right() - rad, r.top())
            path.arcTo(r.right() - rad * 2, r.top(), rad * 2, rad * 2,
                       90, -90)
            path.lineTo(r.right(), r.bottom())
            path.closeSubpath()
            p.setPen(Qt.NoPen)
            p.setBrush(pane)
            p.drawPath(path)
            p.save()
            p.setClipRect(QRectF(r.left() - 1, r.top() - 1,
                                 r.width() + 2, r.height()))
            p.setPen(QPen(line, 1))
            p.setBrush(Qt.NoBrush)
            p.drawPath(path)
            p.restore()
        p.end()
        super().paintEvent(event)


class KpiCard(QFrame):
    """KPI card; optionally clickable (emits ``clicked`` on left-click).

    Clickable cards get a pointer cursor and an accent hover border via the
    ``clickable`` dynamic property in the dashboard QSS.
    """

    clicked = Signal()

    # V1.9.29 (user screenshot): EVERY KPI card is the same width and
    # height -- the Win rate card used to grow taller than its row
    # because it alone carried a sub-caption line. All cards now use
    # one fixed size and always reserve the sub-caption row (empty
    # when a card has no caption), so a row of cards is uniform by
    # construction at any window width.
    # V1.9.30 (user: "you made all of these cards bigger -- when did
    # I ask for that?"): the 1.9.29 uniform size overshot. The cards
    # shrink back to a compact footprint; uniformity stays.
    CARD_W = 196
    CARD_WIDE_W = 252
    # V1.9.34 (user, on the Avg completion / Workload cards): the
    # content used to hug the top of the card and leave a dead void
    # at the bottom -- "looks fucking dumb". The height was never
    # the problem; the structure was. The layout now pins the label
    # to the top and the value block to the bottom (stretch between
    # them), so every card reads filled at both ends and all values
    # share one bottom line across the row.
    CARD_H = 98

    def __init__(self, label, value="—", sub=None, value_pt=26,
                 parent=None, wide=False):
        super().__init__(parent)
        self.setObjectName("dashCard")
        # V1.9.29 refinement (user): every card shares ONE height;
        # widths are uniform too, EXCEPT Total quote value and Won
        # value, which may be wider so a full money figure always
        # fits on one line.
        # V1.9.30: the base size is now a PREFERRED size, not a fixed
        # one -- the Overview's balanced flow stretches cards to fill
        # each row evenly (user: spread them across the screen with
        # even rows). Minimums keep the base footprint on narrow
        # windows; height stays locked to CARD_H everywhere.
        self._wide = wide
        self.setMinimumSize(self.CARD_WIDE_W if wide else self.CARD_W,
                            self.CARD_H)
        self.setMaximumHeight(self.CARD_H)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        self._clickable = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 11, 14, 11)
        lay.setSpacing(3)
        lab = QLabel(label.upper())
        lab.setObjectName("dashKpiLabel")
        lay.addWidget(lab)
        # V1.9.34: value block pinned to the card's bottom edge.
        lay.addStretch(1)
        self._val = QLabel(str(value))
        self._val.setObjectName(
            "dashKpiValue" if value_pt >= 26 else "dashKpiValueSm")
        self._val.setWordWrap(True)
        lay.addWidget(self._val)
        # V1.9.34 (user, on the Logistics strip: "why does the AVG
        # SHIPPING card's text not line up with every other card's
        # text??"): the sub-caption row is ALWAYS created -- empty
        # when the card has no caption. It used to exist only on
        # cards WITH a caption, so a caption-less card's whole text
        # block shifted against its neighbours'. With the row
        # reserved, label / value / caption sit at the same heights
        # on every card, on both dashboard strips.
        self._sub = QLabel(str(sub) if sub else "")
        self._sub.setObjectName("dashKpiSub")
        lay.addWidget(self._sub)

    def set_clickable(self, enabled=True):
        self._clickable = enabled
        cur = Qt.PointingHandCursor if enabled else Qt.ArrowCursor
        self.setCursor(cur)
        for child in self.findChildren(QLabel):
            child.setCursor(cur)
        self.setProperty("clickable", enabled)
        # re-polish so the [clickable="true"]:hover QSS rule takes effect
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def mousePressEvent(self, ev):
        if self._clickable and ev.button() == Qt.LeftButton:
            self.clicked.emit()
            ev.accept()
            return
        super().mousePressEvent(ev)

    def set_value(self, value, sub=None):
        self._val.setText(str(value))
        if self._sub is not None and sub is not None:
            self._sub.setText(str(sub))

    def sizeHint(self):  # noqa: N802 (Qt virtual)
        return QSize(self.CARD_WIDE_W if self._wide else self.CARD_W,
                     self.CARD_H)


# --------------------------------------------------------------------------
# charts (custom painted)
# --------------------------------------------------------------------------
class MonthlyBarChart(QWidget):
    """Vertical bars for per-month series. value_fmt formats ticks/labels.

    V1.9.17: bars are clickable — clicking a bar emits bar_clicked
    with the bucket label, and the dashboard opens that bucket's
    quotes, so every chart shows where its numbers come from.
    """

    bar_clicked = Signal(str)

    def __init__(self, color=C_ACCENT, value_fmt=_int_fmt,
                 placeholder="No data yet", parent=None):
        super().__init__(parent)
        self._data = []
        self._color = QColor(color)
        self._fmt = value_fmt
        self._placeholder = placeholder
        self.setMinimumHeight(230)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMouseTracking(True)

    def set_data(self, data):
        self._data = [(str(lab), v) for lab, v in (data or [])]
        self.update()

    def set_color(self, color):
        """Update the bar color (theme switch) and repaint."""
        self._color = QColor(color)
        self.update()

    def _bar_layout(self):
        """(plot, slot, bw, vals, max_v) or None when nothing to draw.

        Shared by paintEvent and the click hit-test so the clickable
        columns match the painted bars exactly.
        """
        R = self.rect().adjusted(4, 4, -4, -4)
        vals = []
        for _lab, v in self._data:
            try:
                vals.append(max(0.0, float(v)))
            except (TypeError, ValueError):
                vals.append(0.0)
        if not self._data or all(v <= 0 for v in vals):
            return None
        max_v = max(vals)
        ticks = _nice_ticks(max_v)
        axis_font = self.font()
        axis_font.setPointSize(10)
        fm_axis = QFontMetrics(axis_font)
        ylab_w = max((fm_axis.horizontalAdvance(self._fmt(t)) for t in ticks),
                     default=0)
        left = R.left() + ylab_w + 10
        top = R.top() + 34
        bottom = R.bottom() - 30
        right = R.right() - 6
        if right - left < 40 or bottom - top < 40:
            return None
        plot = QRectF(left, top, right - left, bottom - top)
        n = len(self._data)
        slot = plot.width() / n
        bw = min(slot * 0.58, 46)
        return plot, slot, bw, vals, max_v

    def _bar_at(self, pos):
        """Bucket label for a point ON A PAINTED BAR, or None.

        V1.9.34 (user): clicking blank chart space -- above a short
        bar, or over a month with no bar at all -- opened that
        month's list anyway, because the whole slot column used to
        be the target. Now the bar has to EXIST and the click has to
        land on the painted bar itself (same geometry paintEvent
        draws: centred in its slot, bw wide, from its top down to
        the baseline).
        """
        lay = self._bar_layout()
        if lay is None:
            return None
        plot, slot, bw, vals, max_v = lay
        if not (plot.left() <= pos.x() <= plot.right()
                and plot.top() <= pos.y() <= plot.bottom()):
            return None
        i = int((pos.x() - plot.left()) // slot)
        if not (0 <= i < len(self._data)) or not max_v:
            return None
        h = (vals[i] / max_v) * plot.height()
        if h <= 0.5:
            return None  # no bar is painted for this bucket
        cx = plot.left() + slot * i + slot / 2.0
        if abs(pos.x() - cx) > bw / 2.0:
            return None  # beside the bar, still in its slot
        if pos.y() < plot.bottom() - h:
            return None  # above the bar
        return self._data[i][0]

    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.button() == Qt.LeftButton:
            label = self._bar_at(event.position().toPoint())
            if label is not None:
                self.bar_clicked.emit(label)
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: N802 (Qt virtual)
        self.setCursor(Qt.PointingHandCursor
                       if self._bar_at(event.position().toPoint()) is not None
                       else Qt.ArrowCursor)
        super().mouseMoveEvent(event)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        R = self.rect().adjusted(4, 4, -4, -4)
        lay = self._bar_layout()
        if lay is None:
            _draw_placeholder(p, R, self._placeholder)
            return
        plot, slot, bw, vals, max_v = lay
        ticks = _nice_ticks(max_v)

        axis_font = self.font()
        axis_font.setPointSize(10)
        lab_font = self.font()
        lab_font.setPointSize(10)
        val_font = self.font()
        val_font.setPointSize(10)
        val_font.setWeight(QFont.DemiBold)
        fm_axis = QFontMetrics(axis_font)
        ylab_w = max((fm_axis.horizontalAdvance(self._fmt(t)) for t in ticks),
                     default=0)

        # gridlines + y labels
        for t in ticks:
            y = plot.bottom() - (t / max_v) * plot.height() if max_v else plot.bottom()
            p.setPen(QPen(QColor(C_GRID), 1))
            p.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y))
            p.setPen(QColor(C_FAINT))
            p.setFont(axis_font)
            lab_rect = QRectF(R.left(), y - 10, ylab_w + 4, 20)
            if lab_rect.top() < R.top():
                lab_rect.moveTop(R.top())
            p.drawText(lab_rect, Qt.AlignRight | Qt.AlignVCenter, self._fmt(t))

        n = len(self._data)
        drawn_labels = []
        for i, ((lab, _v), v) in enumerate(zip(self._data, vals)):
            cx = plot.left() + slot * i + slot / 2.0
            x = cx - bw / 2.0
            h = (v / max_v) * plot.height() if max_v else 0
            y = plot.bottom() - h
            if h > 0.5:
                r_ = min(5.0, bw / 2.0, h)
                path = QPainterPath()
                path.moveTo(x, plot.bottom())
                path.lineTo(x, y + r_)
                path.quadTo(x, y, x + r_, y)
                path.lineTo(x + bw - r_, y)
                path.quadTo(x + bw, y, x + bw, y + r_)
                path.lineTo(x + bw, plot.bottom())
                path.closeSubpath()
                p.fillPath(path, self._color)
                # value label above the bar; skip only on a REAL
                # text collision. V1.9.29 (user screenshot: the
                # current month's count missing while its neighbours
                # showed): the old guard used a bw+60-wide rect, so
                # two adjacent bars of SIMILAR height (rects at the
                # same y, ~70px apart) always "collided" and the
                # later label -- usually the current month -- was
                # silently dropped. Measure the actual text width,
                # clamp the rect inside the chart, and skip only
                # when the text itself would overlap.
                text = self._fmt(v)
                tw = QFontMetrics(val_font).horizontalAdvance(text)
                lab_rect = QRectF(cx - tw / 2.0 - 2, y - 21, tw + 4, 19)
                if lab_rect.left() < R.left():
                    lab_rect.moveLeft(R.left())
                if lab_rect.right() > R.right():
                    lab_rect.moveRight(R.right())
                if not any(lab_rect.intersects(d) for d in drawn_labels):
                    p.setPen(QColor(C_MUTED))
                    p.setFont(val_font)
                    p.drawText(lab_rect,
                               Qt.AlignHCenter | Qt.AlignVCenter, text)
                    drawn_labels.append(lab_rect)

        # month labels (skip some if crowded)
        fm_lab = QFontMetrics(lab_font)
        step = 1
        while step < n and any(
                fm_lab.horizontalAdvance(self._data[j][0]) > slot * step - 4
                for j in range(0, n, step)):
            step += 1
        p.setPen(QColor(C_FAINT))
        p.setFont(lab_font)
        for j in range(0, n, step):
            cx = plot.left() + slot * j + slot / 2.0
            p.drawText(QRectF(cx - slot * step / 2.0, plot.bottom() + 6,
                              slot * step, 20),
                       Qt.AlignHCenter | Qt.AlignTop, self._data[j][0])


def _donut_legend_count_x(label, label_x, font):
    """X for a donut legend count: immediately right of its label.

    V1.9.17 (user report): labels sat at the left and totals at the
    far right edge, so label and total looked unrelated. The count now
    sits 12px after its own label instead of right-aligned to the card.
    """
    return label_x + QFontMetrics(font).horizontalAdvance(label) + 12


OUTCOME_ORDER = ["won", "lost", "dead", "on_hold", "unknown"]
OUTCOME_LABELS_CHART = {"won": "Won", "lost": "Lost", "dead": "Dead",
                        "on_hold": "On Hold", "unknown": "Unknown"}
OUTCOME_COLORS = {
    "won": STATUS_COLORS["completed"],
    "lost": "#e0655f",
    "dead": "#a05c48",
    "on_hold": STATUS_COLORS["on_hold"],
    "unknown": STATUS_COLORS["canceled"],
}


class DonutChart(QWidget):
    """Donut with legend. set_data({key: count}).

    Defaults to the By-status series; pass order/labels/colors to chart
    another key set (V1.9.29: the By-outcome donut reuses this widget
    with OUTCOME_* constants).
    """

    def __init__(self, parent=None, order=None, labels=None, colors=None):
        super().__init__(parent)
        self._counts = {}
        self._order = list(order) if order else list(STATUS_ORDER)
        self._labels = dict(labels) if labels else dict(STATUS_LABELS)
        self._colors = dict(colors) if colors else dict(STATUS_COLORS)
        self.setMinimumHeight(230)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_data(self, counts):
        self._counts = dict(counts or {})
        self.update()

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        R = self.rect().adjusted(8, 8, -8, -8)
        items = [(k, self._counts.get(k, 0)) for k in self._order]
        items = [(k, v) for k, v in items if v and v > 0]
        if not items:
            _draw_placeholder(p, R, "No tasks yet")
            return
        total = sum(v for _, v in items)

        legend_w = 168
        dia = min(R.height(), R.width() - legend_w - 28)
        dia = max(dia, 90)
        cx = R.left() + dia / 2.0 + 6
        cy = R.center().y()
        thickness = max(20.0, dia * 0.24)
        ring = QRectF(cx - dia / 2.0, cy - dia / 2.0, dia, dia)
        inner = ring.adjusted(thickness / 2.0, thickness / 2.0,
                              -thickness / 2.0, -thickness / 2.0)

        start = 90.0
        for key, val in items:
            span = -360.0 * val / total
            pen = QPen(QColor(self._colors[key]))
            pen.setWidthF(thickness)
            pen.setCapStyle(Qt.FlatCap)
            p.setPen(pen)
            p.drawArc(inner, int(round(start * 16)), int(round(span * 16)))
            start += span

        # center total
        f = self.font()
        f.setPointSize(22)
        f.setWeight(QFont.Bold)
        p.setFont(f)
        p.setPen(QColor(C_TEXT))
        p.drawText(ring, Qt.AlignCenter, str(total))
        f.setPointSize(10)
        f.setWeight(QFont.Normal)
        p.setFont(f)
        p.setPen(QColor(C_FAINT))
        sub = QRectF(ring)
        sub.translate(0, 22)
        p.drawText(sub, Qt.AlignHCenter | Qt.AlignTop, "tasks")

        # legend: count sits right after its label, not at the far edge
        lx = cx + dia / 2.0 + 22
        ly = R.top() + max(0, (R.height() - len(items) * 28) / 2.0)
        dot_r = 5
        for key, val in items:
            label = self._labels.get(key, key)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(self._colors[key]))
            p.drawEllipse(QPointF(lx + dot_r, ly + 10), dot_r, dot_r)
            p.setPen(QColor(C_META))
            f2 = self.font()
            f2.setPointSize(12)
            p.setFont(f2)
            p.drawText(QRectF(lx + 20, ly, 132, 20),
                       Qt.AlignLeft | Qt.AlignVCenter, label)
            f3 = self.font()
            f3.setPointSize(12)
            f3.setWeight(QFont.DemiBold)
            p.setFont(f3)
            p.setPen(QColor(C_TEXT))
            p.drawText(QRectF(_donut_legend_count_x(label, lx + 20, f2),
                              ly, 60, 20),
                       Qt.AlignLeft | Qt.AlignVCenter, str(val))
            ly += 28


class TopDistributorsChart(QWidget):
    """Horizontal bars: name left, bar, count right. set_data([(name, n)]).

    V1.9.17: rows are clickable — clicking a distributor emits
    row_clicked with the name, and the dashboard opens that
    distributor's quotes.
    """

    row_clicked = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data = []
        self._percent = False
        self.setMinimumHeight(230)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMouseTracking(True)

    def set_data(self, data, percent=False, labels=None):
        cleaned = []
        for name, n in (data or []):
            try:
                cleaned.append((str(name), float(n)))
            except (TypeError, ValueError):
                pass
        self._data = cleaned[:8]
        self._percent = bool(percent)
        # V1.9.30 (user): explicit per-row display labels. The By-win-
        # rate view passes "won/total" NUMBERS (V1.9.34: total, not
        # marked) -- he never asked for a percentage readout; the bar
        # length still encodes the rate.
        self._labels = (list(labels)[:len(self._data)]
                        if labels else None)
        self.update()

    def _row_at(self, pos):
        """Distributor name for a point, or None."""
        R = self.rect().adjusted(10, 10, -10, -10)
        if not self._data or all(v <= 0 for _, v in self._data):
            return None
        n = len(self._data)
        rh = R.height() / n
        if not (R.left() <= pos.x() <= R.right()
                and R.top() <= pos.y() <= R.bottom()):
            return None
        i = int((pos.y() - R.top()) // rh)
        if 0 <= i < n:
            return self._data[i][0]
        return None

    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.button() == Qt.LeftButton:
            name = self._row_at(event.position().toPoint())
            if name is not None:
                self.row_clicked.emit(name)
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: N802 (Qt virtual)
        self.setCursor(Qt.PointingHandCursor
                       if self._row_at(event.position().toPoint()) is not None
                       else Qt.ArrowCursor)
        super().mouseMoveEvent(event)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        R = self.rect().adjusted(10, 10, -10, -10)
        if not self._data or all(v <= 0 for _, v in self._data):
            _draw_placeholder(p, R, "No distributors yet")
            return
        max_v = max(v for _, v in self._data)
        n = len(self._data)
        rh = R.height() / n
        bar_h = min(16.0, rh * 0.4)

        name_w = R.width() * 0.34
        val_w = 52
        bx = R.left() + name_w + 12
        bw_area = R.right() - val_w - 8 - bx
        if bw_area < 30:
            _draw_placeholder(p, R, "No distributors yet")
            return

        name_font = self.font()
        name_font.setPointSize(12)
        val_font = self.font()
        val_font.setPointSize(12)
        val_font.setWeight(QFont.DemiBold)
        fm = QFontMetrics(name_font)

        for i, (name, v) in enumerate(self._data):
            y = R.top() + i * rh
            cy = y + rh / 2.0
            # name (elided)
            p.setPen(QColor(C_META))
            p.setFont(name_font)
            p.drawText(QRectF(R.left(), y, name_w, rh),
                       Qt.AlignLeft | Qt.AlignVCenter,
                       fm.elidedText(name, Qt.ElideRight, int(name_w)))
            # track
            track = QRectF(bx, cy - bar_h / 2.0, bw_area, bar_h)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(C_TRACK))
            p.drawRoundedRect(track, bar_h / 2.0, bar_h / 2.0)
            # fill
            w = max(bar_h, (v / max_v) * bw_area) if max_v else 0
            p.setBrush(QColor(C_ACCENT))
            p.drawRoundedRect(QRectF(bx, cy - bar_h / 2.0, w, bar_h),
                              bar_h / 2.0, bar_h / 2.0)
            # count
            p.setPen(QColor(C_TEXT))
            p.setFont(val_font)
            if getattr(self, "_labels", None):
                _txt = (self._labels[i]
                        if i < len(self._labels) else _int_fmt(v))
            else:
                _txt = f"{v:.0f}%" if self._percent else _int_fmt(v)
            p.drawText(QRectF(R.right() - val_w, y, val_w, rh),
                       Qt.AlignRight | Qt.AlignVCenter, _txt)


# --------------------------------------------------------------------------
# numeric-aware table item (header-click sorting on numeric columns)
# --------------------------------------------------------------------------
class _NumItem(QTableWidgetItem):
    def __init__(self, text, value):
        super().__init__(text)
        self._num = value
        self.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

    def __lt__(self, other):
        if isinstance(other, _NumItem):
            return self._num < other._num
        return super().__lt__(other)


def _nitem(text, value):
    """Right-aligned numeric cell with tabular figures."""
    it = _NumItem(text, value)
    it.setFont(_table_font(13, tabular=True))
    return it


def _name_item(text):
    """Primary-identifier cell (quote #, distributor name): more prominent."""
    it = QTableWidgetItem(text)
    it.setFont(_table_font(13, QFont.DemiBold))
    it.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
    return it


def _text_item(text):
    it = QTableWidgetItem(text)
    it.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
    return it


# --------------------------------------------------------------------------
# Clickable row helpers: dashboard lists where a row opens a detail view
# --------------------------------------------------------------------------
class NudgeCard(QFrame):
    """One distributor check-in nudge card.

    Clicking the body (or pressing Enter/Space while focused) emits
    ``open_requested`` with the distributor name; the page opens the CRM
    contact card. The Dismiss button is a child widget, so its clicks
    never reach this card's press handler.
    """

    open_requested = Signal(str)  # distributor name

    def __init__(self, name, parent=None):
        super().__init__(parent)
        self._name = name
        self.setObjectName("nudgeCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setToolTip("Open distributor in CRM")

    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.button() == Qt.LeftButton:
            self.open_requested.emit(self._name)
        super().mousePressEvent(event)

    def keyPressEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.open_requested.emit(self._name)
            event.accept()
            return
        super().keyPressEvent(event)


def _task_id_of_row(table, row):
    """Task id stored on a drill-down row (column 0 item, Qt.UserRole)."""
    item = table.item(row, 0) if row >= 0 else None
    if item is None:
        return None
    try:
        tid = int(item.data(Qt.UserRole) or 0)
    except (TypeError, ValueError):
        return None
    return tid or None


# --------------------------------------------------------------------------
# KPI drill-down dialog: sortable task list behind a clickable KPI card
# --------------------------------------------------------------------------
class TaskDrilldownDialog(QDialog):
    """Themed sortable task list opened from a dashboard KPI card.

    Columns: quote #, distributor, end user, created, completed, days to
    complete, quote price, status, outcome. Header-click sorts; numeric and
    date columns sort by value, not by display text.

    Every row opens its task on DOUBLE-click (or Enter/Space when the
    table is focused) and emits ``open_task_requested`` with the task id;
    the dashboard page forwards it so the app opens the task detail
    window. Single click only selects — V1.9.16, after the dialog opened
    tasks on a single click and opened them behind itself.
    """

    open_task_requested = Signal(int)  # user clicked/activated a task row

    COLUMNS = ("Quote #", "Distributor", "End User", "Created", "Completed",
               "Days", "Price", "Status", "Outcome")

    # Sensible minimum readable widths per column, in COLUMNS order:
    # Quote #, Distributor, End User, Created, Completed, Days, Price,
    # Status, Outcome. ("Est. hours" appends an extra 80px minimum when
    # show_hours is on.)
    MIN_COL_WIDTHS = (70, 180, 180, 90, 90, 60, 80, 100, 80)

    # V1.9.17: logistics mode — the KPI drilldowns show the metric's
    # own numbers per quote (lead time, shipping, freight, trucks),
    # not the generic task columns, which carried none of them.
    LOG_COLUMNS = ("Quote #", "Distributor", "End User", "Lead time",
                   "Shipping", "Freight / truck", "Trucks",
                   "Freight total")
    LOG_MIN_COL_WIDTHS = (80, 180, 180, 110, 110, 110, 80, 120)

    def __init__(self, title, rows, parent=None, *, show_hours=False,
                 settings_key=None, logistics=False, period_filter=False,
                 money_total=False):
        super().__init__(parent)
        self.setAttribute(Qt.WA_DeleteOnClose)
        # QSettings key (under "drilldown/") used to remember this dialog's
        # size between opens, so the user never has to re-widen it.
        self._settings_key = settings_key
        if logistics:
            columns = list(self.LOG_COLUMNS)
            widths = list(self.LOG_MIN_COL_WIDTHS)
        else:
            columns = list(self.COLUMNS)
            widths = list(self.MIN_COL_WIDTHS)
        if show_hours and not logistics:
            columns.append("Est. hours")
            widths.append(80)
        self._column_count = len(columns)  # _fill_key_column sizes column 1
        # Default size is computed from the fitted columns after the table
        # is built (see _fit_dialog_to_columns); the minimum keeps the
        # dialog usable on small screens.
        self.setMinimumSize(1020, 520)
        # dashboard table/header QSS lives in _DASH_QSS (scoped to #dash*
        # object names); apply it here so the dialog matches the page even
        # though it isn't a child of DashboardPage.
        set_dash_theme(saved_theme())
        self.setStyleSheet(dash_qss())
        layout = install_chrome(self, title)
        layout.setSpacing(10)

        # V1.9.29 (user): period filter for the Win rate / Won value
        # drilldowns -- All time / Week / Month / Year over each row's
        # created date, same bucketBtn language as the quotes chart.
        self._period_mode = "all"
        if period_filter and not logistics:
            prow = QHBoxLayout()
            prow.setSpacing(6)
            self._period_group = QButtonGroup(self)
            self._period_group.setExclusive(True)
            self._period_group.buttonClicked.connect(
                lambda b: self._set_period(b.property("periodMode")))
            for mode, text in (("all", "All time"), ("week", "Week"),
                               ("month", "Month"), ("year", "Year")):
                b = QPushButton(text)
                b.setObjectName("bucketBtn")
                b.setCheckable(True)
                b.setProperty("periodMode", mode)
                b.setChecked(mode == "all")
                self._period_group.addButton(b)
                prow.addWidget(b)
            prow.addStretch(1)
            layout.addLayout(prow)

        n = len(rows)
        self._total_rows = n
        # V1.9.29 (user, commission tracking): the Won value / Total
        # quote value drilldowns state their money total right in the
        # count line, and the period filter keeps it in sync -- the
        # number on the card must be reconcilable from this list at
        # a glance, with no hand-adding.
        self._money_total = bool(money_total)
        self._rows_value = sum(
            float(r.get("quote_value") or 0) for r in rows)
        word = "quote" if logistics else "task"
        count = QLabel(f"{n} {word}{'s' if n != 1 else ''}")
        count.setObjectName("dashKpiSub")
        self._count_label = count
        layout.addWidget(count)

        self.table = QTableWidget()
        self.table.setObjectName("dashTable")
        _style_data_table(self.table)
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(
            [c.upper() for c in columns])
        self.table.horizontalHeader().setObjectName("dashHeader")
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeToContents)
        # Distributor is the one key column that fills leftover width. It is
        # filled manually (see _fill_key_column): a native Stretch section
        # cannot hold a minimum width — Qt re-shrinks it instead of engaging
        # the horizontal scrollbar.
        for c in range(1, len(columns)):
            self.table.horizontalHeader().setSectionResizeMode(
                c, QHeaderView.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setSortingEnabled(False)
        self.table.setShowGrid(False)

        self.table.setRowCount(n)
        for i, r in enumerate(rows):
            if logistics:
                # Metric rows from _logistics_data: quote identity plus
                # the freight/lead-time numbers the KPI was computed
                # from. Task id rides on column 0 (UserRole) so a row
                # double-click still opens the detail window.
                quote_item = _name_item(str(r.get("quote_number") or ""))
                try:
                    quote_item.setData(Qt.UserRole, int(r.get("id") or 0))
                except (TypeError, ValueError):
                    pass
                self.table.setItem(i, 0, quote_item)
                self.table.setItem(
                    i, 1, _text_item(str(r.get("distributor") or "—")))
                self.table.setItem(
                    i, 2, _text_item(str(r.get("end_user") or "—")))
                lead_txt = (f"{format_week_range(r['weeks'])} wks"
                            if r.get("weeks") else
                            (f"{r['weeks_raw']} wks" if r.get("weeks_raw")
                             else "—"))
                lead_sort = ((r["weeks"][0] + r["weeks"][1]) / 2
                             if r.get("weeks") else -1)
                self.table.setItem(i, 3, _nitem(lead_txt, lead_sort))
                ship_txt = (f"{_fmt_num(r['ship'])} wks"
                            if r.get("ship") is not None else
                            (f"{r['ship_raw']} wks" if r.get("ship_raw")
                             else "—"))
                self.table.setItem(i, 4, _nitem(ship_txt,
                                                _fnum(r.get("ship"))))
                self.table.setItem(i, 5, _nitem(
                    format_money_value(r.get("cost"))
                    if r.get("cost") is not None
                    else (r.get("cost_raw") or "—"),
                    _fnum(r.get("cost"))))
                self.table.setItem(i, 6, _nitem(
                    str(r["trucks"]) if r.get("trucks") is not None
                    else (r.get("trucks_raw") or "—"),
                    _fnum(r.get("trucks"))))
                self.table.setItem(i, 7, _nitem(
                    format_money_value(r.get("freight_total")),
                    _fnum(r.get("freight_total"))))
                continue
            days = _days_between(r.get("created_at"), r.get("completed_at"))
            price = r.get("quote_value")
            created_txt = _short_date(r.get("created_at")) or "—"
            completed_txt = _short_date(r.get("completed_at")) or "—"
            outcome = (r.get("outcome") or "").lower()
            quote_item = _name_item(str(r.get("quote_number") or ""))
            # Task id rides on column 0 (UserRole) so a row click/Enter can
            # open the detail window; survives sorting since it moves with
            # the item. The created date rides along too (UserRole + 1)
            # for the V1.9.29 period filter, which also reads it off the
            # item so sorting can't desync it from its row.
            try:
                quote_item.setData(Qt.UserRole, int(r.get("id") or 0))
            except (TypeError, ValueError):
                pass
            quote_item.setData(Qt.UserRole + 1,
                               str(r.get("created_at") or ""))
            try:
                quote_item.setData(Qt.UserRole + 2,
                                   float(r.get("quote_value") or 0))
            except (TypeError, ValueError):
                pass
            self.table.setItem(i, 0, quote_item)
            self.table.setItem(i, 1, _text_item(str(r.get("distributor") or "—")))
            self.table.setItem(i, 2, _text_item(str(r.get("end_user") or "—")))
            self.table.setItem(i, 3, _nitem(created_txt, _epoch(r.get("created_at"))))
            self.table.setItem(i, 4, _nitem(completed_txt, _epoch(r.get("completed_at"))))
            self.table.setItem(i, 5, _nitem(
                f"{days:.1f}" if days is not None else "—",
                days if days is not None else -1))
            self.table.setItem(i, 6, _nitem(
                _money(price), _fnum(price)))
            self.table.setItem(i, 7, _text_item(
                STATUS_LABELS.get(r.get("status"), r.get("status") or "—")))
            self.table.setItem(i, 8, _text_item(
                {"won": "Won", "lost": "Lost", "dead": "Dead",
                 "on_hold": "On Hold"}.get(outcome, "—")))
            if show_hours:
                hrs = r.get("estimated_hours")
                self.table.setItem(i, 9, _nitem(
                    _hours_compact(hrs), _fnum(hrs)))
        self.table.setSortingEnabled(True)
        self.table.resizeColumnsToContents()
        # Freeze the sized widths (switching resize mode resets widths set
        # via setColumnWidth, so the minimums go on after the mode switch):
        # every column stays user-resizable but no longer auto-shrinks on
        # later layouts. The Distributor fill is applied in _fill_key_column.
        for c in range(len(columns)):
            self.table.horizontalHeader().setSectionResizeMode(
                c, QHeaderView.Interactive)
        # Then enforce: never clip a column below its minimum readable
        # width, even in narrow windows or with short contents.
        for c, mw in enumerate(widths):
            if self.table.columnWidth(c) < mw:
                self.table.setColumnWidth(c, mw)
        self._ensure_readable_columns()
        # Breathing room: measured widths sit within a few px of the text on
        # the dev machine, and cross-platform font-metric differences flip
        # those tight columns into elision. Pad every column so the fitted
        # width is never borderline, then size the dialog to fit the table.
        fitted = [self.table.columnWidth(c) + 12 for c in range(len(columns))]
        for c, w in enumerate(fitted):
            self.table.setColumnWidth(c, w)
        self._fit_dialog_to_columns(sum(fitted))
        layout.addWidget(self.table, 1)
        # Every row opens the task detail window on DOUBLE-click, or
        # Enter/Space when the table (a row) is focused. Sorting stays on
        # the headers; header clicks don't reach cellDoubleClicked.
        # Single click only selects (V1.9.16: single-click-to-open was
        # opening tasks the user only meant to look at).
        self.table.viewport().setCursor(Qt.PointingHandCursor)
        self.table.cellDoubleClicked.connect(self._on_row_clicked)
        self.table.installEventFilter(self)

    # -- V1.9.29 period filter (Win rate / Won value drilldowns) ----
        # V1.9.29: with a period filter present, run it once now so
        # the count line is born correct -- for money drilldowns that
        # means carrying the total from the first frame, not only
        # after the user touches a period button. Without a period
        # row, a money total is appended directly.
        if period_filter:
            self._apply_period()
        elif self._money_total:
            self._count_label.setText(
                f"{self._count_label.text()} · "
                f"{_money(self._rows_value)} total")

    def _set_period(self, mode):
        if mode not in ("all", "week", "month", "year"):
            return
        self._period_mode = mode
        self._apply_period()

    def _apply_period(self):
        mode = self._period_mode
        today = date.today()
        monday = today - timedelta(days=today.weekday())
        week_lo = monday.isoformat()
        week_hi = (monday + timedelta(days=7)).isoformat()
        month_key = today.strftime("%Y-%m")
        year_key = today.strftime("%Y")

        def keep(created):
            if mode == "all":
                return True
            d = (created or "")[:10]
            if not d:
                return False
            if mode == "week":
                return week_lo <= d < week_hi
            if mode == "month":
                return d.startswith(month_key)
            return d.startswith(year_key)

        visible = 0
        visible_value = 0.0
        for i in range(self.table.rowCount()):
            item = self.table.item(i, 0)
            created = item.data(Qt.UserRole + 1) if item is not None else ""
            k = keep(created)
            self.table.setRowHidden(i, not k)
            if k:
                visible += 1
                v = item.data(Qt.UserRole + 2) if item is not None else 0
                visible_value += float(v or 0)
        suffix = (f" · {_money(visible_value)} total"
                  if self._money_total else "")
        if mode == "all":
            self._count_label.setText(
                f"{self._total_rows} task"
                f"{'s' if self._total_rows != 1 else ''}{suffix}")
        else:
            self._count_label.setText(
                f"{visible} of {self._total_rows} tasks "
                f"(this {mode}){suffix}")

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        if obj is self.table and event.type() == QEvent.KeyPress:
            if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
                self._open_current_row()
                return True
        return super().eventFilter(obj, event)

    def _on_row_clicked(self, row, _column):
        tid = _task_id_of_row(self.table, row)
        if tid is not None:
            # Close FIRST: this dialog is modal (exec), so a detail
            # window opened while it is up lands behind it. Closing
            # first puts the detail in front; the list is one click
            # away on the KPI card. (accept() only schedules deletion
            # via deleteLater, so the emit below still delivers.)
            self.accept()
            self.open_task_requested.emit(tid)

    def _open_current_row(self):
        """Keyboard activation: open the currently selected row's task."""
        self._on_row_clicked(self.table.currentRow(), 0)

    def _ensure_readable_columns(self):
        """Widen any column whose widest content would elide.

        V1.9.16 (user report): dates ("Oct 27, 2026") and prices
        ("$30,329") elided at standard lengths. resizeColumnsToContents
        does not account for the dashTable QSS item padding (8px a
        side), and the old code only padded 12px — so columns landed
        short on his machine's font metrics. Measure with the table's
        own fonts and require text + 16px QSS padding + 8px breathing
        room (headers get 12px extra for letter-spacing and the sort
        arrow). A floor, never a shrink; the dialog width derives after
        it, so a previously saved narrower size cannot re-elide them.
        """
        t = self.table
        fm = QFontMetrics(t.font())
        hfm = QFontMetrics(t.horizontalHeader().font())
        for c in range(self._column_count):
            need = 0
            hdr = t.horizontalHeaderItem(c)
            if hdr is not None:
                need = hfm.horizontalAdvance(hdr.text()) + 16 + 12
            for r in range(t.rowCount()):
                item = t.item(r, c)
                if item is not None:
                    need = max(need,
                               fm.horizontalAdvance(item.text()) + 16 + 8)
            if t.columnWidth(c) < need:
                t.setColumnWidth(c, need)

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        QTimer.singleShot(0, self._fill_key_column)
        QTimer.singleShot(0, self._clear_initial_highlight)

    def _clear_initial_highlight(self):
        """No row is current or selected on open.

        V1.9.16 (user report): the dialog opened with row 0 highlighted
        (Qt makes the first row current when the table takes focus). A
        highlight nobody asked for reads as a selection, so clear it
        once the dialog is shown; the user selects by clicking.
        """
        self.table.clearSelection()
        self.table.setCurrentIndex(QModelIndex())

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # Deferred: the table's viewport only has its new width after the
        # layout pass that follows this event.
        QTimer.singleShot(0, self._fill_key_column)

    @staticmethod
    def _wanted_size(table_need, avail_w, avail_h, saved=None):
        """Pure width/height computation for _fit_dialog_to_columns.

        Separated so the sizing contract is unit-testable without a screen:
        wide enough for the fitted columns plus chrome, never narrower than
        the fitted need even when restoring a smaller saved size, and capped
        at 92% / 90% of the available screen.
        """
        chrome = 48 + 4  # content margins + frame border (V1.9.2: the
        # window frame ends at the window edge, so no shadow slack)
        need = table_need + 16 + chrome  # 16px: vertical scrollbar allowance
        cap_w, cap_h = int(avail_w * 0.92), int(avail_h * 0.9)
        want_w = min(max(need, 1020), cap_w)
        want_h = min(max(640, 520), cap_h)
        if saved is not None and saved.isValid():
            want_w = min(max(saved.width(), need), cap_w)
            want_h = min(max(saved.height(), 520), cap_h)
        return int(want_w), int(want_h)

    def _fit_dialog_to_columns(self, table_need):
        """Size the dialog so every fitted column is readable on first open.

        The old hardcoded 1220px default elided columns on machines whose
        font metrics render slightly wider than the dev machine's. Instead,
        derive the width from the actual fitted columns: table width +
        vertical-scrollbar allowance + chrome margins, capped at 92% of the
        available screen. A previously saved user size is restored when it
        still fits the content (never smaller than the fitted need).
        """
        screen = self.screen()
        avail = (screen.availableGeometry() if screen is not None
                 else QApplication.primaryScreen().availableGeometry())
        saved = None
        if self._settings_key:
            v = QSettings("TaskListApp", "TaskList").value(
                f"drilldown/size/{self._settings_key}")
            if isinstance(v, QSize):
                saved = v
        want_w, want_h = self._wanted_size(table_need, avail.width(),
                                           avail.height(), saved)
        self.resize(want_w, want_h)

    def hideEvent(self, event):  # noqa: N802 (Qt virtual)
        # Remember the size (not position) so the next open keeps the user's
        # widening. hideEvent covers every close path: X button, Esc, done().
        if self._settings_key:
            QSettings("TaskListApp", "TaskList").setValue(
                f"drilldown/size/{self._settings_key}", self.size())
        super().hideEvent(event)

    def _fill_key_column(self):
        """Size the Distributor column (1) to fill leftover viewport width.

        Manual replacement for a Stretch section: native stretch re-shrinks
        the column below its minimum instead of engaging the horizontal
        scrollbar, so the fill is computed here with a hard 180px floor —
        when the dialog is too narrow the table scrolls instead of clipping.
        """
        try:
            t = self.table
        except (AttributeError, RuntimeError):
            return
        others = sum(t.columnWidth(c) for c in range(self._column_count)
                     if c != 1)
        want = max(self.MIN_COL_WIDTHS[1], t.viewport().width() - others)
        if t.columnWidth(1) != want:
            t.setColumnWidth(1, want)


class DistributorMetricsDialog(QDialog):
    """Ranked distributor metrics (V1.9.30, user): clicking the Main
    Distributor KPI used to open just that distributor's CRM card.
    The user wants the METRICS instead -- every distributor (top 25)
    ranked by quote count, the leader on top, with the money and
    outcome numbers per distributor. Double-clicking a row opens
    that distributor's task drilldown.
    """

    distributor_chosen = Signal(str)

    COLUMNS = ("#", "Distributor", "Quotes", "Total value",
               "Won value", "Win rate", "Last quoted")

    def __init__(self, stats, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setMinimumSize(860, 480)
        set_dash_theme(saved_theme())
        self.setStyleSheet(dash_qss())
        layout = install_chrome(
            self, f"Distributor metrics — Top {len(stats)}")
        layout.setSpacing(10)
        self.table = QTableWidget(len(stats), len(self.COLUMNS))
        self.table.setObjectName("dashTable")
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(
            QAbstractItemView.SelectRows)
        self.table.setSelectionMode(
            QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        _style_data_table(self.table)
        for i, s in enumerate(stats):
            rate = s.get("win_rate")
            values = [
                str(i + 1),
                str(s.get("name") or "—"),
                str(s.get("quotes") or 0),
                _money(s.get("total_value") or 0),
                _money(s.get("won_value") or 0),
                f"{float(rate):.0f}%" if rate is not None else "—",
                _short_date(s.get("last_quote") or ""),
            ]
            for c, v in enumerate(values):
                item = QTableWidgetItem(v)
                if c in (0, 2, 3, 4, 5):
                    item.setTextAlignment(
                        Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(i, c, item)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.cellDoubleClicked.connect(self._on_row_chosen)
        layout.addWidget(self.table)
        hint = QLabel("Double-click a distributor to see its quotes.")
        hint.setObjectName("dashKpiSub")
        layout.addWidget(hint)
        self.resize(920, 560)

    def _on_row_chosen(self, row, _col):
        item = self.table.item(row, 1)
        if item is not None:
            self.distributor_chosen.emit(item.text())
            self.accept()


# --------------------------------------------------------------------------
# Dashboard page
# --------------------------------------------------------------------------
class DashboardPage(QWidget):
    open_task_requested = Signal(int)  # user clicked Open on a follow-up

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self._db = db
        self.setObjectName("dashPage")
        set_dash_theme(saved_theme())
        self.setStyleSheet(dash_qss())

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 14, 20, 18)
        root.setSpacing(12)

        title = QLabel("Dashboard")
        title.setObjectName("title")
        root.addWidget(title)
        sub = QLabel("Live overview of quotes, distributors, and follow-ups.")
        sub.setObjectName("subtitle")
        root.addWidget(sub)

        self._tabs = QTabWidget()
        self._tabs.setObjectName("dashTabs")
        # V1.9.18 (user report: white line above the tabs): the tab
        # bar's base line, drawn by the style. drawBase off removes
        # it; the pane QSS already says border:none for the content
        # frame. Applied after setTabBar below (which replaces the
        # bar) — setting it before would land on the discarded bar.
        # Sliding tab pill (AnimatedTabBar) — must be set before tabs
        # are added, or QTabWidget keeps the stock bar.
        self._tabs.setTabBar(AnimatedTabBar())
        self._tabs.tabBar().setDrawBase(False)
        # V1.9.18: tab CONTENT slides like everything else (user order:
        # sliding animations everywhere). The press on the tab bar is
        # captured before the switch so the outgoing page can be
        # grabbed; currentChanged then slides old -> new.
        self._tab_old_pix = None
        self._tabs.tabBar().installEventFilter(self)
        self._tabs.currentChanged.connect(self._on_tab_changed)
        root.addWidget(self._tabs, 1)

        self._bucket_mode = "month"
        self._bucket_btns = {}
        self._main_distributor_name = ""
        self._build_overview_tab()
        self._build_logistics_tab()
        self._build_distributors_tab()
        self._build_nudges_tab()
        self._apply_page_backgrounds()

        self.refresh()
        _chip_font_tree(self)

    # -- tab construction -------------------------------------------------
    def _scroll_wrap(self, inner):
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QScrollArea.NoFrame)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sc.setWidget(inner)
        # App-wide scroll insets (covers the Overview and Nudges tabs):
        # content keeps clear of the viewport edges and the vertical
        # scrollbar. Call-site margins below are superseded by this.
        set_scroll_content_margins(sc)
        return sc

    def _chart_card(self, title):
        card = QFrame()
        card.setObjectName("dashCard")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(18, 14, 18, 12)
        lay.setSpacing(8)
        if title:
            t = QLabel(title)
            t.setObjectName("dashChartTitle")
            lay.addWidget(t)
        return card, lay

    def _build_overview_tab(self):
        tab = QWidget()
        # NOTE: the scroll area stays at the tab's content column — a child
        # widget cannot bleed past its parent tab's bounds (it would clip).
        # Its scrollbar is flush with the scroll area via the shared QSS
        # rule; _ScrollBleedLayout applies to dialogs only.
        outer = QVBoxLayout(tab)
        outer.setContentsMargins(4, 10, 4, 4)
        outer.setSpacing(0)

        inner = QWidget()
        lay = QVBoxLayout(inner)
        # Content insets come from _scroll_wrap (app-wide scroll convention).
        lay.setSpacing(14)

        lay.addWidget(_section_label("Key metrics"))
        kpi_host = _KpiHost()
        self._kpi_host = kpi_host
        # V1.9.34 (user: "EQUAL SAME SIZES" — the balanced flow made
        # each ROW stretch its own cards, so the bottom row's cards
        # came out wider than the top row's: jenga). The strip is a
        # 12-unit grid: every standard card spans 2 units (all
        # identical), and ONLY Total quote value / Won value — the
        # two the user named — span 3. Card geometry is assigned
        # MANUALLY in _layout_kpi_cards (no layout manager): the
        # QGridLayout solver measurably refused to keep its own
        # rows' right edges aligned, so it no longer gets a vote.
        self._kpi_cards = []  # [(card, row, col, span)] in order
        kpi_host.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        lay.addWidget(kpi_host)

        lay.addWidget(_section_label("Trends"))
        grid = QGridLayout()
        grid.setSpacing(14)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)

        card, clay = self._chart_card(None)  # custom header w/ bucket toggle
        head = QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(6)
        self._quotes_title = QLabel("Quotes per month")
        self._quotes_title.setObjectName("dashChartTitle")
        head.addWidget(self._quotes_title)
        head.addStretch(1)
        # V1.9.29 (user): outcome dropdown filter on the chart --
        # Total (as it always was) / Won / Lost / Dead / On Hold.
        self._quotes_outcome = "total"
        self._quotes_outcome_box = SafeComboBox()
        self._quotes_outcome_box.setObjectName("dashOutcomeBox")
        for label, key in (("Total", "total"), ("Won", "won"),
                           ("Lost", "lost"), ("Dead", "dead"),
                           ("On Hold", "on_hold")):
            self._quotes_outcome_box.addItem(label, key)
        self._quotes_outcome_box.currentIndexChanged.connect(
            self._on_quotes_outcome_changed)
        head.addWidget(self._quotes_outcome_box)
        # V1.9.30 (user): the chart toggles are the app's ANIMATED
        # segmented control (sliding highlight), not separate
        # buttons -- same component as the Top distributors and
        # Breakdown toggles below.
        self._bucket_seg = AnimatedSegControl(
            [("month", "Month"), ("week", "Week"), ("year", "Year")],
            self)
        for _mode, _btn in self._bucket_seg.buttons.items():
            _btn.clicked.connect(
                lambda _=False, m=_mode: self._set_bucket_mode(m))
        self._bucket_btns = self._bucket_seg.buttons
        self._bucket_seg.set_checked(self._bucket_mode)
        head.addWidget(self._bucket_seg)
        clay.addLayout(head)
        self._quotes_chart = MonthlyBarChart(color=C_ACCENT)
        self._quotes_chart.bar_clicked.connect(self._open_month_drilldown)
        clay.addWidget(self._quotes_chart)
        grid.addWidget(card, 0, 0)

        card, clay = self._chart_card(None)  # custom header w/ filter
        vhead = QHBoxLayout()
        vhead.setContentsMargins(0, 0, 0, 0)
        vhead.setSpacing(6)
        vtitle = QLabel("Quote value per month")
        vtitle.setObjectName("dashChartTitle")
        vhead.addWidget(vtitle)
        vhead.addStretch(1)
        # V1.9.29 (user): same Total / Won / Lost / Dead / On Hold
        # dropdown filter as the Quotes chart.
        self._value_outcome = "total"
        self._value_outcome_box = SafeComboBox()
        self._value_outcome_box.setObjectName("dashOutcomeBox")
        for label, key in (("Total", "total"), ("Won", "won"),
                           ("Lost", "lost"), ("Dead", "dead"),
                           ("On Hold", "on_hold")):
            self._value_outcome_box.addItem(label, key)
        self._value_outcome_box.currentIndexChanged.connect(
            self._on_value_outcome_changed)
        vhead.addWidget(self._value_outcome_box)
        clay.addLayout(vhead)
        self._value_chart = MonthlyBarChart(
            color=C_MONEY, value_fmt=_money,
            placeholder="No quote values recorded yet")
        self._value_chart.bar_clicked.connect(
            lambda label: self._open_month_drilldown(label, mode="month"))
        clay.addWidget(self._value_chart)
        grid.addWidget(card, 0, 1)

        card, clay = self._chart_card(None)  # custom header w/ toggle
        thead = QHBoxLayout()
        thead.setContentsMargins(0, 0, 0, 0)
        thead.setSpacing(6)
        ttitle = QLabel("Top distributors")
        ttitle.setObjectName("dashChartTitle")
        thead.addWidget(ttitle)
        thead.addStretch(1)
        # V1.9.29 (user): toggle between ranking by quote count and
        # by win rate -- both feed his commission tracking.
        # V1.9.30: rendered as the animated segmented toggle.
        self._topdist_mode = "quotes"
        self._topdist_seg = AnimatedSegControl(
            [("quotes", "By quotes"), ("winrate", "By win rate")], self)
        for _mode, _btn in self._topdist_seg.buttons.items():
            _btn.clicked.connect(
                lambda _=False, m=_mode: self._set_topdist_mode(m))
        self._topdist_btns = self._topdist_seg.buttons
        self._topdist_seg.set_checked(self._topdist_mode)
        thead.addWidget(self._topdist_seg)
        clay.addLayout(thead)
        self._topdist = TopDistributorsChart()
        self._topdist.row_clicked.connect(
            lambda name: self._open_drilldown("distributor", name=name))
        clay.addWidget(self._topdist)
        grid.addWidget(card, 1, 0)

        # V1.9.30 (user): By status and By outcome are ONE card now.
        # Two near-identical donuts wasted a grid cell; a toggle in
        # the same bucketBtn language as Top distributors switches
        # the single donut between the two series.
        card, clay = self._chart_card(None)  # custom header w/ toggle
        dhead = QHBoxLayout()
        dhead.setContentsMargins(0, 0, 0, 0)
        dhead.setSpacing(6)
        dtitle = QLabel("Breakdown")
        dtitle.setObjectName("dashChartTitle")
        dhead.addWidget(dtitle)
        dhead.addStretch(1)
        self._donut_mode = "status"
        self._donut_seg = AnimatedSegControl(
            [("status", "By status"), ("outcome", "By outcome")], self)
        for _mode, _btn in self._donut_seg.buttons.items():
            _btn.clicked.connect(
                lambda _=False, m=_mode: self._set_donut_mode(m))
        self._donut_btns = self._donut_seg.buttons
        self._donut_seg.set_checked(self._donut_mode)
        dhead.addWidget(self._donut_seg)
        clay.addLayout(dhead)
        self._donut = DonutChart()
        clay.addWidget(self._donut)
        grid.addWidget(card, 1, 1)


        self._overview_grid = grid
        grid_wrap = QWidget()
        grid_wrap.setLayout(grid)
        lay.addWidget(grid_wrap)
        lay.addStretch(1)

        outer.addWidget(self._scroll_wrap(inner))
        self._tabs.addTab(tab, "Overview")

    # -- freight & lead time tab (V1.9.10) --------------------------------
    def _build_logistics_tab(self):
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(4, 14, 4, 4)
        lay.setSpacing(10)
        lay.addWidget(_section_label("Freight & lead time"))

        controls = QHBoxLayout()
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(8)
        search_lab = QLabel("Search")
        search_lab.setObjectName("dashKpiSub")
        controls.addWidget(search_lab)
        # V1.9.16 (user request): the Show dropdown is gone — a search
        # bar filters the quotes (number, distributor, end user) and the
        # KPI cards follow the filtered set. Empty = all quotes.
        self._logistics_search = QLineEdit()
        self._logistics_search.setPlaceholderText("Search quotes…")
        self._logistics_search.setClearButtonEnabled(True)
        self._logistics_search.setToolTip(
            "Filter by quote number, distributor, or end user")
        self._logistics_search.textChanged.connect(
            lambda _t: self._refresh_logistics())
        controls.addWidget(self._logistics_search)
        controls.addStretch(1)
        lay.addLayout(controls)

        kpi_host = _KpiHost()
        self._logistics_flow = _FlowLayout(kpi_host, hspacing=12, vspacing=12)
        kpi_host.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        lay.addWidget(kpi_host)

        self._logistics_table = QTableWidget()
        self._logistics_table.setObjectName("dashTable")
        _style_data_table(self._logistics_table)
        self._logistics_headers = [
            "QUOTE #", "DISTRIBUTOR", "END USER", "STATUS",
            "COST / TRUCK", "TRUCKS", "EST. FREIGHT",
            "LEAD TIME", "SHIPPING",
        ]
        self._logistics_table.setColumnCount(len(self._logistics_headers))
        self._logistics_table.setHorizontalHeaderLabels(
            self._logistics_headers)
        self._logistics_table.horizontalHeader().setObjectName("dashHeader")
        self._logistics_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch)
        for c in range(len(self._logistics_headers)):
            if c != 1:
                self._logistics_table.horizontalHeader().setSectionResizeMode(
                    c, QHeaderView.ResizeToContents)
        self._logistics_table.verticalHeader().setVisible(False)
        self._logistics_table.setEditTriggers(
            QAbstractItemView.NoEditTriggers)
        self._logistics_table.setSelectionBehavior(
            QAbstractItemView.SelectRows)
        self._logistics_table.setSelectionMode(
            QAbstractItemView.SingleSelection)
        self._logistics_table.setSortingEnabled(True)
        self._logistics_table.setShowGrid(False)
        self._logistics_table.cellDoubleClicked.connect(self._open_logistics_row)
        self._logistics_table.installEventFilter(self)
        lay.addWidget(self._logistics_table, 1)

        self._logistics_empty = QLabel(
            "No freight or lead-time details recorded yet.\n"
            "Check off Freight or Lead-Time in a quote's scope and save the "
            "details — they will appear here and on the quote's card.")
        self._logistics_empty.setObjectName("dashKpiSub")
        self._logistics_empty.setWordWrap(True)
        lay.addWidget(self._logistics_empty)
        self._tabs.addTab(tab, "Freight && Lead-Time")

    def _logistics_data(self):
        """Parsed freight/lead-time rows for every task that recorded any.

        Read-only and defensive: unparseable values keep their raw text for
        the table and are simply excluded from the numeric aggregates.
        """
        tasks = _safe(lambda: self._db.list_tasks(view="all", sort="newest"),
                      []) or []
        rows = []
        for t in tasks:
            finfo = _scope_info_json(t.get("freight_info"))
            linfo = _scope_info_json(t.get("leadtime_info"))
            cost_raw = str(finfo.get("cost_per_truck") or "").strip()
            trucks_raw = str(finfo.get("num_trucks") or "").strip()
            weeks_raw = str(linfo.get("weeks") or "").strip()
            ship_raw = str(linfo.get("ship_weeks") or "").strip()
            if not (cost_raw or trucks_raw or weeks_raw or ship_raw):
                continue
            cost = parse_money_value(cost_raw)
            trucks = parse_count_value(trucks_raw)
            rng = parse_week_range(weeks_raw)
            ship_rng = parse_week_range(ship_raw)
            ship = ship_rng[1] if ship_rng else None
            rows.append({
                "id": t.get("id"),
                "task": t,
                "quote_number": t.get("quote_number") or "—",
                "distributor": t.get("distributor") or "—",
                "end_user": t.get("end_user") or "—",
                "status": t.get("status") or "",
                "has_freight": bool(cost_raw or trucks_raw),
                "has_lead": bool(weeks_raw or ship_raw),
                "cost": cost, "cost_raw": cost_raw,
                "trucks": trucks, "trucks_raw": trucks_raw,
                "freight_total": (cost * trucks
                                  if cost is not None and trucks is not None
                                  else None),
                "weeks": rng, "weeks_raw": weeks_raw,
                "ship": ship, "ship_raw": ship_raw,
            })
        return rows

    def _refresh_logistics(self):
        rows_all = self._logistics_data()

        # Search filter (V1.9.16: replaced the Show dropdown): quote
        # number, distributor, or end user, case-insensitive substring.
        # Empty search = all quotes. KPIs and the table below follow the
        # filtered set, exactly as the old single-quote picker did.
        search = getattr(self, "_logistics_search", None)
        needle = search.text().strip().lower() if search is not None else ""
        if needle:
            rows = [r for r in rows_all
                    if needle in (r["quote_number"] or "").lower()
                    or needle in (r["distributor"] or "").lower()
                    or needle in (r["end_user"] or "").lower()]
        else:
            rows = rows_all

        # KPI cards for the current selection (whole or single quote).
        # Detach before deleteLater: deleteLater alone leaves the old
        # cards parented (and painting at stale geometry) until the
        # deferred delete lands — visible as ghost card borders.
        while self._logistics_flow.count():
            item = self._logistics_flow.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
        freight_rows = [r for r in rows if r["has_freight"]]
        lead_rows = [r for r in rows if r["has_lead"]]
        totals = [r["freight_total"] for r in rows
                  if r["freight_total"] is not None]
        costs = [r["cost"] for r in rows if r["cost"] is not None]
        truck_counts = [r["trucks"] for r in rows if r["trucks"] is not None]
        lead_mids = [(r["weeks"][0] + r["weeks"][1]) / 2
                     for r in rows if r["weeks"]]
        ships = [r["ship"] for r in rows if r["ship"] is not None]

        def avg(vals):
            return sum(vals) / len(vals) if vals else None

        cards = [
            ("Quotes tracked", _int_fmt(len(rows)),
             "with freight or lead-time details",
             rows),
            ("Est. freight total",
             _money(sum(totals)) if totals else "—",
             f"from {_int_fmt(len(totals))} quotes with full freight data",
             [r for r in rows if r["freight_total"] is not None]),
            ("Avg cost / truck",
             _money(avg(costs)) if costs else "—",
             f"{_int_fmt(sum(truck_counts))} trucks total"
             if truck_counts else None,
             [r for r in rows if r["cost"] is not None]),
            ("Avg lead time",
             f"{_fmt_num(round(avg(lead_mids), 1))} wks"
             if lead_mids else "—",
             "midpoint of the quoted ranges" if lead_mids else None,
             [r for r in rows if r["weeks"]]),
            ("Avg shipping",
             f"{_fmt_num(round(avg(ships), 1))} wks" if ships else "—",
             None,
             [r for r in rows if r["ship"] is not None]),
        ]
        for label, value, sub, drill_rows in cards:
            card = KpiCard(label, value, sub=sub, value_pt=26)
            # V1.9.16: every card the same width (the short "4 wks"
            # card used to render narrower than the rest), and every
            # card with data behind it opens the quotes behind the
            # number — the same drill-down the other dashboard cards
            # already have. V1.9.17: same HEIGHT too — cards without a
            # sub-line used to render shorter (AVG SHIPPING vs AVG
            # LEAD TIME), and the drilldown shows the metric's own
            # logistics columns, not the generic task table.
            card.setFixedWidth(210)
            # V1.9.34: the Logistics cards use the SAME height as
            # every other KPI card (KpiCard.CARD_H) -- the separate
            # 108px family is gone; one card, one height, and the
            # reserved sub-caption row keeps every card's text on
            # the same lines.
            card.setFixedHeight(KpiCard.CARD_H)
            if drill_rows:
                card.set_clickable()
                card.setToolTip("Click to see the quotes behind this number")
                card.clicked.connect(
                    lambda _=False, lbl=label, val=value, drows=drill_rows:
                    self._open_logistics_drilldown(lbl, val, drows))
            self._logistics_flow.addWidget(card)

        # Per-quote table.
        t = self._logistics_table
        t.setSortingEnabled(False)
        t.setRowCount(len(rows))
        for i, r in enumerate(rows):
            quote_item = _name_item(str(r["quote_number"]))
            try:
                quote_item.setData(Qt.UserRole, int(r["id"] or 0))
            except (TypeError, ValueError):
                pass
            t.setItem(i, 0, quote_item)
            t.setItem(i, 1, _text_item(str(r["distributor"])))
            t.setItem(i, 2, _text_item(str(r["end_user"])))
            t.setItem(i, 3, _text_item(
                STATUS_LABELS.get(r["status"], r["status"] or "—")))
            t.setItem(i, 4, _nitem(
                format_money_value(r["cost"]) if r["cost"] is not None
                else (r["cost_raw"] or "—"),
                _fnum(r["cost"])))
            t.setItem(i, 5, _nitem(
                str(r["trucks"]) if r["trucks"] is not None
                else (r["trucks_raw"] or "—"),
                _fnum(r["trucks"])))
            t.setItem(i, 6, _nitem(
                format_money_value(r["freight_total"]),
                _fnum(r["freight_total"])))
            lead_txt = (f"{format_week_range(r['weeks'])} wks"
                        if r["weeks"] else
                        (f"{r['weeks_raw']} wks" if r["weeks_raw"] else "—"))
            lead_sort = ((r["weeks"][0] + r["weeks"][1]) / 2
                         if r["weeks"] else -1)
            t.setItem(i, 7, _nitem(lead_txt, lead_sort))
            t.setItem(i, 8, _nitem(
                f"{_fmt_num(r['ship'])} wks" if r["ship"] is not None
                else (f"{r['ship_raw']} wks" if r["ship_raw"] else "—"),
                _fnum(r["ship"])))
        t.setSortingEnabled(True)
        t.resizeColumnsToContents()
        t.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self._logistics_empty.setVisible(not rows)
        t.setVisible(bool(rows))

    def _open_logistics_drilldown(self, label, value, rows):
        """A logistics KPI card was clicked: show the quotes behind it.

        V1.9.17: the dialog uses the logistics columns (lead time,
        shipping, freight/truck, trucks, freight total) — the numbers
        the KPI was computed from — and the title carries the KPI
        value, so the drilldown answers "where is this number from".
        A row double-click opens that quote's detail window.
        """
        if label == "Quotes tracked":
            title = f"{label} ({len(rows)})"
        else:
            title = f"{label} — {value} ({len(rows)})"
        dlg = TaskDrilldownDialog(title, rows, self, logistics=True,
                                  settings_key="drilldown/logistics")
        sig = getattr(dlg, "open_task_requested", None)
        if sig is not None:
            sig.connect(self.open_task_requested.emit)
        dlg.exec()

    def _open_logistics_row(self, row, _column):
        tid = _task_id_of_row(self._logistics_table, row)
        if tid is not None:
            self.open_task_requested.emit(tid)

    def _build_distributors_tab(self):
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(4, 14, 4, 4)
        lay.setSpacing(10)
        lay.addWidget(_section_label("Distributor performance"))

        self._table = QTableWidget()
        self._table.setObjectName("dashTable")
        _style_data_table(self._table)
        self._headers = ["DISTRIBUTOR", "QUOTES", "COMPLETED", "%",
                         "AVG DAYS", "AVG EST (H)", "LAST QUOTE", "TOTAL VALUE"]
        self._table.setColumnCount(len(self._headers))
        self._table.setHorizontalHeaderLabels(self._headers)
        self._table.horizontalHeader().setObjectName("dashHeader")
        self._table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch)
        for c in range(1, len(self._headers)):
            self._table.horizontalHeader().setSectionResizeMode(
                c, QHeaderView.ResizeToContents)
        self._table.verticalHeader().setVisible(False)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._table.setSortingEnabled(True)
        self._table.setShowGrid(False)
        # Clicking a row opens the SAME CRM detail card the CRM module opens
        # (with all info + the metrics block) — no second implementation.
        # Enter on a focused row does the same (keyboard accessibility).
        self._table.cellDoubleClicked.connect(self._open_distributor_row)
        self._table.installEventFilter(self)
        # A lone Stretch column swallows the table's own horizontal
        # scrollbar when the window narrows, so the table rides inside a
        # horizontal scroller with a floor width instead of clipping.
        self._dist_scroll = QScrollArea()
        self._dist_scroll.setWidgetResizable(True)
        self._dist_scroll.setFrameShape(QFrame.NoFrame)
        self._dist_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._dist_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._dist_scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }")
        self._dist_scroll.setWidget(self._table)
        lay.addWidget(self._dist_scroll, 1)
        self._tabs.addTab(tab, "Distributors")

    def _build_nudges_tab(self):
        tab = QWidget()
        outer = QVBoxLayout(tab)
        outer.setContentsMargins(4, 10, 4, 4)
        outer.setSpacing(0)

        inner = QWidget()
        self._nudge_lay = QVBoxLayout(inner)
        # Content insets come from _scroll_wrap (app-wide scroll convention).
        self._nudge_lay.setSpacing(12)
        # Follow-ups due (standalone widget from ui.py) sits at the TOP,
        # above the distributor check-in nudges.
        self._followups = FollowUpsWidget(self._db)
        self._followups.open_requested.connect(self.open_task_requested.emit)
        self._followups.reminders_changed.connect(self._refresh_nudges)
        self._nudge_lay.addWidget(self._followups)
        self._nudge_lay.addWidget(_section_label("Distributor check-ins"))
        self._nudge_cards = QVBoxLayout()
        self._nudge_cards.setSpacing(12)
        self._nudge_lay.addLayout(self._nudge_cards)
        self._nudge_lay.addStretch(1)

        outer.addWidget(self._scroll_wrap(inner))
        self._tabs.addTab(tab, "Nudges")

    # -- refresh ----------------------------------------------------------
    def _apply_page_backgrounds(self):
        """V1.9.29 (user screenshots): one solid page color, painted
        structurally -- not left to stylesheets alone.

        On real Windows the dashboard showed a black rectangle larger
        than the table bleeding into the rest of the UI, and switching
        tabs flashed that area light gray before it settled: the tab
        pages and scroll viewports had no background of their own, so
        Windows painted them with defaults (near-black at rest, the
        light palette color for a frame mid-switch / mid-slide). The
        table's own near-black is correct INSIDE its frame; what bled
        was everything around it. Every container layer of this page
        -- the page itself, the tab widget and its pages, every scroll
        area, its viewport, and its content widget -- now carries the
        page color as its palette Window/Base with auto-fill on, so
        the first frame and every mid-animation frame are already the
        one solid color every other module uses.
        """
        color = QColor("#0b0c0e" if saved_theme() != "light"
                       else "#f5f5f6")
        targets = [self]
        tabs = getattr(self, "_tabs", None)
        if tabs is not None:
            targets.append(tabs)
            for i in range(tabs.count()):
                targets.append(tabs.widget(i))
        for sc in self.findChildren(QScrollArea):
            targets.append(sc)
            targets.append(sc.viewport())
            if sc.widget() is not None:
                targets.append(sc.widget())
        for w in targets:
            if w is None:
                continue
            pal = w.palette()
            pal.setColor(QPalette.Window, color)
            pal.setColor(QPalette.Base, color)
            w.setPalette(pal)
            w.setAutoFillBackground(True)

    def refresh_theme(self):
        """Re-apply dashboard colors for the active theme.

        Called by the main window on theme switch. Restyles the page,
        retints the stored chart colors, and repaints; charts that read
        the C_* paint palette pick it up on repaint.
        """
        set_dash_theme(saved_theme())
        self.setStyleSheet(dash_qss())
        self._apply_page_backgrounds()
        if hasattr(self, "_quotes_chart"):
            self._quotes_chart.set_color(C_ACCENT)
        if hasattr(self, "_value_chart"):
            self._value_chart.set_color(C_MONEY)
        self.update()

    def refresh(self):
        """Re-query the db and repaint everything. Safe to call often."""
        self._refresh_overview()
        self._refresh_logistics()
        self._refresh_distributors()
        self._refresh_nudges()
        # Some tab content builds lazily after __init__; re-assert the
        # solid page backgrounds on every refresh so late-built scroll
        # viewports carry it too.
        self._apply_page_backgrounds()

    def _layout_kpi_cards(self):
        """Assign the KPI cards their exact positions and sizes.

        V1.9.34 (user: "EQUAL SAME SIZES"): the 12 units are divided
        in whole pixels HERE and each card's geometry is set
        directly — no layout manager. (QGridLayout distributed the
        widths unevenly — one card 251 vs 240 row-mates — and even
        with fixed widths and pinned column minimums its solver
        landed the second row's right edge 6px short of the
        first's. Manual geometry cannot drift: standard cards are
        identical, the money pair is identically wider, both rows
        share left and right edges by construction. The leftover
        pixels (avail mod 12, at most 11) split as symmetric side
        margins.)
        """
        host = getattr(self, "_kpi_host", None)
        cards = getattr(self, "_kpi_cards", None)
        if host is None or not cards:
            return
        w = host.width()
        if w < 240:
            return
        sp = 12
        avail = w - 11 * sp
        if avail <= 0:
            return
        unit = avail // 12
        x0 = (avail - unit * 12) // 2
        rows = max(r for _cd, r, _cl, _s in cards) + 1
        host.setFixedHeight(rows * KpiCard.CARD_H + (rows - 1) * sp)
        for card, r, c, span in cards:
            card.setGeometry(x0 + c * unit + c * sp,
                             r * (KpiCard.CARD_H + sp),
                             span * unit + (span - 1) * sp,
                             KpiCard.CARD_H)

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # Deferred: the host only has its new width after the layout
        # pass that follows this event.
        QTimer.singleShot(0, self._layout_kpi_cards)

    # -- overview --
    def _refresh_overview(self):
        kpis = _safe(lambda: self._db.dashboard_kpis(), {}) or {}

        # rebuild KPI cards (cheap: ~11 small widgets)
        for _old, *_rest in self._kpi_cards:
            _old.deleteLater()
        self._kpi_cards = []
        pending = []  # (card, grid span) in display order

        def _place(card, span):
            pending.append((card, span))

        def num(key, default=0):
            try:
                v = kpis.get(key, default)
                return default if v is None else v
            except Exception:
                return default

        # (label, value, sub, value_pt, click target)
        # click target: a drill-down mode, "main_distributor", or None.
        # V1.9.30 ORDER (user: the cards read as placed randomly --
        # arrange them so the layout makes sense, and the two money
        # cards stay together at the end): work counts first, then
        # rates and times, then the main distributor, and the money
        # pair LAST (added below): Total quote value immediately left
        # of Won value on the bottom row. Completion rate is GONE --
        # the user said he doesn't need that metric.
        cards = [
            ("Total completed", _int_fmt(num("total_completed")), None, 26,
             "completed"),
            ("In process", _int_fmt(num("in_process")), None, 26,
             "in_process"),
            ("On hold", _int_fmt(num("on_hold")), None, 26, "on_hold"),
            ("Quotes this week", _int_fmt(num("quotes_this_week")),
             None, 26, "this_week"),
            ("Quotes this month", _int_fmt(num("quotes_this_month")),
             None, 26, "this_month"),
        ]
        total_tasks = num("total_tasks")
        # V1.9.34: the Win rate card is ALWAYS present (— when
        # there are no quotes yet), and the rate is won / ALL
        # quotes (user: losses are rarely knowable, wins always
        # are -- won/marked fabricated near-100% rates). Cards
        # appearing/disappearing with the data is what broke the
        # grid's shape; the geometry is fixed, only numbers change.
        win_rate = kpis.get("win_rate")
        cards.append(("Win rate",
                      f"{float(win_rate):.0f}%"
                      if total_tasks > 0 and win_rate is not None
                      else "—",
                      None, 26,
                      "win_rate" if total_tasks > 0 else None))
        n_completed = num("total_completed")
        avg_days = kpis.get("avg_completion_days")
        cards.append(("Avg completion time",
                      _days(avg_days) if n_completed else "—", None, 26,
                      "avg_completion_time"))
        open_n = num("in_process") + num("on_hold")
        open_hours = kpis.get("open_estimated_hours")
        cards.append(("Workload",
                      _hours_compact(open_hours) if open_n else "—",
                      None, 26,
                      "workload" if open_n else None))
        # V1.9.30 (user): Avg estimate REMOVED -- next to Avg
        # completion time it read as the same metric twice. The
        # keeper is completion time (real turnaround, the number a
        # customer feels); estimated hours still live on the
        # Workload card for open work.

        main = kpis.get("main_distributor")
        main_n = num("main_distributor_count")
        self._main_distributor_name = str(main or "")
        if main:
            cards.append(("Main distributor", str(main),
                          f"{_int_fmt(main_n)} quotes", 15,
                          "main_distributor"))
        else:
            cards.append(("Main distributor", "—", None, 26, None))
        for label, value, sub, pt, target in cards:
            card = KpiCard(label, value, sub=sub, value_pt=pt)
            if target == "main_distributor":
                card.set_clickable()
                card.clicked.connect(self._open_main_distributor)
            elif target:
                card.set_clickable()
                card.clicked.connect(
                    lambda _=False, m=target: self._open_drilldown(m))
            _place(card, 2)

        # Money cards LAST (V1.9.30 order, above): Total quote value
        # immediately LEFT of Won value, together on the bottom row.
        # EVERY KPI card is clickable and opens the exact tasks its
        # number is computed from -- the drilldown IS the source list.
        # V1.9.34: always present (the grid's shape is fixed), and
        # these are the ONLY cards wider than standard — span 3
        # against the standard span 2, the exception the user named.
        def _add_kpi(label, value, mode):
            card = KpiCard(label, value, wide=True)
            card.set_clickable()
            card.clicked.connect(
                lambda _=False, m=mode: self._open_drilldown(m))
            _place(card, 3)

        total_value = kpis.get("total_quote_value")
        _add_kpi("Total quote value",
                 _money(total_value) if total_value else "$0",
                 "total_value")
        won_value = kpis.get("won_value")
        _add_kpi("Won value",
                 _money(won_value) if won_value else "$0",
                 "won_value")

        # Lay the pending cards onto the 12-unit grid, wrapping to a
        # new row when a card would pass unit 12. 6 standard cards
        # fill row 1 (6 x 2); row 2 is 3 standard (3 x 2) + the two
        # money cards (2 x 3) = 12 -- both rows fill the same width,
        # every vertical edge on the same unit lines.
        row = col = 0
        for card, span in pending:
            if col + span > 12:
                row += 1
                col = 0
            card.setParent(self._kpi_host)
            card.show()
            self._kpi_cards.append((card, row, col, span))
            col += span
        self._layout_kpi_cards()
        QTimer.singleShot(0, self._layout_kpi_cards)

        # charts
        self._apply_bucket_mode()

        self._status_counts = (
            _safe(lambda: self._db.status_counts(), {}) or {})
        self._outcome_counts = (
            _safe(lambda: self._db.outcome_counts(), {}) or {})
        self._apply_donut()

        top = _safe(lambda: self._db.top_distributors(5), []) or []
        self._topdist_quotes = [(n, c) for n, c in top]
        rates = _safe(lambda: self._db.distributor_win_rates(5),
                      []) or []
        self._topdist_rates = [(n, r) for n, r, _w, _m in rates]
        # Display labels for the win-rate view: the NUMBERS behind
        # the rate (won/total since V1.9.34), never a percentage
        # (V1.9.30, user).
        self._topdist_rate_labels = [f"{w}/{m}" for _n, _r, w, m
                                     in rates]
        self._apply_topdist()

        self._value_rows = _safe(
            lambda: self._db.task_value_rows(), []) or []
        self._apply_value_filter()

    # -- quotes chart bucketing --
    def _set_bucket_mode(self, mode):
        if mode not in ("month", "week", "year"):
            return
        self._bucket_mode = mode
        seg = getattr(self, "_bucket_seg", None)
        if seg is not None:
            seg.set_checked(mode)
        self._apply_bucket_mode()

    def _set_topdist_mode(self, mode):
        self._topdist_mode = mode
        self._apply_topdist()

    def _set_donut_mode(self, mode):
        if mode not in ("status", "outcome"):
            return
        self._donut_mode = mode
        seg = getattr(self, "_donut_seg", None)
        if seg is not None:
            seg.set_checked(mode)
        self._apply_donut()

    def _apply_donut(self):
        """Point the single Breakdown donut at the active series."""
        chart = getattr(self, "_donut", None)
        if chart is None:
            return
        if getattr(self, "_donut_mode", "status") == "outcome":
            chart._order = list(OUTCOME_ORDER)
            chart._labels = dict(OUTCOME_LABELS_CHART)
            chart._colors = dict(OUTCOME_COLORS)
            chart.set_data(getattr(self, "_outcome_counts", {}))
        else:
            chart._order = list(STATUS_ORDER)
            chart._labels = dict(STATUS_LABELS)
            chart._colors = dict(STATUS_COLORS)
            chart.set_data(getattr(self, "_status_counts", {}))

    def _apply_topdist(self):
        chart = getattr(self, "_topdist", None)
        if chart is None:
            return
        if getattr(self, "_topdist_mode", "quotes") == "winrate":
            chart.set_data(getattr(self, "_topdist_rates", []),
                           labels=getattr(self, "_topdist_rate_labels",
                                          None))
        else:
            chart.set_data(getattr(self, "_topdist_quotes", []))

    def _on_quotes_outcome_changed(self, index):
        self._quotes_outcome = (
            self._quotes_outcome_box.itemData(index) or "total")
        self._apply_bucket_mode()

    def _on_value_outcome_changed(self, index):
        self._value_outcome = (
            self._value_outcome_box.itemData(index) or "total")
        self._apply_value_filter()

    def _apply_bucket_mode(self):
        rows = _safe(lambda: self._db.quote_creation_rows(), []) or []
        want = getattr(self, "_quotes_outcome", "total")
        dates = [c for c, o in rows if want == "total" or o == want]
        self._quotes_chart.set_data(_bucket_dates(dates, self._bucket_mode))
        titles = {"month": "Quotes per month",
                  "week": "Quotes per week",
                  "year": "Quotes per year"}
        self._quotes_title.setText(titles[self._bucket_mode])

    def _apply_value_filter(self):
        rows = getattr(self, "_value_rows", None)
        if rows is None:
            rows = _safe(lambda: self._db.task_value_rows(), []) or []
            self._value_rows = rows
        want = getattr(self, "_value_outcome", "total")
        pairs = [(c, v) for c, o, v in rows
                 if want == "total" or o == want]
        data = _bucket_values(pairs, "month")
        if any(v > 0 for _lab, v in data):
            self._value_chart.set_data(data)
        else:
            # -> "No quote values recorded yet"
            self._value_chart.set_data([])

    # -- KPI drill-downs --

    def _open_task_list_dialog(self, title, rows, settings_key):
        """TaskDrilldownDialog for an explicit row list (chart clicks)."""
        dlg = TaskDrilldownDialog(f"{title} ({len(rows)})", rows, self,
                                  settings_key=settings_key)
        sig = getattr(dlg, "open_task_requested", None)
        if sig is not None:
            sig.connect(self.open_task_requested.emit)
        dlg.exec()

    def _open_month_drilldown(self, label, mode=None):
        """A chart bar was clicked: show the quotes behind that bucket.

        V1.9.17 (user report): chart bars must open the source data —
        which quotes were done that month/week/year — not just paint a
        number. The bucket span is re-derived from the label + mode at
        click time, so a mode switch after the chart was drawn still
        drills into the right bucket.
        """
        mode = mode or self._bucket_mode
        span = None
        try:
            if mode == "month":
                dt = datetime.strptime(label, "%b '%y")
                start = datetime(dt.year, dt.month, 1)
                end = (datetime(dt.year + 1, 1, 1) if dt.month == 12
                       else datetime(dt.year, dt.month + 1, 1))
                span = (start, end)
            elif mode == "year":
                year = int(label)
                span = (datetime(year, 1, 1), datetime(year + 1, 1, 1))
            elif mode == "week":
                today = datetime.now()
                this_mon = (today - timedelta(days=today.weekday())).replace(
                    hour=0, minute=0, second=0, microsecond=0)
                for i in range(11, -1, -1):
                    ws = this_mon - timedelta(weeks=i)
                    if ws.strftime("%b %d") == label:
                        span = (ws, ws + timedelta(weeks=1))
                        break
        except (ValueError, TypeError):
            span = None
        if span is None:
            return
        start, end = span
        rows = []
        for t in _safe(lambda: self._db.list_tasks(view="all",
                                                   sort="newest"), []) or []:
            try:
                created = datetime.fromisoformat(str(t.get("created_at")))
            except (ValueError, TypeError):
                continue
            if start <= created < end:
                rows.append(t)
        self._open_task_list_dialog(f"Quotes — {label}", rows,
                                    settings_key="drilldown/month")
    _DRILLDOWN_TITLES = {
        "completed": "Completed tasks",
        "in_process": "Tasks in process",
        "on_hold": "Tasks on hold",
        "this_month": "Quotes this month",
        "this_week": "Quotes this week",
        "distributor": "Tasks",
        "workload": "Workload — open quotes",
        "win_rate": "Win rate — won of all quotes",
        "won_value": "Won value — won quotes",
        "total_value": "Total quote value — priced quotes",
        "completion_rate": "Completion rate — completed tasks",
        "avg_completion_time": "Avg completion time — completed tasks",
        "avg_estimate": "Avg estimate — completed tasks",
    }

    # V1.9.29 (user): the Win rate / Won value drilldowns carry a
    # week / month / year period filter.
    _PERIOD_FILTER_MODES = ("win_rate", "won_value")

    def _open_drilldown(self, mode, name=None):
        rows = _safe(lambda: self._db.drilldown_tasks(mode, name), []) or []
        base = self._DRILLDOWN_TITLES.get(mode, "Tasks")
        title = f"{base} — {name}" if mode == "distributor" and name else base
        dlg = TaskDrilldownDialog(f"{title} ({len(rows)})", rows, self,
                                  show_hours=(mode == "workload"),
                                  settings_key=f"drilldown/{mode}",
                                  period_filter=(
                                      mode in self._PERIOD_FILTER_MODES),
                                  money_total=(
                                      mode in ("won_value",
                                               "total_value")))
        # Row double-click / Enter -> the task detail window, via the same
        # signal the follow-ups widget uses (app.py connects it to
        # open_detail).
        sig = getattr(dlg, "open_task_requested", None)
        if sig is not None:
            sig.connect(self.open_task_requested.emit)
        dlg.exec()

    def _open_main_distributor(self):
        """Main-distributor KPI (V1.9.30, user): open the ranked
        distributor METRICS view (top 25, leader on top) -- not just
        the main distributor's own CRM card. Double-clicking a row
        in the metrics view opens that distributor's task list."""
        stats = _safe(lambda: self._db.distributor_stats(), []) or []
        dlg = DistributorMetricsDialog(stats[:25], self)
        dlg.distributor_chosen.connect(
            lambda name: self._open_drilldown("distributor", name=name))
        dlg.exec()

    # -- distributors --
    def _open_distributor_row(self, row, _column):
        """Distributors-tab row click -> the CRM ContactDetailWindow.

        Reuses the exact CRM detail-window code path (same card, same
        metrics block). Falls back to a distributor task list when the
        name has no directory entry, mirroring the row-open behaviour.
        """
        item = self._table.item(row, 0)
        name = item.text().strip() if item is not None else ""
        self._open_distributor_name(name)

    def _open_current_distributor_row(self):
        """Keyboard activation: open the focused distributors-tab row."""
        self._open_distributor_row(self._table.currentRow(), 0)

    def _open_distributor_name(self, name):
        """Shared opener: CRM detail card for a distributor name."""
        name = (name or "").strip()
        if not name:
            return
        entry_id = _safe(
            lambda: self._db.directory_entry_id("distributor", name), None)
        if entry_id:
            win = ContactDetailWindow(self._db, entry_id, self)
            win.show()
        else:
            self._open_drilldown("distributor", name=name)

    def _on_tab_changed(self, _index):
        # The outgoing page was grabbed on the tab-bar press (see
        # eventFilter); slide it out as the new page slides in. A
        # programmatic switch with no press has no outgoing pixmap and
        # simply shows the new page — no half-slide.
        old = self._tab_old_pix
        self._tab_old_pix = None
        if old is None or old.isNull():
            return
        page = self._tabs.currentWidget()
        if page is None:
            return

        def _slide():
            try:
                new = grab_without_scrollbars(page)
            except Exception:
                return
            slide_swap(page, page.rect(), old, new)

        QTimer.singleShot(0, _slide)

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        # Dashboard tabs: capture the outgoing page BEFORE the bar
        # processes the press/key that switches tabs, so _on_tab_changed
        # has something to slide out. Never consumes the event.
        _tabs = getattr(self, "_tabs", None)
        if (_tabs is not None and obj is _tabs.tabBar()
                and event.type() in (
                    QEvent.MouseButtonPress, QEvent.KeyPress)):
            try:
                cur = _tabs.currentWidget()
                self._tab_old_pix = (grab_without_scrollbars(cur)
                                     if cur is not None else None)
            except Exception:
                self._tab_old_pix = None
        # Distributors tab: Enter on a focused row opens the contact card.
        # (getattr-guarded: the logistics tab is built before _table exists,
        # and its table's filter events can arrive during construction.)
        dist_table = getattr(self, "_table", None)
        if (dist_table is not None and obj is dist_table
                and event.type() == QEvent.KeyPress):
            if event.key() in (Qt.Key_Return, Qt.Key_Enter):
                self._open_current_distributor_row()
                return True
        # Freight & Lead Time tab: Enter opens the quote's task detail.
        logistics_table = getattr(self, "_logistics_table", None)
        if (logistics_table is not None and obj is logistics_table
                and event.type() == QEvent.KeyPress
                and event.key() in (Qt.Key_Return, Qt.Key_Enter)):
            self._open_logistics_row(logistics_table.currentRow(), 0)
            return True
        return super().eventFilter(obj, event)

    def _refresh_distributors(self):
        rows = _safe(lambda: self._db.distributor_stats(), []) or []
        t = self._table
        t.setSortingEnabled(False)
        t.setRowCount(len(rows))
        all_zero_value = True
        for i, r in enumerate(rows):
            name = str(r.get("name", "") or "")
            quotes = r.get("quotes") or 0
            completed = r.get("completed") or 0
            pct = r.get("completion_pct")
            avg_days = r.get("avg_days")
            avg_est = r.get("avg_est_hours")
            last = r.get("last_quote")
            value = r.get("total_value") or 0
            try:
                if float(value) > 0:
                    all_zero_value = False
            except (TypeError, ValueError):
                pass

            t.setItem(i, 0, _name_item(name))
            t.setItem(i, 1, _nitem(_int_fmt(quotes), _fnum(quotes)))
            t.setItem(i, 2, _nitem(_int_fmt(completed), _fnum(completed)))
            t.setItem(i, 3, _nitem(
                f"{float(pct):.0f}%" if pct is not None else "—",
                _fnum(pct)))
            t.setItem(i, 4, _nitem(
                f"{float(avg_days):.1f}" if completed else "—",
                _fnum(avg_days) if completed else -1))
            t.setItem(i, 5, _nitem(
                f"{float(avg_est):.1f}" if avg_est else "—",
                _fnum(avg_est) if avg_est else -1))
            last_txt = _short_date(last) or "—"
            last_item = _text_item(last_txt)
            t.setItem(i, 6, last_item)
            t.setItem(i, 7, _nitem(_money(value), _fnum(value)))

        t.setColumnHidden(7, all_zero_value)
        t.resizeColumnsToContents()
        # Floor so columns never squeeze below readable widths; the outer
        # horizontal scroller takes over past this point.
        visible = [c for c in range(t.columnCount())
                   if not t.isColumnHidden(c)]
        fixed = sum(t.columnWidth(c) for c in visible[1:])
        t.setMinimumWidth(fixed + 220)
        t.setSortingEnabled(True)

    # -- nudges --
    def _dismiss_nudge(self, name):
        """V1.9.13: dismiss one distributor check-in, then rebuild cards."""
        try:
            self._db.dismiss_nudge(name)
        except Exception:
            pass
        self._refresh_nudges()

    def _refresh_nudges(self):
        while self._nudge_cards.count():
            item = self._nudge_cards.takeAt(0)
            w = item.widget()
            if w is not None:
                # Unparent at once (the card leaves the tree immediately)
                # AND deleteLater (safe while a child button's clicked
                # signal is still emitting). deleteLater alone only
                # destroys the widget on the next event-loop pass, so a
                # dismissed card could otherwise linger visibly.
                w.setParent(None)
                w.deleteLater()

        nudges = _safe(lambda: self._db.nudge_candidates(), []) or []
        if not nudges:
            box = QVBoxLayout()
            # NOTE: no box-level AlignCenter here. Centering a word-wrapped
            # QLabel via layout alignment makes it keep an arbitrary
            # sizeHint width whose height doesn't match, which is what
            # clipped the descender in "gone". The labels stretch full width
            # and center their *text* instead; Qt's height-for-width then
            # sizes the label exactly to its wrapped text.
            box.setContentsMargins(24, 40, 24, 40)
            box.setSpacing(12)
            check = QLabel("✓")
            check.setObjectName("nudgeCheck")
            check.setAlignment(Qt.AlignCenter)
            msg = QLabel("All caught up — no distributors have gone quiet.")
            msg.setObjectName("dashEmpty")
            msg.setAlignment(Qt.AlignCenter)
            msg.setWordWrap(True)
            box.addWidget(check)
            box.addWidget(msg)
            wrap = QWidget()
            wrap.setLayout(box)
            self._nudge_cards.addWidget(wrap)
            # Safety net: font-metrics floor with explicit descender room,
            # measured once the widget is in the page tree so font()
            # reflects the QSS 14px size.
            msg.ensurePolished()
            fm = QFontMetrics(msg.font())
            msg.setMinimumHeight(fm.lineSpacing() + fm.descent())
            return

        for n in nudges:
            name = str(n.get("name", "") or "Unknown")
            try:
                cadence = float(n.get("cadence_days") or 0)
            except (TypeError, ValueError):
                cadence = 0
            try:
                since = int(n.get("days_since_last") or 0)
            except (TypeError, ValueError):
                since = 0
            card = NudgeCard(name)
            card.open_requested.connect(self._open_distributor_name)
            lay = QVBoxLayout(card)
            lay.setContentsMargins(18, 13, 18, 13)
            lay.setSpacing(5)
            head = QHBoxLayout()
            head.setContentsMargins(0, 0, 0, 0)
            head.setSpacing(8)
            title = QLabel(f"Check in with {name}")
            title.setObjectName("nudgeTitle")
            head.addWidget(title)
            head.addStretch(1)
            # V1.9.13: manual dismiss. The card had no way to remove a
            # check-in, so wrong ones sat there permanently. Dismissing
            # hides this distributor's check-in until it quotes again.
            dismiss = QPushButton("Dismiss")
            dismiss.setObjectName("nudgeDismiss")
            dismiss.setToolTip("Dismiss this check-in until "
                               f"{name} quotes again")
            dismiss.setCursor(Qt.PointingHandCursor)
            dismiss.clicked.connect(
                lambda _c=False, _n=name: self._dismiss_nudge(_n))
            head.addWidget(dismiss)
            lay.addLayout(head)
            body = QLabel(
                f"{name} usually quotes every ~{cadence:.0f} days — "
                f"nothing in {since} days.")
            body.setObjectName("nudgeBody")
            body.setWordWrap(True)
            lay.addWidget(body)
            self._nudge_cards.addWidget(card)

