"""Light (white/blue) and neutral dark (black/gray) themes as Qt stylesheets."""
import re
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QRectF, QSettings, Qt
from PySide6.QtGui import QColor, QPainterPath, QPalette, QRegion
from PySide6.QtWidgets import QMenu

FONT_STACK = '"Inter", "Segoe UI", "Helvetica Neue", Arial, sans-serif'

_ASSETS_DIR = Path(__file__).resolve().parent / "assets"


def _asset_file_url(name):
    """Filesystem path for a bundled asset, for QSS image: url().

    Plain absolute path (forward slashes): Qt stylesheets resolve
    url("...") against the filesystem, and a file:// scheme does NOT
    render (verified). Quoted in the QSS, so spaces in the install
    path are fine.
    """
    return (_ASSETS_DIR / name).as_posix()


# Themed drop-down chevrons: light glyph on the dark theme, dark glyph on
# the light theme (up/down variants for spin buttons).
_CHEV_DOWN_DARK = _asset_file_url("chev_down_light.png")
_CHEV_UP_DARK = _asset_file_url("chev_up_light.png")
_CHEV_DOWN_LIGHT = _asset_file_url("chev_down_dark.png")
_CHEV_UP_LIGHT = _asset_file_url("chev_up_dark.png")

# Check glyph drawn inside a checked QCheckBox::indicator (white check on the
# accent fill; same asset works for both themes).
_CHECK_MARK = _asset_file_url("check_mark.png")

DARK = f"""
* {{ font-family: {FONT_STACK}; }}
QWidget#app {{ background: #0b0c0e; }}
QLabel#title {{ font-size: 22px; font-weight: 700; color: #f4f5f7; }}
QLabel#subtitle {{ color: #9ba1ab; font-size: 12px; }}
QLabel#emptyState {{ color: #6b7078; font-size: 14px; }}

/* ---------- cards ---------- */
QFrame#card {{ background: #141518; border: 1px solid #23252b; border-radius: 14px; }}
QFrame#card:hover {{ border: 1px solid #33363e; }}
/* V1.9.5: hot tasks — red border beats hover. */
QFrame#card[hot="true"] {{ border: 1px solid #e5484d; }}
QFrame#card[hot="true"]:hover {{ border: 1px solid #e5484d; }}
QLabel#quoteNum {{ font-size: 15px; font-weight: 700; color: #f4f5f7;
    background: transparent; border: none; padding: 0px 2px; }}
QLabel#meta {{ color: #c6cbd3; font-size: 13px; }}
QLabel#metaPrefix {{ color: #808080; font-size: 13px; }}
QLabel#notes {{ color: #c6cbd3; font-size: 13px; }}
QLabel#dateLabel {{ color: #6b7078; font-size: 11px; }}
QLabel#progressLabel {{ color: #9ba1ab; font-size: 11px; font-weight: 600; }}
QLabel#hint {{ color: #6b7078; font-size: 11px; }}
QRadioButton {{ color: #c6cbd3; }}

/* ---------- status pill (clickable) ---------- */
QPushButton#statusPill {{ border: none; border-radius: 11px; padding: 4px 12px;
    font-size: 11px; font-weight: 700; }}
QPushButton#statusPill[statusState="in_process"] {{ background: #1a2c4e; color: #7fb0ff; }}
QPushButton#statusPill[statusState="in_process"]:hover {{ background: #22365e; }}
QPushButton#statusPill[statusState="on_hold"] {{ background: #3a2f16; color: #eec25e; }}
QPushButton#statusPill[statusState="on_hold"]:hover {{ background: #4a3c1c; }}
QPushButton#statusPill[statusState="completed"] {{ background: #143327; color: #6fdc9e; }}
QPushButton#statusPill[statusState="completed"]:hover {{ background: #1a4232; }}
QPushButton#statusPill[statusState="canceled"] {{ background: #23252b; color: #9ba1ab; }}
QPushButton#statusPill[statusState="canceled"]:hover {{ background: #2c2f36; }}

/* ---------- outcome pill (clickable, V1.9.29) ---------- */
QPushButton#outcomePill {{ border: none; border-radius: 11px; padding: 4px 12px;
    font-size: 11px; font-weight: 700; }}
QPushButton#outcomePill[outcomeState="won"] {{ background: #143327; color: #6fdc9e; }}
QPushButton#outcomePill[outcomeState="won"]:hover {{ background: #1a4232; }}
QPushButton#outcomePill[outcomeState="lost"] {{ background: #3a2224; color: #ff9d97; }}
QPushButton#outcomePill[outcomeState="lost"]:hover {{ background: #472b2e; }}
QPushButton#outcomePill[outcomeState="dead"] {{ background: #2e2126; color: #d99a86; }}
QPushButton#outcomePill[outcomeState="dead"]:hover {{ background: #3a2a30; }}
QPushButton#outcomePill[outcomeState="on_hold"] {{ background: #3a2f16; color: #eec25e; }}
QPushButton#outcomePill[outcomeState="on_hold"]:hover {{ background: #4a3c1c; }}
QPushButton#outcomePill[outcomeState="unknown"] {{ background: #23252b; color: #9ba1ab; }}
QPushButton#outcomePill[outcomeState="unknown"]:hover {{ background: #2c2f36; }}

/* ---------- scope chips (checkable) ---------- */
QPushButton[role="scopeChip"] {{ border: none; border-radius: 9px; padding: 4px 6px;
    font-size: 11px; font-weight: 600; }}
QPushButton[role="scopeChip"][scopeKey="quote"] {{ background: #1b2b4d; color: #8fb4ff; }}
QPushButton[role="scopeChip"][scopeKey="re-quote"] {{ background: #2b2145; color: #c4a8f7; }}
QPushButton[role="scopeChip"][scopeKey="cad"] {{ background: #14332e; color: #6fd7bd; }}
QPushButton[role="scopeChip"][scopeKey="configura"] {{ background: #3d2a12; color: #f2b25c; }}
QPushButton[role="scopeChip"][scopeKey="prelims"] {{ background: #3a3312; color: #e3c964; }}
QPushButton[role="scopeChip"][scopeKey="misc"] {{ background: #23262c; color: #a7aeb9; }}
QPushButton[role="scopeChip"][scopeKey="custom-0"] {{ background: #2a2136; color: #c9aef2; }}
QPushButton[role="scopeChip"][scopeKey="custom-1"] {{ background: #12283a; color: #7fc4e8; }}
QPushButton[role="scopeChip"][scopeKey="custom-2"] {{ background: #33231a; color: #e8a06f; }}
QPushButton[role="scopeChip"][scopeKey="custom-3"] {{ background: #1f2d22; color: #93d8a4; }}
QPushButton[role="scopeChip"]:hover {{ border: 1px solid #3a3e47; }}
QPushButton[role="scopeChip"]:checked {{ background: #1c2e24; color: #8fdcae; }}

/* ---------- buttons ---------- */
QPushButton {{ background: #1a1c21; border: 1px solid #2c2f37; border-radius: 8px;
    padding: 7px 14px; font-size: 13px; color: #e6e9ee; }}
QPushButton:hover {{ background: #22252c; border-color: #3a3e48; }}
QPushButton:disabled {{ color: #5b6068; background: #141518; border-color: #23252b; }}
QPushButton#primary {{ background: #2f6fed; border: none; color: #ffffff;
    font-weight: 600; padding: 9px 18px; }}
QPushButton#primary:hover {{ background: #4a86f5; }}
/* Name links in the task detail header (V1.9.36, user): plain
   clickable TEXT, no button box -- white text, underline on hover
   (the standard link affordance). */
QPushButton#contactLink {{ background: transparent; border: none;
    color: #e6e9ee; padding: 7px 6px; font-size: 13px; }}
QPushButton#contactLink:hover {{ background: transparent;
    text-decoration: underline; }}
QPushButton#contactLink:focus {{ text-decoration: underline; }}
QPushButton#ghost {{ background: transparent; border: 1px solid #2c2f37;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger {{ background: transparent; border: 1px solid #4a2b2e; color: #ef9a9a;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger:hover {{ background: #2a1a1c; border-color: #6b3a3e; }}
QPushButton#ghost:hover {{ background: #23252b; border-color: #2c2f37; }}
QPushButton#cardHotBtn, QPushButton#cardFolderBtn, QPushButton#cardEditBtn,
QPushButton#cardDeleteBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 8px; padding: 5px 9px; font-size: 12px; color: #c6cbd3; }}
QPushButton#cardHotBtn:hover {{ background: rgba(229, 72, 77, 0.18); color: #ff8589; }}
QPushButton#cardFolderBtn:hover {{ background: rgba(232, 161, 58, 0.18); color: #f0b95a; }}
QPushButton#cardEditBtn:hover {{ background: rgba(79, 140, 255, 0.18); color: #8fb4ff; }}
QPushButton#cardDeleteBtn {{ color: #ef9a9a; }}
QPushButton#cardDeleteBtn:hover {{ background: rgba(229, 72, 77, 0.20); color: #ff8589; }}
QPushButton#scopeButton {{ text-align: left; padding: 9px 12px; }}
QFrame#scopeButton {{ background: #0f1013; border: 1px solid #2a2d34; border-radius: 8px; }}
QFrame#scopeButton:hover {{ border: 1px solid #4f8cff; }}
QLabel#scopeText {{ color: #f4f5f7; font-size: 13px; background: transparent; }}
QLabel#scopeText[empty="true"] {{ color: #6b7078; }}
QLabel#scopeArrow {{ color: #9ba1ab; font-size: 11px; background: transparent; }}
QPushButton#titleLink {{ background: transparent; border: none; text-align: left;
    padding: 0px; font-size: 18px; font-weight: 700; color: #8fb4ff; }}
QPushButton#titleLink:hover {{ color: #b3ccff; text-decoration: underline; }}
QPushButton#titleLink:disabled {{ color: #f4f5f7; }}
QLabel#imageStage {{ background: #000000; border-radius: 8px; }}
QPushButton#seg {{ border: 1px solid transparent; border-radius: 8px; padding: 7px 13px;
    font-size: 13px; font-weight: 600; color: #9ba1ab; background: transparent; }}
QPushButton#seg:hover {{ color: #d5d9e0; }}
QPushButton#seg:checked {{ background: #23252b; color: #ffffff; }}
QPushButton#seg[attention="true"] {{ background: #2a1a1c; color: #ef9a9a;
    border-color: #4a2b2e; }}
QPushButton#seg[attention="true"]:hover {{ background: #382224; color: #ffb4b4;
    border-color: #6b3a3e; }}
QPushButton#seg[attention="true"]:checked {{ background: #3a2224; color: #ffc9c9;
    border-color: #6b3a3e; }}
QPushButton#chipToggle {{ border: 1px solid #2c2f37; border-radius: 11px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #9ba1ab; background: #141518; }}
QPushButton#chipToggle:hover {{ color: #d5d9e0; border-color: #3a3d45; }}
QPushButton#chipToggle:checked {{ background: #1a2c4e; border-color: #2f6fed; color: #8fb4ff; }}
QLabel#chipToggle {{ border: 1px solid #2c2f37; border-radius: 11px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #9ba1ab; background: #141518; }}
QLabel#chipToggle:hover {{ color: #d5d9e0; border-color: #3a3d45; }}
QLabel#chipToggle[checked="true"] {{ background: #1a2c4e; border-color: #2f6fed; color: #8fb4ff; }}
QPushButton#dueChip {{ border: 1px solid #2c2f37; border-radius: 11px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #9ba1ab; background: #141518; }}
QPushButton#dueChip:hover {{ color: #d5d9e0; border-color: #3a3e48; }}
QPushButton#dueChip:checked {{ background: #1a2c4e; border-color: #2c4a7c; color: #8fb4ff; }}
/* card badges */
QLabel#dueChip, QLabel#estChip, QLabel#followChip, QLabel#priceChip {{ font-size: 11px; font-weight: 600;
    padding: 3px 9px; border-radius: 9px; }}
QLabel#dueChip {{ background: #1a2c4e; color: #8fb4ff; }}
QLabel#dueChip[urgent="true"] {{ background: #2a1a1c; color: #ef9a9a; }}
QLabel#estChip {{ background: #1a1c21; color: #9ba1ab; }}
QLabel#priceChip {{ background: #1a1c21; color: #d7dae0; font-weight: 700; }}
QLabel#followChip {{ background: #2a2214; color: #e8b45a; }}
QLabel#logisticsChip {{ background: #1a1c21; color: #c6cbd3; font-size: 11px;
    font-weight: 600; padding: 3px 9px; border-radius: 9px; }}
/* quiet tri-state outcome */
QPushButton#outcomeSeg {{ border: 1px solid #23252b; border-radius: 9px;
    padding: 4px 10px; font-size: 11px; font-weight: 600; color: #5a5f68;
    background: transparent; }}
QPushButton#outcomeSeg:hover {{ color: #9ba1ab; border-color: #33363e; }}
QPushButton#outcomeSeg:checked[outcome_state="unknown"] {{ background: #1a1c21;
    border-color: #2c2f37; color: #9ba1ab; }}
QPushButton#outcomeSeg:checked[outcome_state="won"] {{ background: #12261a;
    border-color: #1e4d33; color: #7fd6a4; }}
QPushButton#outcomeSeg:checked[outcome_state="lost"] {{ background: #2a1a1c;
    border-color: #6b3a3e; color: #ef9a9a; }}
/* re-quote link + version history */
QPushButton#requoteLink {{ background: transparent; border: none; text-align: left;
    padding: 2px 0px; font-size: 12px; color: #6b7078; }}
QPushButton#requoteLink:hover {{ color: #8fb4ff; text-decoration: underline; }}
QPushButton#versionRow {{ background: transparent; border: 1px solid #23252b;
    border-radius: 8px; text-align: left; padding: 7px 12px; font-size: 12px;
    color: #c6cbd3; }}
QPushButton#versionRow:hover {{ border-color: #4f8cff; color: #ffffff; }}
QPushButton#versionRow:disabled {{ background: #1a2c4e; border-color: #2c4a7c;
    color: #8fb4ff; font-weight: 600; }}
/* distributor scope preset suggestion */
QPushButton#scopeSuggest {{ background: #141518; border: 1px dashed #3a3e48;
    border-radius: 8px; padding: 7px 12px; font-size: 12px; color: #9ba1ab;
    text-align: left; }}
QPushButton#scopeSuggest:hover {{ border-color: #4f8cff; color: #d5d9e0; }}
/* follow-ups widget rows */
QFrame#followRow {{ background: #141518; border: 1px solid #23252b;
    border-radius: 10px; }}
QFrame#segBar {{ background: #141518; border: 1px solid #23252b; border-radius: 11px; }}
QPushButton[role="scopeRow"] {{ background: transparent; border: 1px solid transparent; border-radius: 7px;
    text-align: left; padding: 8px 12px; font-size: 13px; color: #d5d9e0; }}
QPushButton[role="scopeRow"]:hover {{ background: transparent; border-color: #3f444e; }}
QPushButton[role="scopeRow"]:checked {{ background: transparent; border-color: #6b7280; color: #f4f5f7; font-weight: 600; }}
QFrame#scopePopup {{ background: transparent; border: none; border-radius: 10px; }}

/* ---------- inputs ---------- */
QLineEdit, QTextEdit, QComboBox {{ background: #0f1013; border: 1px solid #2a2d34;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #f4f5f7;
    selection-background-color: #2f6fed; }}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid #4f8cff; }}
QLineEdit:disabled, QTextEdit:disabled {{ color: #9ba1ab; background: #121316; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{ image: url("{_CHEV_DOWN_DARK}"); width: 10px; height: 10px; }}
QComboBox QAbstractItemView {{ background: rgba(24, 26, 32, 0.84); border: 1px solid rgba(255, 255, 255, 0.19);
    border-radius: 10px; padding: 4px;
    selection-background-color: #2f6fed; color: #e6e9ee; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #e6e9ee; }}
QComboBox QAbstractItemView::item:hover {{ background: transparent; border-color: #3f444e; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #6b7280; color: #ffffff; border-radius: 7px; }}
/* date / time edits: same themed field + chevron dropdown as every combo */
QDateEdit, QTimeEdit, QDateTimeEdit {{ background: #0f1013; border: 1px solid #2a2d34;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #f4f5f7;
    selection-background-color: #2f6fed; }}
QDateEdit:focus, QTimeEdit:focus, QDateTimeEdit:focus {{ border: 1px solid #4f8cff; }}
QDateEdit:disabled, QTimeEdit:disabled, QDateTimeEdit:disabled {{ color: #9ba1ab;
    background: #121316; }}
QDateEdit::drop-down, QTimeEdit::drop-down, QDateTimeEdit::drop-down {{
    border: none; width: 24px; }}
QDateEdit::down-arrow, QTimeEdit::down-arrow, QDateTimeEdit::down-arrow {{
    image: url("{_CHEV_DOWN_DARK}"); width: 10px; height: 10px; }}
/* calendar popup: full dark theme wherever it appears */
QCalendarWidget QWidget {{ alternate-background-color: #1a1c21; }}
QCalendarWidget QAbstractItemView:enabled {{ background-color: #101114; color: #e6e9ee;
    selection-background-color: #2f6fed; selection-color: #ffffff; outline: none; }}
QCalendarWidget QAbstractItemView:disabled {{ color: #4a4f59; }}
QCalendarWidget QToolButton {{ color: #e6e9ee; background: transparent; border: none;
    border-radius: 6px; font-size: 13px; font-weight: 600; padding: 4px; }}
QCalendarWidget QToolButton:hover {{ background: #23252b; }}
QCalendarWidget QToolButton::menu-indicator {{ image: none; }}
QCalendarWidget QSpinBox, QCalendarWidget QAbstractSpinBox {{ background: #0f1013;
    border: 1px solid #2a2d34; border-radius: 6px; color: #e6e9ee;
    padding: 2px 4px; font-size: 12px; }}
QCalendarWidget QAbstractSpinBox::up-button,
QCalendarWidget QAbstractSpinBox::down-button {{ border: none; background: transparent;
    width: 14px; }}
QCalendarWidget QAbstractSpinBox::up-arrow {{ image: url("{_CHEV_UP_DARK}");
    width: 8px; height: 8px; }}
QCalendarWidget QAbstractSpinBox::down-arrow {{ image: url("{_CHEV_DOWN_DARK}");
    width: 8px; height: 8px; }}
#qt_calendar_navigationbar {{ background-color: #101114; }}
#qt_calendar_prevmonth, #qt_calendar_nextmonth {{ min-width: 30px; }}
#qt_calendar_prevmonth {{ qproperty-icon: none; qproperty-text: "\u2039"; }}
#qt_calendar_nextmonth {{ qproperty-icon: none; qproperty-text: "\u203a"; }}
/* themed - / + stepper (replaces native QSpinBox arrows) */
QPushButton#stepperBtn {{ background: #1a1c21; border: 1px solid #2c2f37;
    border-radius: 8px; font-size: 15px; font-weight: 700; color: #9ba1ab;
    padding: 0px; }}
QPushButton#stepperBtn:hover {{ background: #23252b; color: #ffffff;
    border-color: #3a3e48; }}
QPushButton#stepperBtn:disabled {{ color: #4a4f59; background: #141518;
    border-color: #23252b; }}
QLabel#stepperValue {{ background: #0f1013; border: 1px solid #2a2d34;
    border-radius: 8px; padding: 5px 8px; font-size: 13px; font-weight: 600;
    color: #f4f5f7; }}
/* sort dropdown: polished popup to match the theme */
QComboBox#sortBox {{ background: #15171c; }}
QComboBox#sortBox:hover {{ border: 1px solid #3a3e47; }}
QComboBox#sortBox QAbstractItemView {{ background: rgba(24, 26, 32, 0.84); border: 1px solid rgba(255, 255, 255, 0.19);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox#sortBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #e6e9ee; }}
QComboBox#sortBox QAbstractItemView::item:hover {{ background: transparent; border-color: #3f444e; }}
QComboBox#sortBox QAbstractItemView::item:selected {{ background: transparent; border-color: #6b7280; color: #ffffff; border-radius: 7px; }}
/* V1.9.18 (user report: square corners on every NON-sort dropdown):
   only #sortBox views were styled; every other combo fell back to the
   unstyled view. The generic rule gives all combo popups the same
   rounded frame; #sortBox's more specific rule still wins for it. */
QComboBox QAbstractItemView {{ background: rgba(24, 26, 32, 0.84); border: 1px solid rgba(255, 255, 255, 0.19);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border-radius: 7px;
    color: #e6e9ee; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #6b7280; color: #ffffff; }}
/* V1.9.3: the Notes font-size box is only 58px wide — the generic combo
   padding (8px 11px) would leave the text field ~12px and clip "14" to "4".
   Tight padding keeps two digits fully visible. */
QComboBox#notesSizeBox {{ padding: 5px 4px; }}

/* ---------- checkboxes: uniform indicator in both themes ---------- */
QCheckBox {{ color: #d5d9e0; font-size: 13px; spacing: 10px; }}
QCheckBox:disabled {{ color: #5b6068; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 5px;
    border: 1px solid #6b7078; background: #141518; }}
QCheckBox::indicator:hover {{ border-color: #8fb4ff; }}
QCheckBox::indicator:pressed {{ background: #23252b; }}
QCheckBox::indicator:checked {{ background: #2f6fed; border-color: #2f6fed;
    image: url("{_CHECK_MARK}"); }}
QCheckBox::indicator:checked:hover {{ background: #4a86f5; border-color: #4a86f5; }}
QCheckBox::indicator:checked:pressed {{ background: #245fd1; border-color: #245fd1; }}
QCheckBox::indicator:indeterminate {{ background: #2f6fed; border-color: #2f6fed; }}
QCheckBox::indicator:disabled {{ border-color: #2a2d34; background: #101114; }}
QCheckBox::indicator:checked:disabled {{ background: #31405c; border-color: #31405c;
    image: none; }}

/* ---------- quote-folder setup guard (new task dialog) ---------- */
QCheckBox#primaryCheck {{ color: #eaf1ff; font-size: 14px; font-weight: 700;
    spacing: 10px; }}
QLabel#folderSetupWarning {{ background: #2e2310; border: 1px solid #6b531f;
    border-radius: 8px; color: #f2c14e; font-size: 12px; padding: 8px 10px; }}
QPushButton#folderSetupButton {{ background: #1a2c4e; border: 1px solid #2f6fed;
    border-radius: 8px; color: #8fb4ff; font-size: 13px; font-weight: 600;
    padding: 8px 14px; }}
QPushButton#folderSetupButton:hover {{ background: #22365e; color: #b3ccff; }}

/* ---------- contact autocomplete popup ---------- */
QListView#completerPopup {{ background: #1c1e24; border: 1px solid #2c2f37;
    border-radius: 10px; padding: 4px; outline: none; }}
QListView#completerPopup::item {{ padding: 9px 12px; border-radius: 7px;
    color: #e6e9ee; }}
QListView#completerPopup::item:selected, QListView#completerPopup::item:hover {{
    background: #2a2e37; color: #ffffff; }}

/* ---------- menus ---------- */
QMenuBar {{ background: transparent; color: #c6cbd3; border-bottom: 1px solid #1d1f24; }}
QMenuBar::item {{ padding: 6px 12px; background: transparent; }}
QMenuBar::item:selected {{ background: #1e2026; border-radius: 6px; }}
QMenu {{ background: rgba(24, 26, 32, 0.94); border: 1px solid #33363e; border-radius: 8px; padding: 5px; }}
QMenu::item {{ padding: 7px 26px 7px 14px; border: 1px solid transparent; border-radius: 6px; color: #f4f5f7; font-weight: 600; }}
QMenu::item:selected {{ background: transparent; border-color: #3f444e; color: #ffffff; border-radius: 6px; }}
QMenu::separator {{ height: 1px; background: #2a2d34; margin: 5px 8px; }}
QMenu::indicator {{ width: 14px; height: 14px; }}

/* ---------- scrollbars ----------
   Single shared rule: the vertical bar paints flush against its scroll
   area's right edge (no right margin — the bar must not float left of the
   edge). The groove/handle insets above/below keep it off the corners. */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px 0; }}
QScrollBar::handle:vertical {{ background: #33363d; border-radius: 4px; min-height: 32px; }}
QScrollBar::handle:vertical:hover {{ background: #4a4f59; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0 3px 2px 3px; }}
QScrollBar::handle:horizontal {{ background: #33363d; border-radius: 4px; min-width: 32px; }}
QScrollBar::handle:horizontal:hover {{ background: #4a4f59; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{ background: transparent; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea QWidget {{ background: transparent; }}

/* ---------- dialogs & detail ---------- */
QDialog {{ background: transparent; }}
QLabel#dialogTitle {{ font-size: 18px; font-weight: 700; color: #f4f5f7; }}
QLabel#fieldLabel {{ font-size: 12px; font-weight: 600; color: #9ba1ab; }}
QLabel#sectionLabel {{ font-size: 11px; font-weight: 700; color: #6b7078; }}
QLabel#detailValue {{ font-size: 14px; color: #f4f5f7; }}
QLabel#revValue {{ font-size: 18px; font-weight: 700; color: #f4f5f7; }}
QWidget[groupStart="true"] {{ margin-top: 18px; }}
QFrame#attachPanel {{ background: #0f1013; border: 1px dashed #33363e; border-radius: 10px; }}
QFrame#attachPanel[dragOver="true"] {{ border: 1px dashed #4f8cff; background: #121a2c; }}
QListWidget#attachList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #c6cbd3; }}
QListWidget#attachList::item {{ padding: 7px 8px; border-radius: 6px; color: #d5d9e0; }}
QWidget#optionRow QLabel {{ color: #d5d9e0; }}
QListWidget#attachList::item:hover {{ background: #1a1c21; }}
QListWidget#attachList::item:selected {{ background: #2b2e35; color: #f4f5f7; }}
/* V1.9.29: the Settings option lists carry full-row widgets; zero item
   padding so the hover/selected band wraps the row widget exactly
   (the shared attachList 7px/8px padding inset the widget and left
   the band floating wider than the option -- user screenshot). */
QListWidget#optionList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #c6cbd3; }}
QListWidget#optionList::item {{ padding: 0px; border-radius: 6px; color: #d5d9e0; }}
QListWidget#optionList::item:hover {{ background: #1a1c21; }}
QListWidget#optionList::item:selected {{ background: #2b2e35; color: #f4f5f7; }}
/* ---------- notes module ---------- */
QListWidget#noteNav, QListWidget#noteList {{ background: transparent; border: none;
    outline: none; font-size: 13px; color: #c6cbd3; }}
QListWidget#noteNav::item, QListWidget#noteList::item {{ padding: 2px;
    border-radius: 8px; }}
QListWidget#noteNav::item:hover, QListWidget#noteList::item:hover {{ background: #1a1c21; }}
QListWidget#noteNav::item:selected, QListWidget#noteList::item:selected {{ background: #2b2e35; }}
QLabel#noteNavName {{ font-size: 13px; font-weight: 600; color: #c6cbd3; }}
QListWidget#noteNav::item:selected QLabel#noteNavName {{ color: #f4f5f7; }}
QLabel#noteCount {{ font-size: 11px; font-weight: 700; color: #8a919c;
    background: #23252b; border-radius: 8px; padding: 2px 8px; }}
QPushButton#noteScope {{ background: transparent; border: none; border-radius: 8px;
    padding: 8px 10px; font-size: 13px; font-weight: 600; color: #9ba1ab;
    text-align: left; }}
QPushButton#noteScope:hover {{ background: #1a1c21; color: #e6e9ee; }}
QPushButton#noteScope:checked {{ background: #1e2a44; color: #8fb4ff; }}
QLabel#noteRowTitle {{ font-size: 13px; font-weight: 700; color: #e6e9ee; }}
QListWidget#noteList::item:selected QLabel#noteRowTitle {{ color: #f4f5f7; }}
QLabel#noteSnippet {{ font-size: 12px; color: #9ba1ab; }}
QLabel#noteFooter {{ font-size: 11px; color: #6b7078; }}
QLineEdit#noteTitle {{ background: transparent; border: none; border-radius: 0px;
    font-size: 22px; font-weight: 700; color: #f4f5f7; padding: 2px 0px; }}
QLineEdit#noteTitle:focus {{ border: none; }}
QLabel#noteSaved {{ font-size: 11px; color: #6b7078; }}
QLabel#noteEmpty {{ font-size: 14px; color: #6b7078; }}
QPushButton#fmtBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 6px; font-size: 13px; color: #9ba1ab; padding: 0px; }}
QPushButton#fmtBtn:hover {{ background: #1a1c21; color: #e6e9ee; }}
QPushButton#fmtBtn:checked {{ background: #1e2a44; color: #8fb4ff;
    border: 1px solid #2c3a58; }}
QPushButton#notesSizeBtn {{ padding: 0px; }}
QFrame#fmtSep {{ color: #2a2d34; margin: 4px 2px; }}
QTextEdit#noteEditor {{ font-size: 14px; }}
QToolTip {{ background: #23252b; color: #e6e9ee; border: 1px solid #3a3e48;
    padding: 5px 8px; border-radius: 8px; }}
QMessageBox {{ background: #141518; }}
QMessageBox QLabel {{ color: #e6e9ee; }}
QInputDialog QLabel {{ color: #e6e9ee; }}

/* ---------- custom window chrome ---------- */
QFrame#windowFrame {{ background: #101114; border: 1px solid #26282f; border-radius: 12px; }}
/* v1.4.0 item 12: square corners when maximized (no edge gaps) */
QFrame#windowFrame[squareCorners="true"] {{ border-radius: 0px; border: none; }}
QFrame#titleBar {{ background: transparent; border: none; border-bottom: 1px solid #1d1f24; }}
QLabel#titleBarLabel {{ color: #c6cbd3; font-size: 12px; font-weight: 600; background: transparent; }}
QPushButton#winBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #9ba1ab; font-size: 12px; padding: 6px 12px; }}
QPushButton#winBtn:hover {{ background: #23252b; color: #ffffff; }}
QPushButton#winCloseBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #9ba1ab; font-size: 12px; padding: 6px 12px; }}
QPushButton#winCloseBtn:hover {{ background: #e81123; color: #ffffff; }}

/* ---------- rack type tags ---------- */
QPushButton[role="rackTag"] {{ border: none; border-radius: 9px; padding: 4px 6px;
    font-size: 11px; font-weight: 600; background: #123836; color: #6fd7c9; }}
QLabel[role="rackTag"] {{ border: none; border-radius: 9px; padding: 4px 6px;
    font-size: 11px; font-weight: 600; background: #123836; color: #6fd7c9; }}

/* ---------- notes editor ---------- */
QTextEdit#notesEdit {{ padding: 10px; }}

/* ---------- toolbar ---------- */
QFrame#toolBar {{ background: transparent; border: none; }}
QFrame#bulkBar {{ background: #0e0f12; border: 1px solid #26282e; border-radius: 10px; }}
QLabel#bulkLabel {{ color: #e8eaee; font-size: 13px; font-weight: 600; }}
QLabel#sortLabel {{ color: #6b7078; font-size: 12px; }}
QLabel#countLabel {{ color: #6b7078; font-size: 12px; }}

/* ---------- sidebar ---------- */
QFrame#sideBar {{ background: #0e0f12; border: none; border-right: 1px solid #1d1f24; }}
QPushButton#navBtn {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 12px; font-size: 13px; font-weight: 600; color: #9a9a9a;
    text-align: left; }}
QPushButton#navBtn:hover {{ background: #1a1c21; color: #e6e9ee; }}
QPushButton#navBtn:checked {{ background: transparent; color: #ffffff; }}
QFrame#navPill {{ background: #2a2a2a; border-radius: 10px; }}
QLabel#sideFoot {{ color: #4a4f59; font-size: 10px; }}
QPushButton#navToggle {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 0px; font-size: 15px; font-weight: 600; color: #9ba1ab;
    text-align: center; }}
QPushButton#navToggle:hover {{ background: #1a1c21; color: #e6e9ee; }}
/* v1.4.0 item 16: Settings sidebar nav - restrained, no blue tint. */
QPushButton#settingsNav {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 14px; font-size: 13px; color: #9ba1ab; text-align: left; }}
QPushButton#settingsNav:hover {{ background: #1a1c21; color: #e6e9ee; }}
QPushButton#settingsNav:checked {{ background: #26292f; color: #f2f4f7; }}

/* ---------- CRM ---------- */
QLabel#kindPill {{ background: #1e2a44; color: #8fb4ff; border-radius: 9px;
    padding: 4px 12px; font-size: 11px; font-weight: 600; }}
QPushButton#taskLink {{ background: transparent; border: 1px solid #23252b;
    border-radius: 9px; padding: 9px 12px; text-align: left;
    color: #dfe3ea; font-size: 12px; font-weight: 600; }}
QPushButton#taskLink:hover {{ background: #16181d; border-color: #33363e; color: #8fb4ff; }}

/* v1.4.0 item 15: inline SDC badge in the task detail window */
QLabel#sdcBadge {{ border-radius: 8px; padding: 2px 8px; font-size: 11px;
    font-weight: 600; }}
QLabel#sdcBadge[sdcSeverity="low"] {{ background: #1e2025; color: #8f96a3;
    border: 1px solid #2a2d34; }}
QLabel#sdcBadge[sdcSeverity="watch"] {{ background: #3a2f16; color: #eec25e;
    border: 1px solid #5a4a1e; }}
QLabel#sdcBadge[sdcSeverity="high"] {{ background: #3d1f1f; color: #ff8a8a;
    border: 1px solid #5c2b2b; }}
QPushButton#iconBtn {{ background: transparent; border: none; border-radius: 7px;
    padding: 7px; }}
QPushButton#iconBtn:hover {{ background: #23252b; }}

/* ---------- queue board ---------- */
QFrame#queueColumn {{ background: #0e0f12; border: 1px solid #1d1f24; border-radius: 14px; }}
QFrame#queueColumn[dropActive="true"] {{ border: 1px solid #4f8cff; background: #10131a; }}
QFrame#dropPlaceholder {{ background: rgba(79, 140, 255, 0.07);
    border: 1.5px dashed #4f8cff; border-radius: 14px; }}
QLabel#dropPlaceholderText {{ color: #8fb4ff; font-size: 12px; font-weight: 600; }}
QLabel#colTitle {{ font-size: 13px; font-weight: 700; color: #f4f5f7; }}
QLabel#countBadge {{ background: #23252b; color: #9ba1ab; border-radius: 9px;
    padding: 2px 9px; font-size: 11px; font-weight: 700; }}
QFrame#queueCard {{ background: #141518; border: 1px solid #23252b; border-radius: 12px; }}
QFrame#queueCard:hover {{ border-color: #3a3e48; }}
QLabel#queueQuote {{ font-size: 16px; font-weight: 700; color: #cfe0ff;
    background: #1a2c4e; padding: 6px 14px;
    border-top-left-radius: 0px; border-top-right-radius: 0px;
    border-bottom-right-radius: 11px; border-bottom-left-radius: 0px; }}
/* queue-card notes: label-like read-only scroller (see QueueCard._fit_notes) */
QTextEdit#queueDesc {{ background: transparent; border: none; padding: 0px;
    color: #c6cbd3;
    selection-background-color: #2f6fed; selection-color: #ffffff; }}
QLabel#queueMeta {{ font-size: 11px; color: #9ba1ab; }}
QLabel#dropHint {{ color: #4a4f59; font-size: 12px; border: 1px dashed #2a2d34;
    border-radius: 10px; padding: 20px 10px; }}
QLabel#miniPill {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; }}
QLabel#miniPill[statusState="in_process"] {{ background: #1a2c4e; color: #7fb0ff; }}
QLabel#miniPill[statusState="on_hold"] {{ background: #3a2f16; color: #eec25e; }}
QLabel#miniPill[statusState="completed"] {{ background: #143327; color: #6fdc9e; }}
QLabel#miniPill[statusState="canceled"] {{ background: #23252b; color: #9ba1ab; }}
/* v1.4.0 item 10: amber "Waiting: …" chip on queue cards */
QLabel#waitingChip {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; background: #3a2f16; color: #eec25e; }}
QCheckBox#queueCheck {{ color: #d5d9e0; font-size: 13px; spacing: 10px; }}

/* ---------- settings: folder creation guidance (warn/missing states) ---------- */
QLabel#folderHint[warn="true"] {{ color: #ef9a9a; font-weight: 600; }}
QLineEdit[missing="true"] {{ border: 1px solid #b0453f; }}
QLabel#verifyItem[ok="true"] {{ color: #6fdc9e; }}
QLabel#verifyItem[ok="false"] {{ color: #ef9a9a; font-weight: 600; }}
"""

LIGHT = f"""
* {{ font-family: {FONT_STACK}; }}
QWidget#app {{ background: #f5f5f6; }}
QLabel#title {{ font-size: 22px; font-weight: 700; color: #1c1f24; }}
QLabel#subtitle {{ color: #474c54; font-size: 12px; }}
QLabel#emptyState {{ color: #4e535b; font-size: 14px; }}

/* ---------- cards ---------- */
QFrame#card {{ background: #ffffff; border: 1px solid #e3e4e6; border-radius: 14px; }}
QFrame#card:hover {{ border: 1px solid #ccd0d6; }}
/* V1.9.5: hot tasks — red border beats hover. */
QFrame#card[hot="true"] {{ border: 1px solid #e5484d; }}
QFrame#card[hot="true"]:hover {{ border: 1px solid #e5484d; }}
QLabel#quoteNum {{ font-size: 15px; font-weight: 700; color: #1c1f24;
    background: transparent; border: none; padding: 0px 2px; }}
QLabel#meta {{ color: #3d4149; font-size: 13px; }}
QLabel#metaPrefix {{ color: #474c54; font-size: 13px; }}
QLabel#notes {{ color: #3d4149; font-size: 13px; }}
QLabel#dateLabel {{ color: #4e535b; font-size: 11px; }}
QLabel#progressLabel {{ color: #474c54; font-size: 11px; font-weight: 600; }}
QLabel#hint {{ color: #4e535b; font-size: 11px; }}
QRadioButton {{ color: #3d4149; }}

/* ---------- status pill (clickable) ---------- */
QPushButton#statusPill {{ border: none; border-radius: 11px; padding: 4px 12px;
    font-size: 11px; font-weight: 700; }}
QPushButton#statusPill[statusState="in_process"] {{ background: #e3e9f2; color: #1d4ed8; }}
QPushButton#statusPill[statusState="in_process"]:hover {{ background: #dde3ec; }}
QPushButton#statusPill[statusState="on_hold"] {{ background: #f5efdb; color: #b45309; }}
QPushButton#statusPill[statusState="on_hold"]:hover {{ background: #f3ead0; }}
QPushButton#statusPill[statusState="completed"] {{ background: #e4f0e6; color: #15803d; }}
QPushButton#statusPill[statusState="completed"]:hover {{ background: #dcecdf; }}
QPushButton#statusPill[statusState="canceled"] {{ background: #e8ebf0; color: #5f666b; }}
QPushButton#statusPill[statusState="canceled"]:hover {{ background: #dde1e8; }}

/* ---------- outcome pill (clickable, V1.9.29) ---------- */
QPushButton#outcomePill {{ border: none; border-radius: 11px; padding: 4px 12px;
    font-size: 11px; font-weight: 700; }}
QPushButton#outcomePill[outcomeState="won"] {{ background: #e4f0e6; color: #15803d; }}
QPushButton#outcomePill[outcomeState="won"]:hover {{ background: #dcecdf; }}
QPushButton#outcomePill[outcomeState="lost"] {{ background: #f9e3e1; color: #b3261e; }}
QPushButton#outcomePill[outcomeState="lost"]:hover {{ background: #f5d7d4; }}
QPushButton#outcomePill[outcomeState="dead"] {{ background: #f3e2d8; color: #9a4a2f; }}
QPushButton#outcomePill[outcomeState="dead"]:hover {{ background: #eed5c6; }}
QPushButton#outcomePill[outcomeState="on_hold"] {{ background: #f5efdb; color: #b45309; }}
QPushButton#outcomePill[outcomeState="on_hold"]:hover {{ background: #f3ead0; }}
QPushButton#outcomePill[outcomeState="unknown"] {{ background: #e8ebf0; color: #5f666b; }}
QPushButton#outcomePill[outcomeState="unknown"]:hover {{ background: #dde1e8; }}

/* ---------- scope chips (checkable) ---------- */
QPushButton[role="scopeChip"] {{ border: none; border-radius: 9px; padding: 4px 6px;
    font-size: 11px; font-weight: 600; }}
QPushButton[role="scopeChip"][scopeKey="quote"] {{ background: #e3e9f2; color: #1d4ed8; }}
QPushButton[role="scopeChip"][scopeKey="re-quote"] {{ background: #e9e7f2; color: #6d28d9; }}
QPushButton[role="scopeChip"][scopeKey="cad"] {{ background: #e2efe7; color: #047857; }}
QPushButton[role="scopeChip"][scopeKey="configura"] {{ background: #f5e9da; color: #c2410c; }}
QPushButton[role="scopeChip"][scopeKey="prelims"] {{ background: #f2efda; color: #a16207; }}
QPushButton[role="scopeChip"][scopeKey="misc"] {{ background: #ececee; color: #474c54; }}
QPushButton[role="scopeChip"][scopeKey="custom-0"] {{ background: #e9e7f2; color: #6d28d9; }}
QPushButton[role="scopeChip"][scopeKey="custom-1"] {{ background: #e3edf2; color: #0369a1; }}
QPushButton[role="scopeChip"][scopeKey="custom-2"] {{ background: #f5e9da; color: #c2410c; }}
QPushButton[role="scopeChip"][scopeKey="custom-3"] {{ background: #e4f0e6; color: #15803d; }}
QPushButton[role="scopeChip"]:hover {{ border: 1px solid #ccd0d6; }}
QPushButton[role="scopeChip"]:checked {{ background: #e4f0e6; color: #15803d; }}

/* ---------- buttons ---------- */
QPushButton {{ background: #ffffff; border: 1px solid #d9dbde; border-radius: 8px;
    padding: 7px 14px; font-size: 13px; color: #272b33; }}
QPushButton:hover {{ background: #f5f5f6; border-color: #bfc4cb; }}
QPushButton:disabled {{ color: #8f959e; background: #f5f5f6; border-color: #e3e4e6; }}
QPushButton#primary {{ background: #2563eb; border: none; color: #ffffff;
    font-weight: 600; padding: 9px 18px; }}
QPushButton#primary:hover {{ background: #1d55c9; }}
/* Name links (see the dark theme note). */
QPushButton#contactLink {{ background: transparent; border: none;
    color: #272b33; padding: 7px 6px; font-size: 13px; }}
QPushButton#contactLink:hover {{ background: transparent;
    text-decoration: underline; }}
QPushButton#contactLink:focus {{ text-decoration: underline; }}
QPushButton#ghost {{ background: transparent; border: 1px solid #d9dbde;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger {{ background: transparent; border: 1px solid #d9dbde; color: #c0392b;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger:hover {{ background: #f5f5f6; border-color: #bfc4cb; }}
QPushButton#ghost:hover {{ background: #ececee; border-color: #bfc4cb; }}
QPushButton#cardHotBtn, QPushButton#cardFolderBtn, QPushButton#cardEditBtn,
QPushButton#cardDeleteBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 8px; padding: 5px 9px; font-size: 12px; color: #3d4149; }}
QPushButton#cardHotBtn:hover {{ background: rgba(229, 72, 77, 0.14); color: #c0272d; }}
QPushButton#cardFolderBtn:hover {{ background: rgba(217, 144, 27, 0.16); color: #9a6206; }}
QPushButton#cardEditBtn:hover {{ background: rgba(37, 99, 235, 0.12); color: #1d4ed8; }}
QPushButton#cardDeleteBtn {{ color: #c0392b; }}
QPushButton#cardDeleteBtn:hover {{ background: rgba(229, 72, 77, 0.14); color: #c0272d; }}
QPushButton#scopeButton {{ text-align: left; padding: 9px 12px; }}
QFrame#scopeButton {{ background: #ffffff; border: 1px solid #d9dbde; border-radius: 8px; }}
QFrame#scopeButton:hover {{ border: 1px solid #2563eb; }}
QLabel#scopeText {{ color: #1c1f24; font-size: 13px; background: transparent; }}
QLabel#scopeText[empty="true"] {{ color: #4e535b; }}
QLabel#scopeArrow {{ color: #474c54; font-size: 11px; background: transparent; }}
QPushButton#titleLink {{ background: transparent; border: none; text-align: left;
    padding: 0px; font-size: 18px; font-weight: 700; color: #1d4ed8; }}
QPushButton#titleLink:hover {{ color: #1d55c9; text-decoration: underline; }}
QPushButton#titleLink:disabled {{ color: #1c1f24; }}
QLabel#imageStage {{ background: #000000; border-radius: 8px; }}
QPushButton#seg {{ border: 1px solid transparent; border-radius: 8px; padding: 7px 13px;
    font-size: 13px; font-weight: 600; color: #474c54; background: transparent; }}
QPushButton#seg:hover {{ color: #272b33; }}
QPushButton#seg:checked {{ background: #ffffff; color: #1d4ed8; }}
QPushButton#seg[attention="true"] {{ background: #ffffff; color: #b42318;
    border-color: #e5a8a8; }}
QPushButton#seg[attention="true"]:hover {{ background: #f5f5f6; color: #912018;
    border-color: #d98c8c; }}
QPushButton#seg[attention="true"]:checked {{ background: #ececee; color: #912018;
    border-color: #b42318; }}
QPushButton#chipToggle {{ border: 1px solid #d9dbde; border-radius: 11px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #474c54; background: #ececee; }}
QPushButton#chipToggle:hover {{ color: #272b33; border-color: #bfc4cb; }}
QPushButton#chipToggle:checked {{ background: #e3e9f2; border-color: #1d4ed8; color: #1d4ed8; }}
QLabel#chipToggle {{ border: 1px solid #d9dbde; border-radius: 11px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #474c54; background: #ececee; }}
QLabel#chipToggle:hover {{ color: #272b33; border-color: #bfc4cb; }}
QLabel#chipToggle[checked="true"] {{ background: #e3e9f2; border-color: #1d4ed8; color: #1d4ed8; }}
QPushButton#dueChip {{ border: 1px solid #d9dbde; border-radius: 11px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #474c54; background: #ececee; }}
QPushButton#dueChip:hover {{ color: #272b33; border-color: #bfc4cb; }}
QPushButton#dueChip:checked {{ background: #e3e9f2; border-color: #93b4f5; color: #1d4ed8; }}
/* card badges */
QLabel#dueChip, QLabel#estChip, QLabel#followChip, QLabel#priceChip {{ font-size: 11px; font-weight: 600;
    padding: 3px 9px; border-radius: 9px; }}
QLabel#dueChip {{ background: #e3e9f2; color: #1d4ed8; }}
QLabel#dueChip[urgent="true"] {{ background: #f3f4f6; color: #b42318; }}
QLabel#estChip {{ background: #ececee; color: #474c54; }}
QLabel#priceChip {{ background: #ececee; color: #23252b; font-weight: 700; }}
QLabel#followChip {{ background: #f5efdb; color: #8a5f16; }}
QLabel#logisticsChip {{ background: #ececee; color: #3d4149; font-size: 11px;
    font-weight: 600; padding: 3px 9px; border-radius: 9px; }}
/* quiet tri-state outcome */
QPushButton#outcomeSeg {{ border: 1px solid #d9dbde; border-radius: 9px;
    padding: 4px 10px; font-size: 11px; font-weight: 600; color: #52565e;
    background: transparent; }}
QPushButton#outcomeSeg:hover {{ color: #474c54; border-color: #bfc4cb; }}
QPushButton#outcomeSeg:checked[outcome_state="unknown"] {{ background: #ececee;
    border-color: #ccd0d6; color: #474c54; }}
QPushButton#outcomeSeg:checked[outcome_state="won"] {{ background: #e6f1e9;
    border-color: #9ed9b8; color: #1c7a45; }}
QPushButton#outcomeSeg:checked[outcome_state="lost"] {{ background: #f3f4f6;
    border-color: #d9dbde; color: #b42318; }}
/* re-quote link + version history */
QPushButton#requoteLink {{ background: transparent; border: none; text-align: left;
    padding: 2px 0px; font-size: 12px; color: #4e535b; }}
QPushButton#requoteLink:hover {{ color: #1d4ed8; text-decoration: underline; }}
QPushButton#versionRow {{ background: transparent; border: 1px solid #d9dbde;
    border-radius: 8px; text-align: left; padding: 7px 12px; font-size: 12px;
    color: #3a3d44; }}
QPushButton#versionRow:hover {{ border-color: #2563eb; color: #1d4ed8; }}
QPushButton#versionRow:disabled {{ background: #e3e9f2; border-color: #93b4f5;
    color: #1d4ed8; font-weight: 600; }}
/* distributor scope preset suggestion */
QPushButton#scopeSuggest {{ background: #f5f5f6; border: 1px dashed #bfc4cb;
    border-radius: 8px; padding: 7px 12px; font-size: 12px; color: #474c54;
    text-align: left; }}
QPushButton#scopeSuggest:hover {{ border-color: #2563eb; color: #272b33; }}
/* follow-ups widget rows */
QFrame#followRow {{ background: #f5f5f6; border: 1px solid #d9dbde;
    border-radius: 10px; }}
QFrame#segBar {{ background: #e4e4e7; border-radius: 11px; }}
QPushButton[role="scopeRow"] {{ background: transparent; border: 1px solid transparent; border-radius: 7px;
    text-align: left; padding: 8px 12px; font-size: 13px; color: #3a3d44; }}
QPushButton[role="scopeRow"]:hover {{ background: transparent; border-color: #c3c7cd; }}
QPushButton[role="scopeRow"]:checked {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; font-weight: 600; }}
QFrame#scopePopup {{ background: transparent; border: none; border-radius: 10px; }}

/* ---------- contact autocomplete popup ---------- */
QListView#completerPopup {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 10px; padding: 4px; outline: none; }}
QListView#completerPopup::item {{ padding: 9px 12px; border-radius: 7px;
    color: #272b33; }}
QListView#completerPopup::item:selected, QListView#completerPopup::item:hover {{
    background: #e8edf3; color: #1d4ed8; }}

/* ---------- inputs ---------- */
QLineEdit, QTextEdit, QComboBox {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #1c1f24;
    selection-background-color: #2563eb; }}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid #2563eb; }}
QLineEdit:disabled, QTextEdit:disabled {{ color: #474c54; background: #f5f5f6; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{ image: url("{_CHEV_DOWN_LIGHT}"); width: 10px; height: 10px; }}
/* date / time edits: same themed field + chevron dropdown as every combo */
QDateEdit, QTimeEdit, QDateTimeEdit {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #1c1f24;
    selection-background-color: #2563eb; }}
QDateEdit:focus, QTimeEdit:focus, QDateTimeEdit:focus {{ border: 1px solid #2563eb; }}
QDateEdit:disabled, QTimeEdit:disabled, QDateTimeEdit:disabled {{ color: #474c54;
    background: #f5f5f6; }}
QDateEdit::drop-down, QTimeEdit::drop-down, QDateTimeEdit::drop-down {{
    border: none; width: 24px; }}
QDateEdit::down-arrow, QTimeEdit::down-arrow, QDateTimeEdit::down-arrow {{
    image: url("{_CHEV_DOWN_LIGHT}"); width: 10px; height: 10px; }}
/* calendar popup: light theme */
QCalendarWidget QAbstractItemView:enabled {{ background-color: #ffffff; color: #272b33;
    selection-background-color: #2563eb; selection-color: #ffffff; outline: none; }}
QCalendarWidget QAbstractItemView:disabled {{ color: #a8b0bf; }}
QCalendarWidget QToolButton {{ color: #272b33; background: transparent; border: none;
    border-radius: 6px; font-size: 13px; font-weight: 600; padding: 4px; }}
QCalendarWidget QToolButton:hover {{ background: #ececee; }}
QCalendarWidget QToolButton::menu-indicator {{ image: none; }}
QCalendarWidget QSpinBox, QCalendarWidget QAbstractSpinBox {{ background: #ffffff;
    border: 1px solid #d9dbde; border-radius: 6px; color: #1c1f24;
    padding: 2px 4px; font-size: 12px; }}
QCalendarWidget QAbstractSpinBox::up-button,
QCalendarWidget QAbstractSpinBox::down-button {{ border: none; background: transparent;
    width: 14px; }}
QCalendarWidget QAbstractSpinBox::up-arrow {{ image: url("{_CHEV_UP_LIGHT}");
    width: 8px; height: 8px; }}
QCalendarWidget QAbstractSpinBox::down-arrow {{ image: url("{_CHEV_DOWN_LIGHT}");
    width: 8px; height: 8px; }}
#qt_calendar_prevmonth, #qt_calendar_nextmonth {{ min-width: 30px; }}
#qt_calendar_prevmonth {{ qproperty-icon: none; qproperty-text: "‹"; }}
#qt_calendar_nextmonth {{ qproperty-icon: none; qproperty-text: "›"; }}
#qt_calendar_navigationbar {{ background-color: #f7f7f8; }}
/* themed - / + stepper (replaces native QSpinBox arrows) */
QPushButton#stepperBtn {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; font-size: 15px; font-weight: 700; color: #474c54;
    padding: 0px; }}
QPushButton#stepperBtn:hover {{ background: #f5f5f6; color: #1c1f24;
    border-color: #bfc4cb; }}
QPushButton#stepperBtn:disabled {{ color: #9aa0a8; background: #f5f5f6;
    border-color: #e3e4e6; }}
QLabel#stepperValue {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; padding: 5px 8px; font-size: 13px; font-weight: 600;
    color: #1c1f24; }}
QComboBox QAbstractItemView {{ background: rgba(255, 255, 255, 0.84); border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 10px; padding: 4px;
    selection-background-color: #2563eb; selection-color: #ffffff;
    color: #272b33; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #272b33; }}
QComboBox QAbstractItemView::item:hover {{ background: transparent; border-color: #c3c7cd; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; border-radius: 7px; }}
/* sort dropdown: polished popup to match the theme */
QComboBox#sortBox {{ background: #f7f7f8; }}
QComboBox#sortBox:hover {{ border: 1px solid #bfc4cb; }}
QComboBox#sortBox QAbstractItemView {{ background: rgba(255, 255, 255, 0.84); border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox#sortBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #272b33; }}
QComboBox#sortBox QAbstractItemView::item:hover {{ background: transparent; border-color: #c3c7cd; }}
QComboBox#sortBox QAbstractItemView::item:selected {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; border-radius: 7px; }}
/* V1.9.18: generic combo popup frame (see dark note above). */
QComboBox QAbstractItemView {{ background: rgba(255, 255, 255, 0.84); border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border-radius: 7px;
    color: #1c1f24; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; }}
/* V1.9.3: the Notes font-size box is only 58px wide — the generic combo
   padding (8px 11px) would leave the text field ~12px and clip "14" to "4".
   Tight padding keeps two digits fully visible. */
QComboBox#notesSizeBox {{ padding: 5px 4px; }}

/* ---------- checkboxes: uniform indicator in both themes ---------- */
QCheckBox {{ color: #3a3d44; font-size: 13px; spacing: 10px; }}
QCheckBox:disabled {{ color: #8f959e; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 5px;
    border: 1px solid #93a0b4; background: #ffffff; }}
QCheckBox::indicator:hover {{ border-color: #2563eb; }}
QCheckBox::indicator:pressed {{ background: #ececee; }}
QCheckBox::indicator:checked {{ background: #2563eb; border-color: #2563eb;
    image: url("{_CHECK_MARK}"); }}
QCheckBox::indicator:checked:hover {{ background: #1d55c9; border-color: #1d55c9; }}
QCheckBox::indicator:checked:pressed {{ background: #1e4fc4; border-color: #1e4fc4; }}
QCheckBox::indicator:indeterminate {{ background: #2563eb; border-color: #2563eb; }}
QCheckBox::indicator:disabled {{ border-color: #d9dbde; background: #f5f5f6; }}
QCheckBox::indicator:checked:disabled {{ background: #a9bce0; border-color: #a9bce0;
    image: none; }}

/* ---------- quote-folder setup guard (new task dialog) ---------- */
QCheckBox#primaryCheck {{ color: #1c1f24; font-size: 14px; font-weight: 700;
    spacing: 10px; }}
QLabel#folderSetupWarning {{ background: #f5efdb; border: 1px solid #d97706;
    border-radius: 8px; color: #92400e; font-size: 12px; padding: 8px 10px; }}
QPushButton#folderSetupButton {{ background: #e3e9f2; border: 1px solid #2563eb;
    border-radius: 8px; color: #1d4ed8; font-size: 13px; font-weight: 600;
    padding: 8px 14px; }}
QPushButton#folderSetupButton:hover {{ background: #dde3ec; }}

/* ---------- menus ---------- */
QMenuBar {{ background: transparent; color: #3d4149; border-bottom: 1px solid #e3e4e6; }}
QMenuBar::item {{ padding: 6px 12px; background: transparent; }}
QMenuBar::item:selected {{ background: #e9eaec; border-radius: 6px; }}
QMenu {{ background: rgba(255, 255, 255, 0.95); border: 1px solid #d9dbde; border-radius: 8px; padding: 5px; }}
QMenu::item {{ padding: 7px 26px 7px 14px; border: 1px solid transparent; border-radius: 6px; color: #1c1f24; font-weight: 600; }}
QMenu::item:selected {{ background: transparent; border-color: #c3c7cd; color: #1c1f24; border-radius: 6px; }}
QMenu::separator {{ height: 1px; background: #e3e4e6; margin: 5px 8px; }}
QMenu::indicator {{ width: 14px; height: 14px; }}

/* ---------- scrollbars ---------- */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px 0; }}
QScrollBar::handle:vertical {{ background: #c6cfdb; border-radius: 4px; min-height: 32px; }}
QScrollBar::handle:vertical:hover {{ background: #a9b4c4; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0 3px 2px 3px; }}
QScrollBar::handle:horizontal {{ background: #c6cfdb; border-radius: 4px; min-width: 32px; }}
QScrollBar::handle:horizontal:hover {{ background: #a9b4c4; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{ background: transparent; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea QWidget {{ background: transparent; }}

/* ---------- dialogs & detail ---------- */
QDialog {{ background: transparent; }}
QLabel#dialogTitle {{ font-size: 18px; font-weight: 700; color: #1c1f24; }}
QLabel#fieldLabel {{ font-size: 12px; font-weight: 600; color: #474c54; }}
QLabel#sectionLabel {{ font-size: 11px; font-weight: 700; color: #474c54; }}
QLabel#detailValue {{ font-size: 14px; color: #1c1f24; }}
QLabel#revValue {{ font-size: 18px; font-weight: 700; color: #1c1f24; }}
QWidget[groupStart="true"] {{ margin-top: 18px; }}
QFrame#attachPanel {{ background: #f5f5f6; border: 1px dashed #ccd0d6; border-radius: 10px; }}
QFrame#attachPanel[dragOver="true"] {{ border: 1px dashed #2563eb; background: #e8edf3; }}
QListWidget#attachList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #3d4149; }}
QListWidget#attachList::item {{ padding: 7px 8px; border-radius: 6px; color: #1c1f24; }}
QWidget#optionRow QLabel {{ color: #1c1f24; }}
QListWidget#attachList::item:hover {{ background: #ececee; }}
QListWidget#attachList::item:selected {{ background: #e4e5e8; color: #1c1f24; }}
QListWidget#optionList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #3d4149; }}
QListWidget#optionList::item {{ padding: 0px; border-radius: 6px; color: #1c1f24; }}
QListWidget#optionList::item:hover {{ background: #ececee; }}
QListWidget#optionList::item:selected {{ background: #e4e5e8; color: #1c1f24; }}
/* ---------- notes module ---------- */
QListWidget#noteNav, QListWidget#noteList {{ background: transparent; border: none;
    outline: none; font-size: 13px; color: #3d4149; }}
QListWidget#noteNav::item, QListWidget#noteList::item {{ padding: 2px;
    border-radius: 8px; }}
QListWidget#noteNav::item:hover, QListWidget#noteList::item:hover {{ background: #ececee; }}
QListWidget#noteNav::item:selected, QListWidget#noteList::item:selected {{ background: #e4e5e8; }}
QLabel#noteNavName {{ font-size: 13px; font-weight: 600; color: #3d4149; }}
QListWidget#noteNav::item:selected QLabel#noteNavName {{ color: #1c1f24; }}
QLabel#noteCount {{ font-size: 11px; font-weight: 700; color: #474c54;
    background: #ececee; border-radius: 8px; padding: 2px 8px; }}
QPushButton#noteScope {{ background: transparent; border: none; border-radius: 8px;
    padding: 8px 10px; font-size: 13px; font-weight: 600; color: #474c54;
    text-align: left; }}
QPushButton#noteScope:hover {{ background: #ececee; color: #272b33; }}
QPushButton#noteScope:checked {{ background: #e3e9f2; color: #1d4ed8; }}
QLabel#noteRowTitle {{ font-size: 13px; font-weight: 700; color: #1c1f24; }}
QListWidget#noteList::item:selected QLabel#noteRowTitle {{ color: #1c1f24; }}
QLabel#noteSnippet {{ font-size: 12px; color: #474c54; }}
QLabel#noteFooter {{ font-size: 11px; color: #666c75; }}
QLineEdit#noteTitle {{ background: transparent; border: none; border-radius: 0px;
    font-size: 22px; font-weight: 700; color: #1c1f24; padding: 2px 0px; }}
QLineEdit#noteTitle:focus {{ border: none; }}
QLabel#noteSaved {{ font-size: 11px; color: #666c75; }}
QLabel#noteEmpty {{ font-size: 14px; color: #666c75; }}
QPushButton#fmtBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 6px; font-size: 13px; color: #474c54; padding: 0px; }}
QPushButton#fmtBtn:hover {{ background: #ececee; color: #272b33; }}
QPushButton#fmtBtn:checked {{ background: #e3e9f2; color: #1d4ed8;
    border: 1px solid #c6ccd4; }}
QPushButton#notesSizeBtn {{ padding: 0px; }}
QFrame#fmtSep {{ color: #d9dbde; margin: 4px 2px; }}
QTextEdit#noteEditor {{ font-size: 14px; }}
QToolTip {{ background: #ffffff; color: #272b33; border: 1px solid #d9dbde;
    padding: 5px 8px; border-radius: 8px; }}
QMessageBox {{ background: #ffffff; }}
QMessageBox QLabel {{ color: #272b33; }}
QInputDialog QLabel {{ color: #272b33; }}

/* ---------- custom window chrome ---------- */
QFrame#windowFrame {{ background: #f7f7f8; border: 1px solid #d9dbde; border-radius: 12px; }}
/* v1.4.0 item 12: square corners when maximized (no edge gaps) */
QFrame#windowFrame[squareCorners="true"] {{ border-radius: 0px; border: none; }}
QFrame#titleBar {{ background: transparent; border: none; border-bottom: 1px solid #e3e4e6; }}
QLabel#titleBarLabel {{ color: #474c54; font-size: 12px; font-weight: 600; background: transparent; }}
QPushButton#winBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #474c54; font-size: 12px; padding: 6px 12px; }}
QPushButton#winBtn:hover {{ background: #e3e4e6; color: #1c1f24; }}
QPushButton#winCloseBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #474c54; font-size: 12px; padding: 6px 12px; }}
QPushButton#winCloseBtn:hover {{ background: #e81123; color: #ffffff; }}

/* ---------- rack type tags ---------- */
QPushButton[role="rackTag"] {{ border: none; border-radius: 9px; padding: 4px 6px;
    font-size: 11px; font-weight: 600; background: #d7f3ef; color: #0f766e; }}
QLabel[role="rackTag"] {{ border: none; border-radius: 9px; padding: 4px 6px;
    font-size: 11px; font-weight: 600; background: #d7f3ef; color: #0f766e; }}

/* ---------- notes editor ---------- */
QTextEdit#notesEdit {{ padding: 10px; }}

/* ---------- toolbar ---------- */
QFrame#toolBar {{ background: transparent; border: none; }}
QFrame#bulkBar {{ background: #ffffff; border: 1px solid #d8dce3; border-radius: 10px; }}
QLabel#bulkLabel {{ color: #23252b; font-size: 13px; font-weight: 600; }}
QLabel#sortLabel {{ color: #4e535b; font-size: 12px; }}
QLabel#countLabel {{ color: #4e535b; font-size: 12px; }}

/* ---------- sidebar ---------- */
QFrame#sideBar {{ background: #ececee; border: none; border-right: 1px solid #d9dbde; }}
QPushButton#navBtn {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 12px; font-size: 13px; font-weight: 600; color: #4d4d4d;
    text-align: left; }}
QPushButton#navBtn:hover {{ background: #d9dbde; color: #272b33; }}
QPushButton#navBtn:checked {{ background: transparent; color: #1f1f1f; }}
QFrame#navPill {{ background: #e4e4e4; border-radius: 10px; }}
QLabel#sideFoot {{ color: #4e535b; font-size: 10px; }}
QPushButton#navToggle {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 0px; font-size: 15px; font-weight: 600; color: #474c54;
    text-align: center; }}
QPushButton#navToggle:hover {{ background: #d9dbde; color: #272b33; }}
/* v1.4.0 item 16: Settings sidebar nav - restrained, no blue tint. */
QPushButton#settingsNav {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 14px; font-size: 13px; color: #474c54; text-align: left; }}
QPushButton#settingsNav:hover {{ background: #d9dbde; color: #272b33; }}
QPushButton#settingsNav:checked {{ background: #e4e4e7; color: #23262c; }}

/* ---------- CRM ---------- */
QLabel#kindPill {{ background: #e3e9f2; color: #1d4ed8; border-radius: 9px;
    padding: 4px 12px; font-size: 11px; font-weight: 600; }}
QPushButton#taskLink {{ background: transparent; border: 1px solid #e3e4e6;
    border-radius: 9px; padding: 9px 12px; text-align: left;
    color: #272b33; font-size: 12px; font-weight: 600; }}
QPushButton#taskLink:hover {{ background: #f0f0f1; border-color: #c9d5e8; color: #1d4ed8; }}

/* v1.4.0 item 15: inline SDC badge in the task detail window */
QLabel#sdcBadge {{ border-radius: 8px; padding: 2px 8px; font-size: 11px;
    font-weight: 600; }}
QLabel#sdcBadge[sdcSeverity="low"] {{ background: #f0f0f1; color: #4e535b;
    border: 1px solid #d9dbde; }}
QLabel#sdcBadge[sdcSeverity="watch"] {{ background: #f5efdb; color: #b45309;
    border: 1px solid #f5d67b; }}
QLabel#sdcBadge[sdcSeverity="high"] {{ background: #f3f4f6; color: #b91c1c;
    border: 1px solid #d9dbde; }}
QPushButton#iconBtn {{ background: transparent; border: none; border-radius: 7px;
    padding: 7px; }}
QPushButton#iconBtn:hover {{ background: #e8ebf0; }}

/* ---------- queue board ---------- */
QFrame#queueColumn {{ background: #ececee; border: 1px solid #d9dbde; border-radius: 14px; }}
QFrame#queueColumn[dropActive="true"] {{ border: 1px solid #2563eb; background: #e8edf3; }}
QFrame#dropPlaceholder {{ background: rgba(37, 99, 235, 0.06);
    border: 1.5px dashed #2563eb; border-radius: 14px; }}
QLabel#dropPlaceholderText {{ color: #1d4ed8; font-size: 12px; font-weight: 600; }}
QLabel#colTitle {{ font-size: 13px; font-weight: 700; color: #1c1f24; }}
QLabel#countBadge {{ background: #ffffff; color: #474c54; border-radius: 9px;
    padding: 2px 9px; font-size: 11px; font-weight: 700; }}
QFrame#queueCard {{ background: #ffffff; border: 1px solid #e3e4e6; border-radius: 12px; }}
QFrame#queueCard:hover {{ border-color: #bfc4cb; }}
QLabel#queueQuote {{ font-size: 16px; font-weight: 700; color: #ffffff;
    background: #2563eb; padding: 6px 14px;
    border-top-left-radius: 0px; border-top-right-radius: 0px;
    border-bottom-right-radius: 11px; border-bottom-left-radius: 0px; }}
/* queue-card notes: label-like read-only scroller (see QueueCard._fit_notes) */
QTextEdit#queueDesc {{ background: transparent; border: none; padding: 0px;
    color: #3d4149;
    selection-background-color: #2563eb; selection-color: #ffffff; }}
QLabel#queueMeta {{ font-size: 11px; color: #474c54; }}
QLabel#dropHint {{ color: #4e535b; font-size: 12px; border: 1px dashed #ccd0d6;
    border-radius: 10px; padding: 20px 10px; }}
QLabel#miniPill {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; }}
QLabel#miniPill[statusState="in_process"] {{ background: #e3e9f2; color: #1d4ed8; }}
QLabel#miniPill[statusState="on_hold"] {{ background: #f5efdb; color: #b45309; }}
QLabel#miniPill[statusState="completed"] {{ background: #e4f0e6; color: #15803d; }}
QLabel#miniPill[statusState="canceled"] {{ background: #e8ebf0; color: #5f666b; }}
/* v1.4.0 item 10: amber "Waiting: …" chip on queue cards */
QLabel#waitingChip {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; background: #f5efdb; color: #b45309; }}
QCheckBox#queueCheck {{ color: #3a3d44; font-size: 13px; spacing: 10px; }}

/* ---------- settings: folder creation guidance (warn/missing states) ---------- */
QLabel#folderHint[warn="true"] {{ color: #b91c1c; font-weight: 600; }}
QLineEdit[missing="true"] {{ border: 1px solid #c0392b; }}
QLabel#verifyItem[ok="true"] {{ color: #15803d; }}
QLabel#verifyItem[ok="false"] {{ color: #b91c1c; font-weight: 600; }}
"""

THEMES = {"light": LIGHT, "dark": DARK}


def saved_theme():
    return QSettings("TaskListApp", "TaskList").value("theme", "dark")


def save_theme(name):
    QSettings("TaskListApp", "TaskList").setValue("theme", name)


# ------------------------------------------------------------- glass dropdowns
# V1.9.17 (user correction): optional frosted-glass DROPDOWNS — he
# asked for dropdowns glassmorphic, never "glass popups", and menus
# stay solid. OFF by default, and the old "glass_popups" key's value
# does not carry over: glass dropdowns are opt-in under the new key.
# Qt cannot blur what sits behind a popup on its own, so this is
# frosted translucency, not true backdrop blur — stated honestly.
def saved_glass():
    v = QSettings("TaskListApp", "TaskList").value("glass_dropdowns", False)
    return str(v).lower() in ("true", "1", "yes") if isinstance(v, str) \
        else bool(v)


def save_glass(on):
    QSettings("TaskListApp", "TaskList").setValue("glass_dropdowns", bool(on))


def _glass_qss(name):
    if name == "light":
        bg = "rgba(255, 255, 255, 0.95)"
        rim = "rgba(0, 0, 0, 0.10)"
    else:
        bg = "rgba(26, 28, 33, 0.95)"
        rim = "rgba(255, 255, 255, 0.14)"
    # V1.9.17: dropdowns ONLY. Menus stay solid — the V1.9.16 version
    # glassed menus too, which the user never asked for.
    # V1.9.18: glass also covers the TagPopup scope list (QFrame
    # #scopePopup) with a 1px light rim, and combo views get the rim
    # too — the rim is what reads as "glass" against the page behind
    # it. This sheet is appended AFTER the base theme and only when
    # the Glass dropdowns toggle is ON (saved_glass()).
    return f"""
QComboBox QAbstractItemView {{ background: {bg}; border: 1px solid {rim}; }}
QComboBox#sortBox QAbstractItemView {{ background: {bg}; border: 1px solid {rim}; }}
QFrame#scopePopup {{ background: {bg}; border: 1px solid {rim}; }}
"""


# ------------------------------------------------------------- accent color
# V1.9.10: user-chosen accent. The themes are authored in one blue family;
# instead of duplicating every rule per accent, the finished QSS is
# hue-shifted: any blue-family colour (hue 195-245°, saturation >= 0.15)
# keeps its lightness/saturation and takes the accent's hue. Semantic
# colours (green completed, red danger, purple/teal scope chips) sit
# outside that hue band and never move. The default accent IS the native
# blue, so the untouched app looks exactly as before.
DEFAULT_ACCENT = "#2f6fed"
_ACCENT_HEX_RE = re.compile(r"#([0-9a-fA-F]{6})\b")
_ACCENT_RGBA_RE = re.compile(
    r"rgba\(\s*(\d+),\s*(\d+),\s*(\d+),\s*([0-9.]+)\s*\)")


def saved_accent():
    v = str(QSettings("TaskListApp", "TaskList").value(
        "accent_color", "") or "")
    return v.lower() if re.fullmatch(r"#[0-9a-fA-F]{6}", v) else DEFAULT_ACCENT


def save_accent(hex_color):
    if re.fullmatch(r"#[0-9a-fA-F]{6}", str(hex_color or "")):
        QSettings("TaskListApp", "TaskList").setValue(
            "accent_color", str(hex_color).lower())


def _shifted_rgb(r, g, b, target_h, desaturate):
    import colorsys
    h, l, s = colorsys.rgb_to_hls(r / 255.0, g / 255.0, b / 255.0)
    if 195.0 <= h * 360.0 <= 245.0 and s >= 0.15:
        if desaturate:
            s *= 0.15
        r2, g2, b2 = colorsys.hls_to_rgb(target_h, l, s)
        return round(r2 * 255), round(g2 * 255), round(b2 * 255)
    return r, g, b


def apply_accent_shift(qss, accent_hex=None):
    """Hue-shift the blue family in ``qss`` to the saved accent colour."""
    accent = QColor(accent_hex or saved_accent())
    if not accent.isValid():
        return qss
    if accent.name().lower() == DEFAULT_ACCENT:
        return qss
    target_h = accent.hueF()
    if target_h < 0:  # achromatic accent (gray) — desaturate the blues
        target_h = 218.0 / 360.0
        desaturate = True
    else:
        desaturate = accent.hslSaturationF() < 0.12

    def _hex_repl(m):
        v = int(m.group(1), 16)
        r, g, b = (v >> 16) & 255, (v >> 8) & 255, v & 255
        r, g, b = _shifted_rgb(r, g, b, target_h, desaturate)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _rgba_repl(m):
        r, g, b = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        r, g, b = _shifted_rgb(r, g, b, target_h, desaturate)
        return f"rgba({r}, {g}, {b}, {m.group(4)})"

    return _ACCENT_RGBA_RE.sub(_rgba_repl,
                               _ACCENT_HEX_RE.sub(_hex_repl, qss))


def shifted_color(hex_color, accent_hex=None):
    """One painted (non-QSS) colour, hue-shifted like the stylesheet."""
    c = QColor(hex_color)
    if not c.isValid():
        return hex_color
    accent = QColor(accent_hex or saved_accent())
    if not accent.isValid() or accent.name().lower() == DEFAULT_ACCENT:
        return hex_color
    out = apply_accent_shift(f"x:{hex_color};", accent.name())
    return out.split(":", 1)[1].rstrip(";")


def saved_font_family():
    """Font family override; "" means the bundled Inter (default)."""
    return QSettings("TaskListApp", "TaskList").value("font_family", "")


def save_font_family(family):
    QSettings("TaskListApp", "TaskList").setValue("font_family", family or "")


def saved_font_scale():
    """UI text scale factor; 1.0 = default size."""
    try:
        scale = float(QSettings("TaskListApp", "TaskList").value(
            "font_scale", 1.0))
    except (TypeError, ValueError):
        return 1.0
    return min(2.0, max(0.7, scale))


def save_font_scale(scale):
    try:
        scale = float(scale)
    except (TypeError, ValueError):
        scale = 1.0
    QSettings("TaskListApp", "TaskList").setValue(
        "font_scale", min(2.0, max(0.7, scale)))


# Every font-size in the QSS is absolute px. Scaling them here (after the
# template is formatted) makes the Settings > Font size choice apply to
# the whole UI, not just widgets that inherit the application font.
_FONT_SIZE_RE = re.compile(r"font-size:\s*([0-9]+(?:\.[0-9]+)?)px")


def _scale_font_sizes(qss, scale):
    if abs(scale - 1.0) < 0.001:
        return qss

    def _rep(m):
        return f"font-size: {float(m.group(1)) * scale:.1f}px"

    return _FONT_SIZE_RE.sub(_rep, qss)


# Placeholder text can't be styled through QSS, so it is set on the
# application palette here (per theme) to keep it legible.
_PLACEHOLDER_COLORS = {"dark": "#6b7078", "light": "#5f636b"}


def apply_theme(app, name):
    qss = _scale_font_sizes(THEMES.get(name, DARK), saved_font_scale())
    qss = apply_accent_shift(qss)
    # V1.9.25: glass is the BASE look for dropdowns now (user standing
    # order — the toggle is retired). The _glass_qss sheet is no longer
    # appended; its tint/rim live in the base combo rules above and in
    # TagPopup.paintEvent. saved_glass/save_glass/_glass_qss remain for
    # settings compatibility and tests.
    app.setStyleSheet(qss)
    pal = app.palette()
    pal.setColor(QPalette.PlaceholderText,
                 QColor(_PLACEHOLDER_COLORS.get(name, _PLACEHOLDER_COLORS["dark"])))
    app.setPalette(pal)
    # V1.9.17 (light-mode text artifacts): the grayscale-AA strategy
    # lives on the application font, but any widget that got an explicit
    # font (or a font resolved through a stylesheet) can lose the flag.
    # Sweep every live widget after the stylesheet lands so no text path
    # renders with ClearType fringes; later widgets inherit the app font.
    try:
        from PySide6.QtGui import QFont
        from PySide6.QtWidgets import QApplication
        for w in QApplication.allWidgets():
            try:
                f = w.font()
            except Exception:
                continue
            if f.styleStrategy() != QFont.StyleStrategy.NoSubpixelAntialias:
                f.setStyleStrategy(QFont.StyleStrategy.NoSubpixelAntialias)
                try:
                    w.setFont(f)
                except Exception:
                    pass
    except Exception:
        pass


class _MenuGlassFilter(QObject):
    """Keeps a menu's WINDOW clipped to its rounded shape.

    V1.9.30 (user screenshots, Outcome pill menu): translucency alone
    (the V1.9.16 fix) did not stop square corners on his machine --
    the selected item's square background still poked past the
    rounded corner. The guarantee that cannot be painted around is a
    window MASK in the menu's QSS radius (8px): with the window
    region clipped round, nothing -- background, selection, or
    compositor -- can put a square corner on screen. Re-applied on
    every Show/Resize; on Show it also asks for the DWM blur-behind
    so the menu's translucent QSS tint reads as frosted glass.
    """

    def eventFilter(self, watched, event):  # noqa: N802 (Qt virtual)
        if event.type() in (QEvent.Show, QEvent.Resize):
            try:
                path = QPainterPath()
                path.addRoundedRect(QRectF(watched.rect()), 8, 8)
                watched.setMask(
                    QRegion(path.toFillPolygon().toPolygon()))
            except Exception:
                pass
            if event.type() == QEvent.Show:
                try:
                    from tasklist.ui import enable_blur_behind
                    enable_blur_behind(watched)
                except Exception:
                    pass
        return False


def apply_menu_glass(menu):
    """The full glass treatment for a QMenu: translucent window,
    rounded window mask (via _MenuGlassFilter), blur-behind on show.
    Every QMenu in the app goes through here (themed_menu, or the
    menubar walk in app.py for QMenuBar's internally-created menus).
    """
    menu.setAttribute(Qt.WA_TranslucentBackground, True)
    if not menu.property("_glass_filter"):
        menu.installEventFilter(_MenuGlassFilter(menu))
        menu.setProperty("_glass_filter", True)
    return menu


def themed_menu(parent=None):
    """A QMenu that is GLASS with fully rounded corners.

    V1.9.16 (user report, both themes): menus paint rounded corners in
    QSS, but the menu window itself is opaque, so the square window
    corners show as sharp black triangles behind the rounded menu — and
    a square selected-item background pokes past the rounded edge.
    V1.9.30: translucency was not enough on the user's machine; the
    menu now also carries the rounded window MASK and the DWM
    blur-behind (see _MenuGlassFilter), and its QSS background is a
    translucent glass tint, not a solid slab.
    """
    return apply_menu_glass(QMenu(parent))
