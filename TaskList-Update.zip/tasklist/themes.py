"""Light (white/blue) and neutral dark (black/gray) themes as Qt stylesheets."""
import re
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QRectF, QSettings, Qt, QTimer
from PySide6.QtGui import (QColor, QPainter, QPainterPath, QPalette,
                           QPen, QRegion)
from PySide6.QtWidgets import QMenu

FONT_STACK = '"Inter", "Segoe UI", "Helvetica Neue", Arial, sans-serif'

_ASSETS_DIR = Path(__file__).resolve().parent / "assets"


def _asset_file_url(name):
    """Filesystem path for a bundled asset, for QSS image: url().

    Plain absolute path (forward slashes): Qt stylesheets resolve
    url("...") against the filesystem, and a file:// scheme does NOT
    render (verified). Quoted in the QSS, so spaces in the install
    path are fine.
    """
    return (_ASSETS_DIR / name).as_posix()


# Themed drop-down chevrons: light glyph on the dark theme, dark glyph on
# the light theme (up/down variants for spin buttons).
_CHEV_DOWN_DARK = _asset_file_url("chev_down_light.png")
_CHEV_UP_DARK = _asset_file_url("chev_up_light.png")
_CHEV_DOWN_LIGHT = _asset_file_url("chev_down_dark.png")
_CHEV_UP_LIGHT = _asset_file_url("chev_up_dark.png")

# Check glyph drawn inside a checked QCheckBox::indicator (white check on the
# accent fill; same asset works for both themes).
_CHECK_MARK = _asset_file_url("check_mark.svg")

DARK = f"""
* {{ font-family: {FONT_STACK}; }}
QWidget#app {{ background: #0b0c0e; }}
QLabel#title {{ font-size: 22px; font-weight: 700; color: #f4f5f7; }}
QLabel#subtitle {{ color: #9ba1ab; font-size: 12px; }}
QLabel#emptyState {{ color: #6b7078; font-size: 14px; }}

/* ---------- cards ---------- */
QFrame#card {{ background: #141518; border: 1px solid #23252b; border-radius: 14px; }}
/* V1.9.78 (WS-E3): the hover outline is NO LONGER a QSS border
   change -- the QSS border keeps the REST colour on hover and
   the whole continuous hover outline (including the stretch
   behind the corner quote tab, which the tab widget occluded
   from both the QSS border and the old painted inner stroke)
   is painted by _CardHoverOverlay in ui.py, one mechanism, one
   colour, zero geometry shift. This rule stays so the corner
   pill's border-colour parser still resolves a hover state. */
QFrame#card:hover {{ border: 1px solid #23252b; }}
/* V1.9.5: hot tasks — red border beats hover. */
QFrame#card[hot="true"] {{ border: 1px solid #e5484d; }}
QFrame#card[hot="true"]:hover {{ border: 1px solid #e5484d; }}
QLabel#quoteNum {{ font-size: 15px; font-weight: 700; color: #f4f5f7;
    background: transparent; border: none; padding: 0px 2px; }}
/* V1.9.78 (WS-E2, user image-557): card body text is FULL
   WHITE in the dark theme -- distributor/end-user values AND
   their labels AND the notes all peaked at #c6cbd3 (measured
   198,203,211) next to the rack type's pure white and read
   gray. #meta/#metaPrefix/#notes are the card construction
   (grid + queue share TaskCard), so this is the one place. */
QLabel#meta {{ color: #ffffff; font-size: 13px; }}
QLabel#metaPrefix {{ color: #ffffff; font-size: 13px; }}
QLabel#notes {{ color: #ffffff; font-size: 13px; }}
QLabel#dateLabel {{ color: #6b7078; font-size: 11px; }}
QLabel#progressLabel {{ color: #9ba1ab; font-size: 11px; font-weight: 600; }}
QLabel#hint {{ color: #6b7078; font-size: 11px; }}
QRadioButton {{ color: #c6cbd3; }}

/* ---------- status pill (clickable) ---------- */
/* V1.9.75 (workstream C, user 2026-11-15): the status and
   outcome pills carry the rectangle OUTLINE too -- a 1px border
   in the state's own text colour. Padding drops by the border
   width so the pill's box (and the card header row) is
   byte-identical to the borderless construction.
   V1.9.76 fix round (FIX-7, user photo 2026-11-16 11:37):
   the state rules still carried a colour FILL on the closed
   face (blue #1a2c4e for In Process, gray for Unknown) --
   the chip standard is OUTLINE ONLY, no fill, identical on
   the cards, in the detail window and everywhere else, and
   selected/active is never a fill. Every pill background
   (rest and hover, both sheets) is now transparent: the
   surface shows through, the border and the text keep the
   state's colour exactly as before. */
QPushButton#statusPill {{ border: 1px solid transparent; border-radius: 6px; padding: 3px 11px;
    font-size: 11px; font-weight: 700; }}
QPushButton#statusPill[statusState="in_process"] {{ background: transparent; color: #7fb0ff; border-color: #7fb0ff; }}
QPushButton#statusPill[statusState="in_process"]:hover {{ background: transparent; }}
QPushButton#statusPill[statusState="on_hold"] {{ background: transparent; color: #eec25e; border-color: #eec25e; }}
QPushButton#statusPill[statusState="on_hold"]:hover {{ background: transparent; }}
QPushButton#statusPill[statusState="completed"] {{ background: transparent; color: #6fdc9e; border-color: #6fdc9e; }}
QPushButton#statusPill[statusState="completed"]:hover {{ background: transparent; }}
QPushButton#statusPill[statusState="canceled"] {{ background: transparent; color: #9ba1ab; border-color: #9ba1ab; }}
QPushButton#statusPill[statusState="canceled"]:hover {{ background: transparent; }}

/* ---------- outcome pill (clickable, V1.9.29) ---------- */
QPushButton#outcomePill {{ border: 1px solid transparent; border-radius: 6px; padding: 3px 11px;
    font-size: 11px; font-weight: 700; }}
QPushButton#outcomePill[outcomeState="won"] {{ background: transparent; color: #6fdc9e; border-color: #6fdc9e; }}
QPushButton#outcomePill[outcomeState="won"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="lost"] {{ background: transparent; color: #ff9d97; border-color: #ff9d97; }}
QPushButton#outcomePill[outcomeState="lost"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="dead"] {{ background: transparent; color: #d99a86; border-color: #d99a86; }}
QPushButton#outcomePill[outcomeState="dead"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="on_hold"] {{ background: transparent; color: #eec25e; border-color: #eec25e; }}
QPushButton#outcomePill[outcomeState="on_hold"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="unknown"] {{ background: transparent; color: #9ba1ab; border-color: #9ba1ab; }}
QPushButton#outcomePill[outcomeState="unknown"]:hover {{ background: transparent; }}

/* ---------- scope chips (checkable) ---------- */
/* V1.9.75 (workstream C, user 2026-11-15 -- the GLOBAL CHIP
   STANDARD): scope chips are an OUTLINE rectangle that is NOT
   colour-filled, with the existing coloured text; the border
   carries the chip's own text colour. Identical construction
   on cards, the detail window and New Task (one rule set).
   Padding drops by the border width so the chip's box is
   byte-identical to the filled construction it replaces. */
QPushButton[role="scopeChip"] {{ border: 1px solid transparent; border-radius: 6px; padding: 3px 5px;
    font-size: 11px; font-weight: 600; }}
QPushButton[role="scopeChip"][scopeKey="quote"] {{ background: transparent; color: #8fb4ff; border-color: #8fb4ff; }}
QPushButton[role="scopeChip"][scopeKey="re-quote"] {{ background: transparent; color: #c4a8f7; border-color: #c4a8f7; }}
QPushButton[role="scopeChip"][scopeKey="cad"] {{ background: transparent; color: #6fd7bd; border-color: #6fd7bd; }}
QPushButton[role="scopeChip"][scopeKey="configura"] {{ background: transparent; color: #f2b25c; border-color: #f2b25c; }}
QPushButton[role="scopeChip"][scopeKey="prelims"] {{ background: transparent; color: #e3c964; border-color: #e3c964; }}
QPushButton[role="scopeChip"][scopeKey="misc"] {{ background: transparent; color: #a7aeb9; border-color: #a7aeb9; }}
QPushButton[role="scopeChip"][scopeKey="custom-0"] {{ background: transparent; color: #c9aef2; border-color: #c9aef2; }}
QPushButton[role="scopeChip"][scopeKey="custom-1"] {{ background: transparent; color: #7fc4e8; border-color: #7fc4e8; }}
QPushButton[role="scopeChip"][scopeKey="custom-2"] {{ background: transparent; color: #e8a06f; border-color: #e8a06f; }}
QPushButton[role="scopeChip"][scopeKey="custom-3"] {{ background: transparent; color: #93d8a4; border-color: #93d8a4; }}
QPushButton[role="scopeChip"]:checked {{ background: transparent; color: #8fdcae; border-color: #8fdcae; }}

/* ---------- buttons ---------- */
QPushButton {{ background: #1a1c21; border: 1px solid #2c2f37; border-radius: 8px;
    padding: 7px 14px; font-size: 13px; color: #e6e9ee; }}
QPushButton:hover {{ background: #22252c; border-color: #3a3e48; }}
QPushButton:disabled {{ color: #5b6068; background: #141518; border-color: #23252b; }}
QPushButton#primary {{ background: #2f6fed; border: none; color: #ffffff;
    font-weight: 600; padding: 8px 18px; }}
QPushButton#primary:hover {{ background: #4a86f5; }}
/* Name links in the task detail header (V1.9.36, user): plain
   clickable TEXT, no button box -- white text, underline on hover
   (the standard link affordance). */
QPushButton#contactLink {{ background: transparent; border: none;
    color: #e6e9ee; padding: 3px 6px; font-size: 19px; font-weight: 600; }}
QPushButton#contactLink:hover {{ background: transparent;
    text-decoration: underline; }}
QPushButton#contactLink:focus {{ text-decoration: underline; }}
QPushButton#contactLink:disabled {{ color: #6b7078;
    text-decoration: none; }}
QPushButton#ghost {{ background: transparent; border: 1px solid #2c2f37;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger {{ background: transparent; border: 1px solid #4a2b2e; color: #ef9a9a;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger:hover {{ background: #2a1a1c; border-color: #6b3a3e; }}
QPushButton#ghost:hover {{ background: #23252b; border-color: #2c2f37; }}
/* V1.9.51 (user: "these buttons still also have the outline
   of a rectangle around them full time? I asked for that to
   only appear when moused over?"): base border is transparent;
   hover only changes the border COLOR (AGENTS: never swap
   border width per state -- geometry must not move). */
QPushButton#cardHotBtn, QPushButton#cardFolderBtn, QPushButton#cardEditBtn,
QPushButton#cardDeleteBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 8px; padding: 5px 9px; font-size: 12px; color: #c6cbd3; }}
QPushButton#cardHotBtn:hover {{ background: transparent; border-color: #ff8589; color: #ff8589; }}
QPushButton#cardFolderBtn:hover {{ background: transparent; border-color: #f0b95a; color: #f0b95a; }}
QPushButton#cardEditBtn:hover {{ background: transparent; border-color: #8fb4ff; color: #8fb4ff; }}
QPushButton#cardDeleteBtn {{ color: #ef9a9a; }}
QPushButton#cardDeleteBtn:hover {{ background: transparent; border-color: #ff8589; color: #ff8589; }}
QPushButton#scopeButton {{ text-align: left; padding: 9px 12px; }}
QFrame#scopeButton {{ background: #0f1013; border: 1px solid #2a2d34; border-radius: 8px; }}
QFrame#scopeButton:hover {{ border: 1px solid #4f8cff; }}
QLabel#scopeText {{ color: #f4f5f7; font-size: 13px; background: transparent; }}
QLabel#scopeText[empty="true"] {{ color: #6b7078; }}
QLabel#scopeArrow {{ color: #9ba1ab; font-size: 11px; background: transparent; }}
QPushButton#titleLink {{ background: transparent; border: none; text-align: left;
    padding: 0px; font-size: 18px; font-weight: 700; color: #f4f5f7; }}
QPushButton#titleLink:hover {{ color: #f4f5f7; text-decoration: underline; }}
QPushButton#titleLink:disabled {{ color: #f4f5f7; }}
QLabel#imageStage {{ background: #000000; border-radius: 8px; }}
QPushButton#seg {{ border: 1px solid transparent; border-radius: 8px; padding: 7px 13px;
    font-size: 13px; font-weight: 600; color: #9ba1ab; background: transparent; }}
QPushButton#seg:hover {{ color: #d5d9e0; }}
QPushButton#seg:checked {{ background: #23252b; color: #ffffff; }}
QPushButton#seg[attention="true"] {{ background: #2a1a1c; color: #ef9a9a;
    border-color: #4a2b2e; }}
QPushButton#seg[attention="true"]:hover {{ background: #382224; color: #ffb4b4;
    border-color: #6b3a3e; }}
QPushButton#seg[attention="true"]:checked {{ background: #3a2224; color: #ffc9c9;
    border-color: #6b3a3e; }}
QPushButton#chipToggle {{ border: 1px solid #2c2f37; border-radius: 6px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #9ba1ab; background: #141518; }}
QPushButton#chipToggle:hover {{ color: #d5d9e0; border-color: #3a3d45; }}
QPushButton#chipToggle:checked {{ background: #1a2c4e; border-color: #2f6fed; color: #8fb4ff; }}
QLabel#chipToggle {{ border: 1px solid #2c2f37; border-radius: 6px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #9ba1ab; background: #141518; }}
QLabel#chipToggle:hover {{ color: #d5d9e0; border-color: #3a3d45; }}
QLabel#chipToggle[checked="true"] {{ background: #1a2c4e; border-color: #2f6fed; color: #8fb4ff; }}
QPushButton#dueChip {{ border: 1px solid #2c2f37; border-radius: 6px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #9ba1ab; background: #141518; }}
QPushButton#dueChip:hover {{ color: #d5d9e0; border-color: #3a3e48; }}
QPushButton#dueChip:checked {{ background: #1a2c4e; border-color: #2c4a7c; color: #8fb4ff; }}
/* card badges */
QLabel#dueChip, QLabel#estChip, QLabel#followChip, QLabel#priceChip {{ font-size: 11px; font-weight: 600;
    padding: 3px 9px; border-radius: 6px; }}
QLabel#dueChip {{ background: #1a2c4e; color: #8fb4ff; }}
QLabel#dueChip[urgent="true"] {{ background: #2a1a1c; color: #ef9a9a; }}
QLabel#estChip {{ background: #1a1c21; color: #9ba1ab; }}
/* V1.9.71 (S): the card IBC chip carries the SAME declarations as
   the detail chip's flagged state -- the two chips are identical. */
/* V1.9.76 (scope addition 13, user 2026-11-16 08:59, refined
   09:01, corrected 09:02): SDC and IBC are TEXT ONLY -- no
   border, no infill, on cards, detail and New Task. IBC text
   is white unflagged, yellow only when flagged (the face sets
   its own colours via _ibc_colors; this rule is the fallback). */
/* V1.9.78 (WS-D): the flagged colour is TRUE YELLOW #ffd94d --
   the old #eec25e was the SAME amber as the SDC-watch badge, so
   a flagged IBC and an SDC-B read identically on the card. */
QWidget#ibcFlagChip {{ background: transparent; color: #ffd94d; border: none; border-radius: 6px; font-size: 11px; font-weight: 700; }}
QLabel#ibcChipText, QLabel#ibcChipIcon {{ background: transparent; border: none; padding: 0; margin: 0; }}
QLabel#priceChip {{ background: #1a1c21; color: #d7dae0; font-weight: 700; }}
QLabel#followChip {{ background: #2a2214; color: #e8b45a; }}
QLabel#logisticsChip {{ background: #1a1c21; color: #c6cbd3; font-size: 11px;
    font-weight: 600; padding: 3px 9px; border-radius: 9px; }}
/* quiet tri-state outcome */
QPushButton#outcomeSeg {{ border: 1px solid #23252b; border-radius: 6px;
    padding: 4px 10px; font-size: 11px; font-weight: 600; color: #5a5f68;
    background: transparent; }}
QPushButton#outcomeSeg:hover {{ color: #9ba1ab; border-color: #33363e; }}
QPushButton#outcomeSeg:checked[outcome_state="unknown"] {{ background: #1a1c21;
    border-color: #2c2f37; color: #9ba1ab; }}
QPushButton#outcomeSeg:checked[outcome_state="won"] {{ background: #12261a;
    border-color: #1e4d33; color: #7fd6a4; }}
QPushButton#outcomeSeg:checked[outcome_state="lost"] {{ background: #2a1a1c;
    border-color: #6b3a3e; color: #ef9a9a; }}
/* re-quote link + version history */
QPushButton#requoteLink {{ background: transparent; border: none; text-align: left;
    padding: 2px 0px; font-size: 12px; color: #6b7078; }}
QPushButton#requoteLink:hover {{ color: #8fb4ff; text-decoration: underline; }}
QPushButton#versionRow {{ background: transparent; border: 1px solid #23252b;
    border-radius: 8px; text-align: left; padding: 7px 12px; font-size: 12px;
    color: #c6cbd3; }}
QPushButton#versionRow:hover {{ border-color: #4f8cff; color: #ffffff; }}
QPushButton#versionRow:disabled {{ background: #1a2c4e; border-color: #2c4a7c;
    color: #8fb4ff; font-weight: 600; }}
/* distributor scope preset suggestion */
QPushButton#scopeSuggest {{ background: #141518; border: 1px dashed #3a3e48;
    border-radius: 8px; padding: 7px 12px; font-size: 12px; color: #9ba1ab;
    text-align: left; }}
QPushButton#scopeSuggest:hover {{ border-color: #4f8cff; color: #d5d9e0; }}
/* follow-ups widget rows */
QFrame#followRow {{ background: #141518; border: 1px solid #23252b;
    border-radius: 10px; }}
QFrame#segBar {{ background: #141518; border: 1px solid #23252b; border-radius: 11px; }}
QPushButton[role="scopeRow"] {{ background: transparent; border: 1px solid transparent; border-radius: 7px;
    text-align: left; padding: 8px 12px; font-size: 13px; color: #d5d9e0; }}
QPushButton[role="scopeRow"]:hover {{ background: transparent; border-color: #3f444e; }}
QPushButton[role="scopeRow"]:checked {{ background: transparent; border-color: #6b7280; color: #f4f5f7; font-weight: 600; }}
QFrame#scopePopup {{ background: transparent; border: none; border-radius: 10px; }}

/* ---------- inputs ---------- */
QLineEdit, QTextEdit, QComboBox {{ background: #0f1013; border: 1px solid #2a2d34;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #f4f5f7;
    selection-background-color: #2f6fed; }}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid #4f8cff; }}
QLineEdit:disabled, QTextEdit:disabled {{ color: #9ba1ab; background: #121316; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{ image: url("{_CHEV_DOWN_DARK}"); width: 10px; height: 10px; }}
QComboBox QAbstractItemView {{ background: rgba(24, 26, 32, 0.85); border: 1px solid rgba(255, 255, 255, 0.19);
    border-radius: 10px; padding: 4px;
    selection-background-color: #2f6fed; color: #e6e9ee; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #e6e9ee; }}
QComboBox QAbstractItemView::item:hover {{ background: transparent; border-color: #3f444e; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #6b7280; color: #ffffff; border-radius: 7px; }}
/* date / time edits: same themed field + chevron dropdown as every combo */
QDateEdit, QTimeEdit, QDateTimeEdit {{ background: #0f1013; border: 1px solid #2a2d34;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #f4f5f7;
    selection-background-color: #2f6fed; }}
QDateEdit:focus, QTimeEdit:focus, QDateTimeEdit:focus {{ border: 1px solid #4f8cff; }}
QDateEdit:disabled, QTimeEdit:disabled, QDateTimeEdit:disabled {{ color: #9ba1ab;
    background: #121316; }}
QDateEdit::drop-down, QTimeEdit::drop-down, QDateTimeEdit::drop-down {{
    border: none; width: 24px; }}
QDateEdit::down-arrow, QTimeEdit::down-arrow, QDateTimeEdit::down-arrow {{
    image: url("{_CHEV_DOWN_DARK}"); width: 10px; height: 10px; }}
/* calendar popup: full dark theme wherever it appears */
QCalendarWidget QWidget {{ alternate-background-color: #1a1c21; }}
QCalendarWidget QAbstractItemView:enabled {{ background-color: #101114; color: #e6e9ee;
    selection-background-color: #2f6fed; selection-color: #ffffff; outline: none; }}
QCalendarWidget QAbstractItemView:disabled {{ color: #4a4f59; }}
QCalendarWidget QToolButton {{ color: #e6e9ee; background: transparent; border: none;
    border-radius: 6px; font-size: 13px; font-weight: 600; padding: 4px; }}
QCalendarWidget QToolButton:hover {{ background: #23252b; }}
QCalendarWidget QToolButton::menu-indicator {{ image: none; }}
QCalendarWidget QSpinBox, QCalendarWidget QAbstractSpinBox {{ background: #0f1013;
    border: 1px solid #2a2d34; border-radius: 6px; color: #e6e9ee;
    padding: 2px 4px; font-size: 12px; }}
QCalendarWidget QAbstractSpinBox::up-button,
QCalendarWidget QAbstractSpinBox::down-button {{ border: none; background: transparent;
    width: 14px; }}
QCalendarWidget QAbstractSpinBox::up-arrow {{ image: url("{_CHEV_UP_DARK}");
    width: 8px; height: 8px; }}
QCalendarWidget QAbstractSpinBox::down-arrow {{ image: url("{_CHEV_DOWN_DARK}");
    width: 8px; height: 8px; }}
#qt_calendar_navigationbar {{ background-color: #101114; }}
#qt_calendar_prevmonth, #qt_calendar_nextmonth {{ min-width: 30px; }}
#qt_calendar_prevmonth {{ qproperty-icon: none; qproperty-text: "\u2039"; }}
#qt_calendar_nextmonth {{ qproperty-icon: none; qproperty-text: "\u203a"; }}
/* themed - / + stepper (replaces native QSpinBox arrows) */
QPushButton#stepperBtn {{ background: #1a1c21; border: 1px solid #2c2f37;
    border-radius: 8px; font-size: 15px; font-weight: 700; color: #9ba1ab;
    padding: 0px; }}
QPushButton#stepperBtn:hover {{ background: #23252b; color: #ffffff;
    border-color: #3a3e48; }}
QPushButton#stepperBtn:disabled {{ color: #4a4f59; background: #141518;
    border-color: #23252b; }}
QLabel#stepperValue {{ background: #0f1013; border: 1px solid #2a2d34;
    border-radius: 8px; padding: 5px 8px; font-size: 13px; font-weight: 600;
    color: #f4f5f7; }}
/* sort dropdown: polished popup to match the theme */
QComboBox#sortBox {{ background: #15171c; }}
QComboBox#sortBox:hover {{ border: 1px solid #3a3e47; }}
QComboBox#sortBox QAbstractItemView {{ background: rgba(24, 26, 32, 0.85); border: 1px solid rgba(255, 255, 255, 0.19);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox#sortBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #e6e9ee; }}
QComboBox#sortBox QAbstractItemView::item:hover {{ background: transparent; border-color: #3f444e; }}
QComboBox#sortBox QAbstractItemView::item:selected {{ background: transparent; border-color: #6b7280; color: #ffffff; border-radius: 7px; }}
/* V1.9.18 (user report: square corners on every NON-sort dropdown):
   only #sortBox views were styled; every other combo fell back to the
   unstyled view. The generic rule gives all combo popups the same
   rounded frame; #sortBox's more specific rule still wins for it. */
QComboBox QAbstractItemView {{ background: rgba(24, 26, 32, 0.85); border: 1px solid rgba(255, 255, 255, 0.19);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border-radius: 7px;
    color: #e6e9ee; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #6b7280; color: #ffffff; }}
/* V1.9.3: the Notes font-size box is only 58px wide — the generic combo
   padding (8px 11px) would leave the text field ~12px and clip "14" to "4".
   Tight padding keeps two digits fully visible. */
QComboBox#notesSizeBox {{ padding: 5px 4px; }}

/* ---------- checkboxes: uniform indicator in both themes ---------- */
QCheckBox {{ color: #d5d9e0; font-size: 13px; spacing: 10px; }}
QCheckBox:disabled {{ color: #5b6068; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 5px;
    border: 1px solid #6b7078; background: #141518; }}
QCheckBox::indicator:hover {{ border-color: #8fb4ff; }}
QCheckBox::indicator:pressed {{ background: #23252b; }}
QCheckBox::indicator:checked {{ background: #2f6fed; border-color: #2f6fed;
    image: url("{_CHECK_MARK}"); }}
QCheckBox::indicator:checked:hover {{ background: #4a86f5; border-color: #4a86f5; }}
QCheckBox::indicator:checked:pressed {{ background: #245fd1; border-color: #245fd1; }}
QCheckBox::indicator:indeterminate {{ background: #2f6fed; border-color: #2f6fed; }}
QCheckBox::indicator:disabled {{ border-color: #2a2d34; background: #101114; }}
QCheckBox::indicator:checked:disabled {{ background: #31405c; border-color: #31405c;
    image: none; }}

/* ---------- quote-folder setup guard (new task dialog) ---------- */
QCheckBox#primaryCheck {{ color: #eaf1ff; font-size: 14px; font-weight: 700;
    spacing: 10px; }}
QLabel#folderSetupWarning {{ background: #2e2310; border: 1px solid #6b531f;
    border-radius: 8px; color: #f2c14e; font-size: 12px; padding: 8px 10px; }}
QPushButton#folderSetupButton {{ background: #1a2c4e; border: 1px solid #2f6fed;
    border-radius: 8px; color: #8fb4ff; font-size: 13px; font-weight: 600;
    padding: 8px 14px; }}
QPushButton#folderSetupButton:hover {{ background: #22365e; color: #b3ccff; }}

/* ---------- contact autocomplete popup ---------- */
/* V1.9.54: the completer popup is the app's glass view now
   (ui.py _GlassCompleterView) and paints itself; this block is
   only a fallback skin -- transparent, selection as outline. */
QListView#completerPopup {{ background: transparent; border: none;
    padding: 4px; outline: none; }}
QListView#completerPopup::item {{ padding: 9px 12px; border-radius: 7px;
    color: #e6e9ee; }}
QListView#completerPopup::item:selected, QListView#completerPopup::item:hover {{
    background: transparent; color: #ffffff; }}

/* ---------- menus ---------- */
QMenuBar {{ background: transparent; color: #c6cbd3; border-bottom: 1px solid #1d1f24; }}
QMenuBar::item {{ padding: 6px 12px; background: transparent; border: 1px solid transparent; border-radius: 6px; }}
QMenuBar::item:selected {{ background: transparent; border-color: #3f444e; border-radius: 6px; }}
QMenu {{ background: rgba(24, 26, 32, 0.72); border: 1px solid #33363e; border-radius: 8px; padding: 5px; }}
QMenu::item {{ padding: 7px 26px 7px 14px; border: 1px solid transparent; border-radius: 6px; color: #f4f5f7; font-weight: 600; }}
QMenu::item:selected {{ background: transparent; border-color: #3f444e; color: #ffffff; border-radius: 6px; }}
QMenu::separator {{ height: 1px; background: #2a2d34; margin: 5px 8px; }}
QMenu::indicator {{ width: 14px; height: 14px; }}

/* ---------- scrollbars ----------
   Single shared rule: the vertical bar paints flush against its scroll
   area's right edge (no right margin — the bar must not float left of the
   edge). The groove/handle insets above/below keep it off the corners. */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px 0; }}
QScrollBar::handle:vertical {{ background: #33363d; border-radius: 4px; min-height: 32px; }}
QScrollBar::handle:vertical:hover {{ background: #4a4f59; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0 3px 2px 3px; }}
QScrollBar::handle:horizontal {{ background: #33363d; border-radius: 4px; min-width: 32px; }}
QScrollBar::handle:horizontal:hover {{ background: #4a4f59; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{ background: transparent; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea QWidget {{ background: transparent; }}

/* ---------- dialogs & detail ---------- */
QDialog {{ background: transparent; }}
QLabel#dialogTitle {{ font-size: 18px; font-weight: 700; color: #f4f5f7; }}
QLabel#fieldLabel {{ font-size: 12px; font-weight: 600; color: #9ba1ab; }}
QLabel#sectionLabel {{ font-size: 11px; font-weight: 700; color: #6b7078; }}
QLabel#currencyPrefix {{ background: transparent; color: #9ba1ab; font-size: 14px; font-weight: 600; }}
/* V1.9.44: the detail/New-Task header captions (DISTRIBUTOR /
   END USER / CONTACT NAME / SALES REP) — user: the 11px caption
   AND the name under it both read tiny in the header block. */
QLabel#headerNameLabel {{ font-size: 13px; font-weight: 700; color: #9ba1ab; }}
QLabel#detailValue {{ font-size: 14px; color: #f4f5f7; }}
QLabel#revValue {{ font-size: 18px; font-weight: 700; color: #f4f5f7; }}
QFrame#attachPanel {{ background: #0f1013; border: 1px dashed #33363e; border-radius: 10px; }}
QFrame#attachPanel[dragOver="true"] {{ border: 1px dashed #4f8cff; background: #121a2c; }}
QListWidget#attachList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #c6cbd3; }}
QListWidget#attachList::item {{ padding: 7px 8px; border-radius: 6px; color: #d5d9e0; }}
QWidget#optionRow QLabel {{ color: #d5d9e0; }}
QListWidget#attachList::item:hover {{ background: #1a1c21; }}
QListWidget#attachList::item:selected {{ background: #2b2e35; color: #f4f5f7; }}
/* V1.9.29: the Settings option lists carry full-row widgets; zero item
   padding so the hover/selected band wraps the row widget exactly
   (the shared attachList 7px/8px padding inset the widget and left
   the band floating wider than the option -- user screenshot). */
QListWidget#optionList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #c6cbd3; }}
QListWidget#optionList::item {{ padding: 0px; border-radius: 6px; color: #d5d9e0; }}
QListWidget#optionList::item:hover {{ background: #1a1c21; }}
QListWidget#optionList::item:selected {{ background: #2b2e35; color: #f4f5f7; }}
/* ---------- notes module ---------- */
QListWidget#noteNav, QListWidget#noteList {{ background: transparent; border: none;
    outline: none; font-size: 13px; color: #c6cbd3; }}
/* V1.9.47: outline-only selection (user). Solid hex, NOT rgba --
   QStyleSheetStyle drops the alpha in item borders and paints
   them solid white (probed). The hexes are the rgba values
   composited over the near-black nav. */
QListWidget#noteNav::item, QListWidget#noteList::item {{ padding: 2px;
    border: 1px solid transparent; border-radius: 8px;
    background: transparent; }}
QListWidget#noteNav::item:hover, QListWidget#noteList::item:hover {{ background: transparent;
    border: 1px solid #2b2f36; }}
QListWidget#noteNav::item:selected, QListWidget#noteList::item:selected {{ background: transparent;
    border: 1px solid #61666e; }}
QLabel#noteNavName {{ font-size: 13px; font-weight: 600; color: #c6cbd3; }}
QListWidget#noteNav::item:selected QLabel#noteNavName {{ color: #f4f5f7; }}
QLabel#noteCount {{ font-size: 11px; font-weight: 700; color: #8a919c;
    background: transparent; padding: 0px; }}
QPushButton#noteScope {{ background: transparent; border: 1px solid transparent;
    border-radius: 8px;
    padding: 8px 10px; font-size: 13px; font-weight: 600; color: #9ba1ab;
    text-align: left; }}
QPushButton#noteScope:hover {{ background: transparent;
    border: 1px solid #2b2f36; color: #e6e9ee; }}
QPushButton#noteScope:checked {{ background: transparent; color: #f4f5f7; }}
QLabel#noteRowTitle {{ font-size: 13px; font-weight: 700; color: #e6e9ee; }}
QListWidget#noteList::item:selected QLabel#noteRowTitle {{ color: #f4f5f7; }}
QLabel#noteSnippet {{ font-size: 12px; color: #9ba1ab; }}
QLabel#noteFooter {{ font-size: 11px; color: #6b7078; }}
QLineEdit#noteTitle {{ background: transparent; border: none; border-radius: 0px;
    font-size: 22px; font-weight: 700; color: #f4f5f7; padding: 2px 0px; }}
QLineEdit#noteTitle:focus {{ border: none; }}
QLabel#noteSaved {{ font-size: 11px; color: #6b7078; }}
QLabel#noteEmpty {{ font-size: 14px; color: #6b7078; }}
QPushButton#fmtBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 6px; font-size: 13px; color: #9ba1ab; padding: 0px; }}
QPushButton#fmtBtn:hover {{ background: #1a1c21; color: #e6e9ee; }}
QPushButton#fmtBtn:checked {{ background: #1e2a44; color: #8fb4ff;
    border: 1px solid #2c3a58; }}
QPushButton#notesSizeBtn {{ padding: 0px; }}
QFrame#fmtSep {{ color: #2a2d34; margin: 4px 2px; }}
QTextEdit#noteEditor {{ font-size: 14px; }}
QToolTip {{ background: rgba(24, 26, 32, 0.72); color: #e6e9ee; border: 1px solid #33363e;
    padding: 5px 8px; border-radius: 8px; }}
QFrame#offlineBanner {{ background: rgba(224, 178, 44, 0.10);
    border-bottom: 1px solid #6e5a1f; }}
QLabel#offlineBannerText {{ color: #e8d9a0; font-size: 12px; font-weight: 600; }}
QPushButton#offlineBannerClose {{ background: transparent; border: none; border-radius: 6px; }}
QPushButton#offlineBannerClose:hover {{ background: rgba(255, 255, 255, 0.10); }}
QPushButton#offlineIndicator {{ background: transparent; border: none; border-radius: 6px; }}
QPushButton#offlineIndicator:hover {{ background: rgba(255, 255, 255, 0.08); }}
QLabel#pagePlaceholder {{ color: #8a919c; font-size: 13px; }}
QMessageBox {{ background: #141518; }}
QMessageBox QLabel {{ color: #e6e9ee; }}
QInputDialog QLabel {{ color: #e6e9ee; }}

/* ---------- custom window chrome ---------- */
QFrame#windowFrame {{ background: #101114; border: 1px solid #26282f; border-radius: 12px; }}
/* v1.4.0 item 12: square corners when maximized (no edge gaps) */
QFrame#windowFrame[squareCorners="true"] {{ border-radius: 0px; border: none; }}
QFrame#titleBar {{ background: transparent; border: none; border-bottom: 1px solid #1d1f24; }}
QLabel#titleBarLabel {{ color: #c6cbd3; font-size: 12px; font-weight: 600; background: transparent; }}
QPushButton#winBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #9ba1ab; font-size: 12px; padding: 6px 12px; }}
QPushButton#winBtn:hover {{ background: #23252b; color: #ffffff; }}
QPushButton#winCloseBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #9ba1ab; font-size: 12px; padding: 6px 12px; }}
QPushButton#winCloseBtn:hover {{ background: #e81123; color: #ffffff; }}

/* ---------- rack type tags ---------- */
/* V1.9.75 (workstream L, user 2026-11-15, refined 21:28):
   the rack type text was "way too small and green" -- it now
   renders WHITE one clear step ABOVE the distributor/end-user
   VALUE size (QLabel#meta = 13px; rackTag = 14px) so it stands
   out a bit. The vertical padding drops so the tag's total
   height does NOT grow: the card's badge row, and therefore
   every other row, keeps its exact geometry. */
/* V1.9.76 (scope additions 3+8, user 2026-11-16 08:41/08:50):
   the rack tag is BOXLESS text -- the teal fill is gone; the
   text (white, 14px, 600) is the whole construction, identical
   on the card, in the detail window and in New Task. */
/* V1.9.78 (WS-E1, user ruling 2026-11-16 16:01 -- SUPERSEDES
   the 1.9.76 boxless construction): "I dont want the chips
   around the rack type, maybe just a white rectangle outline
   with not color infill." The tag is a WHITE 1px outline
   rectangle, background transparent (NO infill), white 14px
   600 text. The padding drops by exactly the border width
   (1px 6px -> 0px 5px) so the tag's box -- and therefore the
   row's height, its vertical centre, and every element below
   it -- is byte-identical to the boxless construction; the
   growth is absorbed by construction, not by moving anything.
   With no [first="true"] padding carve-out any more, the FIRST
   tag's OUTLINE left edge sits exactly on the text column
   beneath it (the Distributor label's left edge), with the
   standard text padding inside the box. */
/* V1.9.80 (W12, user 2026-11-17 09:41): this padding was
   audited for the off-centre text in image-569 and is NOT
   the culprit -- it is symmetric (0px vertical, 5px each
   side) in both themes. The decentring lived in the QLabel
   constructions (default AlignLeft + a framed label's
   indent slack in the sizeHint); the fix is
   setAlignment(Qt.AlignCenter) at both constructions in
   ui.py. This rule's values are unchanged: colour, width,
   radius, font and padding all stay as E1 approved them. */
/* V1.9.82 (item 5, user 2026-11-18 13:52, image-594): "text
   still is not centered in the rectangle and the rectangle
   should be taller." The vertical padding grows 0px -> 3px:
   the tag's box goes 19 -> 25px tall (colour, border, radius,
   font and the 5px horizontal padding are untouched, so the
   width is byte-identical). The card absorbs the growth in
   the tag row's own spacing -- no other card element moves.
   The CENTRING half is not a padding matter at all:
   the stock QLabel centres the font's LINE BOX (ascent
   13.56 + descent 3.38), so the visible ink band (cap top to
   baseline, ~11px) rode ~0.4px high in the box, worse to the
   eye in the tight 19px box. RackTagLabel in ui.py paints
   the text with the cap-to-baseline band centred instead;
   this rule's symmetric padding only sets the box height. */
QPushButton[role="rackTag"] {{ border: 1px solid #ffffff; border-radius: 6px; padding: 3px 5px;
    font-size: 14px; font-weight: 600; background: transparent; color: #ffffff; }}
QLabel[role="rackTag"] {{ border: 1px solid #ffffff; border-radius: 6px; padding: 3px 5px;
    font-size: 14px; font-weight: 600; background: transparent; color: #ffffff; }}

/* ---------- notes editor ---------- */
QTextEdit#notesEdit {{ padding: 10px; }}

/* ---------- toolbar ---------- */
QFrame#toolBar {{ background: transparent; border: none; }}
QLabel#selCountLabel {{ color: #9ba1ab; font-size: 12px; font-weight: 600; }}
QLabel#sortLabel {{ color: #6b7078; font-size: 12px; }}
QLabel#countLabel {{ color: #6b7078; font-size: 12px; }}

/* ---------- sidebar ---------- */
QFrame#sideBar {{ background: #0e0f12; border: none; border-right: 1px solid #1d1f24; }}
/* V1.9.75 (workstream F): the nav/settings outlines are NO
   LONGER QSS borders -- QSS draws a rounded border as separate
   line + arc segments whose joins overdraw brighter at
   fractional scaling (the user's corner-seam photo). The
   buttons paint ONE single-path stroke themselves
   (SingleStrokeOutlineButton in ui.py; _NavPillFrame for the
   pill), so these rules carry border: none and only the
   text colours remain here. */
QPushButton#navBtn {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 12px; font-size: 13px; font-weight: 600; color: #9a9a9a;
    text-align: left; }}
/* V1.9.71 (user photo: sidebar icons off-centre in their
   outlines): collapsed to the icon rail, the button carries no
   text, but the base rule's left alignment + 12px left padding
   parked the icon-only group at the content-rect's left edge --
   1.5px right of the button's centre, inside an outline (the
   nav pill) that exactly matches the button. Collapsed buttons
   centre their content instead; expanded icon+label rows keep
   the left alignment untouched. The property is set by
   _apply_sidebar_content in app.py. */
QPushButton#navBtn[collapsed="true"] {{ text-align: center; }}
/* V1.9.69 (user, again: sidebar active/hover was a COLOR FILLED
   GRAY rectangle; selected/active = OUTLINE ONLY globally):
   hover and pressed are outline-only, exactly like #settingsNav
   and the menubar -- the base rule carries a transparent 1px
   border so the border-color change never shifts geometry. */
QPushButton#navBtn:hover {{ background: transparent; color: #e6e9ee; }}
QPushButton#navBtn:pressed {{ background: transparent; color: #ffffff; }}
QPushButton#navBtn:checked {{ background: transparent; color: #ffffff; }}
/* V1.9.49 (user: "SHOULD just be the outline of the rectangle
   not this UGLY GRAY COLORED RECTANGLE I KEEP SAYING I HATE"):
   the sidebar's sliding selection marker is an OUTLINE only.
   V1.9.75 (workstream F): painted as ONE single-path stroke by
   _NavPillFrame (app.py) -- no QSS border (see #navBtn note). */
QFrame#navPill {{ background: transparent; border: none; }}
QLabel#sideFoot {{ color: #4a4f59; font-size: 10px; }}
QPushButton#navToggle {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 0px; font-size: 15px; font-weight: 600; color: #9ba1ab;
    text-align: center; }}
/* V1.9.69: outline-only hover/pressed, same rule as #navBtn.
   V1.9.75 (workstream F): the outline is painted single-path
   by the button itself; only text colours live here now. */
QPushButton#navToggle:hover {{ background: transparent; color: #e6e9ee; }}
QPushButton#navToggle:pressed {{ background: transparent; color: #ffffff; }}
/* v1.4.0 item 16: Settings sidebar nav - restrained, no blue tint. */
QPushButton#settingsNav {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 14px; font-size: 13px; color: #9ba1ab; text-align: left; }}
/* V1.9.51 (user: selected/active = OUTLINE ONLY, never a gray
   fill -- his Settings screenshot showed "General" as a filled
   gray slab). V1.9.75 (workstream F): single-path painted
   outline (SingleStrokeOutlineButton); text colours only. */
QPushButton#settingsNav:hover {{ background: transparent; color: #e6e9ee; }}
QPushButton#settingsNav:checked {{ background: transparent; color: #f2f4f7; }}

/* ---------- CRM ---------- */
QLabel#kindPill {{ background: #1e2a44; color: #8fb4ff; border-radius: 6px;
    padding: 4px 12px; font-size: 11px; font-weight: 600; }}
QPushButton#taskLink {{ background: transparent; border: 1px solid #23252b;
    border-radius: 9px; padding: 9px 12px; text-align: left;
    color: #dfe3ea; font-size: 12px; font-weight: 600; }}
QPushButton#taskLink:hover {{ background: #16181d; border-color: #33363e; color: #8fb4ff; }}
/* W17 (1.9.80): the connected-task row's right-aligned Date Added
   label -- same type and colour as the row's own text. */
QLabel#taskLinkDate {{ background: transparent; color: #dfe3ea;
    font-size: 12px; font-weight: 600; }}

/* v1.4.0 item 15: inline SDC badge in the task detail window */
QLabel#sdcBadge {{ border-radius: 6px; padding: 2px 8px; font-size: 11px;
    font-weight: 600; }}
/* V1.9.76 (scope addition 13): text only -- the severity
   COLOURS are unchanged from the colour-by-value behaviour
   he has always had (low #8f96a3 / watch #eec25e / high
   #ff8a8a); only the rectangle and infill come off. The
   1.9.75 WS-A border-match rules are superseded. */
QLabel#sdcBadge[sdcSeverity="low"] {{ background: transparent; color: #8f96a3;
    border: none; }}
QLabel#sdcBadge[sdcSeverity="watch"] {{ background: transparent; color: #eec25e;
    border: none; }}
QLabel#sdcBadge[sdcSeverity="high"] {{ background: transparent; color: #ff8a8a;
    border: none; }}
/* V1.9.76 (scope addition 13): text only, like the SDC badge.
   Unflagged text is the app's white; flagged turns yellow
   (the face colours come from _ibc_colors). */
QPushButton#ibcChip {{ background: transparent; color: #ffffff;
    border: none; border-radius: 6px; padding: 2px 8px;
    font-size: 11px; font-weight: 700; }}
QPushButton#ibcChip:hover {{ color: #ffffff; }}
/* V1.9.78 (WS-D): flagged = TRUE YELLOW #ffd94d (see the
   #ibcFlagChip note -- #eec25e collided with SDC-watch). */
QPushButton#ibcChip[flag="true"] {{ color: #ffd94d;
    border: none; }}
QPushButton#ibcChip[flag="true"]:hover {{ color: #ffd94d; }}
QPushButton#iconBtn {{ background: transparent; border: none; border-radius: 7px;
    padding: 7px; }}
/* V1.9.74: no gray fill on hover, anywhere -- the standing
   outline-only rule. The fill is simply gone. */
QPushButton#iconBtn:hover {{ background: transparent; }}
/* V1.9.75 (workstream B, user 2026-11-15 -- SUPERSEDES the
   1.9.74 always-on outline): the card remove (✕) button is a
   BARE red ✕ with NO outline in the normal state; the red
   outline rectangle appears ONLY while the mouse hovers the
   button. No fill in any state. The ✕ glyph is red via its
   icon. The border width never changes (transparent when not
   hovered) so the button's box never moves. */
QPushButton#cardRemoveBtn {{ background: transparent;
    border: 1px solid transparent; border-radius: 7px; padding: 6px; }}
QPushButton#cardRemoveBtn:hover {{ background: transparent;
    border-color: #e5484d; }}
QPushButton#cardRemoveBtn:pressed {{ background: transparent;
    border-color: #ff8589; }}

/* ---------- queue board ---------- */
QFrame#queueColumn {{ background: #0e0f12; border: 1px solid #1d1f24; border-radius: 14px; }}
QFrame#queueColumn[dropActive="true"] {{ border: 1px solid #4f8cff; background: #10131a; }}
QFrame#dropPlaceholder {{ background: rgba(79, 140, 255, 0.07);
    border: 1.5px dashed #4f8cff; border-radius: 14px; }}
QLabel#dropPlaceholderText {{ color: #8fb4ff; font-size: 12px; font-weight: 600; }}
QLabel#colTitle {{ font-size: 13px; font-weight: 700; color: #f4f5f7; }}
QLabel#countBadge {{ background: #23252b; color: #9ba1ab; border-radius: 6px;
    padding: 2px 9px; font-size: 11px; font-weight: 700; }}
QFrame#queueCard {{ background: #141518; border: 1px solid #23252b; border-radius: 12px; }}
QFrame#queueCard:hover {{ border-color: #3a3e48; }}
QLabel#queueQuote {{ font-size: 16px; font-weight: 700; color: #cfe0ff;
    background: #1a2c4e; padding: 6px 14px;
    border-top-left-radius: 0px; border-top-right-radius: 0px;
    border-bottom-right-radius: 11px; border-bottom-left-radius: 0px; }}
/* queue-card notes: label-like read-only scroller (see QueueCard._fit_notes) */
QTextEdit#queueDesc {{ background: transparent; border: none; padding: 0px;
    color: #c6cbd3;
    selection-background-color: #2f6fed; selection-color: #ffffff; }}
QLabel#queueMeta {{ font-size: 11px; color: #9ba1ab; }}
QLabel#dropHint {{ color: #4a4f59; font-size: 12px; border: 1px dashed #2a2d34;
    border-radius: 10px; padding: 20px 10px; }}
QLabel#miniPill {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; }}
QLabel#miniPill[statusState="in_process"] {{ background: #1a2c4e; color: #7fb0ff; }}
QLabel#miniPill[statusState="on_hold"] {{ background: #3a2f16; color: #eec25e; }}
QLabel#miniPill[statusState="completed"] {{ background: #143327; color: #6fdc9e; }}
QLabel#miniPill[statusState="canceled"] {{ background: #23252b; color: #9ba1ab; }}
/* v1.4.0 item 10: amber "Waiting: …" chip on queue cards */
QLabel#waitingChip {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; background: #3a2f16; color: #eec25e; }}
QCheckBox#queueCheck {{ color: #d5d9e0; font-size: 13px; spacing: 10px; }}

/* ---------- settings: folder creation guidance (warn/missing states) ---------- */
QLabel#folderHint[warn="true"] {{ color: #ef9a9a; font-weight: 600; }}
QLineEdit[missing="true"] {{ border: 1px solid #b0453f; }}
QLabel#verifyItem[ok="true"] {{ color: #6fdc9e; }}
QLabel#verifyItem[ok="false"] {{ color: #ef9a9a; font-weight: 600; }}
"""

LIGHT = f"""
* {{ font-family: {FONT_STACK}; }}
QWidget#app {{ background: #f5f5f6; }}
QLabel#title {{ font-size: 22px; font-weight: 700; color: #1c1f24; }}
QLabel#subtitle {{ color: #474c54; font-size: 12px; }}
QLabel#emptyState {{ color: #4e535b; font-size: 14px; }}

/* ---------- cards ---------- */
QFrame#card {{ background: #ffffff; border: 1px solid #e3e4e6; border-radius: 14px; }}
/* V1.9.78 (WS-E3): hover outline painted by _CardHoverOverlay
   (ui.py) -- the QSS border keeps the rest colour on hover
   (see the dark sheet's note). */
QFrame#card:hover {{ border: 1px solid #e3e4e6; }}
/* V1.9.5: hot tasks — red border beats hover. */
QFrame#card[hot="true"] {{ border: 1px solid #e5484d; }}
QFrame#card[hot="true"]:hover {{ border: 1px solid #e5484d; }}
QLabel#quoteNum {{ font-size: 15px; font-weight: 700; color: #1c1f24;
    background: transparent; border: none; padding: 0px 2px; }}
QLabel#meta {{ color: #3d4149; font-size: 13px; }}
QLabel#metaPrefix {{ color: #474c54; font-size: 13px; }}
QLabel#notes {{ color: #3d4149; font-size: 13px; }}
QLabel#dateLabel {{ color: #4e535b; font-size: 11px; }}
QLabel#progressLabel {{ color: #474c54; font-size: 11px; font-weight: 600; }}
QLabel#hint {{ color: #4e535b; font-size: 11px; }}
QRadioButton {{ color: #3d4149; }}

/* ---------- status pill (clickable) ---------- */
/* V1.9.75 (workstream C): outline construction, light sheet
   (see the dark sheet's note); border = the state's text
   colour, padding drops by the border width. */
QPushButton#statusPill {{ border: 1px solid transparent; border-radius: 6px; padding: 3px 11px;
    font-size: 11px; font-weight: 700; }}
QPushButton#statusPill[statusState="in_process"] {{ background: transparent; color: #1d4ed8; border-color: #1d4ed8; }}
QPushButton#statusPill[statusState="in_process"]:hover {{ background: transparent; }}
QPushButton#statusPill[statusState="on_hold"] {{ background: transparent; color: #b45309; border-color: #b45309; }}
QPushButton#statusPill[statusState="on_hold"]:hover {{ background: transparent; }}
QPushButton#statusPill[statusState="completed"] {{ background: transparent; color: #15803d; border-color: #15803d; }}
QPushButton#statusPill[statusState="completed"]:hover {{ background: transparent; }}
QPushButton#statusPill[statusState="canceled"] {{ background: transparent; color: #5f666b; border-color: #5f666b; }}
QPushButton#statusPill[statusState="canceled"]:hover {{ background: transparent; }}

/* ---------- outcome pill (clickable, V1.9.29) ---------- */
QPushButton#outcomePill {{ border: 1px solid transparent; border-radius: 6px; padding: 3px 11px;
    font-size: 11px; font-weight: 700; }}
QPushButton#outcomePill[outcomeState="won"] {{ background: transparent; color: #15803d; border-color: #15803d; }}
QPushButton#outcomePill[outcomeState="won"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="lost"] {{ background: transparent; color: #b3261e; border-color: #b3261e; }}
QPushButton#outcomePill[outcomeState="lost"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="dead"] {{ background: transparent; color: #9a4a2f; border-color: #9a4a2f; }}
QPushButton#outcomePill[outcomeState="dead"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="on_hold"] {{ background: transparent; color: #b45309; border-color: #b45309; }}
QPushButton#outcomePill[outcomeState="on_hold"]:hover {{ background: transparent; }}
QPushButton#outcomePill[outcomeState="unknown"] {{ background: transparent; color: #5f666b; border-color: #5f666b; }}
QPushButton#outcomePill[outcomeState="unknown"]:hover {{ background: transparent; }}

/* ---------- scope chips (checkable) ---------- */
/* V1.9.75 (workstream C): the GLOBAL CHIP STANDARD, light
   sheet -- outline rectangle, no fill, coloured text. */
QPushButton[role="scopeChip"] {{ border: 1px solid transparent; border-radius: 6px; padding: 3px 5px;
    font-size: 11px; font-weight: 600; }}
QPushButton[role="scopeChip"][scopeKey="quote"] {{ background: transparent; color: #1d4ed8; border-color: #1d4ed8; }}
QPushButton[role="scopeChip"][scopeKey="re-quote"] {{ background: transparent; color: #6d28d9; border-color: #6d28d9; }}
QPushButton[role="scopeChip"][scopeKey="cad"] {{ background: transparent; color: #047857; border-color: #047857; }}
QPushButton[role="scopeChip"][scopeKey="configura"] {{ background: transparent; color: #c2410c; border-color: #c2410c; }}
QPushButton[role="scopeChip"][scopeKey="prelims"] {{ background: transparent; color: #a16207; border-color: #a16207; }}
QPushButton[role="scopeChip"][scopeKey="misc"] {{ background: transparent; color: #474c54; border-color: #474c54; }}
QPushButton[role="scopeChip"][scopeKey="custom-0"] {{ background: transparent; color: #6d28d9; border-color: #6d28d9; }}
QPushButton[role="scopeChip"][scopeKey="custom-1"] {{ background: transparent; color: #0369a1; border-color: #0369a1; }}
QPushButton[role="scopeChip"][scopeKey="custom-2"] {{ background: transparent; color: #c2410c; border-color: #c2410c; }}
QPushButton[role="scopeChip"][scopeKey="custom-3"] {{ background: transparent; color: #15803d; border-color: #15803d; }}
QPushButton[role="scopeChip"]:checked {{ background: transparent; color: #15803d; border-color: #15803d; }}

/* ---------- buttons ---------- */
QPushButton {{ background: #ffffff; border: 1px solid #d9dbde; border-radius: 8px;
    padding: 7px 14px; font-size: 13px; color: #272b33; }}
QPushButton:hover {{ background: #f5f5f6; border-color: #bfc4cb; }}
QPushButton:disabled {{ color: #8f959e; background: #f5f5f6; border-color: #e3e4e6; }}
QPushButton#primary {{ background: #2563eb; border: none; color: #ffffff;
    font-weight: 600; padding: 8px 18px; }}
QPushButton#primary:hover {{ background: #1d55c9; }}
/* Name links (see the dark theme note). */
QPushButton#contactLink {{ background: transparent; border: none;
    color: #272b33; padding: 3px 6px; font-size: 19px; font-weight: 600; }}
QPushButton#contactLink:hover {{ background: transparent;
    text-decoration: underline; }}
QPushButton#contactLink:focus {{ text-decoration: underline; }}
QPushButton#contactLink:disabled {{ color: #9aa0a8;
    text-decoration: none; }}
QPushButton#ghost {{ background: transparent; border: 1px solid #d9dbde;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger {{ background: transparent; border: 1px solid #d9dbde; color: #c0392b;
    padding: 5px 11px; font-size: 12px; }}
QPushButton#danger:hover {{ background: #f5f5f6; border-color: #bfc4cb; }}
QPushButton#ghost:hover {{ background: #ececee; border-color: #bfc4cb; }}
QPushButton#cardHotBtn, QPushButton#cardFolderBtn, QPushButton#cardEditBtn,
QPushButton#cardDeleteBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 8px; padding: 5px 9px; font-size: 12px; color: #3d4149; }}
QPushButton#cardHotBtn:hover {{ background: transparent; border-color: #c0272d; color: #c0272d; }}
QPushButton#cardFolderBtn:hover {{ background: transparent; border-color: #9a6206; color: #9a6206; }}
QPushButton#cardEditBtn:hover {{ background: transparent; border-color: #1d4ed8; color: #1d4ed8; }}
QPushButton#cardDeleteBtn {{ color: #c0392b; }}
QPushButton#cardDeleteBtn:hover {{ background: transparent; border-color: #c0272d; color: #c0272d; }}
QPushButton#scopeButton {{ text-align: left; padding: 9px 12px; }}
QFrame#scopeButton {{ background: #ffffff; border: 1px solid #d9dbde; border-radius: 8px; }}
QFrame#scopeButton:hover {{ border: 1px solid #2563eb; }}
QLabel#scopeText {{ color: #1c1f24; font-size: 13px; background: transparent; }}
QLabel#scopeText[empty="true"] {{ color: #4e535b; }}
QLabel#scopeArrow {{ color: #474c54; font-size: 11px; background: transparent; }}
QPushButton#titleLink {{ background: transparent; border: none; text-align: left;
    padding: 0px; font-size: 18px; font-weight: 700; color: #1c1f24; }}
QPushButton#titleLink:hover {{ color: #1c1f24; text-decoration: underline; }}
QPushButton#titleLink:disabled {{ color: #1c1f24; }}
QLabel#imageStage {{ background: #000000; border-radius: 8px; }}
QPushButton#seg {{ border: 1px solid transparent; border-radius: 8px; padding: 7px 13px;
    font-size: 13px; font-weight: 600; color: #474c54; background: transparent; }}
QPushButton#seg:hover {{ color: #272b33; }}
QPushButton#seg:checked {{ background: #ffffff; color: #1d4ed8; }}
QPushButton#seg[attention="true"] {{ background: #ffffff; color: #b42318;
    border-color: #e5a8a8; }}
QPushButton#seg[attention="true"]:hover {{ background: #f5f5f6; color: #912018;
    border-color: #d98c8c; }}
QPushButton#seg[attention="true"]:checked {{ background: #ececee; color: #912018;
    border-color: #b42318; }}
QPushButton#chipToggle {{ border: 1px solid #d9dbde; border-radius: 6px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #474c54; background: #ececee; }}
QPushButton#chipToggle:hover {{ color: #272b33; border-color: #bfc4cb; }}
QPushButton#chipToggle:checked {{ background: #e3e9f2; border-color: #1d4ed8; color: #1d4ed8; }}
QLabel#chipToggle {{ border: 1px solid #d9dbde; border-radius: 6px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #474c54; background: #ececee; }}
QLabel#chipToggle:hover {{ color: #272b33; border-color: #bfc4cb; }}
QLabel#chipToggle[checked="true"] {{ background: #e3e9f2; border-color: #1d4ed8; color: #1d4ed8; }}
QPushButton#dueChip {{ border: 1px solid #d9dbde; border-radius: 6px; padding: 6px 14px;
    font-size: 12px; font-weight: 600; color: #474c54; background: #ececee; }}
QPushButton#dueChip:hover {{ color: #272b33; border-color: #bfc4cb; }}
QPushButton#dueChip:checked {{ background: #e3e9f2; border-color: #93b4f5; color: #1d4ed8; }}
/* card badges */
QLabel#dueChip, QLabel#estChip, QLabel#followChip, QLabel#priceChip {{ font-size: 11px; font-weight: 600;
    padding: 3px 9px; border-radius: 6px; }}
QLabel#dueChip {{ background: #e3e9f2; color: #1d4ed8; }}
QLabel#dueChip[urgent="true"] {{ background: #f3f4f6; color: #b42318; }}
QLabel#estChip {{ background: #ececee; color: #474c54; }}
/* V1.9.71 (S): identical to the detail chip's flagged state. */
/* V1.9.76 (addition 13): text only, light sheet. */
/* V1.9.78 (WS-D): light flagged KEEPS the dark amber #b45309 --
   the dark theme's true yellow #ffd94d is unreadable on white. */
QWidget#ibcFlagChip {{ background: transparent; color: #b45309; border: none; border-radius: 6px; font-size: 11px; font-weight: 700; }}
QLabel#ibcChipText, QLabel#ibcChipIcon {{ background: transparent; border: none; padding: 0; margin: 0; }}
QLabel#priceChip {{ background: #ececee; color: #23252b; font-weight: 700; }}
QLabel#followChip {{ background: #f5efdb; color: #8a5f16; }}
QLabel#logisticsChip {{ background: #ececee; color: #3d4149; font-size: 11px;
    font-weight: 600; padding: 3px 9px; border-radius: 9px; }}
/* quiet tri-state outcome */
QPushButton#outcomeSeg {{ border: 1px solid #d9dbde; border-radius: 6px;
    padding: 4px 10px; font-size: 11px; font-weight: 600; color: #52565e;
    background: transparent; }}
QPushButton#outcomeSeg:hover {{ color: #474c54; border-color: #bfc4cb; }}
QPushButton#outcomeSeg:checked[outcome_state="unknown"] {{ background: #ececee;
    border-color: #ccd0d6; color: #474c54; }}
QPushButton#outcomeSeg:checked[outcome_state="won"] {{ background: #e6f1e9;
    border-color: #9ed9b8; color: #1c7a45; }}
QPushButton#outcomeSeg:checked[outcome_state="lost"] {{ background: #f3f4f6;
    border-color: #d9dbde; color: #b42318; }}
/* re-quote link + version history */
QPushButton#requoteLink {{ background: transparent; border: none; text-align: left;
    padding: 2px 0px; font-size: 12px; color: #4e535b; }}
QPushButton#requoteLink:hover {{ color: #1d4ed8; text-decoration: underline; }}
QPushButton#versionRow {{ background: transparent; border: 1px solid #d9dbde;
    border-radius: 8px; text-align: left; padding: 7px 12px; font-size: 12px;
    color: #3a3d44; }}
QPushButton#versionRow:hover {{ border-color: #2563eb; color: #1d4ed8; }}
QPushButton#versionRow:disabled {{ background: #e3e9f2; border-color: #93b4f5;
    color: #1d4ed8; font-weight: 600; }}
/* distributor scope preset suggestion */
QPushButton#scopeSuggest {{ background: #f5f5f6; border: 1px dashed #bfc4cb;
    border-radius: 8px; padding: 7px 12px; font-size: 12px; color: #474c54;
    text-align: left; }}
QPushButton#scopeSuggest:hover {{ border-color: #2563eb; color: #272b33; }}
/* follow-ups widget rows */
QFrame#followRow {{ background: #f5f5f6; border: 1px solid #d9dbde;
    border-radius: 10px; }}
QFrame#segBar {{ background: #e4e4e7; border-radius: 11px; }}
QPushButton[role="scopeRow"] {{ background: transparent; border: 1px solid transparent; border-radius: 7px;
    text-align: left; padding: 8px 12px; font-size: 13px; color: #3a3d44; }}
QPushButton[role="scopeRow"]:hover {{ background: transparent; border-color: #c3c7cd; }}
QPushButton[role="scopeRow"]:checked {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; font-weight: 600; }}
QFrame#scopePopup {{ background: transparent; border: none; border-radius: 10px; }}

/* ---------- contact autocomplete popup ---------- */
/* V1.9.54: see the dark-theme note -- glass view, fallback
   skin transparent, selection never a filled slab. */
QListView#completerPopup {{ background: transparent; border: none;
    padding: 4px; outline: none; }}
QListView#completerPopup::item {{ padding: 9px 12px; border-radius: 7px;
    color: #272b33; }}
QListView#completerPopup::item:selected, QListView#completerPopup::item:hover {{
    background: transparent; color: #1d4ed8; }}

/* ---------- inputs ---------- */
QLineEdit, QTextEdit, QComboBox {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #1c1f24;
    selection-background-color: #2563eb; }}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid #2563eb; }}
QLineEdit:disabled, QTextEdit:disabled {{ color: #474c54; background: #f5f5f6; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{ image: url("{_CHEV_DOWN_LIGHT}"); width: 10px; height: 10px; }}
/* date / time edits: same themed field + chevron dropdown as every combo */
QDateEdit, QTimeEdit, QDateTimeEdit {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; padding: 8px 11px; font-size: 13px; color: #1c1f24;
    selection-background-color: #2563eb; }}
QDateEdit:focus, QTimeEdit:focus, QDateTimeEdit:focus {{ border: 1px solid #2563eb; }}
QDateEdit:disabled, QTimeEdit:disabled, QDateTimeEdit:disabled {{ color: #474c54;
    background: #f5f5f6; }}
QDateEdit::drop-down, QTimeEdit::drop-down, QDateTimeEdit::drop-down {{
    border: none; width: 24px; }}
QDateEdit::down-arrow, QTimeEdit::down-arrow, QDateTimeEdit::down-arrow {{
    image: url("{_CHEV_DOWN_LIGHT}"); width: 10px; height: 10px; }}
/* calendar popup: light theme */
QCalendarWidget QAbstractItemView:enabled {{ background-color: #ffffff; color: #272b33;
    selection-background-color: #2563eb; selection-color: #ffffff; outline: none; }}
QCalendarWidget QAbstractItemView:disabled {{ color: #a8b0bf; }}
QCalendarWidget QToolButton {{ color: #272b33; background: transparent; border: none;
    border-radius: 6px; font-size: 13px; font-weight: 600; padding: 4px; }}
QCalendarWidget QToolButton:hover {{ background: #ececee; }}
QCalendarWidget QToolButton::menu-indicator {{ image: none; }}
QCalendarWidget QSpinBox, QCalendarWidget QAbstractSpinBox {{ background: #ffffff;
    border: 1px solid #d9dbde; border-radius: 6px; color: #1c1f24;
    padding: 2px 4px; font-size: 12px; }}
QCalendarWidget QAbstractSpinBox::up-button,
QCalendarWidget QAbstractSpinBox::down-button {{ border: none; background: transparent;
    width: 14px; }}
QCalendarWidget QAbstractSpinBox::up-arrow {{ image: url("{_CHEV_UP_LIGHT}");
    width: 8px; height: 8px; }}
QCalendarWidget QAbstractSpinBox::down-arrow {{ image: url("{_CHEV_DOWN_LIGHT}");
    width: 8px; height: 8px; }}
#qt_calendar_prevmonth, #qt_calendar_nextmonth {{ min-width: 30px; }}
#qt_calendar_prevmonth {{ qproperty-icon: none; qproperty-text: "‹"; }}
#qt_calendar_nextmonth {{ qproperty-icon: none; qproperty-text: "›"; }}
#qt_calendar_navigationbar {{ background-color: #f7f7f8; }}
/* themed - / + stepper (replaces native QSpinBox arrows) */
QPushButton#stepperBtn {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; font-size: 15px; font-weight: 700; color: #474c54;
    padding: 0px; }}
QPushButton#stepperBtn:hover {{ background: #f5f5f6; color: #1c1f24;
    border-color: #bfc4cb; }}
QPushButton#stepperBtn:disabled {{ color: #9aa0a8; background: #f5f5f6;
    border-color: #e3e4e6; }}
QLabel#stepperValue {{ background: #ffffff; border: 1px solid #d9dbde;
    border-radius: 8px; padding: 5px 8px; font-size: 13px; font-weight: 600;
    color: #1c1f24; }}
QComboBox QAbstractItemView {{ background: rgba(255, 255, 255, 0.85); border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 10px; padding: 4px;
    selection-background-color: #2563eb; selection-color: #ffffff;
    color: #272b33; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #272b33; }}
QComboBox QAbstractItemView::item:hover {{ background: transparent; border-color: #c3c7cd; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; border-radius: 7px; }}
/* sort dropdown: polished popup to match the theme */
QComboBox#sortBox {{ background: #f7f7f8; }}
QComboBox#sortBox:hover {{ border: 1px solid #bfc4cb; }}
QComboBox#sortBox QAbstractItemView {{ background: rgba(255, 255, 255, 0.85); border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox#sortBox QAbstractItemView::item {{ padding: 9px 12px; border: 1px solid transparent; border-radius: 7px;
    color: #272b33; }}
QComboBox#sortBox QAbstractItemView::item:hover {{ background: transparent; border-color: #c3c7cd; }}
QComboBox#sortBox QAbstractItemView::item:selected {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; border-radius: 7px; }}
/* V1.9.18: generic combo popup frame (see dark note above). */
QComboBox QAbstractItemView {{ background: rgba(255, 255, 255, 0.85); border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 10px; padding: 5px; outline: none; }}
QComboBox QAbstractItemView::item {{ padding: 9px 12px; border-radius: 7px;
    color: #1c1f24; }}
QComboBox QAbstractItemView::item:selected {{ background: transparent; border-color: #9aa0a8; color: #1c1f24; }}
/* V1.9.3: the Notes font-size box is only 58px wide — the generic combo
   padding (8px 11px) would leave the text field ~12px and clip "14" to "4".
   Tight padding keeps two digits fully visible. */
QComboBox#notesSizeBox {{ padding: 5px 4px; }}

/* ---------- checkboxes: uniform indicator in both themes ---------- */
QCheckBox {{ color: #3a3d44; font-size: 13px; spacing: 10px; }}
QCheckBox:disabled {{ color: #8f959e; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 5px;
    border: 1px solid #93a0b4; background: #ffffff; }}
QCheckBox::indicator:hover {{ border-color: #2563eb; }}
QCheckBox::indicator:pressed {{ background: #ececee; }}
QCheckBox::indicator:checked {{ background: #2563eb; border-color: #2563eb;
    image: url("{_CHECK_MARK}"); }}
QCheckBox::indicator:checked:hover {{ background: #1d55c9; border-color: #1d55c9; }}
QCheckBox::indicator:checked:pressed {{ background: #1e4fc4; border-color: #1e4fc4; }}
QCheckBox::indicator:indeterminate {{ background: #2563eb; border-color: #2563eb; }}
QCheckBox::indicator:disabled {{ border-color: #d9dbde; background: #f5f5f6; }}
QCheckBox::indicator:checked:disabled {{ background: #a9bce0; border-color: #a9bce0;
    image: none; }}

/* ---------- quote-folder setup guard (new task dialog) ---------- */
QCheckBox#primaryCheck {{ color: #1c1f24; font-size: 14px; font-weight: 700;
    spacing: 10px; }}
QLabel#folderSetupWarning {{ background: #f5efdb; border: 1px solid #d97706;
    border-radius: 8px; color: #92400e; font-size: 12px; padding: 8px 10px; }}
QPushButton#folderSetupButton {{ background: #e3e9f2; border: 1px solid #2563eb;
    border-radius: 8px; color: #1d4ed8; font-size: 13px; font-weight: 600;
    padding: 8px 14px; }}
QPushButton#folderSetupButton:hover {{ background: #dde3ec; }}

/* ---------- menus ---------- */
QMenuBar {{ background: transparent; color: #3d4149; border-bottom: 1px solid #e3e4e6; }}
QMenuBar::item {{ padding: 6px 12px; background: transparent; border: 1px solid transparent; border-radius: 6px; }}
QMenuBar::item:selected {{ background: transparent; border-color: #c3c7cd; border-radius: 6px; }}
QMenu {{ background: rgba(255, 255, 255, 0.72); border: 1px solid #d9dbde; border-radius: 8px; padding: 5px; }}
QMenu::item {{ padding: 7px 26px 7px 14px; border: 1px solid transparent; border-radius: 6px; color: #1c1f24; font-weight: 600; }}
QMenu::item:selected {{ background: transparent; border-color: #c3c7cd; color: #1c1f24; border-radius: 6px; }}
QMenu::separator {{ height: 1px; background: #e3e4e6; margin: 5px 8px; }}
QMenu::indicator {{ width: 14px; height: 14px; }}

/* ---------- scrollbars ---------- */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px 0; }}
QScrollBar::handle:vertical {{ background: #c6cfdb; border-radius: 4px; min-height: 32px; }}
QScrollBar::handle:vertical:hover {{ background: #a9b4c4; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0 3px 2px 3px; }}
QScrollBar::handle:horizontal {{ background: #c6cfdb; border-radius: 4px; min-width: 32px; }}
QScrollBar::handle:horizontal:hover {{ background: #a9b4c4; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{ background: transparent; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea QWidget {{ background: transparent; }}

/* ---------- dialogs & detail ---------- */
QDialog {{ background: transparent; }}
QLabel#dialogTitle {{ font-size: 18px; font-weight: 700; color: #1c1f24; }}
QLabel#fieldLabel {{ font-size: 12px; font-weight: 600; color: #474c54; }}
QLabel#sectionLabel {{ font-size: 11px; font-weight: 700; color: #474c54; }}
QLabel#currencyPrefix {{ background: transparent; color: #5f656e; font-size: 14px; font-weight: 600; }}
QLabel#headerNameLabel {{ font-size: 13px; font-weight: 700; color: #5f656e; }}
QLabel#detailValue {{ font-size: 14px; color: #1c1f24; }}
QLabel#revValue {{ font-size: 18px; font-weight: 700; color: #1c1f24; }}
QFrame#attachPanel {{ background: #f5f5f6; border: 1px dashed #ccd0d6; border-radius: 10px; }}
QFrame#attachPanel[dragOver="true"] {{ border: 1px dashed #2563eb; background: #e8edf3; }}
QListWidget#attachList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #3d4149; }}
QListWidget#attachList::item {{ padding: 7px 8px; border-radius: 6px; color: #1c1f24; }}
QWidget#optionRow QLabel {{ color: #1c1f24; }}
QListWidget#attachList::item:hover {{ background: #ececee; }}
QListWidget#attachList::item:selected {{ background: #e4e5e8; color: #1c1f24; }}
QListWidget#optionList {{ background: transparent; border: none; outline: none;
    font-size: 12px; color: #3d4149; }}
QListWidget#optionList::item {{ padding: 0px; border-radius: 6px; color: #1c1f24; }}
QListWidget#optionList::item:hover {{ background: #ececee; }}
QListWidget#optionList::item:selected {{ background: #e4e5e8; color: #1c1f24; }}
/* ---------- notes module ---------- */
QListWidget#noteNav, QListWidget#noteList {{ background: transparent; border: none;
    outline: none; font-size: 13px; color: #3d4149; }}
QListWidget#noteNav::item, QListWidget#noteList::item {{ padding: 2px;
    border: 1px solid transparent; border-radius: 8px;
    background: transparent; }}
QListWidget#noteNav::item:hover, QListWidget#noteList::item:hover {{ background: transparent;
    border: 1px solid #c9cbce; }}
QListWidget#noteNav::item:selected, QListWidget#noteList::item:selected {{ background: transparent;
    border: 1px solid #93969b; }}
QLabel#noteNavName {{ font-size: 13px; font-weight: 600; color: #3d4149; }}
QListWidget#noteNav::item:selected QLabel#noteNavName {{ color: #1c1f24; }}
QLabel#noteCount {{ font-size: 11px; font-weight: 700; color: #474c54;
    background: transparent; padding: 0px; }}
QPushButton#noteScope {{ background: transparent; border: 1px solid transparent;
    border-radius: 8px;
    padding: 8px 10px; font-size: 13px; font-weight: 600; color: #474c54;
    text-align: left; }}
QPushButton#noteScope:hover {{ background: transparent;
    border: 1px solid #c9cbce; color: #272b33; }}
QPushButton#noteScope:checked {{ background: transparent; color: #1c1f24; }}
QLabel#noteRowTitle {{ font-size: 13px; font-weight: 700; color: #1c1f24; }}
QListWidget#noteList::item:selected QLabel#noteRowTitle {{ color: #1c1f24; }}
QLabel#noteSnippet {{ font-size: 12px; color: #474c54; }}
QLabel#noteFooter {{ font-size: 11px; color: #666c75; }}
QLineEdit#noteTitle {{ background: transparent; border: none; border-radius: 0px;
    font-size: 22px; font-weight: 700; color: #1c1f24; padding: 2px 0px; }}
QLineEdit#noteTitle:focus {{ border: none; }}
QLabel#noteSaved {{ font-size: 11px; color: #666c75; }}
QLabel#noteEmpty {{ font-size: 14px; color: #666c75; }}
QPushButton#fmtBtn {{ background: transparent; border: 1px solid transparent;
    border-radius: 6px; font-size: 13px; color: #474c54; padding: 0px; }}
QPushButton#fmtBtn:hover {{ background: #ececee; color: #272b33; }}
QPushButton#fmtBtn:checked {{ background: #e3e9f2; color: #1d4ed8;
    border: 1px solid #c6ccd4; }}
QPushButton#notesSizeBtn {{ padding: 0px; }}
QFrame#fmtSep {{ color: #d9dbde; margin: 4px 2px; }}
QTextEdit#noteEditor {{ font-size: 14px; }}
QToolTip {{ background: rgba(255, 255, 255, 0.72); color: #272b33; border: 1px solid #d9dbde;
    padding: 5px 8px; border-radius: 8px; }}
QFrame#offlineBanner {{ background: rgba(180, 140, 20, 0.12);
    border-bottom: 1px solid #c9a83c; }}
QLabel#offlineBannerText {{ color: #6b5510; font-size: 12px; font-weight: 600; }}
QPushButton#offlineBannerClose {{ background: transparent; border: none; border-radius: 6px; }}
QPushButton#offlineBannerClose:hover {{ background: rgba(0, 0, 0, 0.08); }}
QPushButton#offlineIndicator {{ background: transparent; border: none; border-radius: 6px; }}
QPushButton#offlineIndicator:hover {{ background: rgba(0, 0, 0, 0.06); }}
QLabel#pagePlaceholder {{ color: #6a7078; font-size: 13px; }}
QMessageBox {{ background: #ffffff; }}
QMessageBox QLabel {{ color: #272b33; }}
QInputDialog QLabel {{ color: #272b33; }}

/* ---------- custom window chrome ---------- */
QFrame#windowFrame {{ background: #f7f7f8; border: 1px solid #d9dbde; border-radius: 12px; }}
/* v1.4.0 item 12: square corners when maximized (no edge gaps) */
QFrame#windowFrame[squareCorners="true"] {{ border-radius: 0px; border: none; }}
QFrame#titleBar {{ background: transparent; border: none; border-bottom: 1px solid #e3e4e6; }}
QLabel#titleBarLabel {{ color: #474c54; font-size: 12px; font-weight: 600; background: transparent; }}
QPushButton#winBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #474c54; font-size: 12px; padding: 6px 12px; }}
QPushButton#winBtn:hover {{ background: #e3e4e6; color: #1c1f24; }}
QPushButton#winCloseBtn {{ background: transparent; border: none; border-radius: 6px;
    color: #474c54; font-size: 12px; padding: 6px 12px; }}
QPushButton#winCloseBtn:hover {{ background: #e81123; color: #ffffff; }}

/* ---------- rack type tags ---------- */
/* V1.9.75 (workstream L): 14px -- one step above the 13px
   distributor value; on the light sheet "white" becomes the
   theme's strong text colour (white on the pale tag ground
   would vanish). Tag height held by the reduced padding. */
/* V1.9.76 (scope additions 3+8): boxless, like the dark
   sheet -- the fill is gone on both themes. */
/* V1.9.78 (WS-E1): the outline rectangle returns on both
   themes (see the dark sheet's note). On the light sheet the
   outline carries the light theme's rack text colour #26282c
   (a white outline would vanish on the white card), the
   infill stays transparent, and the padding drops by the
   border width so the box geometry is unchanged. */
QPushButton[role="rackTag"] {{ border: 1px solid #26282c; border-radius: 6px; padding: 3px 5px;
    font-size: 14px; font-weight: 600; background: transparent; color: #26282c; }}
QLabel[role="rackTag"] {{ border: 1px solid #26282c; border-radius: 6px; padding: 3px 5px;
    font-size: 14px; font-weight: 600; background: transparent; color: #26282c; }}

/* ---------- notes editor ---------- */
QTextEdit#notesEdit {{ padding: 10px; }}

/* ---------- toolbar ---------- */
QFrame#toolBar {{ background: transparent; border: none; }}
QLabel#selCountLabel {{ color: #4e535b; font-size: 12px; font-weight: 600; }}
QLabel#sortLabel {{ color: #4e535b; font-size: 12px; }}
QLabel#countLabel {{ color: #4e535b; font-size: 12px; }}

/* ---------- sidebar ---------- */
QFrame#sideBar {{ background: #ececee; border: none; border-right: 1px solid #d9dbde; }}
/* V1.9.75 (workstream F): single-path painted outlines (see
   the dark sheet); border: none here, text colours only. */
QPushButton#navBtn {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 12px; font-size: 13px; font-weight: 600; color: #4d4d4d;
    text-align: left; }}
/* V1.9.71: collapsed-rail centring (see the dark sheet). */
QPushButton#navBtn[collapsed="true"] {{ text-align: center; }}
/* V1.9.69: outline-only hover/pressed (see the dark sheet). */
QPushButton#navBtn:hover {{ background: transparent; color: #272b33; }}
QPushButton#navBtn:pressed {{ background: transparent; color: #1f1f1f; }}
QPushButton#navBtn:checked {{ background: transparent; color: #1f1f1f; }}
QFrame#navPill {{ background: transparent; border: none; }}
QLabel#sideFoot {{ color: #4e535b; font-size: 10px; }}
QPushButton#navToggle {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 0px; font-size: 15px; font-weight: 600; color: #474c54;
    text-align: center; }}
/* V1.9.69: outline-only hover/pressed, same rule as #navBtn.
   V1.9.75 (workstream F): painted single-path; colours only. */
QPushButton#navToggle:hover {{ background: transparent; color: #272b33; }}
QPushButton#navToggle:pressed {{ background: transparent; color: #1f1f1f; }}
/* v1.4.0 item 16: Settings sidebar nav - restrained, no blue tint. */
QPushButton#settingsNav {{ background: transparent; border: none; border-radius: 10px;
    padding: 10px 14px; font-size: 13px; color: #474c54; text-align: left; }}
/* V1.9.51: outline-only selected state (see the dark sheet). */
QPushButton#settingsNav:hover {{ background: transparent; color: #272b33; }}
QPushButton#settingsNav:checked {{ background: transparent; color: #23262c; }}

/* ---------- CRM ---------- */
QLabel#kindPill {{ background: #e3e9f2; color: #1d4ed8; border-radius: 6px;
    padding: 4px 12px; font-size: 11px; font-weight: 600; }}
QPushButton#taskLink {{ background: transparent; border: 1px solid #e3e4e6;
    border-radius: 9px; padding: 9px 12px; text-align: left;
    color: #272b33; font-size: 12px; font-weight: 600; }}
QPushButton#taskLink:hover {{ background: #f0f0f1; border-color: #c9d5e8; color: #1d4ed8; }}
/* W17 (1.9.80): the connected-task row's right-aligned Date Added
   label -- same type and colour as the row's own text. */
QLabel#taskLinkDate {{ background: transparent; color: #272b33;
    font-size: 12px; font-weight: 600; }}

/* v1.4.0 item 15: inline SDC badge in the task detail window */
QLabel#sdcBadge {{ border-radius: 6px; padding: 2px 8px; font-size: 11px;
    font-weight: 600; }}
/* V1.9.76 (scope addition 13): text only -- severity colours
   unchanged (low #4e535b / watch #b45309 / high #b91c1c). */
QLabel#sdcBadge[sdcSeverity="low"] {{ background: transparent; color: #4e535b;
    border: none; }}
QLabel#sdcBadge[sdcSeverity="watch"] {{ background: transparent; color: #b45309;
    border: none; }}
QLabel#sdcBadge[sdcSeverity="high"] {{ background: transparent; color: #b91c1c;
    border: none; }}
/* V1.9.76 (scope addition 13): text only (light) -- see dark note. */
QPushButton#ibcChip {{ background: transparent; color: #26282c;
    border: none; border-radius: 6px; padding: 2px 8px;
    font-size: 11px; font-weight: 700; }}
QPushButton#ibcChip:hover {{ color: #26282c; }}
QPushButton#ibcChip[flag="true"] {{ color: #b45309;
    border: none; }}
QPushButton#ibcChip[flag="true"]:hover {{ color: #b45309; }}
QPushButton#iconBtn {{ background: transparent; border: none; border-radius: 7px;
    padding: 7px; }}
/* V1.9.74: no gray fill on hover (outline-only rule). */
QPushButton#iconBtn:hover {{ background: transparent; }}
/* V1.9.75 (workstream B): bare red ✕; the red outline shows
   ONLY on hover; never a fill (light theme). */
QPushButton#cardRemoveBtn {{ background: transparent;
    border: 1px solid transparent; border-radius: 7px; padding: 6px; }}
QPushButton#cardRemoveBtn:hover {{ background: transparent;
    border-color: #c0272d; }}
QPushButton#cardRemoveBtn:pressed {{ background: transparent;
    border-color: #e5484d; }}

/* ---------- queue board ---------- */
QFrame#queueColumn {{ background: #ececee; border: 1px solid #d9dbde; border-radius: 14px; }}
QFrame#queueColumn[dropActive="true"] {{ border: 1px solid #2563eb; background: #e8edf3; }}
QFrame#dropPlaceholder {{ background: rgba(37, 99, 235, 0.06);
    border: 1.5px dashed #2563eb; border-radius: 14px; }}
QLabel#dropPlaceholderText {{ color: #1d4ed8; font-size: 12px; font-weight: 600; }}
QLabel#colTitle {{ font-size: 13px; font-weight: 700; color: #1c1f24; }}
QLabel#countBadge {{ background: #ffffff; color: #474c54; border-radius: 6px;
    padding: 2px 9px; font-size: 11px; font-weight: 700; }}
QFrame#queueCard {{ background: #ffffff; border: 1px solid #e3e4e6; border-radius: 12px; }}
QFrame#queueCard:hover {{ border-color: #bfc4cb; }}
QLabel#queueQuote {{ font-size: 16px; font-weight: 700; color: #ffffff;
    background: #2563eb; padding: 6px 14px;
    border-top-left-radius: 0px; border-top-right-radius: 0px;
    border-bottom-right-radius: 11px; border-bottom-left-radius: 0px; }}
/* queue-card notes: label-like read-only scroller (see QueueCard._fit_notes) */
QTextEdit#queueDesc {{ background: transparent; border: none; padding: 0px;
    color: #3d4149;
    selection-background-color: #2563eb; selection-color: #ffffff; }}
QLabel#queueMeta {{ font-size: 11px; color: #474c54; }}
QLabel#dropHint {{ color: #4e535b; font-size: 12px; border: 1px dashed #ccd0d6;
    border-radius: 10px; padding: 20px 10px; }}
QLabel#miniPill {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; }}
QLabel#miniPill[statusState="in_process"] {{ background: #e3e9f2; color: #1d4ed8; }}
QLabel#miniPill[statusState="on_hold"] {{ background: #f5efdb; color: #b45309; }}
QLabel#miniPill[statusState="completed"] {{ background: #e4f0e6; color: #15803d; }}
QLabel#miniPill[statusState="canceled"] {{ background: #e8ebf0; color: #5f666b; }}
/* v1.4.0 item 10: amber "Waiting: …" chip on queue cards */
QLabel#waitingChip {{ border: none; border-radius: 9px; padding: 3px 10px;
    font-size: 10px; font-weight: 700; background: #f5efdb; color: #b45309; }}
QCheckBox#queueCheck {{ color: #3a3d44; font-size: 13px; spacing: 10px; }}

/* ---------- settings: folder creation guidance (warn/missing states) ---------- */
QLabel#folderHint[warn="true"] {{ color: #b91c1c; font-weight: 600; }}
QLineEdit[missing="true"] {{ border: 1px solid #c0392b; }}
QLabel#verifyItem[ok="true"] {{ color: #15803d; }}
QLabel#verifyItem[ok="false"] {{ color: #b91c1c; font-weight: 600; }}
"""

THEMES = {"light": LIGHT, "dark": DARK}


def saved_theme():
    return QSettings("TaskListApp", "TaskList").value("theme", "dark")


def save_theme(name):
    QSettings("TaskListApp", "TaskList").setValue("theme", name)


# ------------------------------------------------------------- glass dropdowns
# V1.9.17 (user correction): optional frosted-glass DROPDOWNS — he
# asked for dropdowns glassmorphic, never "glass popups", and menus
# stay solid. OFF by default, and the old "glass_popups" key's value
# does not carry over: glass dropdowns are opt-in under the new key.
# Qt cannot blur what sits behind a popup on its own, so this is
# frosted translucency, not true backdrop blur — stated honestly.
def saved_glass():
    v = QSettings("TaskListApp", "TaskList").value("glass_dropdowns", False)
    return str(v).lower() in ("true", "1", "yes") if isinstance(v, str) \
        else bool(v)


def save_glass(on):
    QSettings("TaskListApp", "TaskList").setValue("glass_dropdowns", bool(on))


def _glass_qss(name):
    if name == "light":
        bg = "rgba(255, 255, 255, 0.85)"
        rim = "rgba(0, 0, 0, 0.10)"
    else:
        bg = "rgba(26, 28, 33, 0.85)"
        rim = "rgba(255, 255, 255, 0.14)"
    # V1.9.17: dropdowns ONLY. Menus stay solid — the V1.9.16 version
    # glassed menus too, which the user never asked for.
    # V1.9.18: glass also covers the TagPopup scope list (QFrame
    # #scopePopup) with a 1px light rim, and combo views get the rim
    # too — the rim is what reads as "glass" against the page behind
    # it. This sheet is appended AFTER the base theme and only when
    # the Glass dropdowns toggle is ON (saved_glass()).
    return f"""
QComboBox QAbstractItemView {{ background: {bg}; border: 1px solid {rim}; }}
QComboBox#sortBox QAbstractItemView {{ background: {bg}; border: 1px solid {rim}; }}
QFrame#scopePopup {{ background: {bg}; border: 1px solid {rim}; }}
"""


# ------------------------------------------------------------- accent color
# V1.9.10: user-chosen accent. The themes are authored in one blue family;
# instead of duplicating every rule per accent, the finished QSS is
# hue-shifted: any blue-family colour (hue 195-245°, saturation >= 0.15)
# keeps its lightness/saturation and takes the accent's hue. Semantic
# colours (green completed, red danger, purple/teal scope chips) sit
# outside that hue band and never move. The default accent IS the native
# blue, so the untouched app looks exactly as before.
DEFAULT_ACCENT = "#2f6fed"
_ACCENT_HEX_RE = re.compile(r"#([0-9a-fA-F]{6})\b")
_ACCENT_RGBA_RE = re.compile(
    r"rgba\(\s*(\d+),\s*(\d+),\s*(\d+),\s*([0-9.]+)\s*\)")


def saved_accent():
    v = str(QSettings("TaskListApp", "TaskList").value(
        "accent_color", "") or "")
    return v.lower() if re.fullmatch(r"#[0-9a-fA-F]{6}", v) else DEFAULT_ACCENT


def save_accent(hex_color):
    if re.fullmatch(r"#[0-9a-fA-F]{6}", str(hex_color or "")):
        QSettings("TaskListApp", "TaskList").setValue(
            "accent_color", str(hex_color).lower())


def _shifted_rgb(r, g, b, target_h, desaturate):
    import colorsys
    h, l, s = colorsys.rgb_to_hls(r / 255.0, g / 255.0, b / 255.0)
    if 195.0 <= h * 360.0 <= 245.0 and s >= 0.15:
        if desaturate:
            s *= 0.15
        r2, g2, b2 = colorsys.hls_to_rgb(target_h, l, s)
        return round(r2 * 255), round(g2 * 255), round(b2 * 255)
    return r, g, b


def apply_accent_shift(qss, accent_hex=None):
    """Hue-shift the blue family in ``qss`` to the saved accent colour."""
    accent = QColor(accent_hex or saved_accent())
    if not accent.isValid():
        return qss
    if accent.name().lower() == DEFAULT_ACCENT:
        return qss
    target_h = accent.hueF()
    if target_h < 0:  # achromatic accent (gray) — desaturate the blues
        target_h = 218.0 / 360.0
        desaturate = True
    else:
        desaturate = accent.hslSaturationF() < 0.12

    def _hex_repl(m):
        v = int(m.group(1), 16)
        r, g, b = (v >> 16) & 255, (v >> 8) & 255, v & 255
        r, g, b = _shifted_rgb(r, g, b, target_h, desaturate)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _rgba_repl(m):
        r, g, b = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        r, g, b = _shifted_rgb(r, g, b, target_h, desaturate)
        return f"rgba({r}, {g}, {b}, {m.group(4)})"

    return _ACCENT_RGBA_RE.sub(_rgba_repl,
                               _ACCENT_HEX_RE.sub(_hex_repl, qss))


def shifted_color(hex_color, accent_hex=None):
    """One painted (non-QSS) colour, hue-shifted like the stylesheet."""
    c = QColor(hex_color)
    if not c.isValid():
        return hex_color
    accent = QColor(accent_hex or saved_accent())
    if not accent.isValid() or accent.name().lower() == DEFAULT_ACCENT:
        return hex_color
    out = apply_accent_shift(f"x:{hex_color};", accent.name())
    return out.split(":", 1)[1].rstrip(";")


def saved_font_family():
    """Font family override; "" means the bundled Inter (default)."""
    return QSettings("TaskListApp", "TaskList").value("font_family", "")


def save_font_family(family):
    QSettings("TaskListApp", "TaskList").setValue("font_family", family or "")


def saved_font_scale():
    """UI text scale factor; 1.0 = default size."""
    try:
        scale = float(QSettings("TaskListApp", "TaskList").value(
            "font_scale", 1.0))
    except (TypeError, ValueError):
        return 1.0
    return min(2.0, max(0.7, scale))


def save_font_scale(scale):
    try:
        scale = float(scale)
    except (TypeError, ValueError):
        scale = 1.0
    QSettings("TaskListApp", "TaskList").setValue(
        "font_scale", min(2.0, max(0.7, scale)))


# Every font-size in the QSS is absolute px. Scaling them here (after the
# template is formatted) makes the Settings > Font size choice apply to
# the whole UI, not just widgets that inherit the application font.
_FONT_SIZE_RE = re.compile(r"font-size:\s*([0-9]+(?:\.[0-9]+)?)px")


def _scale_font_sizes(qss, scale):
    if abs(scale - 1.0) < 0.001:
        return qss

    def _rep(m):
        return f"font-size: {float(m.group(1)) * scale:.1f}px"

    return _FONT_SIZE_RE.sub(_rep, qss)


# Placeholder text can't be styled through QSS, so it is set on the
# application palette here (per theme) to keep it legible.
_PLACEHOLDER_COLORS = {"dark": "#6b7078", "light": "#5f636b"}


def apply_theme(app, name):
    qss = _scale_font_sizes(THEMES.get(name, DARK), saved_font_scale())
    qss = apply_accent_shift(qss)
    # V1.9.25: glass is the BASE look for dropdowns now (user standing
    # order — the toggle is retired). The _glass_qss sheet is no longer
    # appended; its tint/rim live in the base combo rules above and in
    # TagPopup.paintEvent. saved_glass/save_glass/_glass_qss remain for
    # settings compatibility and tests.
    app.setStyleSheet(qss)
    pal = app.palette()
    pal.setColor(QPalette.PlaceholderText,
                 QColor(_PLACEHOLDER_COLORS.get(name, _PLACEHOLDER_COLORS["dark"])))
    app.setPalette(pal)
    # V1.9.17 (light-mode text artifacts): the grayscale-AA strategy
    # lives on the application font, but any widget that got an explicit
    # font (or a font resolved through a stylesheet) can lose the flag.
    # Sweep every live widget after the stylesheet lands so no text path
    # renders with ClearType fringes; later widgets inherit the app font.
    try:
        from PySide6.QtGui import QFont
        from PySide6.QtWidgets import QApplication
        for w in QApplication.allWidgets():
            try:
                f = w.font()
            except Exception:
                continue
            if f.styleStrategy() != QFont.StyleStrategy.NoSubpixelAntialias:
                f.setStyleStrategy(QFont.StyleStrategy.NoSubpixelAntialias)
                try:
                    w.setFont(f)
                except Exception:
                    pass
    except Exception:
        pass


def _mask_menu(menu):
    """Clip a menu's window to its rounded shape (the 8px QSS
    radius). Used by _MenuGlassFilter on Show, Resize and Paint.

    V1.9.74 (WS11): the mask comes from ui._rounded_mask -- the
    ONE shared rounded-mask construction (finely sampled true
    arcs). The local toFillPolygon() version flattened each
    corner to three chords with 22-degree kinks, so a menu's
    silhouette stepped where its painted rim curved smooth."""
    try:
        from tasklist.ui import _rounded_mask
        # V1.9.78 (WS-B/B2): grow_rb -- the menu's rim stroke outer
        # half sits in the window's outermost device row/column on
        # the right/bottom, which the platform window region drops
        # (image-560: left/top rim whole, right/bottom clipped).
        # The slack is mask-only: no geometry, frost or tint change.
        _rounded_mask(menu, 8, grow_rb=True)
    except Exception:
        try:
            path = QPainterPath()
            path.addRoundedRect(QRectF(menu.rect()), 8, 8)
            menu.setMask(QRegion(path.toFillPolygon().toPolygon()))
        except Exception:
            pass


class _MenuGlassFilter(QObject):
    """Keeps a menu's WINDOW clipped to its rounded shape.

    V1.9.30 (user screenshots, Outcome pill menu): translucency alone
    (the V1.9.16 fix) did not stop square corners on his machine --
    the selected item's square background still poked past the
    rounded corner. The guarantee that cannot be painted around is a
    window MASK in the menu's QSS radius (8px): with the window
    region clipped round, nothing -- background, selection, or
    compositor -- can put a square corner on screen. Re-applied on
    every Show/Resize; on Show it also asks for the DWM blur-behind
    so the menu's translucent QSS tint reads as frosted glass.
    """

    def eventFilter(self, watched, event):  # noqa: N802 (Qt virtual)
        if event.type() == QEvent.Paint:
            # V1.9.49: re-assert the mask on the first paint too
            # -- a menu whose Show arrived before its final size
            # (menubar popups are sized by the bar as they open)
            # could otherwise paint one frame with a stale or
            # empty mask and read as sharp corners.
            _mask_menu(watched)
            # V1.9.45: the app's own frost goes UNDER the menu's
            # QSS tint (painted by the menu itself right after this
            # filter returns) -- a blurred snapshot of what is
            # behind the menu, clipped to the same rounded shape.
            try:
                from tasklist.ui import paint_frost
                _p = QPainter(watched)
                paint_frost(watched, _p, 8)
                _p.end()
            except Exception:
                pass
            return False
        if event.type() in (QEvent.Show, QEvent.Resize):
            _mask_menu(watched)
            if event.type() == QEvent.Show:
                # V1.9.80 (W22): submenus sit beside their parent
                # (see _submenu_beside_parent) -- corrected before
                # the capture so the snapshot is at the final frame.
                _submenu_beside_parent(watched)
                try:
                    watched._w22_matching_recaptures = 0
                except Exception:
                    pass
                try:
                    from tasklist.ui import capture_frost
                    capture_frost(watched)
                except Exception:
                    pass
                # V1.9.50: one more mask pass once the menu's
                # final size has settled (menubar popups are
                # sized by the bar as they open; a mask built
                # from a mid-layout size can leave the last
                # corners square on the user's machine even
                # though every earlier pass ran).
                # V1.9.76 (scope addition 10): the settle pass
                # also RE-CAPTURES the frost and repaints -- the
                # show-time snapshot can predate the menu's
                # final position on Windows, leaving the plain
                # tint (the opaque read in his 2026-11-16 menu
                # photos) even though the capture machinery ran.
                def _settle(m=watched):
                    _mask_menu(m)
                    try:
                        if m.isVisible():
                            # V1.9.80 (W22): same bound as
                            # GlassMenu._recapture_frost -- this
                            # settle is the ONE budgeted
                            # matching-frame recapture per showing
                            # (the approved recipe); it is the
                            # first, so it always runs when a live
                            # snapshot matches, and the budget
                            # records it.
                            if getattr(m, "_frost_pixmap", None) \
                                    is not None and getattr(
                                        m, "_frost_frame", None) \
                                    == m.frameGeometry():
                                if getattr(
                                        m, "_w22_matching_recaptures",
                                        0) >= 1:
                                    return
                                m._w22_matching_recaptures = \
                                    getattr(
                                        m, "_w22_matching_recaptures",
                                        0) + 1
                            from tasklist.ui import capture_frost
                            capture_frost(m)
                            m.update()
                    except Exception:
                        pass
                try:
                    QTimer.singleShot(60, _settle)
                except Exception:
                    pass
        return False


def apply_menu_glass(menu):
    """The full glass treatment for a QMenu: translucent window,
    rounded window mask (via _MenuGlassFilter), blur-behind on show.
    Every QMenu in the app goes through here (themed_menu, or the
    menubar walk in app.py for QMenuBar's internally-created menus).
    """
    if menu.property("_glass_menu"):
        # V1.9.51: a GlassMenu paints its own frost (see below);
        # the filter machinery would only double-paint under it.
        # V1.9.60: it also masks its OWN window (Show/Resize/
        # Paint) -- before this, the skip left GlassMenus as the
        # only unmasked menus in the app, and their corners were
        # the black squares in the user's 1.9.59 Surface photo.
        return menu
    menu.setAttribute(Qt.WA_TranslucentBackground, True)
    # V1.9.50 (user, Help menu report): the OS drop shadow of a
    # popup window is drawn from the window's RECTANGLE on his
    # machine -- a dark squarish halo hugging the top corners
    # that reads as "sharp corners" even with the body masked
    # round (his screenshot, zoomed: the body IS round, the
    # halo is not). The app's own glass popups already carry
    # NoDropShadowWindowHint for this exact reason; menus get
    # it too -- the rim light is the menu's edge language.
    try:
        menu.setWindowFlags(
            menu.windowFlags() | Qt.NoDropShadowWindowHint)
    except Exception:
        pass
    if not menu.property("_glass_filter"):
        menu.installEventFilter(_MenuGlassFilter(menu))
        menu.setProperty("_glass_filter", True)
    return menu


class GlassMenu(QMenu):
    """A QMenu that paints its OWN frosted glass (V1.9.51).

    The user's verdict on 1.9.49, with screenshots: the combo
    dropdowns are "GREAT" and are the standard for frosted glass;
    every menu (File menu, card pill menus, context menus) was
    still a BLACK SLAB, and one menu's bottom corner kept a sharp
    square behind its rounded corner. Four releases of menu fixes
    (translucency flags, window masks re-asserted on timers, an
    event filter painting frost BEFORE the menu's own paint ran)
    all depended on machinery outside the menu's paint cycle --
    and on his machine the menu's QSS background slab painted
    over whatever the filter laid down, and a mask built from a
    mid-layout size left the last corner square.

    This class removes every one of those dependencies, by being
    built exactly like the dropdown he approved (_GlassComboPopup
    in ui.py):

    - translucent window from construction, no drop shadow;
    - paintEvent paints the glass FIRST -- the captured frost
      snapshot (real blur of what is behind), the accepted tint
      over it (140 over frost, 150 fallback), the rim stroked on
      an inset path -- inside the menu's own rounded shape, so
      the corners are transparent BY CONSTRUCTION (no mask);
    - an instance stylesheet retires the app QSS's background
      slab for this menu only, so the normal menu paint that
      follows (items, separators, selection) lands on the glass
      instead of burying it. Item rules still come from the app
      sheet; only background/border are overridden.
    """

    RADIUS = 8

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        try:
            # V1.9.61: Frameless completes the combo-popup recipe
            # (the user's global standard) -- without it the DWM
            # frame/shadow region paints black wedges outside
            # the rounded glass even with the mask (his Help
            # menu photo, 2026-11-13).
            self.setWindowFlags(
                self.windowFlags() | Qt.NoDropShadowWindowHint
                | Qt.FramelessWindowHint)
        except Exception:
            pass
        self.setProperty("_glass_menu", True)
        self.setStyleSheet(
            "QMenu { background: transparent; border: none; }")
        self._frost_pixmap = None
        # V1.9.74 (workstream 26): pen/touch drag scrolling for
        # over-tall menus, the same QScroller gesture the popup
        # lists use -- a drag scrolls, a tap still activates.
        # V1.9.75 (workstream I): the gesture listens for MOUSE
        # events, which the Surface pen never sends (it arrives
        # as tablet events) -- install the shared pen bridge so
        # pen strokes replay as mouse events here too.
        # V1.9.76 fix round (FIX-2): the bridge install was
        # dropped during the scope-(10) glass restoration and
        # the verifier's A/B convicted it -- a pen TAP on a menu
        # fired the action in 1.9.75 and did nothing in 1.9.76.
        # Restored exactly; the glass construction is untouched
        # (the bridge only replays pen tablet events as mouse
        # events, the path a tap needs to activate an item).
        try:
            from PySide6.QtWidgets import QScroller
            QScroller.grabGesture(
                self, QScroller.LeftMouseButtonGesture)
            from tasklist.ui import install_pen_tablet_bridge
            install_pen_tablet_bridge(self)
        except Exception:
            pass

    def sizeHint(self):  # noqa: N802 (Qt virtual)
        """V1.9.76 (scope addition 10 addendum, user photos
        image-524/525): exact-fit width, computed from the font
        metrics and the QSS recipe -- never the platform
        style's hint. On the user's Windows the style's hint
        overshoots the widest item by a wide gutter, so the
        menus rendered far wider than their contents. Recipe:
        widest item text + item padding (14 + 26 from the QSS)
        + menu padding (5 + 5) + 2 border; +26 when any action
        carries an icon or a checkmark (their gutter). Height
        stays the style's."""
        hint = super().sizeHint()
        try:
            from PySide6.QtGui import QFontMetrics
            fm = QFontMetrics(self.font())
            text_w = 0
            gutter = 0
            for a in self.actions():
                if a.isSeparator():
                    continue
                t = a.text().replace("&&", "\x00").replace(
                    "&", "").replace("\x00", "&")
                text_w = max(text_w, fm.horizontalAdvance(t))
                if a.isCheckable() or (a.icon() is not None
                                       and not a.icon().isNull()):
                    gutter = 26
            if text_w > 0:
                hint.setWidth(text_w + 52 + gutter)
        except Exception:
            pass
        return hint

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        _mask_menu(self)
        # V1.9.80 (W22): a SUBMENU must sit BESIDE its parent,
        # never on top of it. Qt's own submenu placement
        # overlaps the parent by the style's submenu-overlap
        # (measured: 3 logical px at scale 1.0, 5 at 2.0 --
        # pixel-confirmed in the user's field photo image-582,
        # where the submenu's left rim lands 3 px inside the
        # parent's right rim and covers the parent's rim for
        # the submenu's whole height). Correct the position
        # BEFORE the frost capture below, so the snapshot is
        # taken at the final beside-parent frame.
        self._beside_parent()
        # V1.9.80 (W22): per-showing budget for recaptures at
        # an already-matching frame (see _recapture_frost):
        # exactly ONE is approved -- the +60 ms settle below,
        # whose output IS the 1.9.77 baseline (test_v1978 B2's
        # GlassMenu samples are that settle generation,
        # measured (71,21,78) over magenta). Reset per show.
        self._w22_matching_recaptures = 0
        try:
            from tasklist.ui import capture_frost
            capture_frost(self)
        except Exception:
            pass
        # V1.9.76 (scope addition 10): settle re-capture. The
        # show-time snapshot can be taken before the menu
        # reaches its final on-screen position on Windows (the
        # popup is positioned by the style as it opens), so the
        # first capture can hold the wrong region or a dead
        # frame and the menu falls back to the plain tint --
        # the opaque read in the user's photos. One more
        # capture a beat later, once the menu has settled,
        # then repaint with the real frost. (The V1.9.41
        # settle lesson, applied to menus.)
        try:
            QTimer.singleShot(60, self._recapture_frost)
        except Exception:
            pass

    def _beside_parent(self):
        """V1.9.80 (W22): see _submenu_beside_parent below."""
        _submenu_beside_parent(self)

    def _recapture_frost(self):
        try:
            if self.isVisible():
                # V1.9.80 (W22): every recapture arm funnels
                # here (settle timer, W11 resize/move schedule,
                # paint_frost's recovery arm, capture_frost's
                # dead-frame retry). A same-size translation of
                # a few px since the snapshot is positioning
                # jitter: re-label the snapshot's frame instead
                # of capturing (see _w11_schedule_recapture for
                # the full reasoning) -- this also covers arms
                # raised by paint_frost itself, whose mismatch
                # may be exactly this jitter presenting one
                # frame late.
                _pm = getattr(self, "_frost_pixmap", None)
                _fr = getattr(self, "_frost_frame", None)
                if _pm is not None and _fr is not None:
                    from PySide6.QtCore import QRect
                    _cur = self.frameGeometry()
                    if _fr.size() == _cur.size() \
                            and abs(_fr.x() - _cur.x()) <= 4 \
                            and abs(_fr.y() - _cur.y()) <= 4 \
                            and _fr != _cur:
                        self._frost_frame = QRect(_cur)
                        self._frost_recovery_epoch = QRect(_cur)
                        self.update()
                        return
                # V1.9.80 (W22): bound the SELF-CAPTURE chain.
                # On a real compositor (DWM), a capture taken
                # after the menu is presented grabs the menu's
                # OWN tinted paint, and each such recapture
                # multiplies the stored backdrop variation by
                # ~0.45 (measured with a composited-screen grab
                # model: stored-grid spread 119 -> 54 after one
                # post-presentation capture). ONE such capture
                # is the approved recipe -- the +60 ms settle
                # recapture, whose output is exactly the 1.9.77
                # baseline the user approved (test_v1978 B2's
                # GlassMenu samples (71,21,78) over magenta are
                # that generation, not the clean show capture's
                # (128,14,133)). What the field photo image-582
                # convicts is the chain running PAST it: settle
                # + open-time repositioning arms + paint-recovery
                # arms each adding a generation until the frost
                # converges to the flat tint (both menus there
                # are the exact tint-fallback composite
                # (20,21,26) over the board and (25,33,51) over
                # the header -- no frost variation anywhere).
                # So: at an already-matching frame, allow the
                # ONE budgeted settle recapture per showing and
                # skip every later matching-frame recapture.
                # Recaptures with NO snapshot (dead/discarded
                # show capture -- W11's retry chain) or with a
                # genuinely moved frame (W11's frame-truth rule)
                # are never blocked by this budget.
                if getattr(self, "_frost_pixmap", None) is not None \
                        and getattr(self, "_frost_frame", None) \
                        == self.frameGeometry():
                    if getattr(self, "_w22_matching_recaptures",
                               0) >= 1:
                        return
                    self._w22_matching_recaptures = \
                        getattr(self, "_w22_matching_recaptures",
                                0) + 1
                from tasklist.ui import capture_frost
                capture_frost(self)
                self.update()
        except Exception:
            pass

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        _mask_menu(self)
        self._w11_schedule_recapture()

    def moveEvent(self, event):  # noqa: N802 (Qt virtual)
        super().moveEvent(event)
        # V1.9.80 (W11): the platform positions a menu as it
        # opens (see the showEvent note) -- a move after the
        # show-time capture is the same invalidation as a
        # resize, and gets the same settle re-capture.
        self._w11_schedule_recapture()

    def _w11_schedule_recapture(self):
        """V1.9.80 (W11): a resize/move after the show-time
        capture invalidates the frost snapshot (paint_frost's
        geometry guard then paints the flat tint for the menu's
        whole life -- the detail pills' menus in images
        566/567). Re-take the frost on the settle timer, the
        class's own approved timing. STRICTLY guarded: only
        when a stored snapshot exists AND its frame no longer
        matches, and only one arm at a time (capture_frost
        discharges the arm) -- an unguarded schedule on every
        move/resize chained self-captures during popup
        positioning and measurably darkened the frost away
        from the 1.9.77 baseline samples (sim1978
        glass_baseline, scale 1.0: (71,21,78) -> (46,25,54))."""
        try:
            if getattr(self, "_frost_frame", None) is not None \
                    and self._frost_frame != self.frameGeometry():
                from PySide6.QtCore import QRect
                _cur = self.frameGeometry()
                _stored = self._frost_frame
                if getattr(self, "_frost_pixmap", None) is not None \
                        and _stored.size() == _cur.size() \
                        and abs(_stored.x() - _cur.x()) <= 4 \
                        and abs(_stored.y() - _cur.y()) <= 4:
                    # V1.9.80 (W22): a same-size translation of a
                    # few px is platform POSITIONING JITTER as the
                    # menu opens, not a new backdrop: the stored
                    # snapshot is a factor-9-blurred backdrop, for
                    # which a <=4 px shift is invisible, while a
                    # recapture here is a SELF-capture (the menu
                    # is already presented) that measurably
                    # converges the frost toward the flat tint --
                    # the chain that produced the field slab.
                    # Re-label the snapshot's frame to the
                    # presented frame and arm nothing. Genuine
                    # geometry changes (resize, a move beyond the
                    # jitter bound, an edge flip) still take the
                    # recapture path below, exactly as W11 built
                    # it (the W11 gate's own recovery probes move
                    # +18 px / resize +14 px -- far outside this
                    # bound, and still gated green).
                    self._frost_frame = QRect(_cur)
                    self._frost_recovery_epoch = QRect(_cur)
                    return
                if getattr(self, "_frost_recovery_pending", False):
                    # V1.9.80 (W22): an arm is already pending and
                    # capture_frost reads the frame at capture
                    # time, so the pending arm will land at THIS
                    # newest frame -- retarget its epoch to it, so
                    # paint_frost does not arm a second, chained
                    # self-capture for the same final frame.
                    self._frost_recovery_epoch = QRect(
                        self.frameGeometry())
                    return
                if getattr(self, "_frost_recovery_epoch",
                           None) == self.frameGeometry():
                    return
                self._frost_recovery_epoch = QRect(
                    self.frameGeometry())
                self._frost_recovery_pending = True
                QTimer.singleShot(60, self._recapture_frost)
        except Exception:
            pass

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        # V1.9.60: re-assert the window mask on paint too (the
        # _MenuGlassFilter rhythm for plain menus) -- a menubar
        # menu can reach its final size after Show, and a stale
        # or empty mask is exactly the sharp-corner frame the
        # user photographed on 1.9.59.
        _mask_menu(self)
        try:
            from tasklist.ui import glass_colors, paint_frost
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing, True)
            fill, rim = glass_colors()
            fill = QColor(fill)
            if paint_frost(self, painter, self.RADIUS):
                fill.setAlpha(140)
            else:
                fill.setAlpha(150)
            path = QPainterPath()
            path.addRoundedRect(QRectF(self.rect()),
                                self.RADIUS, self.RADIUS)
            painter.setPen(Qt.NoPen)
            painter.setBrush(fill)
            painter.drawPath(path)
            rim_path = QPainterPath()
            rim_path.addRoundedRect(
                QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
                self.RADIUS - 0.5, self.RADIUS - 0.5)
            painter.setPen(QPen(rim, 1))
            painter.setBrush(Qt.NoBrush)
            painter.drawPath(rim_path)
            painter.end()
        except Exception:
            pass
        super().paintEvent(event)

    def addMenu(self, *args):  # noqa: N802 (Qt name)
        """Submenus are GlassMenus too (QMenu.addMenu(str) would
        build a plain QMenu internally)."""
        if len(args) == 1 and isinstance(args[0], str):
            sub = GlassMenu(self)
            sub.setTitle(args[0])
            self.addAction(sub.menuAction())
            return sub
        if len(args) == 2 and isinstance(args[1], str):
            sub = GlassMenu(self)
            sub.setIcon(args[0])
            sub.setTitle(args[1])
            self.addAction(sub.menuAction())
            return sub
        return super().addMenu(*args)


def _submenu_beside_parent(menu):
    """V1.9.80 (W22): if `menu` is a submenu (its parent is a
    visible QMenu) and Qt placed it overlapping the parent,
    shift it horizontally until the two frames are exactly
    adjacent -- on the side Qt chose, flipping to the parent's
    other side when the chosen side would run off the screen.
    Adjacent means an EMPTY intersection (submenu.left ==
    parent.right + 1, or submenu.right == parent.left - 1):
    no shared rim column, no gap a hover could fall through.
    Top-level menus (menubar menus, context menus, pill menus)
    are untouched: their parent is not a QMenu. Shared by
    GlassMenu.showEvent and _MenuGlassFilter (plain QMenus --
    Qt-internal context menus -- get the same correction)."""
    try:
        parent = menu.parent()
        if not isinstance(parent, QMenu) or not parent.isVisible():
            return
        pf = parent.frameGeometry()
        mf = menu.frameGeometry()
        if not pf.intersects(mf):
            return
        try:
            avail = menu.screen().availableGeometry()
        except Exception:
            avail = pf
        if mf.center().x() >= pf.center().x():
            nx = pf.right() + 1
            if nx + mf.width() - 1 > avail.right():
                nx = pf.left() - mf.width()
        else:
            nx = pf.left() - mf.width()
            if nx < avail.left():
                nx = pf.right() + 1
        # Last resort (a screen too narrow for both): clamp the
        # chosen side into the screen rather than lose the menu
        # off-screen entirely.
        nx = max(avail.left(),
                 min(nx, avail.right() - mf.width() + 1))
        if nx != mf.x():
            menu.move(nx, mf.y())
    except Exception:
        pass


def themed_menu(parent=None):
    """A QMenu that is GLASS with fully rounded corners.

    V1.9.51: the menu IS a GlassMenu -- it paints the same frosted
    glass as the combo dropdowns the user made the standard. (The
    V1.9.16-V1.9.50 history of translucency flags, window masks
    and filter-painted frost is in GlassMenu's docstring; the
    filter path remains only for Qt-internal menus this factory
    never sees, via _GlobalSurfaceFilter.)
    """
    return GlassMenu(parent)
