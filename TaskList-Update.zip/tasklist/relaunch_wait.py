"""Task List stale-mirror relaunch waiter -- launched detached
by the app's stale-mirror offer accept path with the BUNDLED
python (which an update never replaces), mirroring the
apply_update.py helper's pattern:

    pythonw.exe relaunch_wait.py --wait-relaunch <app_pid>
        <launcher_path> <data_dir>

V1.9.80 (W1b): the stale-mirror accept used to Popen the
launcher and quit IMMEDIATELY. Under the V1.9.80 early
single-instance gate, the relaunched process decides instance
ownership at startup (the datahome seed lock, re-asserted as
main()'s first gate): if this process is still alive at that
moment -- shutdown carries a final sync/backup and can take
seconds, while a launcher whose mirror needs no copy reaches
the app start in well under one -- the newcomer sees a LIVE
lock holder, hands off, and exits; this process then finishes
exiting and NO app is running (convicted end-to-end in
sim1980/checks_w1b.py: zero windows 10s after the accept).
The update-apply hop never had this race because its helper
waits for the app pid to exit before relaunching. This waiter
gives the stale-mirror hop the same shape: it waits for the
app pid to exit (180s cap, then it relaunches anyway -- the
helper's semantics), and only then starts the launcher.

Stdlib only; no PySide6 -- this runs while the app exits.
A single-waiter lock (<data_dir>/relaunch_wait.lock) keeps
waiters from multiplying, exactly like the apply helper's.
The relaunch strips TASKLIST_LAUNCH_DEPTH from the child's
environment (the launcher's lineage guard refuses a start
carrying it; this hop is intentional -- see
taskbar.relaunch_env, whose environment the caller already
used when spawning this waiter).
"""
import os
import subprocess
import sys
import time


def _upd_log(data_dir, msg):
    try:
        with open(os.path.join(data_dir, "update.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except Exception:
        pass


def _pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x00100000, False, pid)
        if not handle:
            return False
        try:
            # WAIT_OBJECT_0 (0) = signalled = the process exited
            return kernel32.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _acquire_waiter_lock(data_dir):
    """Single-waiter lock. Returns the lock path when this
    waiter owns it, or None when a LIVE waiter already holds
    it (the caller then logs and exits -- waiters never
    multiply). A lock whose pid is dead is taken over."""
    lock = os.path.join(data_dir, "relaunch_wait.lock")
    for _attempt in range(2):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(str(os.getpid()))
            return lock
        except FileExistsError:
            try:
                with open(lock, encoding="utf-8") as fh:
                    owner = int(fh.read().split()[0])
            except Exception:
                owner = -1
            if owner != os.getpid() and _pid_alive(owner):
                return None
            try:
                os.remove(lock)
            except OSError:
                return None
        except OSError:
            return lock  # cannot lock (odd fs) -- proceed unlocked
    return None


def wait_relaunch_main(argv):
    """--wait-relaunch <app_pid> <launcher_path> <data_dir>"""
    pid = int(argv[0])
    target, data_dir = argv[1], argv[2]
    lock = _acquire_waiter_lock(data_dir)
    if lock is None:
        _upd_log(data_dir,
                 "relaunch waiter: another live waiter holds "
                 "the lock; exiting without acting")
        return 0
    try:
        return _wait_relaunch_locked(pid, target, data_dir)
    finally:
        try:
            os.remove(lock)
        except OSError:
            pass


def _wait_relaunch_locked(pid, target, data_dir):
    _upd_log(data_dir,
             f"relaunch waiter: start, waiting for app pid "
             f"{pid} to exit before relaunching {target}")
    deadline = time.time() + 180
    while _pid_alive(pid) and time.time() < deadline:
        time.sleep(0.25)
    gone = not _pid_alive(pid)
    _upd_log(data_dir, "relaunch waiter: app exited" if gone
             else "relaunch waiter: app still running after "
                  "180s; relaunching anyway")
    if not os.path.isfile(target):
        _upd_log(data_dir,
                 f"relaunch waiter: target {target} is not a "
                 "file; not relaunching")
        return 1
    try:
        flags = 0
        if os.name == "nt":
            flags = 0x00000008 | 0x08000000  # DETACHED | NO_WINDOW
        cmd = [target]
        if target.lower().endswith(".bat"):
            cmd = ["cmd", "/c", target]
        # Strip the lineage token -- this relaunch is
        # intentional, and the launcher refuses a start that
        # still carries it (see taskbar.relaunch_env).
        env = dict(os.environ)
        env.pop("TASKLIST_LAUNCH_DEPTH", None)
        subprocess.Popen(
            cmd, cwd=os.path.dirname(target) or None,
            creationflags=flags, close_fds=True, env=env)
        _upd_log(data_dir, f"relaunch waiter: relaunched {target}")
    except Exception as exc:
        _upd_log(data_dir,
                 f"relaunch waiter: relaunch failed: {exc!r}")
        return 1
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--wait-relaunch":
        raise SystemExit(wait_relaunch_main(sys.argv[2:5]))
    raise SystemExit("usage: relaunch_wait.py --wait-relaunch "
                     "<pid> <launcher_path> <data_dir>")
