"""V1.9.71 (workstream U): "Quote Tracking" text-export import.

Parses the fixed label:value export (Infor Quote Tracking) into
the fields Task List shares with it. Pure functions -- no Qt --
so the parser is bench-testable against the real fixture.

Format notes (from the fixture, which is ground truth):
- Several label:value pairs share a line, separated by runs of
  spaces/tabs. A value ends at the next known label on the line
  or at line end.
- Notes may span lines: continuation lines (carrying no known
  label) belong to Notes until the next label line.
- "CODE = NAME" values (Salesrep, Quoted By) resolve to the
  NAME side.
- The filename also encodes the quote id + revision
  (Quote_ID__26-2876______Revision__00_...); content wins, the
  filename is only a fallback.
- Fields with no Task List counterpart (price breakdown,
  customer number, email, the orders table) are parsed for
  completeness of the label scan but never mapped anywhere.
"""

import re

# Labels whose values map (or terminate values). Terminator-only
# labels (Create/Change stamps, Customer PO Date) are scanned
# so a value never swallows them, then discarded.
LABELS = [
    "Quote ID", "Revision", "Quote Date", "Salesrep",
    "Quoted By", "Customer Number", "Customer Name",
    "Contact Name", "End User", "Description", "Notes",
    "Email Address", "Engineering Hours",
    "Price - Speedrack", "Price - Outsource", "Price - Margin",
    "Price - Total", "Status",
    # terminators only:
    "Create Date", "Create Time", "Create User",
    "Change Date", "Change Time", "Change User",
    "Customer PO Date",
]
_LABEL_RES = [
    (label, re.compile(re.escape(label) + r"\s*:"))
    for label in sorted(LABELS, key=len, reverse=True)
]

_FILENAME_RE = re.compile(
    r"Quote_ID__([0-9A-Za-z][0-9A-Za-z-]*)_*Revision__(\d+)",
    re.IGNORECASE)

_END_USER_LOC_RE = re.compile(
    r"^(?P<name>.*?)\s+-\s+(?P<city>[^,]+),\s*"
    r"(?P<state>[A-Za-z]{2})\s*$")

_STATUS_MAP = {"active": "in_process"}

# Description token separators (user, 2026-11-14): the rack
# types in a Description are joined by one of these.
_TOKEN_SPLIT_RE = re.compile(r"[/,&+\-]")


def looks_like_quote_export(text):
    """Content validation for drops/menu picks: the export's
    identifying header is the Quote ID label."""
    return bool(text) and "Quote ID:" in text[:4096]


def parse_quote_export(text):
    """Raw label -> value dict (first occurrence wins; Notes
    accumulates its continuation lines)."""
    fields = {}
    notes_lines = None

    def _commit_notes():
        nonlocal notes_lines
        if notes_lines is not None:
            joined = "\n".join(notes_lines)
            fields["Notes"] = joined.strip("\n").rstrip()
            notes_lines = None

    for line in (text or "").splitlines():
        hits = []
        for label, rx in _LABEL_RES:
            for m in rx.finditer(line):
                hits.append((m.start(), m.end(), label))
        hits.sort()
        # De-overlap: a shorter label matched inside a longer
        # one's span (none in the current set, but stay safe).
        deduped = []
        last_end = -1
        for start, end, label in hits:
            if start >= last_end:
                deduped.append((start, end, label))
                last_end = end
        hits = deduped
        if notes_lines is not None and not hits:
            notes_lines.append(line.rstrip())
            continue
        if notes_lines is not None and hits:
            _commit_notes()           # Notes ended at this label
        for i, (start, end, label) in enumerate(hits):
            val_end = hits[i + 1][0] if i + 1 < len(hits) \
                else len(line)
            value = line[end:val_end].strip()
            if label == "Notes":
                if "Notes" not in fields:
                    notes_lines = [value] if value else []
                continue
            if label not in fields:
                fields[label] = value
    _commit_notes()
    return fields


def filename_quote_revision(filename):
    """(quote_id, revision) encoded in the export filename, or
    (None, None). Fallback only -- file content wins."""
    m = _FILENAME_RE.search(filename or "")
    if not m:
        return None, None
    return m.group(1), m.group(2)


def code_name(value):
    """"HOUSE = HOUSE ACCOUNT" -> "HOUSE ACCOUNT" (the NAME
    side of a CODE = NAME pair); a bare value passes through."""
    v = (value or "").strip()
    if " = " in v:
        return v.split(" = ", 1)[1].strip()
    return v


def parse_end_user(value):
    """Split a trailing " - City, ST" off the end-user name.

    Returns (name, city, state); when the pattern doesn't
    match, the whole string is the name and city/state are
    None."""
    v = (value or "").strip()
    m = _END_USER_LOC_RE.match(v)
    if m and m.group("name").strip():
        return (m.group("name").strip(),
                m.group("city").strip(),
                m.group("state").upper())
    return v, None, None


def _number(value):
    try:
        return float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def resolve_description(description, vocabulary):
    """Split a Description into rack types.

    Returns (matched, unmatched): canonical vocabulary names
    matched case-insensitively, and the tokens that matched
    nothing. The whole Description is tried as one rack type
    first (a type may itself contain a separator); otherwise
    it is split on the separator characters and each token is
    matched on its own. NOTHING is guessed here -- unmatched
    tokens are the caller's to prompt about (user, 2026-11-14:
    an unmatched token is never silently filed anywhere)."""
    text = (description or "").strip()
    if not text:
        return [], []
    canon = {}
    for name in vocabulary or []:
        canon.setdefault(name.strip().lower(), name)
    whole = canon.get(text.lower())
    if whole is not None:
        return [whole], []
    matched, unmatched = [], []
    for tok in _TOKEN_SPLIT_RE.split(text):
        tok = tok.strip()
        if not tok:
            continue
        hit = canon.get(tok.lower())
        if hit is not None:
            if hit not in matched:
                matched.append(hit)
        else:
            unmatched.append(tok)
    return matched, unmatched


def build_prefill(fields, filename=""):
    """Map parsed export fields onto New Quote prefill values.

    Only fields with a Task List counterpart are mapped.
    Price/hours of 0 become None (the dialog leaves them
    BLANK, per the user's mapping rule). Rack-type resolution
    is NOT done here (it needs the live vocabulary and may
    prompt) -- the caller fills "rack_types"/"scope" after
    resolving the Description, which is passed through raw.
    """
    qid = (fields.get("Quote ID") or "").strip()
    rev = (fields.get("Revision") or "").strip()
    if not qid or not rev:
        f_qid, f_rev = filename_quote_revision(filename)
        qid = qid or (f_qid or "")
        rev = rev or (f_rev or "")
    end_user, city, state = parse_end_user(fields.get("End User"))
    price = _number(fields.get("Price - Total"))
    hours = _number(fields.get("Engineering Hours"))
    status_raw = (fields.get("Status") or "").strip().lower()
    return {
        "quote_number": qid,
        "revision": rev or "00",
        "distributor": (fields.get("Customer Name") or "").strip(),
        "end_user": end_user,
        "location": (city, state) if state else None,
        "per": (fields.get("Contact Name") or "").strip(),
        "sales_rep": code_name(fields.get("Salesrep")),
        "notes": fields.get("Notes") or "",
        "quote_value": price if price else None,
        "estimated_hours": hours if hours else None,
        "status": _STATUS_MAP.get(status_raw),
        "description": (fields.get("Description") or "").strip(),
    }
