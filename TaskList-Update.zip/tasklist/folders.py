"""Automatic quote folder creation — pure filesystem helpers (no Qt).

Settings keys (read/written via TaskDatabase.get_setting/set_setting;
the UI owns the Settings surface, this module only documents them):

    "folder_creation_enabled"  "1" / "0", default "0" — master on/off toggle.
    "folder_template_dir"      folder copied into each new quote folder ("",
                               nothing to copy when empty).
    "folder_dest_dir"          parent directory where quote folders land
                               (e.g. a UNC path like \\\\fileshare\\redirect).
    "folder_initials"          user initials appended to the folder name.

Naming: {quote#}_{distributor}_{enduser}_{MM-DD-YYYY}_{initials}, each
segment sanitized for Windows and empty segments dropped so there are
never dangling underscores.

Nothing here ever overwrites an existing directory: copy_template()
raises FileExistsError when the target exists and the UI picks the
collision action (use existing / "(2)" via next_available_name / cancel).
find_folders_for_quote() lets the UI match an existing folder by quote
number (the first name segment) instead of by full generated name, so
additions and revisions to an old quote link to the original folder
instead of spawning a duplicate.
"""
import ntpath
import os
import re
import shutil


def canonical_path(p):
    """The ONE canonical form of a stored folder path
    (V1.9.74, workstream 21, user screenshot 2026-11-14 20:56:
    a stored path read "Q:/2026\\26-1720_..." -- a
    forward-slash root joined to backslash children by
    os.path.join, which never normalises the part it is
    given).

    Windows-form values (drive letter, UNC, or anything
    containing a backslash) are normalised with WINDOWS
    semantics (ntpath) regardless of the host OS: backslashes
    throughout, no duplicate separators, no trailing slash
    but the root's. Anything else (a POSIX path on a test
    bench) is normalised with the host's own rules. Applied
    when a folder path is BUILT/STORED (db writes) and when
    one is READ for display or opening, so legacy mixed
    values heal on use; the underlying folder is untouched."""
    if not p:
        return ""
    s = str(p)
    try:
        if "\\" in s or s.startswith("//") or (
                len(s) >= 2 and s[1] == ":"):
            return ntpath.normpath(s)
        return os.path.normpath(s)
    except Exception:
        return s

# Characters Windows forbids in file names, plus anything control-ish.
_ILLEGAL = '<>:"/\\|?*'
_WS_RUN = re.compile(r"\s+")


def sanitize_segment(s):
    """Make a single name segment safe for Windows.

    - each of <>:"/\\|?* and control chars (ord < 32) becomes "-"
    - runs of internal whitespace collapse to one space
    - leading/trailing whitespace stripped
    - trailing dots/spaces stripped (Windows quirk)
    Returns "" for empty/None input.
    """
    if not s:
        return ""
    if not isinstance(s, str):
        s = str(s)
    out = []
    for ch in s:
        if ch in _ILLEGAL or ord(ch) < 32:
            out.append("-")
        else:
            out.append(ch)
    s = _WS_RUN.sub(" ", "".join(out)).strip()
    s = s.rstrip(" .")
    return s


def build_quote_folder_name(quote_number, distributor, end_user, date, initials):
    """Build "{quote#}_{dist}_{enduser}_{MM-DD-YYYY}_{initials}".

    `date` is a datetime.date (or datetime). Empty segments are omitted
    (no dangling underscores).
    """
    date_str = date.strftime("%m-%d-%Y")
    segments = [
        sanitize_segment(quote_number),
        sanitize_segment(distributor),
        sanitize_segment(end_user),
        date_str,
        sanitize_segment(initials),
    ]
    return "_".join(s for s in segments if s)


def dest_reachable(path):
    """True when `path` is an accessible directory. Never raises."""
    if not path:
        return False
    try:
        return bool(os.path.isdir(path))
    except Exception:
        return False


def next_available_name(parent_dir, base_name):
    """First free name under parent_dir: base_name, "base_name (2)", ..."""
    if not os.path.exists(os.path.join(parent_dir, base_name)):
        return base_name
    i = 2
    while True:
        candidate = f"{base_name} ({i})"
        if not os.path.exists(os.path.join(parent_dir, candidate)):
            return candidate
        i += 1


def find_folders_for_quote(parent_dir, quote_number):
    """Folder names under parent_dir belonging to ``quote_number``.

    Quote folders are named "{quote#}_{dist}_{enduser}_{date}_{initials}",
    so the quote number is always the first segment. Matches names that
    start with the sanitized quote number plus "_" — the trailing
    underscore is the segment boundary, so quote "26-17" never matches a
    folder for "26-1706". Returns a sorted list (possibly empty); never
    raises — a missing/unreadable directory simply yields [].
    """
    prefix = sanitize_segment(quote_number)
    if not prefix or not parent_dir:
        return []
    prefix += "_"
    try:
        entries = os.listdir(parent_dir)
    except Exception:
        return []
    return sorted(
        name for name in entries
        if name.startswith(prefix)
        and os.path.isdir(os.path.join(parent_dir, name))
    )


def copy_template(template_dir, dest_parent, folder_name):
    """Copy the template tree into dest_parent/folder_name.

    Returns the final absolute path as a string.
    Raises FileNotFoundError when template_dir is missing/not a dir,
    FileExistsError when the target already exists (never overwrites).
    """
    if not template_dir or not os.path.isdir(template_dir):
        raise FileNotFoundError(f"template dir not found: {template_dir!r}")
    target = os.path.join(dest_parent, folder_name)
    if os.path.exists(target):
        raise FileExistsError(f"folder already exists: {target!r}")
    shutil.copytree(template_dir, target)
    return os.path.abspath(target)


# ------------------------------------------------- price summary form
# V1.9.86 (user item 4, ordered 2026-11-14, confirmed 2026-11-23):
# when a quote folder is created from the templates, the ONE Excel
# form in its "Price Summary" subfolder (template name
# "XX-0000_Customer_End User_Description_Rev 13.*") is renamed to
# "{quote#} Rev {rev}_{distributor}_{end user}_{rack type}" and its
# top block is pre-filled: A1 = today (a real Excel date), A3 =
# the task's contact name VERBATIM (the sheet's own lookups keyed on
# A3 fill the rest of that block from its contact sheet; a name the
# sheet doesn't know leaves its #N/A — the form's own behaviour,
# not worked around), A9 =
# "SHIP TO: " + the task's End User field VERBATIM, A12 =
# "SUBJECT: " + the rack type, H7 = the task's revision as held in
# Task List, H8 = the lead-time string from Settings. Multiple rack
# types get one renamed, filled copy EACH. No rack type: the
# template file is left untouched and the miss is logged.
#
# The write is SURGICAL: an .xlsx/.xlsm is a zip; only the first
# worksheet's XML is edited, and only the five target cells -- every
# other zip part (vbaProject.bin included) is copied byte-for-byte,
# so macros and formulas (the form's #N/A lookup cells) survive
# untouched. Stdlib only: the bundled runtime carries no Excel
# library. Nothing here ever touches the templates folder itself,
# and a failure NEVER propagates -- the caller logs the returned
# lines and folder creation completes regardless.
import io
import zipfile
from datetime import date as _date

_FORM_EXTS = (".xlsx", ".xlsm")
_FORM_CELLS_DATE = ("A1",)
_FORM_NS_RELS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _xml_escape(text):
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))


def _col_index(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch.upper()) - 64)
    return n


def _cell_parts(ref):
    m = re.match(r"([A-Z]+)([0-9]+)$", ref)
    return m.group(1), int(m.group(2))


def _style_attr(cell_xml):
    m = re.search(r'\bs="([0-9]+)"', cell_xml or "")
    return f' s="{m.group(1)}"' if m else ""


def _set_cell(xml, ref, inner, t_attr=""):
    """Replace (or insert) one cell in worksheet XML text.

    ``inner`` is the cell's inner XML (``<v>..</v>`` or
    ``<is><t>..</t></is>``); the cell's existing style attribute is
    preserved. Everything outside the target cell/row is returned
    byte-identical."""
    col, row = _cell_parts(ref)
    pat = re.compile(r'<c r="' + ref + r'"[^>]*?(?:/>|>.*?</c>)', re.S)
    m = pat.search(xml)
    if m:
        new = f'<c r="{ref}"{_style_attr(m.group(0))}{t_attr}>{inner}</c>'
        return xml[:m.start()] + new + xml[m.end():]
    cell = f'<c r="{ref}"{t_attr}>{inner}</c>'
    row_pat = re.compile(r'<row r="' + str(row) + r'"[^>]*?(?:/>|>.*?</row>)',
                         re.S)
    rm = row_pat.search(xml)
    if rm:
        row_xml = rm.group(0)
        if row_xml.endswith("/>"):
            head = row_xml[:-2] + ">"
            new_row = head + cell + "</row>"
        else:
            cells = list(re.finditer(
                r'<c r="([A-Z]+)[0-9]+"', row_xml))
            at = None
            for cm in cells:
                if _col_index(cm.group(1)) > _col_index(col):
                    at = cm.start()
                    break
            if at is None:
                new_row = row_xml[:-len("</row>")] + cell + "</row>"
            else:
                new_row = row_xml[:at] + cell + row_xml[at:]
        return xml[:rm.start()] + new_row + xml[rm.end():]
    new_row = f'<row r="{row}">{cell}</row>'
    rows = list(re.finditer(r'<row r="([0-9]+)"', xml))
    for rm2 in rows:
        if int(rm2.group(1)) > row:
            return xml[:rm2.start()] + new_row + xml[rm2.start():]
    end = xml.find("</sheetData>")
    if end == -1:
        return xml
    return xml[:end] + new_row + xml[end:]


def _first_sheet_part(parts):
    """Zip-part name of the workbook's first worksheet, via
    workbook.xml + its rels. None when unresolvable."""
    try:
        wb = parts["xl/workbook.xml"].decode("utf-8")
        m = re.search(r'<sheet[^>]*r:id="([^"]+)"', wb)
        if not m:
            return None
        rels = parts["xl/_rels/workbook.xml.rels"].decode("utf-8")
        for tag in re.findall(r"<Relationship[^>]*>", rels):
            idm = re.search(r'Id="([^"]+)"', tag)
            tgm = re.search(r'Target="([^"]+)"', tag)
            if idm and tgm and idm.group(1) == m.group(1):
                target = tgm.group(1).lstrip("/")
                if not target.startswith("xl/"):
                    target = "xl/" + target
                return target
    except Exception:
        return None
    return None


def _filled_workbook_bytes(src_bytes, values):
    """The workbook bytes with the five form cells written.

    ``values`` maps cell ref -> ("date", serial) or ("str", text).
    Raises on any structural problem; the caller treats a raise as
    'leave the template file untouched and log it'."""
    zin = zipfile.ZipFile(io.BytesIO(src_bytes))
    parts = {name: zin.read(name) for name in zin.namelist()}
    infos = {info.filename: info for info in zin.infolist()}
    zin.close()
    sheet = _first_sheet_part(parts)
    if sheet is None or sheet not in parts:
        raise ValueError("first worksheet not found")
    xml = parts[sheet].decode("utf-8")
    for ref, (kind, val) in values.items():
        if kind == "date":
            xml = _set_cell(xml, ref, f"<v>{val}</v>")
        else:
            xml = _set_cell(
                xml, ref,
                f'<is><t xml:space="preserve">{_xml_escape(val)}</t></is>',
                ' t="inlineStr"')
    parts[sheet] = xml.encode("utf-8")
    out = io.BytesIO()
    zout = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
    for name, data in parts.items():
        info = infos[name]
        zi = zipfile.ZipInfo(name, date_time=info.date_time)
        zi.compress_type = info.compress_type
        zi.external_attr = info.external_attr
        zout.writestr(zi, data)
    zout.close()
    return out.getvalue()


def fill_price_summary_form(folder_path, spec):
    """Rename + pre-fill the Price Summary form inside a FRESHLY
    COPIED quote folder. Returns a list of log lines (never raises).

    ``spec``: quote_number, revision (as held), distributor,
    end_user (verbatim), end_user_for_name ("Unknown" when blank),
    rack_types (list), lead_time (string), today (datetime.date).
    The templates folder is never touched -- only the copy inside
    ``folder_path``."""
    log = []
    try:
        sub = None
        for entry in sorted(os.listdir(folder_path)):
            full = os.path.join(folder_path, entry)
            if os.path.isdir(full) and entry.lower() == "price summary":
                sub = full
                break
        if sub is None:
            log.append("Price Summary form not processed — no "
                       "'Price Summary' subfolder in the new folder")
            return log
        candidates = []
        for entry in sorted(os.listdir(sub)):
            full = os.path.join(sub, entry)
            if not os.path.isfile(full):
                continue
            stem, ext = os.path.splitext(entry)
            if (stem.lower().startswith("xx-0000")
                    and ext.lower() in _FORM_EXTS + (".xls",)):
                candidates.append((entry, ext))
        if len(candidates) != 1:
            log.append(
                "Price Summary form not processed — expected exactly "
                f"one XX-0000 template file, found {len(candidates)}")
            return log
        entry, ext = candidates[0]
        if ext.lower() == ".xls":
            log.append("Price Summary form left untouched — the "
                       "template is a legacy .xls, which cannot be "
                       "filled safely")
            return log
        rack_types = [str(r).strip() for r in (spec.get("rack_types")
                                               or []) if str(r).strip()]
        if not rack_types:
            log.append("Price Summary form left untouched — the task "
                       "has no rack type to name it for")
            return log
        src = os.path.join(sub, entry)
        with open(src, "rb") as fh:
            src_bytes = fh.read()
        rev = str(spec.get("revision") or "00").strip() or "00"
        if rev.isdigit() and len(rev) < 2:
            rev = rev.zfill(2)
        today = spec.get("today") or _date.today()
        serial = (today - _date(1899, 12, 30)).days
        end_user = spec.get("end_user") or ""
        ship_to = "SHIP TO: " + end_user if end_user else "SHIP TO:"
        written = []
        for rack in rack_types:
            values = {
                "A1": ("date", serial),
                "A9": ("str", ship_to),
                "A12": ("str", "SUBJECT: " + rack),
                "H7": ("str", rev),
                "H8": ("str", spec.get("lead_time") or ""),
            }
            contact = str(spec.get("contact") or "")
            if contact:
                values["A3"] = ("str", contact)
            data = _filled_workbook_bytes(src_bytes, values)
            name = (f"{spec.get('quote_number') or ''} Rev {rev}_"
                    f"{spec.get('distributor') or ''}_"
                    f"{spec.get('end_user_for_name') or 'Unknown'}_"
                    f"{rack}{ext}")
            target = os.path.join(sub, name)
            with open(target, "wb") as fh:
                fh.write(data)
            written.append(name)
        os.remove(src)
        for name in written:
            log.append(f"Price Summary form prepared: {name}")
    except Exception as exc:  # noqa: BLE001 -- never fail the folder
        log.append("Price Summary form not processed — "
                   f"{type(exc).__name__}: {exc}")
    return log
