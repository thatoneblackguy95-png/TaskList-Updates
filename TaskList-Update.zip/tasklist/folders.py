"""Automatic quote folder creation — pure filesystem helpers (no Qt).

Settings keys (read/written via TaskDatabase.get_setting/set_setting;
the UI owns the Settings surface, this module only documents them):

    "folder_creation_enabled"  "1" / "0", default "0" — master on/off toggle.
    "folder_template_dir"      folder copied into each new quote folder ("",
                               nothing to copy when empty).
    "folder_dest_dir"          parent directory where quote folders land
                               (e.g. a UNC path like \\\\fileshare\\redirect).
    "folder_initials"          user initials appended to the folder name.

Naming: {quote#}_{distributor}_{enduser}_{MM-DD-YYYY}_{initials}, each
segment sanitized for Windows and empty segments dropped so there are
never dangling underscores.

Nothing here ever overwrites an existing directory: copy_template()
raises FileExistsError when the target exists and the UI picks the
collision action (use existing / "(2)" via next_available_name / cancel).
find_folders_for_quote() lets the UI match an existing folder by quote
number (the first name segment) instead of by full generated name, so
additions and revisions to an old quote link to the original folder
instead of spawning a duplicate.
"""
import os
import re
import shutil

# Characters Windows forbids in file names, plus anything control-ish.
_ILLEGAL = '<>:"/\\|?*'
_WS_RUN = re.compile(r"\s+")


def sanitize_segment(s):
    """Make a single name segment safe for Windows.

    - each of <>:"/\\|?* and control chars (ord < 32) becomes "-"
    - runs of internal whitespace collapse to one space
    - leading/trailing whitespace stripped
    - trailing dots/spaces stripped (Windows quirk)
    Returns "" for empty/None input.
    """
    if not s:
        return ""
    if not isinstance(s, str):
        s = str(s)
    out = []
    for ch in s:
        if ch in _ILLEGAL or ord(ch) < 32:
            out.append("-")
        else:
            out.append(ch)
    s = _WS_RUN.sub(" ", "".join(out)).strip()
    s = s.rstrip(" .")
    return s


def build_quote_folder_name(quote_number, distributor, end_user, date, initials):
    """Build "{quote#}_{dist}_{enduser}_{MM-DD-YYYY}_{initials}".

    `date` is a datetime.date (or datetime). Empty segments are omitted
    (no dangling underscores).
    """
    date_str = date.strftime("%m-%d-%Y")
    segments = [
        sanitize_segment(quote_number),
        sanitize_segment(distributor),
        sanitize_segment(end_user),
        date_str,
        sanitize_segment(initials),
    ]
    return "_".join(s for s in segments if s)


def dest_reachable(path):
    """True when `path` is an accessible directory. Never raises."""
    if not path:
        return False
    try:
        return bool(os.path.isdir(path))
    except Exception:
        return False


def next_available_name(parent_dir, base_name):
    """First free name under parent_dir: base_name, "base_name (2)", ..."""
    if not os.path.exists(os.path.join(parent_dir, base_name)):
        return base_name
    i = 2
    while True:
        candidate = f"{base_name} ({i})"
        if not os.path.exists(os.path.join(parent_dir, candidate)):
            return candidate
        i += 1


def find_folders_for_quote(parent_dir, quote_number):
    """Folder names under parent_dir belonging to ``quote_number``.

    Quote folders are named "{quote#}_{dist}_{enduser}_{date}_{initials}",
    so the quote number is always the first segment. Matches names that
    start with the sanitized quote number plus "_" — the trailing
    underscore is the segment boundary, so quote "26-17" never matches a
    folder for "26-1706". Returns a sorted list (possibly empty); never
    raises — a missing/unreadable directory simply yields [].
    """
    prefix = sanitize_segment(quote_number)
    if not prefix or not parent_dir:
        return []
    prefix += "_"
    try:
        entries = os.listdir(parent_dir)
    except Exception:
        return []
    return sorted(
        name for name in entries
        if name.startswith(prefix)
        and os.path.isdir(os.path.join(parent_dir, name))
    )


def copy_template(template_dir, dest_parent, folder_name):
    """Copy the template tree into dest_parent/folder_name.

    Returns the final absolute path as a string.
    Raises FileNotFoundError when template_dir is missing/not a dir,
    FileExistsError when the target already exists (never overwrites).
    """
    if not template_dir or not os.path.isdir(template_dir):
        raise FileNotFoundError(f"template dir not found: {template_dir!r}")
    target = os.path.join(dest_parent, folder_name)
    if os.path.exists(target):
        raise FileExistsError(f"folder already exists: {target!r}")
    shutil.copytree(template_dir, target)
    return os.path.abspath(target)
