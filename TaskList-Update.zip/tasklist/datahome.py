"""Local machine state for Task List: where the data lives, the
offline seed, and the quote-folder cache config.

Everything in this module lives OUTSIDE the data folder, in
``%LOCALAPPDATA%\\TaskList``, because it must be reachable exactly
when the data folder is not:

- the data-home pointer records a data folder the user moved the
  app to (Settings -> Offline), per machine;
- the seed is a local copy of the database (+ attachments) that
  lets the app open and work with no network at all, and merge
  back when the live database is reachable again;
- the folder-cache config (roots, budget) is per machine because
  the paths only exist on this machine.

Stdlib only, no Qt, import-safe anywhere, never raises.
"""

import json
import os
from pathlib import Path

POINTER_NAME = "data_home.txt"
SEED_META_NAME = "seed_meta.json"


def local_state_dir():
    """``%LOCALAPPDATA%\\TaskList`` (created on first use)."""
    base = os.environ.get("LOCALAPPDATA", "").strip()
    if base:
        root = Path(base) / "TaskList"
    else:
        root = Path.home() / ".local" / "share" / "TaskList"
    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return root


# ---- data-home pointer -------------------------------------------------

def read_pointer():
    """The data dir the user chose on THIS machine, or None."""
    try:
        raw = (local_state_dir() / POINTER_NAME).read_text(
            encoding="utf-8").strip()
        if raw:
            cand = Path(raw)
            if cand.is_dir():
                return cand
    except Exception:
        pass
    return None


def write_pointer(data_dir):
    try:
        (local_state_dir() / POINTER_NAME).write_text(
            str(data_dir), encoding="utf-8")
        return read_pointer() == Path(data_dir)
    except Exception:
        return False


def clear_pointer():
    try:
        (local_state_dir() / POINTER_NAME).unlink(missing_ok=True)
        return True
    except Exception:
        return False


def resolve_data_dir(install_data_dir):
    """Where this machine's data lives, in priority order:

    1. the pointer (an explicit per-machine choice beats everything,
       including the launcher's env var — the launcher derives the
       env var from the INSTALL's location, which is exactly what
       the pointer exists to override);
    2. ``TASKLIST_DATA_DIR`` (the launcher's share data folder);
    3. the install's own ``data`` folder.
    """
    ptr = read_pointer()
    if ptr is not None:
        return ptr
    override = os.environ.get("TASKLIST_DATA_DIR", "").strip()
    if override:
        try:
            cand = Path(override)
            if cand.is_dir():
                return cand
        except Exception:
            pass
    return Path(install_data_dir)


# ---- offline seed --------------------------------------------------------

def seed_dir():
    d = local_state_dir() / "seed"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


def seed_db_path():
    return seed_dir() / "tasks.db"


def seed_attachments_dir():
    return seed_dir() / "attachments"


def read_seed_meta():
    try:
        return json.loads((seed_dir() / SEED_META_NAME).read_text(
            encoding="utf-8"))
    except Exception:
        return {}


def write_seed_meta(meta):
    try:
        (seed_dir() / SEED_META_NAME).write_text(
            json.dumps(meta, indent=1), encoding="utf-8")
        return True
    except Exception:
        return False


def seed_exists():
    try:
        p = seed_db_path()
        return p.is_file() and p.stat().st_size > 0
    except Exception:
        return False


# ---- quote-folder cache config ------------------------------------------

def folder_cache_dir():
    d = local_state_dir() / "foldercache"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


def read_cache_config():
    """{enabled, roots: [...], budget_gb} — per machine, JSON file."""
    cfg = {"enabled": True, "roots": [], "budget_gb": 5}
    try:
        raw = json.loads((local_state_dir() / "foldercache.json").read_text(
            encoding="utf-8"))
        if isinstance(raw, dict):
            cfg.update({k: raw[k] for k in cfg if k in raw})
    except Exception:
        pass
    return cfg


def write_cache_config(cfg):
    try:
        (local_state_dir() / "foldercache.json").write_text(
            json.dumps(cfg, indent=1), encoding="utf-8")
        return True
    except Exception:
        return False
