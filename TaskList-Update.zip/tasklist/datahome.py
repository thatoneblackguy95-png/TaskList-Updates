"""Local machine state for Task List: where the data lives, the
offline seed, and the quote-folder cache config.

Everything in this module lives OUTSIDE the data folder, in
``%LOCALAPPDATA%\\TaskList``, because it must be reachable exactly
when the data folder is not:

- the data-home pointer records a data folder the user moved the
  app to (Settings -> Offline), per machine;
- the seed is a local copy of the database (+ attachments) that
  lets the app open and work with no network at all, and merge
  back when the live database is reachable again;
- the folder-cache config (roots, budget) is per machine because
  the paths only exist on this machine.

Stdlib only, no Qt, import-safe anywhere, never raises.
"""

import hashlib
import json
import os
import time
from pathlib import Path

POINTER_NAME = "data_home.txt"
SEED_META_NAME = "seed_meta.json"
SEED_CONFLICTS_NAME = "seed_conflicts.json"
INSTANCE_LOCK_NAME = "seed_instance.lock"


def local_state_dir():
    """``%LOCALAPPDATA%\\TaskList`` (created on first use)."""
    base = os.environ.get("LOCALAPPDATA", "").strip()
    if base:
        root = Path(base) / "TaskList"
    else:
        root = Path.home() / ".local" / "share" / "TaskList"
    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return root


# ---- data-home pointer -------------------------------------------------

def read_pointer():
    """The data dir the user chose on THIS machine, or None."""
    try:
        raw = (local_state_dir() / POINTER_NAME).read_text(
            encoding="utf-8").strip()
        if raw:
            cand = Path(raw)
            if cand.is_dir():
                return cand
    except Exception:
        pass
    return None


def write_pointer(data_dir):
    try:
        (local_state_dir() / POINTER_NAME).write_text(
            str(data_dir), encoding="utf-8")
        return read_pointer() == Path(data_dir)
    except Exception:
        return False


def read_pointer_raw():
    """The pointer file's stored string, VERBATIM, or None.

    V1.9.75 (workstream O): read_pointer() existence-gates the
    choice -- a mapped drive that is unmapped at launch (Q:
    before the VPN is up) made the user's picked location
    VANISH from resolution and from the Sync page, which then
    showed the Documents fallback as if it were his choice.
    The raw string is what he picked; the page shows it as-is,
    and the move flow compares against it, whether or not the
    folder happens to be reachable this minute. Resolution
    (read_pointer / resolve_data_dir) keeps its existence
    gate -- the engine never opens a folder that isn't there.
    """
    try:
        raw = (local_state_dir() / POINTER_NAME).read_text(
            encoding="utf-8").strip()
        return raw or None
    except Exception:
        return None


def write_pointer_raw(text):
    """Store the pointer string VERBATIM (the exact form the
    user picked in the folder dialog -- drive letter and all),
    so the Sync page can show his picked form back to him.
    Resolution still runs the stored string through Path(),
    which accepts either slash form."""
    try:
        (local_state_dir() / POINTER_NAME).write_text(
            str(text), encoding="utf-8")
        return read_pointer_raw() == str(text)
    except Exception:
        return False


def clear_pointer():
    try:
        (local_state_dir() / POINTER_NAME).unlink(missing_ok=True)
        return True
    except Exception:
        return False


def resolve_data_dir(install_data_dir):
    """Where this machine's data lives, in priority order:

    1. the pointer (an explicit per-machine choice beats everything,
       including the launcher's env var — the launcher derives the
       env var from the INSTALL's location, which is exactly what
       the pointer exists to override);
    2. ``TASKLIST_DATA_DIR`` (the launcher's share data folder);
    3. the install's own ``data`` folder.
    """
    ptr = read_pointer()
    if ptr is not None:
        return ptr
    override = os.environ.get("TASKLIST_DATA_DIR", "").strip()
    if override:
        try:
            cand = Path(override)
            if cand.is_dir():
                return cand
        except Exception:
            pass
    return Path(install_data_dir)


# ---- offline seed --------------------------------------------------------

def seed_dir():
    d = local_state_dir() / "seed"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


def seed_db_path():
    return seed_dir() / "tasks.db"


def seed_attachments_dir():
    return seed_dir() / "attachments"


def _meta_checksum(meta):
    payload = {k: v for k, v in meta.items() if k != "_checksum"}
    canon = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(canon.encode("utf-8", "replace")).hexdigest()


def _read_meta_file(path):
    """Parse + checksum-verify one meta file; None when the
    file is missing, unparseable, or fails its checksum."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        if "_checksum" in data:
            if data["_checksum"] != _meta_checksum(data):
                return None
            data = {k: v for k, v in data.items()
                    if k != "_checksum"}
        return data
    except Exception:
        return None


def _atomic_write_json(path, data):
    """tmp + fsync + replace, keeping the previous good file
    as <name>.bak. Returns True on success."""
    try:
        tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(data, indent=1))
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        if _read_meta_file(path) is not None or path.exists():
            try:
                import shutil
                shutil.copy2(path, path.with_name(path.name + ".bak"))
            except Exception:
                pass
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def read_seed_meta():
    """The seed meta, verified.

    V1.9.71 (research checklist 1.3/6.5, matrix PF-2): the
    meta carries the merge BASE -- the protocol's tombstone
    store. It used to be a bare write_text read back as {}
    on ANY error, so one torn write silently erased the
    base and every prior deletion became un-inferable (a
    locally deleted row read as "never arrived" and was
    resurrected). Now: writes are atomic with a checksum
    and a .bak of the previous good file; a corrupt main
    falls back to the .bak; when a meta file EXISTS but
    neither copy verifies, the loss is REPORTED via the
    ``_meta_lost`` key (never silently treated as a fresh
    install) so the engine can re-baseline safely."""
    main = seed_dir() / SEED_META_NAME
    data = _read_meta_file(main)
    if data is not None:
        return data
    bak = _read_meta_file(main.with_name(main.name + ".bak"))
    if bak is not None:
        bak["_recovered_from_backup"] = True
        return bak
    try:
        if main.exists() or main.with_name(
                main.name + ".bak").exists():
            return {"_meta_lost": True}
    except Exception:
        pass
    return {}


def write_seed_meta(meta):
    try:
        data = dict(meta)
        data.pop("_meta_lost", None)
        data.pop("_recovered_from_backup", None)
        # V1.9.71 (crossed wires): archive the outgoing base
        # into base_hist (newest first, last 4). A machine that
        # pushed one route's state advanced its base past the
        # common ancestor; when the other route's divergent
        # state arrives, the merge must be judged against that
        # ancestor or the other branch's rows read as reverts
        # and edits are silently lost. The fold picks the
        # oldest recorded base that is still a true ancestor
        # of every side (offline._pick_fold_base).
        if data.get("base"):
            cur = _read_meta_file(seed_dir() / SEED_META_NAME)
            if isinstance(cur, dict) and cur.get("base") \
                    and cur["base"] != data["base"]:
                hist = list(data.get("base_hist") or [])
                prev = {"hashes": cur["base"],
                        "gen": cur.get("live_gen")}
                if not hist or hist[0] != prev:
                    hist.insert(0, prev)
                data["base_hist"] = hist[:4]
        data["_checksum"] = _meta_checksum(data)
        return _atomic_write_json(seed_dir() / SEED_META_NAME, data)
    except Exception:
        return False


def seed_conflicts_path():
    return seed_dir() / SEED_CONFLICTS_NAME


def read_seed_conflicts():
    data = _read_meta_file(seed_conflicts_path())
    if isinstance(data, dict) and isinstance(
            data.get("conflicts"), list):
        return data["conflicts"]
    return []


def write_seed_conflicts(conflicts):
    try:
        data = {"conflicts": list(conflicts)}
        data["_checksum"] = _meta_checksum(data)
        return _atomic_write_json(seed_conflicts_path(), data)
    except Exception:
        return False


# ---- per-machine instance lock (matrix PF-10) -------------------
#
# Two app instances on one PC share one seed: interleaved
# read-modify-write meta updates and a launch-time working-file
# install under the other instance's open connection can lose
# edits. The first instance holds this lock for its lifetime;
# a second instance's engine refuses to sync (its app says the
# app is already running). Liveness is judged by pid, never by
# the lock's age alone.

_INSTANCE_LOCK_HELD = [False]


def _pid_alive(pid):
    try:
        pid = int(pid)
        if pid <= 0:
            return False
        if os.name == "nt":
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(
                0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def acquire_instance_lock():
    """Take the per-machine seed lock. True when this process
    holds it (or already did); False when a LIVE other
    instance holds it."""
    if _INSTANCE_LOCK_HELD[0]:
        return True
    try:
        path = seed_dir() / INSTANCE_LOCK_NAME
        for _attempt in range(2):
            try:
                fd = os.open(str(path),
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                import socket
                os.write(fd, json.dumps({
                    "pid": os.getpid(),
                    "host": socket.gethostname(),
                    "at": time.time()}).encode())
                os.close(fd)
                _INSTANCE_LOCK_HELD[0] = True
                return True
            except FileExistsError:
                try:
                    owner = json.loads(path.read_text(
                        encoding="utf-8"))
                except Exception:
                    owner = None
                if owner is None:
                    # V1.9.80 (W1): the create and the owner
                    # write are two steps -- a challenger that
                    # arrives in the gap reads an EMPTY lock and
                    # must not judge the creator dead and steal
                    # the lock from a live starting instance
                    # (the overlap race the twin-window incident
                    # turned on). A live creator's write lands
                    # within milliseconds; poll briefly. Only a
                    # lock that STAYS unreadable past the grace
                    # (a creator that crashed mid-write) is
                    # treated as a dead owner below.
                    _deadline = time.time() + 1.5
                    while owner is None and time.time() < _deadline:
                        time.sleep(0.05)
                        try:
                            owner = json.loads(path.read_text(
                                encoding="utf-8"))
                        except Exception:
                            owner = None
                    if owner is None:
                        owner = {}
                import socket
                if (owner.get("host") == socket.gethostname()
                        and _pid_alive(owner.get("pid"))):
                    return False
                # Dead owner (or unreadable lock): take over.
                try:
                    path.unlink()
                except Exception:
                    return False
        return False
    except Exception:
        return True   # never let the lock machinery block the app


def seed_exists():
    try:
        p = seed_db_path()
        return p.is_file() and p.stat().st_size > 0
    except Exception:
        return False


# ---- quote-folder cache config ------------------------------------------

def folder_cache_dir():
    d = local_state_dir() / "foldercache"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


def read_cache_config():
    """{enabled, roots: [...], budget_gb} — per machine, JSON file."""
    cfg = {"enabled": True, "roots": [], "budget_gb": 5}
    try:
        raw = json.loads((local_state_dir() / "foldercache.json").read_text(
            encoding="utf-8"))
        if isinstance(raw, dict):
            cfg.update({k: raw[k] for k in cfg if k in raw})
    except Exception:
        pass
    return cfg


def write_cache_config(cfg):
    try:
        (local_state_dir() / "foldercache.json").write_text(
            json.dumps(cfg, indent=1), encoding="utf-8")
        return True
    except Exception:
        return False


# ---- live candidate dirs (dual-path sync, V1.9.69) ----------------------
#
# The live data folder can be spelled two ways (a direct network
# path and a redirected / CSC path) that may reach the SAME
# underlying share -- or, in a split-brain moment, two divergent
# copies of it. The alternate spelling is an explicit per-machine
# setting stored in the seed meta (the same store the sync engine
# already uses for its base/gen bookkeeping, so it stays per
# machine and survives alongside it). The Settings UI writes it
# through set_live_alt_dir(); the sync engine reads the ordered
# candidate list through live_candidate_dirs(). Default: no
# alternate, so the candidate list is just the primary.

def live_alt_dir():
    """The configured alternate live data DIR, or None."""
    try:
        raw = str(read_seed_meta().get("live_alt_dir") or "").strip()
        return Path(raw) if raw else None
    except Exception:
        return None


def set_live_alt_dir(path):
    """Set (or clear, with None/"") the alternate live data dir.

    Stored as the ``live_alt_dir`` key in the seed meta. Returns
    True when the meta was written."""
    try:
        meta = read_seed_meta()
        if path:
            meta["live_alt_dir"] = str(path)
        else:
            meta.pop("live_alt_dir", None)
        return write_seed_meta(meta)
    except Exception:
        return False


def _unc_documents_local(path_str):
    """The local redirected-folder spelling of a UNC path:
    \\\\server\\share\\...\\Documents\\<tail> -> ~/Documents/<tail>.

    String-level (not pathlib) so the transform is identical on
    any platform: on his machines the Documents folder is
    redirected to the share, and the SAME folder is reachable
    locally through the profile path (Windows Offline Files
    serves it from cache when the share is away). Returns None
    when the path is not a UNC path with a Documents component
    and a tail under it."""
    try:
        s = str(path_str)
        if not s.startswith("\\\\"):
            return None
        segs = [seg for seg in s.split("\\") if seg]
        if "Documents" not in segs:
            return None
        tail = segs[segs.index("Documents") + 1:]
        if not tail:
            return None
        return str(Path.home() / "Documents" / Path(*tail))
    except Exception:
        return None


def _is_unc(path_str):
    try:
        return str(path_str).startswith("\\\\")
    except Exception:
        return False


def derive_route_spellings(primary_dir):
    """Ordered route spellings for the CHOSEN data dir (V1.9.71,
    workstream I; the user's three-source model, 2026-11-14):

    the shared/master copy is reachable by two routes -- the
    direct network spelling (UNC, instant when the VPN is up)
    and the synced/redirected-folder spelling (the local
    Documents path, served by Offline Files, may lag) -- and
    sync uses whichever answers, network route first. The
    spellings are derived from the CURRENT chosen location
    (the resolved primary), plus the other spellings this
    machine already knows (the launcher's env var, the
    per-machine pointer), plus the Documents transform of any
    UNC spelling among them. Moving the data folder re-derives
    everything from the new location (register_derived_alt is
    called again); a location whose twin cannot be derived is
    used as-is -- a single route is a valid state, never an
    error. Generation, never route speed, decides content
    (see offline.py); this function only enumerates routes.

    Returns a list of dir strings, network (UNC) spellings
    first, the primary first among equals."""
    pool = []

    def _add(p):
        if p is None:
            return
        try:
            s = str(p).strip()
        except Exception:
            return
        if not s:
            return
        key = os.path.normcase(s)
        if key not in {os.path.normcase(x) for x in pool}:
            pool.append(s)

    _add(primary_dir)
    # V1.9.80 (W18, user correction 2026-11-17 10:08): ALL
    # connected locations stay connected. The folder the user
    # personally picks (the pointer; his Q: folder) is an
    # EXTRA copy -- a fast lane between his PCs -- never a
    # replacement for the network-account location the env
    # var names. The 1.9.76 rule that pooled ONLY the picked
    # folder once a pick existed (stranding the account
    # location at whatever state it had) is REMOVED: the pool
    # always carries the primary, the account location (env
    # var), and the pick, plus every spelling derived below.
    # The generation-gated merge converges all of them;
    # picking a folder retires nothing.
    _add(os.environ.get("TASKLIST_DATA_DIR", "").strip() or None)
    _add(read_pointer())
    for s in list(pool):
        _add(_unc_documents_local(s))
    unc = [s for s in pool if _is_unc(s)]
    rest = [s for s in pool if not _is_unc(s)]
    primary_key = os.path.normcase(str(primary_dir))
    unc.sort(key=lambda s: 0 if os.path.normcase(s) == primary_key
             else 1)
    rest.sort(key=lambda s: 0 if os.path.normcase(s) == primary_key
              else 1)
    return unc + rest


def register_derived_alt(primary_dir):
    """Derive the route spellings for the chosen data dir and
    store the highest-priority OTHER spelling as the live
    alternate, so the sync engine's candidate list always
    carries both routes without any Settings field (the
    forensic's H1: the alternate existed but nothing in
    production ever set it). Idempotent; called at app start
    and after a data-folder move. Returns the route list.

    V1.9.80 (W18): the alternate is a SPELLING OF THE SAME
    FOLDER (the primary itself, or its redirected-folder
    transform, or a route whose transform lands back on the
    primary) -- never another LOCATION. Since the pick
    became an additional connected location with its own
    slot in live_candidate_dirs, letting the route pool's
    next entry land here captured the picked folder into
    the alt slot, where it stayed a cycle candidate forever
    -- even after the user removed the pick."""
    try:
        routes = derive_route_spellings(primary_dir)
        primary_key = os.path.normcase(str(primary_dir))
        _p_local = _unc_documents_local(str(primary_dir))

        def _same_folder(r):
            if os.path.normcase(r) == primary_key:
                return False
            if _p_local and os.path.normcase(r) == \
                    os.path.normcase(_p_local):
                return True
            _back = _unc_documents_local(r)
            return bool(_back and os.path.normcase(_back)
                        == primary_key)

        alt = next((r for r in routes if _same_folder(r)), None)
        current = live_alt_dir()
        if alt is None:
            if current is not None:
                set_live_alt_dir(None)
        elif current is None or os.path.normcase(
                str(current)) != os.path.normcase(alt):
            set_live_alt_dir(alt)
        return routes
    except Exception:
        return [str(primary_dir)]


def account_data_dir(install_data_dir):
    """The network-account data dir: the launcher's
    ``TASKLIST_DATA_DIR`` when it names an existing folder,
    else the install's own ``data`` folder. The user's picked
    folder (the pointer) is NOT consulted here -- since
    V1.9.80 (W18) the pick is an ADDITIONAL fast copy, not the
    data home, so the account location is resolved on its own
    and stays a sync target whether or not a pick exists."""
    override = os.environ.get("TASKLIST_DATA_DIR", "").strip()
    if override:
        try:
            cand = Path(override)
            if cand.is_dir():
                return cand
        except Exception:
            pass
    return Path(install_data_dir)


def picked_data_dir():
    """The folder the user personally picked for the extra
    fast copy (the raw pointer string as a Path), or None.
    NOT existence-gated: a picked folder whose drive is
    unmapped right now (Q: before the VPN is up) is still the
    pick -- the sync engine treats an unanswering candidate
    as ordinary offline working, never as an error and never
    as a reason to drop the location."""
    raw = read_pointer_raw()
    if not raw:
        return None
    try:
        return Path(raw)
    except Exception:
        return None


def live_candidate_dirs(primary_dir=None):
    """Ordered live data dirs: primary first, alternate second,
    the user's picked fast-copy folder last.

    ``primary_dir`` is today's resolved data dir (the caller in
    the sync engine passes the folder of the live path it was
    given); when omitted, the data-home pointer is the fallback
    primary. Duplicates (same spelling) collapse; existence is
    NOT required -- probing/selection is the sync engine's job,
    and a candidate that cannot be stat'ed is skipped there.

    V1.9.80 (W18): the picked folder is ALWAYS a candidate
    when a pick exists (added from the raw pointer, not
    existence-gated), alongside the primary and the alternate
    spelling -- every connected location is engaged by every
    cycle and converges; none is retired by a pick."""
    out = []
    seen = set()

    def _add(p):
        if p is None:
            return
        try:
            pp = Path(p)
        except Exception:
            return
        key = os.path.normcase(str(pp))
        if key in seen:
            return
        seen.add(key)
        out.append(pp)

    if primary_dir is not None:
        _add(primary_dir)
    else:
        _add(read_pointer())
    _add(live_alt_dir())
    _add(picked_data_dir())
    return out
