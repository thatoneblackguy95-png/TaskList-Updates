"""Task List main window."""

# Visible build marker. Bump for every release; tests assert both in-app
# markers show exactly this version and no stale older markers remain.
APP_VERSION = "1.9.60"

# V1.9.50: main() sets this when the live database could not be
# opened and the session is running on the local offline seed.
_OFFLINE_SESSION = False

import csv
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import (Qt, QEvent, QObject, QLockFile, QSettings,
                            QSize, QTimer, Signal,
                            QPropertyAnimation, QEasingCurve)
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtGui import QAction, QActionGroup, QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog,
    QFrame, QGridLayout, QHBoxLayout, QInputDialog, QLabel, QLineEdit,
    QMainWindow, QMenu, QMenuBar, QMessageBox, QPlainTextEdit, QPushButton,
    QScrollArea, QSizePolicy, QSpacerItem, QStackedWidget, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget, QWidgetAction,
)

from . import updater
from . import datahome as _datahome
from . import offline as _offline_engine
from . import foldercache as _folder_cache
from .db import (STATUSES, STATUS_LABELS, SORT_MODES, TaskDatabase,
                 _backup_worker_main, _is_io_failure)
from .dashboard import DashboardPage
# v1.4.0 item 14: export (openpyxl) is lazy-loaded at the call site —
# not on the launch path.
from .fonts import app_font
from .icons import nav_icon, svg_icon
from .themes import (GlassMenu, apply_theme, saved_theme,
                     save_theme)
from .startup_log import log_startup_event
from .taskbar import (set_app_user_model_id, stamp_window_identity,
                      register_app_identity,
                      ensure_start_menu_shortcut, ensure_desktop_shortcut,
                      launcher_root, launcher_target,
                      preferred_launcher_target)
from .toast import show_toast
from .ui import (
    SettingsDialog, TaskCard, TaskTable, TaskDetailWindow,
    install_main_chrome, task_attachments_dir, DirectoryPage, QueuePage,
    NotesPage, SafeComboBox,
    confirm_cancel_with_reason, CountLabel, SearchField, SearchSlashFilter,
    slash_search_target, sweep_staging_dirs, maybe_ask_price,
    maybe_prompt_scope_info,
    begin_quote_folder_flow, process_pending_folders_startup, chip_font,
    run_new_task_dialog, set_scroll_content_margins, FlowLayout,
    run_folder_background, enable_touch_scroll,
    _ChromeTabBar, _page_tab_palette,
    _chip_font_tree, ToggleSwitch, slide_swap, grab_without_scrollbars,
    app_confirm, app_message, app_choose, app_get_item,
    install_global_surface_filter,
)


# Main-list filter chips, in display order. Needs attention sits last
# and takes the red attention style while its count is above zero.
# V1.9.30 (user): the Overdue chip is GONE -- overdue is part of
# Needs Attention now (the db view counts stale OR hot OR overdue).
FILTER_VIEWS = [
    ("all", "All"),
    ("in_process", "In Process"),
    ("completed", "Completed"),
    ("on_hold", "On Hold"),
    ("canceled", "Canceled"),
    ("needs_attention", "Needs attention"),
]
ATTENTION_VIEWS = ("needs_attention",)

# V1.9.8: task cards build in chunks of this many per event-loop turn so
# the window appears immediately with thousands of tasks.
_CARD_CHUNK_SIZE = 60
# At or below this many cards, refresh() builds synchronously (unchanged
# behavior — instant for normal lists, and what the test suite expects).
_CARD_SYNC_LIMIT = 120


def default_db_path():
    # V1.9.16: the local-mirror launcher sets TASKLIST_DATA_DIR to the
    # SHARE's data folder, so code runs locally while the database (and
    # attachments, which live beside it) stay shared. Without the env
    # var, the database lives beside the code, as before. Invalid
    # values fall back silently — a bad env var must never break launch.
    # V1.9.50: resolution lives in datahome now, and a per-machine
    # data-home pointer (Settings -> Offline: the user moved the data
    # to a folder he chose) beats both the env var and the install
    # default.
    from . import datahome
    install_data = Path(__file__).resolve().parent.parent / "data"
    return datahome.resolve_data_dir(install_data) / "tasks.db"


def default_export_dir():
    """Folder containing the app folder (not inside it) — sensible default
    for the Excel save dialog, and robust once packaged as an .exe."""
    app_dir = Path(__file__).resolve().parent.parent
    parent = app_dir.parent
    return str(parent) if parent.is_dir() else str(app_dir)


CSV_COLUMNS = ("quote_number", "distributor", "end_user", "notes", "scope",
               "rack_types", "due_date", "estimated_hours", "quote_value",
               "status")

# Held for the life of the process by _already_running().
_app_lock = None
_instance_server = None
# Local-socket name the primary instance listens on so a later launch can
# ask it to raise its window instead of starting a second copy.
_INSTANCE_KEY = "tasklist-v1-instance"


def _raise_all_windows():
    """Bring the running instance's windows forward (best effort, no-raise)."""
    try:
        app = QApplication.instance()
        widgets = app.topLevelWidgets() if app is not None else []
    except Exception:
        return
    for w in widgets:
        try:
            if not w.isWindow():
                continue
            if w.windowState() & Qt.WindowMinimized:
                w.showNormal()
            if w.isVisible():
                w.raise_()
                w.activateWindow()
        except Exception:  # noqa: BLE001 - one bad window must not block the rest
            pass


def _drain_instance_server():
    """Accept and discard pending raise-request connections."""
    try:
        while _instance_server is not None:
            conn = _instance_server.nextPendingConnection()
            if conn is None:
                break
            try:
                conn.close()
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        pass


def _already_running(app):
    """Single-instance guard: instant and non-blocking.

    - First instance: takes a QLockFile and listens on a local socket so
      later launches can ask it to raise its window.
    - Later launch while one holds the lock: pings the running instance
      to bring its window forward, then returns True (the caller exits).

    No modal dialogs: a popup that sits until clicked is the worst
    possible thing during a slow first launch (every impatient
    double-click stacked another one). Pure Qt — no native window
    messages, no style-bit changes.
    """
    global _app_lock, _instance_server
    lock_path = Path(tempfile.gettempdir()) / "tasklist-v1-2-0.lock"
    _app_lock = QLockFile(str(lock_path))
    # A crashed instance must never wedge the app: 30s stale time. Live
    # holders are still detected by PID, so a running app is never
    # misjudged as stale.
    _app_lock.setStaleLockTime(30000)
    if _app_lock.tryLock(0):
        # Primary instance: listen for raise-requests from later launches.
        try:
            _instance_server = QLocalServer()
            _instance_server.newConnection.connect(
                lambda: (_raise_all_windows(), _drain_instance_server()))
            if not _instance_server.listen(_INSTANCE_KEY):
                # Stale pipe from a crashed run — clear it and retry once.
                QLocalServer.removeServer(_INSTANCE_KEY)
                _instance_server.listen(_INSTANCE_KEY)
        except Exception:  # noqa: BLE001 - the lock still enforces single instance
            _instance_server = None
        return False
    # Another copy holds the lock: ask it to raise its window, then exit.
    try:
        sock = QLocalSocket()
        sock.connectToServer(_INSTANCE_KEY)
        if sock.waitForConnected(500):
            sock.write(b"raise")
            sock.waitForBytesWritten(500)
            sock.disconnectFromServer()
    except Exception:  # noqa: BLE001 - nothing to raise; just exit
        pass
    return True


class CsvImportDialog(QDialog):
    """Pick a CSV file, preview the first rows, confirm the import.

    Expected headers: quote_number, distributor, end_user, notes, scope
    (semicolon-separated), rack_types (semicolon-separated), due_date
    (YYYY-MM-DD), estimated_hours, quote_value, status.
    """

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Import CSV")
        self.setMinimumSize(720, 480)
        self._rows = []

        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        # V1.9.38 (user: "I don't see a clear way of understanding
        # what it wants for imports") — the whole contract, in
        # plain terms, matching exactly what the importer does:
        hint = QLabel(
            "<b>How CSV import works</b><br>"
            "The first row of the file must be a header row using "
            "these exact column names:<br>"
            + ", ".join(f"<b>{c}</b>" for c in CSV_COLUMNS) + "<br><br>"
            "<b>quote_number</b> is the only required column — a row "
            "without one is skipped, and a quote number that already "
            "exists is skipped as a duplicate. Every other column "
            "is optional.<br>"
            "• <b>scope</b> and <b>rack_types</b>: separate multiple "
            "values with semicolons (e.g. <i>Design; Site visit</i>).<br>"
            "• <b>due_date</b>: YYYY-MM-DD (e.g. 2026-03-15).<br>"
            "• <b>estimated_hours</b> and <b>quote_value</b>: plain "
            "numbers, no $ or commas.<br>"
            "• <b>status</b>: one of in_process, on_hold, completed, "
            "canceled — anything else imports as in progress.<br>"
            "Columns with other names are ignored. Not sure? Save "
            "the template below and fill it in.")
        hint.setWordWrap(True)
        hint.setObjectName("hint")
        layout.addWidget(hint)

        pick_row = QHBoxLayout()
        pick = QPushButton("Choose CSV file…")
        pick.setObjectName("ghost")
        pick.clicked.connect(self._pick)
        pick_row.addWidget(pick)
        template_btn = QPushButton("Save template CSV…")
        template_btn.setObjectName("ghost")
        template_btn.clicked.connect(self._save_template)
        pick_row.addWidget(template_btn)
        pick_row.addStretch(1)
        layout.addLayout(pick_row)

        self._table = QTableWidget()
        self._table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self._table, 1)

        self._status = QLabel("No file chosen.")
        self._status.setObjectName("hint")
        layout.addWidget(self._status)

        btns = QHBoxLayout()
        btns.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.setObjectName("ghost")
        cancel.clicked.connect(self.reject)
        self._import_btn = QPushButton("Import")
        self._import_btn.setObjectName("primary")
        self._import_btn.setEnabled(False)
        self._import_btn.clicked.connect(self.accept)
        btns.addWidget(cancel)
        btns.addWidget(self._import_btn)
        layout.addLayout(btns)

    def _pick(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Import CSV", default_export_dir(), "CSV Files (*.csv)",
            "", QFileDialog.DontUseNativeDialog)
        if not path:
            return
        try:
            with open(path, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                self._rows = [r for r in reader if any((v or "").strip()
                                                       for v in r.values())]
                headers = reader.fieldnames or []
        except Exception as exc:  # noqa: BLE001
            self._status.setText(f"Could not read the file: {exc}")
            return
        self._table.setColumnCount(len(headers))
        self._table.setHorizontalHeaderLabels(headers)
        preview = self._rows[:6]
        self._table.setRowCount(len(preview))
        for r, row in enumerate(preview):
            for c, h in enumerate(headers):
                self._table.setItem(r, c, QTableWidgetItem((row.get(h) or "")))
        self._table.resizeColumnsToContents()
        self._status.setText(
            f"{len(self._rows)} row(s) found — showing first {len(preview)}. "
            "Click Import to add them as new tasks.")
        self._import_btn.setEnabled(bool(self._rows))

    def _save_template(self):
        """A ready-to-fill CSV: the exact header row + one example."""
        path, _ = QFileDialog.getSaveFileName(
            self, "Save template CSV",
            str(Path(default_export_dir()) / "TaskList-Import-Template.csv"),
            "CSV Files (*.csv)", "", QFileDialog.DontUseNativeDialog)
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(CSV_COLUMNS)
                w.writerow([
                    "Q-1001", "Example Distributor", "Example End User",
                    "Any notes about the job go here.",
                    "Design; Site visit", "Selective",
                    "2026-03-15", "12.5", "45000", "in_process"])
        except OSError as exc:
            self._status.setText(f"Could not save the template: {exc}")
            return
        self._status.setText(f"Template saved to {path} — fill it in "
                             "and choose it above.")

    def rows(self):
        return self._rows


class TaskListWindow(QMainWindow):
    # V1.9.30: emitted (from the update worker thread) when a
    # staged update is ready to apply; the offer runs on the UI
    # thread via the queued connection.
    _upd_ready = Signal(str)

    def __init__(self, db_path=None):
        super().__init__()
        self.setWindowTitle("Task List")
        # V1.9.9: explicit window icon (not just app-level). For frameless
        # windows on the taskbar, the window icon is what Windows shows —
        # relying on app-level inheritance alone has proven flaky.
        # V1.9.12: file-first + embedded fallback (see _load_app_icon), so
        # the window never starts icon-less when the share is slow to
        # answer at launch.
        try:
            _wi, _src = _load_app_icon()
            if _wi is not None:
                self.setWindowIcon(_wi)
        except Exception:  # noqa: BLE001 - icon must never break startup
            pass
        self.resize(1300, 830)
        # V1.9.51 (user: snapped half-screen was "basically not
        # really usable"): the 1220 floor made a half-screen snap
        # wider than the half it snapped to. 760 keeps the layout
        # honest at half of a 1080p screen (and on the Surface)
        # -- the toolbar wraps, the table scrolls, the sidebar
        # collapses.
        self.setMinimumSize(760, 620)

        self.db = TaskDatabase(db_path or default_db_path())
        log_startup_event("DB opened")
        self._real_launch = False
        self._upd_ready.connect(self._offer_update_ready)
        self.view = "all"
        self.search_text = ""
        self.outcome_filter = "all"
        self.scope_filter = None
        self.theme = saved_theme()
        # V1.9.9: staging sweep moved past first paint (see main()) — it
        # globs %TEMP% and must never block the window appearing.
        log_startup_event("staging deferred")
        # Automatic quote folder creation: process any folders queued while
        # the destination was unreachable. Deferred to the event loop so it
        # never delays the window showing; all network checks run off the UI
        # thread and only ONE summary notice appears.
        QTimer.singleShot(0, self._startup_folder_queue)
        settings = QSettings("TaskListApp", "TaskList")
        geo = settings.value("geometry")
        if geo is not None:
            self.restoreGeometry(geo)
            self._ensure_on_screen()
        self.layout_mode = settings.value("layout_mode", "list")
        # V1.9.30 (user): the 2-column grid view is removed (the
        # 3-column grid stays). A saved "grid" lands on grid3.
        if self.layout_mode == "grid":
            self.layout_mode = "grid3"
        if self.layout_mode not in ("list", "grid3"):
            self.layout_mode = "list"
        self.sort = settings.value("sort", "newest")
        if self.sort not in SORT_MODES:
            self.sort = "newest"
        self._tasks = {}
        self._view_buttons = {}
        self._detail_windows = {}

        # ---- frameless chrome: title bar, then menu bar, then content ----
        content, frame_layout = install_main_chrome(self, "Task List")
        menubar = QMenuBar()
        menubar.setObjectName("menuBar")
        frame_layout.insertWidget(1, menubar)
        self._build_menu(menubar)
        # V1.9.51: no glass walk needed here anymore -- _build_menu
        # creates GlassMenu instances directly (they paint their
        # own frost; see themes.GlassMenu).

        # ---- body: sidebar + stacked pages ----
        content.setContentsMargins(0, 0, 0, 0)
        content.setSpacing(0)
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        content.addLayout(body)

        # V1.9.50: offline session banner. main() could not open
        # the live database, so this session runs on the local
        # seed; the banner is the session's state, with the way
        # back (retry -> merge -> restart onto the live copy).
        self._offline = bool(_OFFLINE_SESSION)
        self._live_db_path = default_db_path()
        if self._offline:
            _banner = QFrame()
            _banner.setObjectName("offlineBanner")
            _bl = QHBoxLayout(_banner)
            _bl.setContentsMargins(12, 6, 12, 6)
            _bl.setSpacing(10)
            _blab = QLabel(
                "Offline — working on the local copy of your data. "
                "Changes merge back when the live database is "
                "reachable.")
            _blab.setObjectName("offlineBannerText")
            _bl.addWidget(_blab, 1)
            _retry = QPushButton("Retry connection")
            _retry.setObjectName("ghost")
            _retry.setCursor(Qt.PointingHandCursor)
            _retry.clicked.connect(self._retry_live_connection)
            _bl.addWidget(_retry)
            content.insertWidget(0, _banner)

        sidebar = QFrame()
        sidebar.setObjectName("sideBar")
        sidebar.setFixedWidth(200)
        sb = QVBoxLayout(sidebar)
        sb.setContentsMargins(12, 16, 12, 16)
        sb.setSpacing(6)
        self.sidebar = sidebar
        self._nav_group = QButtonGroup(self)
        self._nav_group.setExclusive(True)
        self._nav_buttons = {}
        self._nav_labels = {}
        for key, label, icon_name in (
            ("tasks", "Task List", "list"),
            ("queue", "Queue", "kanban"),
            ("directory", "CRM", "users"),
            ("dashboard", "Dashboard", "chart"),
            ("notes", "Notes", "notebook"),
        ):
            btn = QPushButton(label)
            btn.setObjectName("navBtn")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setIconSize(QSize(20, 20))
            btn.setToolTip(label)
            btn.clicked.connect(lambda _=False, k=key: self.set_page(k))
            self._nav_group.addButton(btn)
            sb.addWidget(btn)
            self._nav_buttons[key] = btn
            self._nav_labels[key] = label
        self._nav_buttons["tasks"].setChecked(True)
        # V1.9.17: sliding nav pill — the selected-item highlight is a
        # real widget behind the buttons that SLIDES (200ms ease-out)
        # to the newly selected item instead of flashing. The checked
        # button's own background is transparent in the theme (navPill
        # carries the colour), so only the pill shows.
        self._nav_pill = QFrame(sidebar)
        self._nav_pill.setObjectName("navPill")
        self._nav_pill.lower()
        self._nav_pill_anim = QPropertyAnimation(self._nav_pill, b"geometry")
        self._nav_pill_anim.setDuration(200)
        self._nav_pill_anim.setEasingCurve(QEasingCurve.OutCubic)
        sb.addStretch(1)
        # Collapse toggle (VS Code-style icon rail). Always visible; keyboard
        # focusable (in tab order) and activatable with Space, plus the Ctrl+B
        # shortcut.
        self._rail_toggle = QPushButton()
        self._rail_toggle.setObjectName("navToggle")
        self._rail_toggle.setCursor(Qt.PointingHandCursor)
        self._rail_toggle.setIconSize(QSize(20, 20))
        self._rail_toggle.setFocusPolicy(Qt.StrongFocus)
        self._rail_toggle.clicked.connect(self.toggle_sidebar)
        sb.addWidget(self._rail_toggle)
        # Build marker so the user can verify they got the new build.
        build_tag = QLabel(f"V{APP_VERSION}")
        build_tag.setObjectName("sideFoot")
        build_tag.setAlignment(Qt.AlignCenter)
        sb.addWidget(build_tag)
        self._build_tag = build_tag
        body.addWidget(sidebar)
        self._refresh_nav_icons()
        # Restore persisted rail state before first show.
        self._apply_sidebar_collapsed(
            QSettings("TaskListApp", "TaskList").value(
                "sidebar_collapsed", False, type=bool))
        # First layout pass: snap the nav pill onto the tasks button
        # (geometries are empty until the window is laid out).
        QTimer.singleShot(0, lambda: self._move_nav_pill(
            "tasks", animate=False))
        # Ctrl+B anywhere in the main window toggles the sidebar rail.
        QShortcut(QKeySequence("Ctrl+B"), self,
                  activated=self.toggle_sidebar)

        self.stack = QStackedWidget()
        self.tasks_page = QWidget()
        self._build_tasks_ui(self.tasks_page)
        log_startup_event("tasks UI built")
        # V1.9.12: shell-first startup. The other four pages used to be
        # built here, before the window could show — so any slow page
        # build delayed the window AND its taskbar button (Windows only
        # puts the button up once the window appears). The tasks page is
        # the one that opens, so it builds now; the rest start as
        # placeholders at the same stack indices and are built on the
        # first event-loop pass after show, or on demand if the user
        # navigates first (set_page ensures them).
        self._deferred_pages_built = False
        # V1.9.55: pages build one at a time, on first visit
        # (see _ensure_page); the attributes stay None until
        # their page exists.
        self._pages_built = set()
        self.queue_page = None
        self.directory_page = None
        self.dashboard_page = None
        self.notes_page = None
        self._page_placeholders = {}
        self.stack.addWidget(self.tasks_page)
        for _key in ("queue", "directory", "dashboard", "notes"):
            _ph = QWidget()
            self._page_placeholders[_key] = _ph
            self.stack.addWidget(_ph)
        body.addWidget(self.stack, 1)
        # V1.9.9: integrity check moved past first paint (see main()) — it
        # stats every attachment file and must never block the window.
        log_startup_event("integrity deferred")
        log_startup_event("window ready (shell)")
        # V1.9.25: the other four pages used to build on the FIRST
        # event-loop pass after show — so the window appeared and then
        # froze while Queue/CRM/Dashboard/Notes all built (the lag
        # right after launch). Pages now build ONLY on first
        # navigation: set_page() already calls _build_deferred_pages()
        # for any non-tasks page, so nothing is lost, and the tasks
        # page — the one that opens — is complete before first paint.
        # V1.9.10: cross-device freshness. The database lives in the app
        # folder, which sits on a network share used from more than one
        # machine (work PC + Surface) — an instance left open showed a
        # badly outdated queue because nothing re-read the file. Watch
        # the database file's stamp: check when the window is activated
        # and every 30 s; refresh only when the file actually changed.
        self._db_stamp = self._current_db_stamp()
        self._db_watch_timer = QTimer(self)
        self._db_watch_timer.setInterval(30_000)
        self._db_watch_timer.timeout.connect(self._check_external_db_change)
        self._db_watch_timer.start()

    def _build_deferred_pages(self):
        """Build the queue / CRM / dashboard / notes pages (once).

        V1.9.25: on demand ONLY — called by set_page /
        _slash_search_target / open_settings when a page is first
        needed. It used to also run on the first event-loop pass after
        show, which froze the just-appeared window while four pages
        built. Swaps each placeholder for its real page at the same
        stack index so set_page's fixed indices keep working.
        """
        if self._deferred_pages_built:
            return
        for key in ("queue", "directory", "dashboard", "notes"):
            self._ensure_page(key)
        _chip_font_tree(self)
        log_startup_event("deferred pages built")

    #: Sidebar key -> (stack index, page attribute).
    _PAGE_SLOTS = {"queue": (1, "queue_page"),
                   "directory": (2, "directory_page"),
                   "dashboard": (3, "dashboard_page"),
                   "notes": (4, "notes_page")}

    def _ensure_page(self, key):
        """Build ONE deferred page (once) and swap it into its
        stack slot. V1.9.55 (user, 2026-11-13: he selected
        Dashboard in the sidebar and the UI did not change --
        "eventually the ui changed to that module"): the old
        _build_deferred_pages built ALL FOUR pages synchronously
        inside the nav click, before the stack switched or the
        nav pill moved, so the click had no visible answer until
        four page constructions plus a full refresh had run --
        seconds on a slow-I/O database. Pages now build singly,
        only when first visited."""
        if key in self._pages_built:
            return
        self._pages_built.add(key)
        index, attr = self._PAGE_SLOTS[key]
        if key == "directory":
            page = DirectoryPage(self.db)
            # V1.9.51: a rename saved in any CRM contact card
            # refreshes the task views immediately.
            page.directory_changed.connect(self.refresh)
        elif key == "queue":
            page = QueuePage(self.db)
            page.card_open_requested.connect(self.open_detail)
            page.scope_toggled.connect(self.on_scope_toggled)
            page.hot_toggled.connect(self.on_hot_toggled)
            page.status_chosen.connect(self.on_status_chosen)
            page.edit_requested.connect(self.edit_task)
            page.delete_requested.connect(self.delete_task)
        elif key == "dashboard":
            page = DashboardPage(self.db)
            page.open_task_requested.connect(self.open_detail)
        else:
            page = NotesPage(self.db)
        setattr(self, attr, page)
        # If the placeholder being swapped out is the CURRENT
        # widget (the user is looking at this page's slot right
        # now -- the normal first-visit path), removing it makes
        # the stack fall back to another page; restore the slot
        # as current so the freshly built page is what shows.
        was_current = self.stack.currentIndex() == index
        old = self.stack.widget(index)
        self.stack.removeWidget(old)
        old.deleteLater()
        self.stack.insertWidget(index, page)
        if was_current:
            self.stack.setCurrentIndex(index)
        if len(self._pages_built) == 4:
            self._deferred_pages_built = True
        _chip_font_tree(self)
        log_startup_event(f"deferred page built: {key}")

    # ---- cross-device freshness ----
    def _current_db_stamp(self):
        try:
            base = Path(self.db.path)
            stamps = []
            for suffix in ("", "-wal", "-journal"):
                p = Path(str(base) + suffix)
                if p.exists():
                    st = p.stat()
                    stamps.append((suffix, st.st_mtime_ns, st.st_size))
            return tuple(stamps)
        except Exception:
            return None

    def _check_external_db_change(self):
        try:
            if QApplication.activeModalWidget() is not None:
                return  # never yank data out from under a dialog/edit
            focus = QApplication.focusWidget()
            if isinstance(focus, (QPlainTextEdit, QTextEdit)):
                return  # user is mid-edit in a text field; next tick retries
            stamp = self._current_db_stamp()
            if stamp is not None and self._db_stamp is not None \
                    and stamp != self._db_stamp:
                self._db_stamp = stamp
                self.refresh()
                # The visible page refreshes too — the queue is where
                # cross-device staleness bites hardest.
                current = self.stack.currentWidget()
                for page in (self.queue_page, self.dashboard_page,
                             self.directory_page):
                    if current is page:
                        page.refresh()
                        break
        except Exception:
            pass

    def changeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().changeEvent(event)
        if event.type() == QEvent.ActivationChange and self.isActiveWindow():
            self._check_external_db_change()

    def _build_tasks_ui(self, page):
        """The original Task List overview, now one sidebar page."""
        # NOTE: the card-list scroll area stays at the page's content column
        # (it cannot bleed past the page widget — child widgets clip at the
        # parent's bounds). Its scrollbar is flush with the scroll area via
        # the shared QSS rule; see _ScrollBleedLayout (dialogs only).
        main = QVBoxLayout(page)
        main.setContentsMargins(24, 16, 24, 18)
        main.setSpacing(12)

        # ---- header ----
        header = QHBoxLayout()
        header.setSpacing(12)
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title = QLabel("Task List")
        title.setObjectName("title")
        subtitle = QLabel("Quotes, CAD, Configura and everything in between.")
        subtitle.setObjectName("subtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box)
        header.addStretch(1)

        new_btn = QPushButton("+ New Task")
        new_btn.setObjectName("primary")
        new_btn.setCursor(Qt.PointingHandCursor)
        new_btn.setToolTip("Create a new task (Ctrl+N)")
        new_btn.clicked.connect(self.new_task)
        header.addWidget(new_btn)
        self.new_task_btn = new_btn
        # V1.9.30 (user): the leftover sun/moon theme button is GONE
        # from the header -- theme changes live in Settings only.
        # + New Task now sits at the header's right edge.
        main.addLayout(header)

        # V1.9.34 (user: "the search and sort by are NOT INLINE with
        # everything else"): Sort and Search sit IN the filter
        # toolbar row below, right side -- one controls row, one
        # baseline. (V1.9.29 had moved them to their own sub-header
        # row; side by side with the filters they read as a mistake,
        # so they are back in line. The widgets are built here and
        # added to the toolbar layout further down.)
        sort_label = QLabel("Sort by")
        sort_label.setObjectName("sortLabel")
        sort_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.sort_box = SafeComboBox()
        self.sort_box.setObjectName("sortBox")
        self.sort_box.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        for key in SORT_MODES:
            self.sort_box.addItem(SORT_MODES[key][0], key)
        self.sort_box.setCurrentIndex(list(SORT_MODES).index(self.sort))
        self.sort_box.currentIndexChanged.connect(self._on_sort_changed)

        self.search = SearchField()
        self.search.setPlaceholderText("Search quote, distributor, end user, rack type, notes\u2026")
        self.search.setFixedWidth(380)
        self.search.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        # debounced: refresh only after the user pauses typing (~280ms)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(280)
        self._search_timer.timeout.connect(self._apply_search)
        self.search.textChanged.connect(lambda _=None: self._search_timer.start())
        # The result count lives INSIDE the search field (not in any
        # layout), so it never shifts the row's geometry.

        # ---- toolbar: filter chips + outcome filter + sort + search --
        toolbar = QFrame()
        toolbar.setObjectName("toolBar")
        # V1.9.37 (user: "not aligned or uniform... the left bar is
        # not fully visible so I can't filter all the options"): TWO
        # FIXED ROWS, always the same shape at every width. Row 1 is
        # the chip strip ALONE at full width -- all six chips always
        # visible, never squeezed, never sliced mid-word. Row 2 is
        # the controls (Outcome, Scope, attachments, Sort, Search)
        # in a FlowLayout: one line at desktop widths, wrapping
        # right-aligned at very narrow ones. The V1.9.36 experiment
        # (one flow row, strip absorbs the squeeze) is what cut the
        # chips in half on the user's screen.
        tool_rows = QVBoxLayout(toolbar)
        tool_rows.setContentsMargins(0, 0, 0, 0)
        tool_rows.setSpacing(8)
        controls = QWidget()
        bar = FlowLayout(controls, h_spacing=10, v_spacing=8)
        bar.setContentsMargins(0, 0, 0, 0)
        # V1.9.49 (user: "I think these should be tabs as well.
        # That way ITS ALL UNIFORM"): the status filter is a tab
        # strip now -- the same _ChromeTabBar the dashboard and
        # CRM use, its active tab merging into the page surface.
        # The buttons keep the _view_buttons shape the counts
        # update (setText + the attention property) already uses;
        # chip_strip/_filter_seg keep pointing at the strip for
        # the theme refresh.
        seg = _ChromeTabBar(palette_fn=_page_tab_palette)
        self._filter_seg = seg
        for key, label in FILTER_VIEWS:
            btn = seg.add_tab(label)
            # V1.9.51 (user: the contact-window tabs animate
            # right, the rest glitch): the strip's own group slot
            # starts the silhouette slide FIRST, but set_view then
            # rebuilt the whole task list SYNCHRONOUSLY in the same
            # click, freezing the slide's opening frames -- it read
            # as a jump, not a glide. Defer the rebuild a few
            # frames so the slide is visibly moving first, exactly
            # like the contact window whose page swap is instant
            # and cheap. Latest click wins.
            btn.clicked.connect(
                lambda _=False, k=key: self._schedule_set_view(k))
            self._view_buttons[key] = btn
        seg.setCurrentIndex(0)
        tool_rows.addWidget(seg)
        self.chip_strip = seg

        # V1.9.29 (user request): Won / Lost / Unknown outcome filter
        # in the seat Sort used to occupy (Sort + Search moved to the
        # header rows above). "All outcomes" = no filtering.
        # V1.9.37 (user): no "Outcome"/"Scope" labels -- the combos
        # already say it ("All outcomes" / "All scopes"), and the
        # labels were eating toolbar width the chips need.
        self.outcome_box = SafeComboBox()
        self.outcome_box.setObjectName("sortBox")
        self.outcome_box.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        for label, key in (("All outcomes", "all"), ("Won", "won"),
                           ("Lost", "lost"), ("Dead", "dead"),
                           ("On Hold", "on_hold"),
                           ("Unknown", "unknown")):
            self.outcome_box.addItem(label, key)
        self.outcome_box.currentIndexChanged.connect(
            self._on_outcome_filter_changed)
        # V1.9.52 (user): the selection count lives UNDER the
        # outcomes dropdown -- the combo and its count form one
        # little column in the bar (see _sel_count_label below).
        # The bar is a FlowLayout (widgets only), so the column
        # is a small transparent container widget.
        _outcome_cell = QWidget()
        _outcome_cell.setObjectName("outcomeCell")
        _outcome_vbox = QVBoxLayout(_outcome_cell)
        _outcome_vbox.setContentsMargins(0, 0, 0, 0)
        _outcome_vbox.setSpacing(2)
        _outcome_vbox.addWidget(self.outcome_box)
        bar.addWidget(_outcome_cell)
        self._outcome_cell = _outcome_cell
        self._outcome_layout = _outcome_vbox

        # V1.9.34 moved the Scope filter and the attachments toggle
        # up into the toolbar (out of their old stacked rows below);
        # V1.9.37 gives them the toolbar's second row (see above).

        self.scope_box = SafeComboBox()
        self.scope_box.setObjectName("sortBox")
        self.scope_box.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.scope_box.setToolTip("Show only tasks with this scope step")
        self._populate_scope_box()
        self.scope_box.currentIndexChanged.connect(self._on_scope_changed)
        bar.addWidget(self.scope_box)

        # V1.9.16: the filter is a real toggle switch now (user request:
        # toggle preferred over the old chip button or a checkbox). The
        # switch keeps the attach_only_btn name/API its filter reads use.
        attach_lab = QLabel("Has attachments")
        attach_lab.setObjectName("sortLabel")
        attach_lab.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.attach_only_btn = ToggleSwitch()
        self.attach_only_btn.setToolTip("Show only tasks with attachments")
        self.attach_only_btn.toggled.connect(self._on_attach_toggled)
        bar.addWidget(attach_lab)
        bar.addWidget(self.attach_only_btn)
        # V1.9.50 (user): the selection count is plain text and
        # nothing else -- the floating bulk bar is GONE (his
        # order: "JUST REMOVE THAT MENU ALL TOGETHER"): every
        # action it held lives in the right-click menu now,
        # which applies to the whole selection.
        # V1.9.52 (user): the count moves to sit nicely UNDER
        # the outcomes dropdown (the _outcome_cell column).
        self._sel_count_label = QLabel("")
        self._sel_count_label.setObjectName("selCountLabel")
        self._sel_count_label.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._sel_count_label.setVisible(False)
        self._outcome_layout.addWidget(self._sel_count_label)
        # The spring keeps Sort + Search at the right edge whenever
        # the row fits on one line (the V1.9.34 arrangement); on a
        # wrapped row it just takes that row's leftover.
        bar.addItem(QSpacerItem(
            0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        # V1.9.50 (user): "Sort by" sits ABOVE its dropdown instead
        # of beside it, which frees the row's width.
        sort_wrap = QWidget()
        sort_col = QVBoxLayout(sort_wrap)
        sort_col.setContentsMargins(0, 0, 0, 0)
        sort_col.setSpacing(2)
        sort_col.addWidget(sort_label)
        sort_col.addWidget(self.sort_box)
        # Balance the caption's height BELOW the dropdown, so
        # the dropdown itself sits on the controls row's centre
        # line with its siblings (the flow centres the wrap;
        # without the counterweight the box rides ~9px low).
        sort_col.addItem(QSpacerItem(
            0, sort_label.sizeHint().height() + 2,
            QSizePolicy.Minimum, QSizePolicy.Fixed))
        bar.addWidget(sort_wrap)
        bar.addWidget(self.search)
        tool_rows.addWidget(controls)
        main.addWidget(toolbar)

        # ---- selection state (V1.9.50: the bulk bar is REMOVED --
        # see the count label by the attachments toggle; bulk
        # actions live in the right-click menus) ----
        self._selected = set()
        self._col_sort = None  # (TaskTable column, descending) or None
        # V1.9.8: card-build generation — refresh() builds cards in chunks
        # (see _build_card_chunk); a newer refresh cancels a stale build.
        self._card_build_gen = 0
        self._card_build_tasks = []

        # ---- card list ----
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        container = QWidget()
        self.cards_layout = QGridLayout(container)
        self.cards_layout.setSpacing(12)
        self.cards_layout.setAlignment(Qt.AlignTop)
        self.cards_layout.setColumnStretch(0, 1)
        self.cards_layout.setColumnStretch(1, 1)
        self.cards_layout.setColumnStretch(2, 1)
        scroll.setWidget(container)
        self._cards_scroll = scroll
        # App-wide scroll insets: cards keep clear of the viewport edges
        # and the vertical scrollbar.
        set_scroll_content_margins(scroll)
        # Pen/finger kinetic scrolling (Surface-friendly).
        enable_touch_scroll(scroll)
        main.addWidget(scroll, 1)
        # V1.9.19: List View is a table now (attached-1 look); grid views
        # keep cards. The table lives beside the cards scroll area and
        # refresh() shows exactly one of them.
        self._tasks_table = TaskTable()
        self._tasks_table.sort_requested.connect(self._on_table_sort)
        self._tasks_table.hide()
        self._tasks_table.open_requested.connect(self.open_detail)
        self._tasks_table.edit_requested.connect(self.edit_task)
        self._tasks_table.delete_requested.connect(self.delete_task)
        self._tasks_table.duplicate_requested.connect(
            self.duplicate_as_requote)
        self._tasks_table.outcome_requested.connect(self.on_outcome_chosen)
        self._tasks_table.status_requested.connect(self.on_status_chosen)
        # V1.9.50: right-click bulk actions (the removed bulk bar's
        # engine, driven from the table's context menu).
        self._tasks_table.bulk_outcome_requested.connect(
            self._bulk_set_outcome)
        self._tasks_table.bulk_status_requested.connect(
            self._bulk_set_status)
        self._tasks_table.bulk_delete_requested.connect(self._bulk_delete)
        self._tasks_table.selection_changed.connect(self._on_table_selection)
        main.addWidget(self._tasks_table, 1)
        self._cards_container = container
        self._card_sync_queued = False
        self._card_syncing = False
        container.installEventFilter(self)


        # Ctrl+N anywhere in the main window opens the New Task dialog
        QShortcut(QKeySequence("Ctrl+N"), self, activated=self.new_task)

        # Bare "/" focuses the context-appropriate search box: the queue
        # filter when the queue page is visible, otherwise the main search.
        # (Suppressed while typing in an editable widget.)
        self.installEventFilter(SearchSlashFilter(self._slash_search_target, self))

        self.refresh()

    def _slash_search_target(self):
        self._build_deferred_pages()
        return slash_search_target(
            self.stack.currentWidget() is self.queue_page,
            self.queue_page.search,
            self.search,
        )

    # ---- sidebar navigation ----
    def set_page(self, key):
        # V1.9.55: the click answers NOW -- the stack switches
        # (to the page, or its placeholder on a first visit),
        # the nav button checks and the pill starts sliding in
        # this same handler. Building the page (first visit
        # only) and refreshing it run one event-loop tick later,
        # after this switch has painted, so a slow build or a
        # slow database can never again make a sidebar click
        # look ignored.
        index = {"tasks": 0, "queue": 1, "directory": 2, "dashboard": 3,
                 "notes": 4}[key]
        self.stack.setCurrentIndex(index)
        self._nav_buttons[key].setChecked(True)
        self._move_nav_pill(key)
        if key != "tasks":
            QTimer.singleShot(0, lambda: self._enter_page(key))

    def _enter_page(self, key):
        """Post-switch page entry: build on first visit, then
        refresh. Runs after set_page's switch has painted."""
        self._ensure_page(key)
        page = getattr(self, self._PAGE_SLOTS[key][1], None)
        if page is not None:
            page.refresh()

    def _move_nav_pill(self, key, animate=True):
        """Slide (or snap) the sidebar pill to a nav button's geometry."""
        pill = getattr(self, "_nav_pill", None)
        btn = self._nav_buttons.get(key) if pill is not None else None
        if pill is None or btn is None:
            return
        rect = btn.geometry()
        if rect.isEmpty():
            return
        if not animate or not self.isVisible():
            self._nav_pill_anim.stop()
            pill.setGeometry(rect)
            return
        self._nav_pill_anim.stop()
        self._nav_pill_anim.setStartValue(pill.geometry())
        self._nav_pill_anim.setEndValue(rect)
        self._nav_pill_anim.start()

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # Layout shifts: snap the pill to the checked button, no slide.
        checked = next((k for k, b in self._nav_buttons.items()
                        if b.isChecked()), "tasks")
        self._move_nav_pill(checked, animate=False)

    def _refresh_nav_icons(self):
        # V1.9.16 (user spec): the active sidebar item's icon is white
        # (dark theme) / near-black (light theme) — NOT accent-tinted and
        # NOT blue. The old code shifted the active icon to the accent,
        # and set_accent() never re-ran this refresh, so icons sat on
        # stale blue no matter what accent was picked.
        # V1.9.19 (his image-48 "blue-ish" report, never root-caused):
        # the RESTING grays were blue-toned by the numbers — #9ba1ab
        # (blue +16) and #5d6b82 (blue +37). True neutrals now (R=G=B),
        # which also pass through the accent shift unchanged.
        if self.theme == "dark":
            normal, active = "#9a9a9a", "#ffffff"
        else:
            normal, active = "#6e6e6e", "#1f1f1f"
        for key, icon_name in (
            ("tasks", "list"), ("queue", "kanban"), ("directory", "users"),
            ("dashboard", "chart"), ("notes", "notebook"),
        ):
            self._nav_buttons[key].setIcon(nav_icon(icon_name, normal, active, 20))

    # ---- collapsible sidebar rail ----
    def toggle_sidebar(self):
        target = not self._sidebar_collapsed
        QSettings("TaskListApp", "TaskList").setValue(
            "sidebar_collapsed", target)
        self._animate_sidebar_collapsed(target)

    def _animate_sidebar_collapsed(self, collapsed):
        """V1.9.51 (user, SMOOTH ANIMATION STANDARD, global: "the
        sidebar does jump versus expanding -- I want that smooth
        animation there"): the rail used to teleport between 200
        and 60 in one frame. The width now glides over 180ms with
        the tab slide's easing. Collapsing clears the labels up
        front (they would clip as the rail narrows); expanding
        restores them when the rail lands. A toggle mid-glide
        retargets from the current width."""
        from PySide6.QtCore import QParallelAnimationGroup
        self._sidebar_collapsed = bool(collapsed)
        end_w = 60 if collapsed else 200
        if collapsed:
            self._apply_sidebar_content(True)
        old = getattr(self, "_sidebar_anim", None)
        if old is not None:
            old.stop()
        group = QParallelAnimationGroup(self)
        for prop in (b"minimumWidth", b"maximumWidth"):
            anim = QPropertyAnimation(self.sidebar, prop, self)
            anim.setDuration(180)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            anim.setStartValue(self.sidebar.width())
            anim.setEndValue(end_w)
            group.addAnimation(anim)

        def _landed():
            self.sidebar.setFixedWidth(end_w)
            if not collapsed:
                self._apply_sidebar_content(False)
            else:
                checked = next(
                    (k for k, b in self._nav_buttons.items()
                     if b.isChecked()), "tasks")
                self._move_nav_pill(checked, animate=False)

        group.finished.connect(_landed)
        self._sidebar_anim = group
        group.start()

    def _apply_sidebar_content(self, collapsed):
        """The rail's non-width state for a collapsed flag:
        margins, labels, toggle glyph, build tag, nav pill."""
        self.sidebar.layout().setContentsMargins(
            *((8, 16, 8, 16) if collapsed else (12, 16, 12, 16)))
        for key, btn in self._nav_buttons.items():
            btn.setText("" if collapsed else self._nav_labels[key])
            btn.setToolTip(self._nav_labels[key])
        self._rail_toggle.setText("»" if collapsed else "«")
        self._rail_toggle.setToolTip(
            "Expand sidebar (Ctrl+B)" if collapsed
            else "Collapse sidebar (Ctrl+B)")
        self._build_tag.setVisible(not collapsed)
        checked = next((k for k, b in self._nav_buttons.items()
                        if b.isChecked()), "tasks")
        self._move_nav_pill(checked, animate=False)

    def _apply_sidebar_collapsed(self, collapsed):
        """Instant full apply (startup restore): width + content."""
        self._sidebar_collapsed = bool(collapsed)
        self.sidebar.setFixedWidth(60 if collapsed else 200)
        self._apply_sidebar_content(collapsed)

    # ---- menu bar ----
    def _build_menu(self, bar):
        # V1.9.51: the menubar's menus are GlassMenus like every
        # other menu in the app (the user: the File menu was still
        # a black slab -- "these should all be glass up here as
        # well"). bar.addMenu(str) would build plain QMenus
        # internally, so the instances are created first and
        # handed to the bar.
        file_menu = GlassMenu(bar)
        file_menu.setTitle("File")
        bar.addMenu(file_menu)
        settings_action = QAction("Settings…", self)
        settings_action.setShortcut("Ctrl+,")
        settings_action.triggered.connect(self.open_settings)
        file_menu.addAction(settings_action)
        file_menu.addSeparator()
        import_action = QAction("Import CSV…", self)
        import_action.triggered.connect(self.import_csv)
        file_menu.addAction(import_action)
        export_action = QAction("Export to Excel…", self)
        export_action.setShortcut("Ctrl+E")
        export_action.triggered.connect(self.export_excel)
        file_menu.addAction(export_action)
        file_menu.addSeparator()
        restore_action = QAction("Restore backup…", self)
        restore_action.triggered.connect(self.restore_backup)
        file_menu.addAction(restore_action)
        # V1.9.34 (user): "Pin to Taskbar…" REMOVED from this menu.
        # It was a workaround Icarus added instead of fixing pinning
        # itself; pinning works properly now (real .exe launcher +
        # Start Menu/Desktop shortcuts with the app's own identity),
        # so the menu item is clutter with a confusing job.
        file_menu.addSeparator()
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        view_menu = GlassMenu(bar)
        view_menu.setTitle("View")
        bar.addMenu(view_menu)
        # V1.9.30 (user): no theme actions here either -- the theme
        # is changeable in Settings only. self._theme_actions stays
        # an empty dict so set_theme's bookkeeping remains valid.
        self._theme_actions = {}

        layout_group = QActionGroup(self)
        layout_group.setExclusive(True)
        self._layout_actions = {}
        for key, label in (("list", "List View"),
                           ("grid3", "Grid View (3 columns)")):
            action = QAction(label, self, checkable=True)
            action.setChecked(self.layout_mode == key)
            action.triggered.connect(lambda _=False, k=key: self.set_layout_mode(k))
            layout_group.addAction(action)
            view_menu.addAction(action)
            self._layout_actions[key] = action

        help_menu = GlassMenu(bar)
        help_menu.setTitle("Help")
        bar.addMenu(help_menu)
        about_action = QAction("About Task List", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def set_layout_mode(self, mode):
        if mode == "grid":  # removed in V1.9.30 -- see __init__ note
            mode = "grid3"
        if mode not in ("list", "grid3"):
            mode = "list"
        self.layout_mode = mode
        QSettings("TaskListApp", "TaskList").setValue("layout_mode", mode)
        self._layout_actions[mode].setChecked(True)
        self.refresh()

    def _on_sort_changed(self, index):
        self.sort = self.sort_box.itemData(index)
        QSettings("TaskListApp", "TaskList").setValue("sort", self.sort)
        # A preset choice supersedes a header-click column sort.
        self._col_sort = None
        try:
            self._tasks_table.horizontalHeader().setSortIndicator(
                -1, Qt.AscendingOrder)
        except Exception:
            pass
        self.refresh()

    # Column orders for header-click sorting (V1.9.30).
    _STATUS_ORDER = {"in_process": 0, "on_hold": 1, "completed": 2,
                     "canceled": 3}
    _OUTCOME_ORDER = {"won": 0, "lost": 1, "dead": 2, "on_hold": 3,
                      "unknown": 4}

    def _on_table_sort(self, col):
        """Header click: sort by that column; clicking the same
        column again flips the direction (standard behavior)."""
        if getattr(self, "_col_sort", None) and self._col_sort[0] == col:
            self._col_sort = (col, not self._col_sort[1])
        else:
            self._col_sort = (col, False)
        try:
            self._tasks_table.horizontalHeader().setSortIndicator(
                col, Qt.DescendingOrder if self._col_sort[1]
                else Qt.AscendingOrder)
        except Exception:
            pass
        self.refresh()

    def _apply_col_sort(self, tasks):
        if not getattr(self, "_col_sort", None):
            return tasks
        from .ui import TaskTable as _TT
        col, rev = self._col_sort

        def notes_key(t):
            n = (t.get("notes") or "").strip()
            return n.splitlines()[0].lower() if n else ""

        keys = {
            _TT.COL_TASK: lambda t: (t.get("quote_number") or "").lower(),
            _TT.COL_DIST: lambda t: (t.get("distributor") or "").lower(),
            _TT.COL_SCOPE: lambda t: ", ".join(
                t.get("scope_of_work") or []).lower(),
            _TT.COL_STATUS: lambda t: self._STATUS_ORDER.get(
                t.get("status"), 9),
            _TT.COL_DUE: lambda t: (t.get("due_date") or "9999-99"),
            _TT.COL_NOTES: notes_key,
            _TT.COL_RACK: lambda t: ", ".join(
                t.get("rack_types") or []).lower(),
            _TT.COL_DATE: lambda t: t.get("created_at") or "",
            _TT.COL_COMPLETED: lambda t: t.get("completed_at") or "",
            _TT.COL_VALUE: lambda t: (t.get("quote_value") is None,
                                      t.get("quote_value") or 0),
            _TT.COL_OUTCOME: lambda t: self._OUTCOME_ORDER.get(
                t.get("outcome"), 9),
            _TT.COL_WAITING: lambda t: (t.get("waiting_on") or "").lower(),
            _TT.COL_REP: lambda t: (t.get("sales_rep") or "").lower(),
            _TT.COL_PER: lambda t: (t.get("per") or "").lower(),
            _TT.COL_REVISION: lambda t: (t.get("revision") or "00"),
            _TT.COL_HOURS: lambda t: (t.get("estimated_hours")
                                      or 0),
            _TT.COL_PROGRESS: lambda t: (
                len([s for s in (t.get("scope_done") or [])
                     if s in (t.get("scope") or [])]),
                len(t.get("scope") or [])),
            _TT.COL_FILES: lambda t: t.get("_att_count", 0),
        }
        if col == _TT.COL_FILES:
            # Attachment counts are not on the task dicts; batch
            # them in (visible rows only) for this sort.
            try:
                counts = {}
                hidden = {t["id"]: set(t.get("att_hidden") or [])
                          for t in tasks}
                for _tid, _aid in self.db.conn.execute(
                        "SELECT task_id, id FROM attachments"):
                    if _aid not in hidden.get(_tid, set()):
                        counts[_tid] = counts.get(_tid, 0) + 1
                for t in tasks:
                    t["_att_count"] = counts.get(t["id"], 0)
            except Exception:
                pass
        key = keys.get(col)
        if key is None:
            return tasks
        return sorted(tasks, key=key, reverse=rev)

    def _on_outcome_filter_changed(self, index):
        self.outcome_filter = self.outcome_box.itemData(index) or "all"
        self.refresh()

    def open_settings(self):
        self._build_deferred_pages()
        dialog = SettingsDialog(self.db, self)
        dialog.update_ready.connect(self._offer_update_ready)
        dialog.scopes_changed.connect(self.refresh)
        dialog.rack_types_changed.connect(self.refresh)
        dialog.sales_reps_changed.connect(self.refresh)
        dialog.queue_changed.connect(self.queue_page.refresh)
        # V1.9.29: live appearance sync while Settings is open (see
        # the signal's note in ui.py) -- not just after it closes.
        dialog.theme_changed.connect(self._sync_appearance_from_settings)
        dialog.exec()
        # Appearance changes made inside Settings (theme / accent) apply
        # live to the stylesheet, but the window's own theme state and
        # the painted surfaces (dashboard charts, directory chrome) sync
        # here so nothing is left stale.
        self._sync_appearance_from_settings()

    # ---- in-app updates (V1.9.30): the Drawing Finder flow ----
    def _start_update_launch_flow(self):
        """Called by main() for real launches only (never in tests):
        a short delay after show, then (1) resolve any staged
        update — offer it if newer, clear it if not — and (2) if
        nothing was staged and the startup check is on, run the
        silent background check."""
        QTimer.singleShot(2000, self._update_launch_step)

    def _update_launch_step(self):
        if not self._real_launch:
            return
        data_dir = self.db.path.parent
        try:
            action, tag = updater.pending_offer(data_dir, APP_VERSION)
        except Exception:
            action, tag = ("none", "")
        if action == "clear":
            updater.clear_pending_update(data_dir)
            updater.upd_log(
                f"launch: discarded staged update {tag} "
                f"(running {APP_VERSION})", data_dir)
        elif action == "offer":
            self._offer_update_ready(tag)
            return
        if updater.check_updates_enabled():
            threading.Thread(target=self._update_check_worker,
                             daemon=True).start()
        # V1.9.52: refresh the building-code dataset silently in
        # the background (offline / failure keeps the cached or
        # bundled copy -- the chip's data is never blocked on it).
        try:
            from . import building_codes as _bc
            _bc.fetch_remote(data_dir)
        except Exception:
            pass

    def _update_check_worker(self):
        """Silent launch check (DF semantics): only a staged,
        ready update makes any noise."""
        data_dir = self.db.path.parent
        try:
            release = updater.fetch_latest_release()
        except Exception:
            return
        tag = str(release.get("tag_name", "")).lstrip("v")
        if not tag or updater.version_tuple(tag) \
                <= updater.version_tuple(APP_VERSION):
            return
        url = updater.pick_zip_asset(release)
        if not url:
            return
        if updater.pending_offer(data_dir, APP_VERSION) \
                == ("offer", tag):
            self._upd_ready.emit(tag)
            return
        try:
            updater.stage_update(url, data_dir, tag)
        except Exception:
            return
        updater.upd_log(f"launch check: staged {tag}", data_dir)
        self._upd_ready.emit(tag)

    def _offer_update_ready(self, tag):
        if app_confirm(
                self, "Task List update",
                f"Version {tag} has been downloaded.",
                confirm_label="Restart now", cancel_label="Later",
                informative="Restart Task List now to apply the update?"):
            self._apply_update_and_restart()

    def _apply_update_and_restart(self):
        """Hand the staged zip to the detached helper (bundled
        python running tasklist/apply_update.py — DF's model) and
        quit; the helper waits for this process to exit, unpacks,
        and relaunches. In a source/dev layout (no bundled python)
        quitting is all that happens."""
        # V1.9.32 FIX (user: "definitely not launching" after the
        # 1.9.31 in-app update): __file__ resolves into the LOCAL
        # MIRROR under the launcher layout, so the helper extracted
        # the update into the mirror — not the real install — and
        # then relaunched "<mirror>/Task List.exe", which does not
        # exist there. The app closed and never came back. The update
        # must target the REAL install (launcher_root, resolved from
        # TASKLIST_DATA_DIR) and relaunch the user's actual launcher
        # (launcher_target); the launcher then re-mirrors the new
        # version from the updated install on its own gate.
        install = launcher_root()
        # V1.9.57: relaunch the LOCAL launcher copy when it
        # exists -- the share exe is exactly what a sick share
        # refuses to run (his Surface, 2026-11-13: the update
        # restart died on "Windows cannot access
        # \\fileshare1\...\Task List.exe").
        relaunch = preferred_launcher_target()
        data_dir = self.db.path.parent
        pending = data_dir / "pending_update.zip"
        pyw = install / "python" / "pythonw.exe"
        helper = install / "tasklist" / "apply_update.py"
        updater.upd_log(
            f"apply requested: running {APP_VERSION}, staged "
            f"{updater.pending_update_tag(data_dir)}, install "
            f"{install}, relaunch {relaunch}", data_dir)
        if pending.is_file() and pyw.is_file() and helper.is_file():
            flags = 0
            if sys.platform == "win32":
                flags = 0x00000008 | 0x08000000  # DETACHED | NO_WINDOW
            try:
                subprocess.Popen(
                    [str(pyw), str(helper), "--apply-update",
                     str(os.getpid()), str(pending), str(install),
                     str(data_dir), str(relaunch)],
                    cwd=str(install), creationflags=flags,
                    close_fds=True)
            except Exception as exc:
                updater.upd_log(f"helper spawn failed: {exc!r}",
                                data_dir)
        QApplication.instance().quit()

    def _sync_appearance_from_settings(self):
        """Re-theme every painted surface from the saved appearance.

        Runs live on the Settings dialog's theme_changed signal and
        again after the dialog closes (backstop). set_theme covers
        the dashboard, CRM, chip strip and the task table's private
        stylesheet; refresh() rebuilds the task cards, whose painted
        colors are chosen at build time.
        """
        if saved_theme() != self.theme:
            self.set_theme(saved_theme())
        else:
            self.set_accent()
        self.refresh()

    def set_accent(self):
        """Re-apply the current theme with the saved accent colour."""
        apply_theme(QApplication.instance(), self.theme)
        if getattr(self, "dashboard_page", None) is not None:
            self.dashboard_page.refresh_theme()
        if getattr(self, "directory_page", None) is not None:
            self.directory_page.refresh_theme()
        self._refresh_nav_icons()
        self.refresh()

    def set_theme(self, name):
        self.theme = name
        save_theme(name)
        apply_theme(QApplication.instance(), name)
        if hasattr(self, "chip_strip"):
            self.chip_strip.refresh_theme()
        # Dashboard and CRM pages own module-local stylesheets; re-theme
        # them so they follow the app instead of staying dark in light mode.
        if getattr(self, "dashboard_page", None) is not None:
            self.dashboard_page.refresh_theme()
        if getattr(self, "directory_page", None) is not None:
            self.directory_page.refresh_theme()
        # V1.9.19: the task table owns the same module-local sheet.
        if hasattr(self, "_tasks_table"):
            from .ui import data_table_qss
            self._tasks_table.setStyleSheet(data_table_qss())
        if name in self._theme_actions:
            self._theme_actions[name].setChecked(True)
        self._refresh_nav_icons()
        if hasattr(self, "theme_btn"):
            self._update_theme_icon()

    def show_about(self):
        app_message(
            self, "About Task List",
            f"<b>Task List</b> V{APP_VERSION}<br>Track work from first request to final outcome. "
            "Files, notes, contacts and history stay attached to the job they belong to, "
            "and the dashboard shows what's open, what's due and what's been won — all in one place.<br>"
            "Your data is stored locally and travels with the app.",
            rich=True,
        )

    def export_excel(self):
        default_name = f"TaskList-Export-{datetime.now():%Y-%m-%d}.xlsx"
        start = str(Path(default_export_dir()) / default_name)
        path, _ = QFileDialog.getSaveFileName(
            self, "Export to Excel", start, "Excel Files (*.xlsx)",
            "", QFileDialog.DontUseNativeDialog
        )
        if not path:
            return
        try:
            # export exactly what the list is showing: current view, filters,
            # search and sort
            tasks = self.db.list_tasks(
                view=self.view, search=self.search_text, sort=self.sort,
                scope_filter=self.scope_filter,
                has_attachments=self.attach_only_btn.isChecked(),
                outcome=self.outcome_filter,
            )
            atts = {t["id"]: self.db.list_attachments(t["id"]) for t in tasks}
            # v1.4.0 item 14: lazy import — openpyxl stays off the launch path.
            from .export import export_tasks_to_excel
            export_tasks_to_excel(tasks, atts, path)
        except Exception as exc:  # noqa: BLE001
            show_toast(self, "error", "Export failed",
                       f"Could not write the file:\n{exc}")
            return
        show_toast(
            self, "success", "Export complete",
            f"Exported {len(tasks)} tasks (current view) to:\n{path}"
        )

    def import_csv(self):
        """Import tasks from a CSV file with a preview/confirmation step."""
        dialog = CsvImportDialog(self.db, self)
        if not dialog.exec():
            return
        rows = dialog.rows()
        imported, skipped, dupes = 0, 0, 0

        def _float(v):
            try:
                return float(str(v).strip()) if str(v).strip() else None
            except (TypeError, ValueError):
                return None

        for row in rows:
            quote = (row.get("quote_number") or "").strip()
            if not quote:
                skipped += 1
                continue
            if self.db.task_id_for_quote(quote) is not None:
                skipped += 1
                dupes += 1
                continue
            status = (row.get("status") or "").strip()
            scope = [s.strip() for s in (row.get("scope") or "").split(";")
                     if s.strip()]
            racks = [s.strip() for s in (row.get("rack_types") or "").split(";")
                     if s.strip()]
            due = (row.get("due_date") or "").strip() or None
            task_id = self.db.add_task(
                quote,
                (row.get("distributor") or "").strip(),
                (row.get("end_user") or "").strip(),
                (row.get("notes") or "").strip(),
                scope,
                rack_types=racks,
                due_date=due,
                estimated_hours=_float(row.get("estimated_hours")),
                quote_value=_float(row.get("quote_value")),
            )
            if status in STATUSES:
                try:
                    self.db.set_status(task_id, status)
                except Exception:  # noqa: BLE001
                    pass
            self.db.log_activity(task_id, "create", "Imported from CSV")
            imported += 1
        self.refresh()
        msg = f"Imported {imported} task(s)."
        if skipped:
            msg += f" Skipped {skipped} row(s)"
            bits = []
            if dupes:
                bits.append(f"{dupes} duplicate quote number(s)")
            if skipped - dupes:
                bits.append(f"{skipped - dupes} with no quote number")
            if bits:
                msg += " (" + ", ".join(bits) + ")."
        show_toast(self, "success", "Import complete", msg)

    def restore_backup(self):
        """One-click restore from a rotated backup (with safety copy first)."""
        try:
            backups = self.db.list_backups()
        except Exception as exc:  # noqa: BLE001
            show_toast(self, "error", "Restore backup",
                       f"Could not list backups:\n{exc}")
            return
        if not backups:
            show_toast(self, "info", "Restore backup",
                       "No backups found yet.")
            return
        names = [b["name"] if isinstance(b, dict) else str(b) for b in backups]
        name, ok = app_get_item(
            self, "Restore backup",
            "Choose a backup to restore.\n"
            "Your current data is backed up first, so nothing is lost.",
            names, 0)
        if not ok or not name:
            return
        if not app_confirm(
                self, "Restore backup",
                f"Restore “{name}”?\nThe current database will be saved as a backup first.",
                confirm_label="Restore"):
            return
        try:
            self.db.restore_backup(name)
        except Exception as exc:  # noqa: BLE001
            show_toast(self, "error", "Restore failed",
                       f"Could not restore the backup:\n{exc}")
            return
        self.refresh()
        show_toast(self, "success", "Restore complete",
                   f"Restored “{name}”.\nYour previous data was kept as a backup.")

    # ---- task actions ----
    def _on_attach_toggled(self, _checked=False):
        # V1.9.18: filter switches SLIDE (user order) — the attach
        # toggle's old crammed-flash came from the same clear-then-lay
        # -out frame as the view switches; both are fixed by the
        # hide-before-delete in refresh() plus the slide below.
        self._want_slide = True
        self.refresh()

    def _schedule_set_view(self, view):
        """V1.9.52 (user: the filter-tab animation "is still
        choppy and not smooth"): the content rebuild now waits
        until the tab slide SETTLES. The V1.9.51 ~50ms defer
        landed the full task-list rebuild in the middle of the
        180ms slide, and the rebuild's frames were the slide's
        missing frames. A 400ms fallback covers switches that
        start no slide, so a click can never be eaten; only the
        latest requested view applies."""
        self._pending_view = view
        if getattr(self, "_view_timer", None) is None:
            self._view_timer = QTimer(self)
            self._view_timer.setSingleShot(True)
            self._view_timer.timeout.connect(self._apply_pending_view)
            try:
                self._filter_seg.slideFinished.connect(
                    self._apply_pending_view)
            except Exception:
                pass
        self._view_timer.start(400)

    def _apply_pending_view(self):
        view = getattr(self, "_pending_view", None)
        self._pending_view = None
        timer = getattr(self, "_view_timer", None)
        if timer is not None:
            timer.stop()
        if view is not None and view != getattr(self, "view", None):
            self.set_view(view)

    def set_view(self, view):
        self.view = view
        # V1.9.51: NO content slide on a filter-TAB switch -- tab
        # switches are silhouette-slide + instant content swap
        # everywhere (the contact window's pattern). The V1.9.18
        # content slide under the tab slide was the double motion
        # the user called glitchy. (The attachments toggle and the
        # scope combo keep their slides -- they are not tabs.)
        self.refresh()

    def _apply_search(self):
        self.search_text = self.search.text().strip()
        self.refresh()

    def _populate_scope_box(self):
        current = self.scope_box.currentData() if hasattr(self, "scope_box") else None
        self.scope_box.blockSignals(True)
        self.scope_box.clear()
        self.scope_box.addItem("All scopes", None)
        try:
            scopes = self.db.get_scopes()
        except Exception:
            scopes = []
        for s in scopes:
            self.scope_box.addItem(s, s)
        if current is not None:
            idx = self.scope_box.findData(current)
            if idx >= 0:
                self.scope_box.setCurrentIndex(idx)
        self.scope_box.blockSignals(False)

    def _on_scope_changed(self, index):
        self.scope_filter = self.scope_box.itemData(index)
        self._want_slide = True
        self.refresh()

    def toggle_theme(self):
        self.set_theme("light" if self.theme == "dark" else "dark")

    def _update_theme_icon(self):
        if not hasattr(self, "theme_btn"):
            return
        # show the icon of the mode you will switch TO
        name = "sun" if self.theme == "dark" else "moon"
        color = "#9ba1ab" if self.theme == "dark" else "#5d6b82"
        self.theme_btn.setIcon(svg_icon(name, color, 18))

    def new_task(self):
        # Same NewTaskDialog both modules use; the Task List path passes no
        # queue columns, so there is no picker and no column assignment.
        task_id = run_new_task_dialog(
            self.db, self,
            on_created=None,
            open_existing=self.open_detail,
            on_settled=self.refresh,
        )
        if task_id:
            self.refresh()

    def _ensure_on_screen(self):
        """Phantom-monitor guard (v1.2.9): if the restored geometry lands on
        no available screen (e.g. closed on a work monitor, reopened on the
        laptop at home), re-center on the primary screen instead of opening
        invisibly. Only the no-intersection case is moved; anything
        partially visible is left exactly where it was."""
        try:
            frame = self.frameGeometry()
            if any(s.geometry().intersects(frame)
                   for s in QGuiApplication.screens()):
                return
            primary = QGuiApplication.primaryScreen()
            if primary is None:
                return
            avail = primary.availableGeometry()
            x = avail.x() + max(0, (avail.width() - frame.width()) // 2)
            y = avail.y() + max(0, (avail.height() - frame.height()) // 2)
            self.move(x, y)
        except Exception:
            pass

    def run_deferred_backup(self):
        """Rotating backup, deferred until after the window first shows.

        v1.2.9: backup_now() used to re-zip every attachment on the UI
        thread BEFORE the window appeared — minutes with a big attachment
        library, and the app never even reached Alt+Tab. Deferring alone
        was not enough either: the first v1.2.9 launch has no stored
        fingerprint, so it would do a full multi-minute rezip and freeze
        the VISIBLE window. So now the cheap fingerprint check runs here
        on the UI thread, and the heavy work (DB snapshot copy,
        attachments zip build, pruning) runs on a QThread worker — but
        ONLY when the fingerprint says a rebuild is actually needed. The
        worker never touches widgets; "deferred backup done" is logged
        from the completion handler, which the signal machinery delivers
        on the main thread. Worker errors are swallowed: the backup is
        best-effort and must never disturb the running app.
        """
        # V1.9.37 (user): the snapshot now runs on EVERY launch.
        # The old gate (attachments fingerprint) left pure task
        # edits -- most of his changes -- unsnapshotted for days.
        # The worker snapshots the DB unconditionally and only
        # rebuilds the attachments zip when its fingerprint moved.
        try:
            prev_fp = self.db.get_setting(
                "last_attachments_backup_fp", "")
        except Exception:
            prev_fp = ""
        db_path_str = str(self.db.path)

        def _backup_finished(payload):
            try:
                if payload.get("ok"):
                    fp = (payload.get("value") or {}).get("fingerprint")
                    if fp:
                        try:
                            self.db.set_setting(
                                "last_attachments_backup_fp", fp)
                        except Exception:
                            pass
            finally:
                log_startup_event("deferred backup done")

        run_folder_background(_backup_worker_main, _backup_finished,
                              db_path_str, prev_fp)

    def _startup_folder_queue(self):
        """Process quote folders queued while the destination was offline.

        Unattended: never shows dialogs (collisions auto-use the existing
        folder); ends with a single summary notice. Everything network-bound
        runs off the UI thread; all SQLite writes happen on the main thread.
        """
        def _done(summary):
            log_startup_event("folder queue finished")
            # V1.9.8: only refresh when folders were actually created —
            # an unconditional refresh here rebuilds all cards a second
            # time right after startup for no reason.
            if not (summary or {}).get("created"):
                return
            try:
                self.refresh()
            except Exception:
                pass
        try:
            process_pending_folders_startup(
                self.db, parent=self, on_done=_done)
        except Exception:
            log_startup_event("folder queue finished")

    def open_detail(self, task_id, editing=False):
        existing = self._detail_windows.get(task_id)
        if existing is not None:
            try:
                existing.raise_()
                existing.activateWindow()
            except RuntimeError:
                # window was deleted out from under us
                self._detail_windows.pop(task_id, None)
                existing = None
            else:
                if editing:
                    existing.set_editing(True)
                return
        window = TaskDetailWindow(self.db, task_id, start_editing=editing, parent=self)
        window.setAttribute(Qt.WA_DeleteOnClose)
        window.task_changed.connect(self.refresh)
        window.open_task_requested.connect(self.open_detail)
        window.destroyed.connect(
            lambda _obj=None, tid=task_id: self._detail_windows.pop(tid, None)
        )
        self._detail_windows[task_id] = window
        window.show()
        # Bring to front: show() alone can leave the window behind the
        # main window on Windows (user-reported: completed task detail
        # opened behind).
        window.raise_()
        window.activateWindow()
        # V1.9.48: detail windows are top-level windows too -- stamp
        # the same taskbar identity on them, so no Task List window
        # can ever present as "Python" in the taskbar.
        try:
            stamp_window_identity(int(window.winId()))
        except Exception:  # noqa: BLE001 - identity must never break open
            pass

    def edit_task(self, task_id):
        self.open_detail(task_id, editing=True)

    def delete_task(self, task_id):
        task = self._tasks.get(task_id)
        name = task["quote_number"] if task else ""
        if app_confirm(
            self, "Delete task",
            f"Delete task {name} and all its attachments? This cannot be undone.",
            confirm_label="Delete", danger=True):
            self.db.delete_task(task_id)
            shutil.rmtree(task_attachments_dir(self.db, task_id), ignore_errors=True)
            self.refresh()

    def duplicate_as_requote(self, task_id):
        """Card menu 'Duplicate': copy as a new linked re-quote."""
        try:
            new_id = self.db.duplicate_task(task_id)
        except Exception as exc:  # noqa: BLE001
            show_toast(self, "error", "Duplicate",
                       f"Could not duplicate the task:\n{exc}")
            return
        self.db.log_activity(new_id, "duplicate",
                             f"Created as re-quote of task {task_id}")
        self.refresh()
        self.open_detail(new_id)

    def on_scope_toggled(self, task_id, scope, done):
        task = self.db.get_task(task_id)
        if not task:
            return
        done_list = list(task.get("scope_done", []))
        if done and scope not in done_list:
            done_list.append(scope)
        elif not done and scope in done_list:
            done_list.remove(scope)
        self.db.set_scope_done(task_id, done_list)
        # auto-complete: every selected step checked -> Completed
        task = self.db.get_task(task_id)
        scopes = task.get("scope", [])
        done_set = set(task.get("scope_done", []))
        if scopes and all(s in done_set for s in scopes):
            if task["status"] not in ("completed", "canceled"):
                self.db.set_status(task_id, "completed")
                maybe_ask_price(self, self.db, task_id)
        elif task["status"] == "completed" and any(s not in done_set for s in scopes):
            self.db.set_status(task_id, "in_process")
        # V1.9.5: checking off Freight / Lead-Time prompts for its details.
        # Unchecking keeps the saved details; re-checking re-prompts and
        # overwrites with the new information.
        if done:
            maybe_prompt_scope_info(self, self.db, task_id, scope)
        self.refresh()

    def on_hot_toggled(self, task_id):
        """V1.9.5: flip the hot/attention flag; the card redraws with a red
        border and red ! icon while hot."""
        task = self.db.get_task(task_id)
        if not task:
            return
        new_hot = not task.get("is_hot")
        self.db.set_hot(task_id, new_hot)
        # V1.9.7: update the visible cards in place. The old full refresh()
        # here destroyed and rebuilt every card, which dropped the clicked
        # button's focus and made the queue scroll jump ("everything shifts
        # down" on every ! click).
        self._update_cards_hot(task_id, new_hot)

    def _update_cards_hot(self, task_id, is_hot):
        """Apply a hot-state change to on-screen cards without rebuilding."""
        try:
            columns = list(self.queue_page.columns.values())
        except Exception:  # noqa: BLE001
            columns = []
        for col in columns:
            try:
                cards = list(col._iter_cards())
            except Exception:  # noqa: BLE001
                continue
            for card in cards:
                try:
                    if card._task.get("id") == task_id:
                        card.set_hot(is_hot)
                except Exception:  # noqa: BLE001
                    pass
        try:
            layout = self.cards_layout
        except Exception:  # noqa: BLE001
            return
        for i in range(layout.count()):
            try:
                item = layout.itemAt(i)
                w = item.widget() if item is not None else None
                if w is not None and hasattr(w, "set_hot") \
                        and w._task.get("id") == task_id:
                    w.set_hot(is_hot)
            except Exception:  # noqa: BLE001
                pass

    def on_status_chosen(self, task_id, status):
        task = self.db.get_task(task_id)
        if status == "canceled" and task and task["status"] != "canceled":
            if not confirm_cancel_with_reason(self, self.db, task_id):
                self.refresh()  # pill re-renders from the unchanged db status
                return
        else:
            self.db.set_status(task_id, status)
            if status == "completed":
                maybe_ask_price(self, self.db, task_id)
        self.refresh()

    def on_outcome_chosen(self, task_id, outcome):
        # From the card context menu (Mark won / Mark lost / Clear mark).
        # db.set_outcome validates; the menu only ever sends valid values.
        try:
            self.db.set_outcome(task_id, outcome)
        except ValueError:
            pass
        else:
            detail = (f"Marked {outcome}" if outcome in ("won", "lost")
                      else "Outcome mark cleared")
            self.db.log_activity(task_id, "outcome", detail)
        self.refresh()

    # ---- rendering ----

    def eventFilter(self, obj, event):
        if (obj is getattr(self, "_cards_container", None)
                and event.type() == QEvent.Type.Resize):
            # Column widths changed (window resized) -> wrapped text may
            # need a different height; re-sync once the layout settles.
            self._queue_card_sync()
        return super().eventFilter(obj, event)

    def _queue_card_sync(self):
        """Defer a uniform-height pass until the layout has settled."""
        if not self._card_sync_queued:
            self._card_sync_queued = True
            QTimer.singleShot(0, self._sync_card_heights)

    def _sync_card_heights(self):
        """Cards use their FIXED 332px height (uniform across Task List and Queue).

        The old behavior cleared fixed heights for "natural heights", which
        caused Task List cards (289px natural) to mismatch Queue cards (332px
        fixed). The user requires uniform 332px everywhere. Do not clear.
        """
        self._card_sync_queued = False
        # Intentionally do nothing: TaskCard.setFixedHeight(332) is the
        # contract. Clearing it breaks Queue/Task List uniformity.
        return
    def refresh(self):
        counts = self.db.counts()
        view_labels = {"all": "All",
                       "needs_attention": "Needs attention"}
        view_labels.update(STATUS_LABELS)
        for key, btn in self._view_buttons.items():
            btn.setText(f"{view_labels.get(key, key)} ({counts.get(key, 0)})")
            if key in ATTENTION_VIEWS:
                # Red attention style exactly while the count is above zero.
                attn = counts.get(key, 0) > 0
                if btn.property("attention") != attn:
                    btn.setProperty("attention", attn)
                    btn.style().unpolish(btn)
                    btn.style().polish(btn)
        if hasattr(self, "scope_box"):
            self._populate_scope_box()

        # keep the other sidebar pages in sync (cheap: small row counts)
        if getattr(self, "directory_page", None) is not None:
            self.directory_page.refresh()
        if getattr(self, "queue_page", None) is not None:
            self.queue_page.refresh()
        if (getattr(self, "dashboard_page", None) is not None
                and self.stack.currentWidget() is self.dashboard_page):
            self.dashboard_page.refresh()

        # V1.9.18 (user report: filter switches flash "everything
        # crammed"): removed cards stayed VISIBLE at their old geometry
        # for a frame while the new cards laid out, because deleteLater
        # only destroys on the next event-loop turn. Hiding first makes
        # the outgoing set vanish instantly; the slide below then
        # animates old -> new instead of flashing both at once. This
        # also fixes the has-attachments toggle's identical glitch.
        want_slide = getattr(self, "_want_slide", False)
        self._want_slide = False
        # V1.9.19: the slide source is whichever surface is visible —
        # the table viewport in List View, the cards viewport otherwise.
        # (Mode cannot change mid-refresh: refresh is synchronous.)
        _slide_vp = (self._tasks_table.viewport()
                     if self.layout_mode == "list"
                     else self._cards_scroll.viewport())
        old_pix = None
        if want_slide:
            try:
                old_pix = grab_without_scrollbars(_slide_vp)
            except Exception:
                old_pix = None

        # V1.9.30 (user): a NON-slide refresh (e.g. completing a card
        # from mid-list) must keep the user's place -- the page used
        # to shift when the finished card left the view. Capture the
        # scroll position now; restore it after the rebuild (right
        # away for sync builds, at chunk completion for chunked
        # builds). Slide refreshes still reset to the top by design.
        _keep_scroll = None
        if not want_slide:
            try:
                _keep_scroll = (
                    self._tasks_table.verticalScrollBar().value()
                    if self.layout_mode == "list" else
                    self._cards_scroll.verticalScrollBar().value())
            except Exception:
                _keep_scroll = None

        def _restore_scroll():
            if _keep_scroll is None:
                return
            try:
                if self.layout_mode == "list":
                    bar = self._tasks_table.verticalScrollBar()
                    bar.setValue(min(_keep_scroll, bar.maximum()))
                else:
                    # Cards: _hold_scroll_height() (called before the
                    # rebuild) froze the container height so the range
                    # never collapsed; finish on the next event pass,
                    # when the new cards are visible and the real
                    # maximum exists.
                    self._scroll_target = _keep_scroll
                    QTimer.singleShot(0, self._finish_scroll_restore)
            except Exception:
                pass

        def _maybe_slide():
            if not want_slide or old_pix is None or old_pix.isNull():
                return
            vp = _slide_vp

            def _go():
                try:
                    if self.layout_mode == "list":
                        self._tasks_table.scrollToTop()
                    else:
                        self._cards_scroll.verticalScrollBar().setValue(0)
                        _lay = self._cards_container.layout()
                        _lay.activate()
                        # V1.9.30 (user's crammed-cards report): the
                        # grab used to catch the container still sized
                        # for the OLD (shorter) list, so incoming
                        # cards photographed condensed, then visibly
                        # expanded once the real layout landed. Force
                        # the container to its full laid-out size and
                        # let the resize settle before grabbing.
                        try:
                            _hint = _lay.sizeHint()
                            _vpw = self._cards_scroll.viewport().width()
                            _vph = self._cards_scroll.viewport().height()
                            self._cards_container.resize(
                                _vpw, max(_hint.height(), _vph))
                            QApplication.processEvents()
                        except Exception:
                            pass
                    new_pix = grab_without_scrollbars(vp)
                except Exception:
                    return
                slide_swap(vp, vp.rect(), old_pix, new_pix)

            QTimer.singleShot(0, _go)

        if _keep_scroll is not None and self.layout_mode != "list":
            # Freeze the container at its current height for the
            # duration of the rebuild (released by
            # _finish_scroll_restore on the next pass).
            try:
                self._cards_container.setFixedHeight(
                    self._cards_container.height())
            except Exception:
                pass

        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            if item.widget():
                item.widget().hide()
                item.widget().deleteLater()
        # Clear any bottom stretch row left by the previous refresh.
        for r in range(self.cards_layout.rowCount()):
            self.cards_layout.setRowStretch(r, 0)

        tasks = self.db.list_tasks(
            view=self.view, search=self.search_text, sort=self.sort,
            scope_filter=self.scope_filter,
            has_attachments=self.attach_only_btn.isChecked(),
            outcome=self.outcome_filter,
        )
        tasks = self._apply_col_sort(tasks)
        self._tasks = {t["id"]: t for t in tasks}
        if hasattr(self, "_selected"):
            self._selected.intersection_update(self._tasks.keys())
            self._update_sel_count()
        n = len(tasks)
        self.search.set_count(
            f"{n} result{'s' if n != 1 else ''}" if self.search_text else ""
        )

        # V1.9.19 (launch): one CRM map for the whole refresh instead of
        # one directory query per card (73 queries at startup, each a
        # share round-trip on a network database). Falls back to
        # per-card queries if the map load fails. Built here so both
        # the table branch and the card path share it.
        try:
            self._sdc_contacts = self.db.directory_customers_by_name()
        except Exception:
            self._sdc_contacts = None

        # V1.9.19: List View is a table now. The table always builds
        # synchronously (row items are cheap, unlike cards) and slides
        # like everything else; an empty result is headers with no rows.
        if self.layout_mode == "list":
            self._cards_scroll.hide()
            self._tasks_table.show()
            self._tasks_table.set_tasks(
                tasks, sdc_contacts=self._sdc_contacts, db=self.db,
                selected_ids=getattr(self, "_selected", set()))
            _restore_scroll()
            _maybe_slide()
            self._db_stamp = self._current_db_stamp()
            return

        self._cards_scroll.show()
        self._tasks_table.hide()

        if not tasks:
            self.cards_layout.setAlignment(Qt.AlignCenter)
            empty = QLabel(
                "No tasks here yet.\nClick “+ New Task” to add your first one."
                if self.view == "all" and not self.search_text
                else "Nothing matches this view."
            )
            empty.setObjectName("emptyState")
            empty.setAlignment(Qt.AlignCenter)
            if self.layout_mode == "grid3":
                self.cards_layout.setColumnStretch(0, 1)
                self.cards_layout.setColumnStretch(1, 1)
                self.cards_layout.setColumnStretch(2, 1)
                self.cards_layout.addWidget(empty, 0, 0, 1, 3)
            elif self.layout_mode == "grid":
                self.cards_layout.setColumnStretch(0, 1)
                self.cards_layout.setColumnStretch(1, 1)
                self.cards_layout.setColumnStretch(2, 0)
                self.cards_layout.addWidget(empty, 0, 0, 1, 2)
            else:
                self.cards_layout.setColumnStretch(0, 1)
                self.cards_layout.setColumnStretch(1, 1)
                self.cards_layout.setColumnStretch(2, 0)
                self.cards_layout.addWidget(empty, 0, 0, 1, 2)
            QTimer.singleShot(0, self._finish_scroll_restore)
            _maybe_slide()
            return

        self.cards_layout.setAlignment(Qt.AlignTop)
        # Ensure equal column widths for grid modes: set stretch for all
        # columns used by the current mode (2 for grid, 3 for grid3).
        if self.layout_mode == "grid3":
            self.cards_layout.setColumnStretch(0, 1)
            self.cards_layout.setColumnStretch(1, 1)
            self.cards_layout.setColumnStretch(2, 1)
        elif self.layout_mode == "grid":
            self.cards_layout.setColumnStretch(0, 1)
            self.cards_layout.setColumnStretch(1, 1)
            self.cards_layout.setColumnStretch(2, 0)
        # V1.9.8: with thousands of tasks, building every card widget
        # synchronously stalls startup for ~10s. Cards build in chunks over
        # event-loop turns (see _build_card_chunk) so the window appears
        # immediately. The bottom stretch row depends only on the count, so
        # compute it up front — short lists never stretch cards while the
        # chunks are still building.
        if self.layout_mode == "grid":
            rows_used = (n + 1) // 2
        elif self.layout_mode == "grid3":
            rows_used = (n + 2) // 3
        else:
            rows_used = n
        # Bottom stretch row: absorbs leftover vertical space so a short
        # result list never stretches its cards to fill the viewport
        # (the "single search result renders huge" bug). Cards keep their
        # natural content height.
        self.cards_layout.setRowStretch(rows_used, 1)
        self._card_build_gen += 1
        # Small lists build synchronously (unchanged behavior — and what the
        # test suite expects). Large lists chunk over event-loop turns.
        if n <= _CARD_SYNC_LIMIT:
            for i, task in enumerate(tasks):
                self._make_card(task, i)
            self._card_build_tasks = []
            self._queue_card_sync()
            _restore_scroll()
            # Sync path only: the chunked path builds progressively
            # over event-loop turns, so there is no single "new" frame
            # to slide to — sliding there would animate a half-built
            # list.
            _maybe_slide()
        else:
            self._card_build_tasks = tasks
            self._pending_scroll_restore = _restore_scroll
            self._build_card_chunk(self._card_build_gen, 0)
        # Own writes are not "external changes" — re-stamp after refresh.
        self._db_stamp = self._current_db_stamp()

    def _finish_scroll_restore(self):
        """Release the rebuild height freeze and put the scroll back
        where the user left it (V1.9.30 scroll anchoring)."""
        try:
            self._cards_container.setMinimumHeight(0)
            self._cards_container.setMaximumHeight(16777215)
        except Exception:
            pass
        target = getattr(self, "_scroll_target", None)
        if target is None:
            return
        self._scroll_target = None
        try:
            lay = self._cards_container.layout()
            if lay is not None:
                lay.activate()
            bar = self._cards_scroll.verticalScrollBar()
            bar.setValue(min(target, bar.maximum()))
        except Exception:
            pass

    def _make_card(self, task, i):
        """Build one task card and place it in the grid at index i."""
        card = TaskCard(task, db=self.db,
                        sdc_contacts=getattr(self, "_sdc_contacts", None))
        card.open_requested.connect(self.open_detail)
        card.edit_requested.connect(self.edit_task)
        card.delete_requested.connect(self.delete_task)
        card.selection_toggled.connect(self._on_card_selection)
        if task["id"] in self._selected:
            card.set_selected(True)
        card.scope_toggled.connect(self.on_scope_toggled)
        card.hot_toggled.connect(self.on_hot_toggled)
        card.status_chosen.connect(self.on_status_chosen)
        card.outcome_requested.connect(self.on_outcome_chosen)
        # V1.9.50: the card's right-click menu acts on the whole
        # selection when this card is part of one (the bulk bar's
        # replacement); the provider hands the menu the live set.
        card.selection_provider = lambda: self._selected
        card.bulk_outcome_requested.connect(self._bulk_set_outcome)
        card.bulk_status_requested.connect(self._bulk_set_status)
        card.bulk_delete_requested.connect(self._bulk_delete)
        card.duplicate_requested.connect(self.duplicate_as_requote)
        if self.layout_mode == "grid":
            self.cards_layout.addWidget(card, i // 2, i % 2)
        elif self.layout_mode == "grid3":
            self.cards_layout.addWidget(card, i // 3, i % 3)
        else:
            self.cards_layout.addWidget(card, i, 0, 1, 2)
        return card

    def _build_card_chunk(self, gen, start):
        """Build one chunk of task cards, then schedule the next.

        Runs on the event loop so the UI stays responsive while thousands
        of cards materialize. A newer refresh() bumps _card_build_gen and
        silently retires a stale chunk chain.
        """
        if gen != self._card_build_gen:
            return
        tasks = self._card_build_tasks
        n = len(tasks)
        end = min(n, start + _CARD_CHUNK_SIZE)
        for i in range(start, end):
            self._make_card(tasks[i], i)
        if end < n:
            QTimer.singleShot(0, lambda: self._build_card_chunk(gen, end))
        else:
            # Cards keep their natural content heights (no forced uniformity).
            self._card_build_tasks = []
            self._queue_card_sync()
            _pending = getattr(self, "_pending_scroll_restore", None)
            if _pending is not None:
                self._pending_scroll_restore = None
                _pending()


    # ---- multi-selection (V1.9.50: no bulk bar -- the count is a
    # plain label by the attachments toggle, and the actions below
    # are driven from the right-click menus) ----
    def _on_table_selection(self, ids):
        # Table rows replace the card selection wholesale: the
        # count label always reflects exactly the selected rows.
        self._selected = set(ids) & set(self._tasks.keys())
        self._update_sel_count()

    def _on_card_selection(self, task_id, selected):
        if selected:
            self._selected.add(task_id)
        else:
            self._selected.discard(task_id)
        self._update_sel_count()

    def _update_sel_count(self):
        n = len(self._selected)
        label = getattr(self, "_sel_count_label", None)
        if label is not None:
            label.setText(
                f"{n} task{'s' if n != 1 else ''} selected" if n else "")
            label.setVisible(n > 0)

    def _bulk_set_status(self, status):
        completed_ids = []
        for tid in list(self._selected):
            task = self.db.get_task(tid)
            if not task:
                continue
            if status == "canceled" and task.get("status") != "canceled":
                if not confirm_cancel_with_reason(self, self.db, tid):
                    continue
            else:
                self.db.set_status(tid, status)
                self.db.log_activity(
                    tid, "status", f"Status → {STATUS_LABELS[status]} (bulk)")
                if status == "completed":
                    completed_ids.append(tid)
        for tid in completed_ids:
            maybe_ask_price(self, self.db, tid)
        self._selected.clear()
        self.refresh()

    def _bulk_set_outcome(self, outcome):
        for tid in list(self._selected):
            try:
                self.db.set_outcome(tid, outcome)
            except ValueError:
                pass
            else:
                detail = (f"Marked {outcome} (bulk)" if outcome in ("won", "lost")
                          else "Outcome mark cleared (bulk)")
                self.db.log_activity(tid, "outcome", detail)
        self._selected.clear()
        self.refresh()

    def _bulk_delete(self):
        n = len(self._selected)
        if not n:
            return
        if not app_confirm(
                self, "Delete tasks",
                f"Delete {n} selected task(s) and all their attachments?\n"
                "This cannot be undone.",
                confirm_label="Delete", danger=True):
            return
        for tid in list(self._selected):
            self.db.delete_task(tid)
            shutil.rmtree(task_attachments_dir(self.db, tid),
                          ignore_errors=True)
        self._selected.clear()
        self.refresh()

    # ---- startup ----
    def _startup_integrity_check(self):
        """Warn (non-blocking) if any attachment records lack their file."""
        try:
            rows = self.db.conn.execute(
                "SELECT task_id, stored FROM attachments").fetchall()
        except Exception:  # noqa: BLE001
            return
        missing = 0
        for task_id, stored in rows:
            try:
                if not (task_attachments_dir(self.db, task_id)
                        / (stored or "")).is_file():
                    missing += 1
            except Exception:  # noqa: BLE001
                continue
        if missing:
            show_toast(
                self, "warning", "Attachment check",
                f"{missing} attachment file(s) could not be found on disk.\n"
                "Your tasks are intact — only the linked files are missing.")

    def _retry_live_connection(self):
        """Offline banner action: if the live database opens
        now, merge this session's offline changes into it, then
        offer a restart onto the live copy. The running session
        keeps its (seed) database handle throughout -- switching
        databases live under every open window is not attempted;
        the restart is the switch."""
        try:
            probe = TaskDatabase(self._live_db_path)
        except Exception:  # noqa: BLE001
            app_message(
                self, "Task List",
                "The live database still can't be reached. "
                "You're still working on the local copy — "
                "nothing is lost.")
            return
        merged = {"applied": 0, "conflicts": 0}
        try:
            if _offline_engine.seed_is_dirty():
                merged = _offline_engine.merge_seed_into(probe)
        finally:
            try:
                probe.conn.close()
            except Exception:
                pass
        note = ""
        if merged.get("conflicts"):
            note = (f"\n\n{merged['conflicts']} change(s) were "
                    "edited in both places — the live version was "
                    "kept; review them in Settings → Offline.")
        choice = app_choose(
            self, "Back online",
            "The live database is reachable and your offline "
            f"changes were merged ({merged.get('applied', 0)} "
            "applied)." + note +
            "\n\nRestart Task List to work on the live database.",
            [("Restart now", "primary"), ("Later", "ghost")])
        if choice == "Restart now":
            try:
                target = launcher_target()
                if target.is_file():
                    flags = 0
                    if sys.platform == "win32":
                        flags = 0x00000008 | 0x08000000
                    subprocess.Popen([str(target)],
                                     cwd=str(target.parent),
                                     creationflags=flags,
                                     close_fds=True)
            except Exception:
                pass
            QApplication.instance().quit()

    def closeEvent(self, event):
        QSettings("TaskListApp", "TaskList").setValue(
            "geometry", self.saveGeometry())
        # V1.9.37 (user): snapshot on close too, so the day's work
        # is never more than a session away from a backup. The DB
        # copy is fast; the attachments zip inside backup_now()
        # skips itself when nothing changed. A backup problem must
        # never trap the user in the app -- failures are swallowed.
        try:
            self.db.backup_now()
        except Exception:
            pass
        # V1.9.50: refresh the offline seed on close (connected
        # sessions only -- an offline session's seed IS the live
        # data until it merges, and refreshing would erase the
        # merge base).
        try:
            if not getattr(self, "_offline", False):
                _offline_engine.refresh_seed(self.db)
        except Exception:
            pass
        super().closeEvent(event)


_APP_ICON_FILE_CACHE = {}


def _load_app_icon():
    """(QIcon or None, source string), with the file result
    cached per process (V1.9.48).

    This ran on EVERY detail-window open (TaskListWindow and
    TaskDetailWindow both call it), re-reading the .ico from
    disk -- on the share that is a network round trip plus a
    decode, part of the "lag when opening a task" the user
    reported. Only a successful FILE load is cached: when the
    share was not ready and the embedded fallback answered,
    later calls still retry the file (the _retry_file_icon
    path depends on that)."""
    cached = _APP_ICON_FILE_CACHE.get("pair")
    if cached is not None:
        return cached
    pair = _load_app_icon_fresh()
    if pair[1] == "file" and pair[0] is not None:
        _APP_ICON_FILE_CACHE["pair"] = pair
    return pair


def _load_app_icon_fresh():
    """(QIcon or None, source string). Share file first, embedded fallback.

    V1.9.12: the icon file lives on the network share, and the old
    is_file() check ran before the share had reconnected — the app then
    started with NO window icon at all, Windows showed a generic taskbar
    button, and nothing ever re-set it afterward. The embedded copy
    guarantees a real icon even when the share file is momentarily
    unreadable; the file still wins whenever it is readable, so a future
    icon update takes effect.
    """
    try:
        from PySide6.QtGui import QIcon
        icon_path = Path(__file__).resolve().parent / "assets" / "tl_icon.ico"
        if not icon_path.is_file():
            icon_path = Path(__file__).resolve().parent / "assets" / "tl_icon.png"
        if icon_path.is_file():
            icon = QIcon(str(icon_path))
            if not icon.isNull():
                return icon, "file"
    except Exception:  # noqa: BLE001 - icon must never break startup
        pass
    try:
        from .embedded_icon import embedded_icon
        icon = embedded_icon()
        if icon is not None:
            return icon, "embedded fallback"
    except Exception:  # noqa: BLE001 - icon must never break startup
        pass
    return None, "none"


def _retry_file_icon(window):
    """Re-assert the share icon file on app + window, once, after show.

    V1.9.12: if startup fell back to the embedded icon because the share
    wasn't ready, this retries the file a few seconds later — setting a
    window icon refreshes the taskbar button if the share has
    reconnected by then. Silent no-op when the file is still unreadable.
    """
    try:
        app = QApplication.instance()
        if app is None:
            return
        from PySide6.QtGui import QIcon
        icon_path = Path(__file__).resolve().parent / "assets" / "tl_icon.ico"
        if not icon_path.is_file():
            icon_path = Path(__file__).resolve().parent / "assets" / "tl_icon.png"
        if icon_path.is_file():
            icon = QIcon(str(icon_path))
            if not icon.isNull():
                app.setWindowIcon(icon)
                window.setWindowIcon(icon)
                log_startup_event("window icon re-asserted from file")
    except Exception:  # noqa: BLE001 - icon must never break startup
        pass


class _TaskListApplication(QApplication):
    """QApplication with a notify hook for tooltip translucency.

    V1.9.17: QToolTip's label window is created internally and Qt
    offers no hook for it — but notify() sees its Show event. Setting
    WA_TranslucentBackground there (before first paint) lets the
    rounded QSS radius actually round the tooltip window instead of
    leaving a square opaque artifact around it.
    """

    def notify(self, receiver, event):  # noqa: N802 (Qt virtual)
        if event.type() == QEvent.Show:
            try:
                if receiver.metaObject().className() == "QTipLabel":
                    receiver.setAttribute(Qt.WA_TranslucentBackground, True)
            except Exception:  # noqa: BLE001 - best effort only
                pass
        return super().notify(receiver, event)


def _housekeeping_worker_main(db_path_str):
    """Staging sweep + attachment integrity, off the UI thread.

    V1.9.25: the UI-thread versions froze the just-appeared window
    while they touched the share. Opens its OWN sqlite connection
    (a TaskDatabase connection must never cross threads) and checks
    file existence without creating anything (unlike
    task_attachments_dir, which mkdirs). Returns the missing-file
    count; the main-thread callback shows the toast if it is > 0.
    """
    sweep_staging_dirs()
    try:
        import sqlite3
        conn = sqlite3.connect(db_path_str, timeout=5)
        try:
            rows = conn.execute(
                "SELECT task_id, stored FROM attachments").fetchall()
        finally:
            conn.close()
    except Exception:  # noqa: BLE001
        rows = []
    from pathlib import Path
    root = Path(db_path_str).parent / "attachments"
    missing = 0
    for task_id, stored in rows:
        try:
            if not (root / str(task_id) / (stored or "")).is_file():
                missing += 1
        except Exception:  # noqa: BLE001
            continue
    return missing


class _WindowIdentityFilter(QObject):
    """V1.9.50: stamp EVERY top-level window's taskbar identity
    (AppUserModelID + relaunch icon + command + display name) at
    its first show. The main window is stamped explicitly in
    main() before its first paint; this filter covers every
    other window the app ever opens (task detail, contact
    detail, settings, dialogs), each exactly once, and logs the
    per-window result to startup.log. Never raises, never
    consumes an event."""

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        try:
            if (event.type() == QEvent.Show
                    and isinstance(obj, QWidget) and obj.isWindow()
                    and not obj.property("_identity_stamped")):
                obj.setProperty("_identity_stamped", True)
                ok = stamp_window_identity(int(obj.winId()))
                log_startup_event(
                    "taskbar: stamped %s -> %s"
                    % (obj.metaObject().className(), ok))
        except Exception:
            pass
        return False


def main(db_path=None):
    # V1.9.48: crash capture FIRST, before anything that could
    # fault -- a native crash after this point leaves its
    # traceback in data/crash.log instead of vanishing.
    from .startup_log import install_crash_logging
    install_crash_logging()
    # v1.5.9: give the process its own Windows taskbar identity before any
    # window exists, so the taskbar groups the icon under Task List (not
    # "Python") and offers Pin to taskbar. Safe no-op off Windows.
    # V1.9.9: log the result — a False here means Windows rejected the ID
    # and the taskbar falls back to the window icon alone.
    _taskbar_id_ok = set_app_user_model_id()
    log_startup_event(f"taskbar id set: {_taskbar_id_ok}")
    # V1.9.50: register the ID itself (DisplayName + IconUri in
    # HKCU Classes) -- the layer that gives the taskbar a name
    # to show for the running window instead of "Python".
    _identity_ok = register_app_identity()
    log_startup_event(f"taskbar identity registered: {_identity_ok}")
    # v1.4.0 item 14: fine-grained timing marks (measure-first). The
    # user's startup.log after install is the real verification.
    log_startup_event("main entered")
    t0 = time.monotonic()
    app = _TaskListApplication(sys.argv)
    log_startup_event(f"QApplication created ({time.monotonic() - t0:.3f}s)")
    if _already_running(app):
        log_startup_event("single-instance check done (already running)")
        return
    log_startup_event("single-instance check done")
    t1 = time.monotonic()
    app.setStyle("Fusion")
    # Central text-rendering base: bundled Inter with grayscale (not
    # subpixel) antialiasing, inherited by every widget — including ones
    # created later (dialogs, cards, tables). See fonts.app_font().
    app.setFont(app_font())
    log_startup_event(f"font set ({time.monotonic() - t1:.3f}s)")
    t2 = time.monotonic()
    apply_theme(app, saved_theme())
    # V1.9.31: rounded corners are GLOBAL — the surface filter rounds
    # every menu, tooltip and popup the app (or Qt itself) shows.
    install_global_surface_filter(app)
    # V1.9.50 (user: taskbar hover STILL titled the app "Python"):
    # EVERY top-level window gets the identity stamp, not just
    # the main window -- a detail window or dialog shown without
    # one reintroduces the host process identity. The filter
    # stamps each window once, at its first show, and logs the
    # result per window class so a failure is visible in
    # startup.log instead of silent.
    app.installEventFilter(_WindowIdentityFilter(app))
    log_startup_event("window identity filter installed")
    log_startup_event(f"theme applied ({time.monotonic() - t2:.3f}s)")
    # V1.9.50: offline seed probe. Open the live database once
    # here: if a previous offline session left changes, merge
    # them in; otherwise refresh the local seed from the live
    # database. If the live database cannot be opened at all
    # (IO-class failure -- share down, VPN not up yet, poisoned
    # WAL sidecar) and a seed exists, the session runs on the
    # seed instead and merges back on a later launch. Any other
    # probe failure falls through: window construction surfaces
    # the canonical startup error.
    global _OFFLINE_SESSION
    _OFFLINE_SESSION = False
    _primary_path = Path(db_path) if db_path else default_db_path()
    try:
        _probe = TaskDatabase(_primary_path)
        try:
            if _offline_engine.seed_is_dirty():
                _merged = _offline_engine.merge_seed_into(_probe)
                log_startup_event(f"offline merge at launch: {_merged}")
            else:
                _offline_engine.refresh_seed(_probe)
                threading.Thread(
                    target=_folder_cache.fill_working_set,
                    args=(str(_primary_path),), daemon=True).start()
        finally:
            _probe.conn.close()
    except Exception as _probe_exc:  # noqa: BLE001
        if (_is_io_failure(_probe_exc)
                or isinstance(_probe_exc, OSError)) \
                and _datahome.seed_exists():
            _OFFLINE_SESSION = True
            db_path = str(_datahome.seed_db_path())
            _offline_engine.mark_offline_dirty()
            log_startup_event(
                "live database unreachable; OFFLINE session on the "
                f"local seed ({_probe_exc!r})")
        else:
            log_startup_event(
                f"db probe failed (window will surface it): "
                f"{_probe_exc!r}")
    # V1.9.9: verify the icon actually loads. V1.9.12: file-first with an
    # embedded fallback (see _load_app_icon) — a slow share must never
    # leave the app icon-less with a generic taskbar button.
    _app_icon, _app_icon_src = _load_app_icon()
    if _app_icon is not None:
        app.setWindowIcon(_app_icon)
    log_startup_event(f"app icon loaded: {_app_icon_src}")
    t3 = time.monotonic()
    # V1.9.7: never fail silently. pythonw.exe has no console, so until now
    # any exception here meant the process simply vanished — "nothing
    # appears" with no explanation. Now the real error is shown.
    # V1.9.57 (user, 2026-11-13: on his Surface the FIRST
    # launch dead-ended in this dialog and the SECOND opened
    # offline on the seed): the seed fallback used to arm only
    # when the startup PROBE failed -- but a flickering
    # Offline-Files cache passes the probe's narrow reads and
    # then fails a real read during window construction (the
    # exact shape in his 2026-11-13 morning startup.log: "db
    # connected", then construction died on a data read). An
    # I/O-class construction failure now retries on the local
    # seed before the dialog is even considered.
    window = None
    _construction_exc = None
    try:
        window = TaskListWindow(db_path=db_path)
    except Exception as exc:  # noqa: BLE001 - classified below
        _construction_exc = exc
        if not _OFFLINE_SESSION and _is_io_failure(exc) \
                and _datahome.seed_exists():
            log_startup_event(
                "window construction hit an I/O failure on the "
                f"live database ({exc!r}); retrying on the "
                "local seed")
            _OFFLINE_SESSION = True
            db_path = str(_datahome.seed_db_path())
            _offline_engine.mark_offline_dirty()
            try:
                window = TaskListWindow(db_path=db_path)
                _construction_exc = None
            except Exception as exc2:  # noqa: BLE001
                _construction_exc = exc2
    if _construction_exc is not None:
        exc = _construction_exc
        log_startup_event(f"window construction FAILED: {exc!r}")
        try:
            app_message(
                None, "Task List",
                "Task List could not start:\n\n"
                f"{exc}\n\n"
                "Details were written to data\\startup.log in the app folder.")
        except Exception:  # noqa: BLE001
            try:
                QMessageBox.critical(
                    None, "Task List",
                    "Task List could not start:\n\n"
                    f"{exc}\n\n"
                    "Details were written to data\\startup.log in the app folder.")
            except Exception:  # noqa: BLE001
                pass
        raise SystemExit(1)
    log_startup_event(f"window constructed ({time.monotonic() - t3:.3f}s)")
    # V1.9.34 (user: the running app's taskbar button said "Python",
    # with the Python icon and NO Pin to taskbar — Drawing Finder's
    # button is correct because it's a real exe): stamp the main
    # window's own property store with the app ID + icon. The
    # taskbar reads the WINDOW first; the process-level ID alone
    # demonstrably fell back to pythonw.exe on his machine. Logged
    # so the result is checkable in startup.log.
    try:
        _stamp_ok = stamp_window_identity(int(window.winId()))
    except Exception:  # noqa: BLE001 - identity must never break startup
        _stamp_ok = False
    log_startup_event(f"window identity stamped: {_stamp_ok}")
    # V1.9.48 (user: the taskbar button started as the GENERIC
    # Windows icon and only "eventually" became the proper one):
    # the stamp used to run AFTER show(), so the button was born
    # under the bare process identity and re-identified a beat
    # later. winId() creates the native handle now, before the
    # window is ever shown, so the button is born correct.
    # v1.4.0 item 14: shell-first paint — show the window frame before
    # heavy content fills in, so something is on screen ASAP.
    window.show()
    log_startup_event("window shown (shell)")
    # V1.9.48: re-stamp once after the first paint settles. If the
    # frameless window's native handle was recreated during show,
    # the pre-show stamp went to the dead handle and the button
    # fell back to the Python identity (the user's 1.9.47
    # screenshot); the read-back-verified stamp now lands on the
    # live handle either way.
    def _restamp():
        try:
            _ok = stamp_window_identity(int(window.winId()))
        except Exception:  # noqa: BLE001
            _ok = False
        log_startup_event(f"window identity re-stamped: {_ok}")
    QTimer.singleShot(1200, _restamp)
    window._real_launch = True
    window._start_update_launch_flow()
    app.processEvents()
    log_startup_event("first paint processed")
    # V1.9.25: one number for the whole launch, from the launcher's
    # first line (the pyw sets _LAUNCH_T0 on this module). The bat
    # lines + these markers already bracket every phase; this total
    # is what the next slow launch gets judged by.
    _launch_t0 = globals().get("_LAUNCH_T0")
    if _launch_t0:
        log_startup_event(
            f"launch total: {time.time() - _launch_t0:.2f}s "
            "since launcher start")
    # V1.9.12: if startup fell back to the embedded icon, retry the share
    # file once the window is up (see _retry_file_icon).
    # V1.9.48: only when startup did NOT already load the file
    # icon -- re-setting the same icon seconds after launch is
    # one more visible taskbar change for no reason.
    if _app_icon_src != "file":
        QTimer.singleShot(5000, lambda: _retry_file_icon(window))
    # v1.2.9: the rotating backup (incl. the attachments zip) used to run
    # inside __init__, before the window could paint. It now runs here,
    # after first show — and the heavy work runs on a QThread worker, so
    # the UI is never held hostage by it.
    QTimer.singleShot(0, window.run_deferred_backup)
    # V1.9.9: non-critical startup housekeeping deferred past first paint.
    # V1.9.25: it used to run on the UI thread right after first paint —
    # the staging sweep and the per-attachment stat check touch the
    # share, so a big attachment library froze the just-appeared window
    # for seconds (part of the lagged launch). Both now run on a worker
    # thread; only the toast (if files are missing) and the cheap local
    # shortcut creation run on the UI thread, via the completion
    # callback. _startup_integrity_check stays for manual callers.
    def _housekeeping_done(payload):
        try:
            if payload.get("ok") and (payload.get("value") or 0):
                missing = payload["value"]
                show_toast(
                    window, "warning", "Attachment check",
                    f"{missing} attachment file(s) could not be found "
                    "on disk.\nYour tasks are intact — only the linked "
                    "files are missing.")
        except Exception:  # noqa: BLE001
            pass
        finally:
            log_startup_event("staging swept")
            log_startup_event("integrity checked")
        # V1.9.16: the Start Menu shortcut is what Windows resolves
        # for right-click -> Pin on the running app. Create it when
        # missing so the Pin verb appears without menu hunting.
        # V1.9.32: the ensure now also repairs a stale target, and a
        # matching Desktop shortcut gives a clean "Task List" icon
        # (the raw launcher file shows "Task List.exe").
        try:
            ensure_start_menu_shortcut()
        except Exception:  # noqa: BLE001
            pass
        try:
            ensure_desktop_shortcut()
        except Exception:  # noqa: BLE001
            pass
    QTimer.singleShot(0, lambda: run_folder_background(
        _housekeeping_worker_main, _housekeeping_done, str(window.db.path)))
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
