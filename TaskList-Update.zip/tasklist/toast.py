"""Bottom-edge toast notifications.

Non-modal, auto-dismissing, click-to-dismiss feedback toasts. They never
steal keyboard focus (``Qt.ToolTip`` window flag plus
``WA_ShowWithoutActivating``), anchor to the bottom-right of the app's main
window, and stack upward with consistent spacing — newest nearest the edge.

Visual language matches the app: true-black dark surfaces / white+blue
light surfaces, Inter with grayscale (not subpixel) antialiasing on the
text (see the AGENTS.md lesson on chip/pill fringe), 12px rounded corners,
restrained glassmorphism (translucent background, thin border). No QSS
state changes, so the box model never shifts.

Public API
----------
show_toast(parent, kind, title, text, duration_ms=4000)
    kind is one of "success" | "info" | "warning" | "error".
    Returns the Toast widget (already shown). The toast closes itself
    after ``duration_ms`` or on click.
"""

from PySide6.QtCore import QObject, QEvent, QRect, Qt, QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from .themes import saved_theme

SUCCESS = "success"
INFO = "info"
WARNING = "warning"
ERROR = "error"
KINDS = (SUCCESS, INFO, WARNING, ERROR)

DEFAULT_DURATION_MS = 4000
_EDGE_MARGIN = 18      # gap between the toast stack and the window edges
_STACK_SPACING = 10    # vertical gap between stacked toasts
_TEXT_WIDTH = 300      # wrapping width for the toast body text

# Accent-bar color per kind: (dark theme, light theme).
_ACCENTS = {
    SUCCESS: ("#6fdc9e", "#15803d"),
    INFO: ("#7fb0ff", "#2563eb"),
    WARNING: ("#eec25e", "#b45309"),
    ERROR: ("#ff8a8a", "#dc2626"),
}


def _stylesheet(theme, accent):
    """Self-contained QSS for one toast (scoped to objectNames, so the
    application stylesheet can't restyle toast internals)."""
    if theme == "light":
        bg, border = "#ffffff", "#d5dce8"
        title_c, text_c = "#131a26", "#3d4a61"
    else:  # dark: true-black surfaces, no blue tint
        bg, border = "#191b1f", "#2e3138"
        title_c, text_c = "#f4f5f7", "#c6cbd3"
    return f"""
    QFrame#toastCard {{ background: {bg}; border: 1px solid {border};
        border-radius: 12px; }}
    QFrame#toastAccent {{ background: {accent}; border: none;
        border-radius: 2px; }}
    QLabel#toastTitle {{ color: {title_c}; font-size: 13px; font-weight: 700;
        background: transparent; border: none; }}
    QLabel#toastText {{ color: {text_c}; font-size: 12px;
        background: transparent; border: none; }}
    """


def _crisp(widget):
    """Grayscale (not subpixel) antialiasing on toast text, per the
    AGENTS.md chip/pill lesson — avoids red/blue fringe on small text."""
    font = widget.font()
    font.setStyleStrategy(QFont.StyleStrategy.NoSubpixelAntialias)
    widget.setFont(font)
    return widget


def _esc(text):
    """Escape user data for plain QLabel text (``&`` -> ``&&``).

    Qt treats ``&`` as a mnemonic marker; doubling shows a literal ``&``.
    (Local copy -- toast.py cannot import from ui.py: ui imports toast.)
    """
    return str(text).replace("&", "&&")


class Toast(QWidget):
    """One toast bubble. Closes itself on click or when its timer fires."""

    def __init__(self, kind, title, text, duration_ms=DEFAULT_DURATION_MS,
                 parent=None):
        super().__init__(
            parent, Qt.ToolTip | Qt.FramelessWindowHint)
        self._kind = kind if kind in KINDS else INFO
        # A non-positive duration would leave a stuck toast; fall back to
        # the default instead.
        self._duration_ms = (duration_ms if duration_ms
                             and duration_ms > 0 else DEFAULT_DURATION_MS)
        self._dismissed = False
        # Never steal keyboard focus: ToolTip windows don't activate, and
        # WA_ShowWithoutActivating guarantees show() can't either.
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFocusPolicy(Qt.NoFocus)
        # Restrained glassmorphism: barely-translucent floating card.
        self.setWindowOpacity(0.97)

        theme = saved_theme()
        accent = _ACCENTS[self._kind][0 if theme != "light" else 1]
        self.setStyleSheet(_stylesheet(theme, accent))

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.dismiss)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        card = QFrame()
        card.setObjectName("toastCard")
        outer.addWidget(card)

        row = QHBoxLayout(card)
        row.setContentsMargins(14, 12, 16, 12)
        row.setSpacing(12)

        bar = QFrame()
        bar.setObjectName("toastAccent")
        bar.setFixedWidth(4)
        bar.setFocusPolicy(Qt.NoFocus)
        # Expanding vertical policy: the bar fills the card height.
        bar.setSizePolicy(QSizePolicy.Policy.Fixed,
                          QSizePolicy.Policy.Expanding)
        row.addWidget(bar)

        col = QVBoxLayout()
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(2)
        title_lab = _crisp(QLabel(_esc(title)))
        title_lab.setObjectName("toastTitle")
        title_lab.setFixedWidth(_TEXT_WIDTH)
        title_lab.setFocusPolicy(Qt.NoFocus)
        col.addWidget(title_lab)
        text_lab = _crisp(QLabel(_esc(text)))
        text_lab.setObjectName("toastText")
        text_lab.setFixedWidth(_TEXT_WIDTH)
        text_lab.setWordWrap(True)
        text_lab.setFocusPolicy(Qt.NoFocus)
        col.addWidget(text_lab)
        row.addLayout(col)

    # -- public ------------------------------------------------------
    @property
    def kind(self):
        return self._kind

    def title_text(self):
        lab = self.findChild(QLabel, "toastTitle")
        return lab.text() if lab is not None else ""

    def body_text(self):
        lab = self.findChild(QLabel, "toastText")
        return lab.text() if lab is not None else ""

    def dismiss(self):
        """Close now (click or timer). Idempotent."""
        if self._dismissed:
            return
        self._dismissed = True
        self._timer.stop()
        self.close()

    # -- events ------------------------------------------------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dismiss()
            event.accept()
            return
        super().mousePressEvent(event)


class _ToastStack(QObject):
    """Per-anchor stack: owns the live toasts, lays them out above the
    anchor's bottom edge (newest nearest the edge), and re-lays-out when
    the anchor resizes or moves."""

    def __init__(self, anchor):
        # anchor is a QWidget or None (screen fallback); parent to it when
        # possible so Qt owns the C++ side, and keep the Python wrapper
        # alive via an attribute on the anchor (see show_toast).
        super().__init__(anchor if isinstance(anchor, QObject) else None)
        self._anchor = anchor
        self._toasts = []
        if anchor is not None:
            anchor.installEventFilter(self)

    def eventFilter(self, obj, event):
        if (obj is self._anchor
                and event.type() in (QEvent.Resize, QEvent.Move)):
            self._relayout()
        return super().eventFilter(obj, event)

    def add(self, toast):
        self._toasts.append(toast)
        # destroyed fires via WA_DeleteOnClose when the toast closes.
        toast.destroyed.connect(
            lambda _obj=None, t=toast: self._remove(t))
        self._relayout()

    def _remove(self, toast):
        if toast in self._toasts:
            self._toasts.remove(toast)
        if self._toasts:
            self._relayout()
        else:
            if self._anchor is not None:
                try:
                    self._anchor.removeEventFilter(self)
                except RuntimeError:
                    pass  # anchor already gone
            try:
                self.deleteLater()
            except RuntimeError:
                pass  # stack itself already gone (teardown)

    def _geometry(self):
        if self._anchor is not None:
            try:
                return self._anchor.frameGeometry()
            except RuntimeError:
                pass  # anchor deleted out from under us
        screen = QApplication.primaryScreen()
        if screen is not None:
            return screen.availableGeometry()
        return QRect(0, 0, 1024, 768)

    def _relayout(self):
        if not self._toasts:
            return
        geo = self._geometry()
        x_right = geo.right() - _EDGE_MARGIN
        y = geo.bottom() - _EDGE_MARGIN
        for toast in reversed(self._toasts):  # newest nearest the edge
            try:
                toast.adjustSize()
                w, h = toast.width(), toast.height()
                y -= h
                toast.move(x_right - w, y)
                y -= _STACK_SPACING
            except RuntimeError:
                continue  # toast deleted mid-layout; _remove follows


def _anchor_for(parent):
    """Bottom-edge anchor: the app's visible main window when there is one,
    else the parent's top-level window, else None (screen fallback)."""
    app = QApplication.instance()
    if app is not None:
        for w in app.topLevelWidgets():
            if isinstance(w, QMainWindow) and w.isVisible():
                return w
    if isinstance(parent, QWidget):
        win = parent.window()
        if isinstance(win, QWidget):
            return win
    return None


def show_toast(parent, kind, title, text, duration_ms=DEFAULT_DURATION_MS):
    """Show a bottom-edge toast; returns the Toast widget (already shown).

    ``parent`` is only used to find an anchor window when no main window
    exists; toasts always dock to the main window's bottom-right edge.
    ``kind`` is one of "success" | "info" | "warning" | "error".
    """
    anchor = _anchor_for(parent)
    stack = getattr(anchor, "_toast_stack", None)
    if stack is None:
        stack = _ToastStack(anchor)
        if anchor is not None:
            # Keep the Python wrapper alive exactly as long as the anchor.
            anchor._toast_stack = stack
        else:
            # Screen fallback: no anchor to hang the stack on, so the
            # module keeps it alive instead.
            _SCREEN_STACKS.append(stack)
    toast = Toast(kind, title, text, duration_ms)
    stack.add(toast)
    toast.show()
    toast._timer.start(toast._duration_ms)
    return toast


# Live screen-fallback stacks (no anchor widget to parent them to).
_SCREEN_STACKS = []
