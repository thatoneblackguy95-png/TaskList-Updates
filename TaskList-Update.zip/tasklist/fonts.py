"""Bundled application font (Inter, SIL Open Font License)."""
from pathlib import Path
from PySide6.QtGui import QFont, QFontDatabase

_ASSETS = Path(__file__).resolve().parent / "assets"

_cached_family = None


def load_app_font():
    """Load the bundled Inter faces (Regular + Bold). Returns family name, or None.

    Only the two static faces are loaded. The variable Inter.ttf is
    deliberately skipped: it registers the same family name as the static
    Regular, and the duplicate registration made Qt render small text with
    a ghosted double image.
    """
    global _cached_family
    if _cached_family is not None:
        return _cached_family
    db = QFontDatabase()
    family = None
    for fname in ("Inter-Regular.ttf", "Inter-Bold.ttf"):
        path = _ASSETS / fname
        if not path.exists():
            continue
        fid = db.addApplicationFont(str(path))
        if fid >= 0:
            for fam in db.applicationFontFamilies(fid):
                family = family or fam
    _cached_family = family
    return family


def font_with_weight(font, weight):
    """Copy of `font` with a different weight — the only sanctioned way
    to derive a bold/demi-bold variant outside fonts.py (the light-mode
    suite forbids bare QFont() constructors elsewhere).

    Derive from the LIVE widget font (e.g. table.font()), not from
    app_font(): the widget font is stylesheet-resolved (Inter via the
    app sheet), while app_font() follows the saved family override, so
    copying app_font() can paint a cell in a different face than the
    rest of its row (V1.9.19: TASK column came out Noto Sans while the
    table painted Inter, from a stray override in the sandbox store).
    """
    f = QFont(font)
    f.setWeight(weight)
    return f


def app_font():
    """Central application font — the single text-rendering base for the app.

    Returns the bundled Inter family (when available) with subpixel
    antialiasing DISABLED. Qt's default subpixel (ClearType-style) rendering
    tints glyph edges with red/blue fringes; on small light-on-dark text
    this reads as a colored fringe/ghost (see the AGENTS.md lesson). Grayscale
    antialiasing is subpixel-order independent, so text renders cleanly on
    any display.

    Wiring: main() calls app.setFont(app_font()) once, so EVERY widget —
    labels, buttons, line edits, tables, menus, tooltips, dialogs, and
    dynamically created cards — inherits grayscale AA by default. Widgets
    that build their own QFont (table cells, QPainter text) should start
    from app_font() instead of a bare QFont() so the strategy is preserved.

    Grep anchor for Worker 2: card pill/label text is covered automatically
    because pills inherit the application font.
    """
    f = QFont()
    # User override wins; otherwise the bundled Inter is the default.
    # (Imported here to keep fonts.py importable without Qt settings
    # side effects at module load.)
    from .themes import saved_font_family, saved_font_scale
    override = saved_font_family()
    if override:
        f.setFamily(override)
    else:
        family = load_app_font()
        if family:
            f.setFamily(family)
    f.setStyleStrategy(QFont.StyleStrategy.NoSubpixelAntialias)
    scale = saved_font_scale()
    if abs(scale - 1.0) >= 0.001:
        f.setPointSizeF(max(6.0, f.pointSizeF() * scale))
    return f
