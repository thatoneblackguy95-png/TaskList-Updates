"""Entry point: python -m tasklist"""
from .app import main

if __name__ == "__main__":
    main()
