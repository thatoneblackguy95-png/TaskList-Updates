"""Building-code (IBC) resolution for the IBC chip (V1.9.52, user).

The user’s rule, verbatim in spirit: if the IBC shown isn’t 100%
accurate the feature is useless — so this module NEVER guesses.

Data model (ibc_data.json, bundled; refreshed automatically from
the hosted copy — see fetch_remote):
  states[ST] = {
    edition: int | None,        # IBC base edition in force
    since: "YYYY-MM-DD" | None, # when that edition took effect
    name: str | None,           # the state code's own name
    source: str,                # primary source (body — document)
    verified: "YYYY-MM-DD",     # when Apollo last verified the row
    mechanism: "statewide" | "local",
    next: {edition, effective, status: "adopted" | "scheduled",
           name?} | None,
    note: str | None,
  }
  counties["ST|City"] = {county, state, source, verified, note,
                         ...optional own edition fields...}

Resolution rules (the foolproof contract):
- A county row wins when one exists for the job's city.
- A state row states an edition ONLY when mechanism == "statewide".
  "local" states (no statewide code, or a state floor with local
  programs — TX/TN/IL/MS class) yield NO edition: the UI says
  adoption is local rather than inventing a number.
- A formally ADOPTED next edition with an effective date ROLLS
  FORWARD: on/after that date it IS the current edition.
- A "scheduled" next edition (announced, final adoption paperwork
  not sighted — FL/LA/WA at compile time) NEVER rolls forward and
  NEVER raises the warning flag; it is disclosed in the panel as
  scheduled-not-final.
- The warning flag fires only for an ADOPTED switch whose
  effective date falls inside the delivery horizon
  (today, today + lead_max_weeks]. Lead times come from Settings
  (defaults 20/22 weeks — the user's current typical range).
"""

import json
import threading
import urllib.request
from datetime import date, timedelta
from pathlib import Path

REMOTE_URL = ("https://raw.githubusercontent.com/"
              "thatoneblackguy95-png/TaskList-Updates/main/"
              "ibc_codes.json")
CACHE_NAME = "ibc_codes_cache.json"
_FETCH_TIMEOUT = 6

_cache = {"data": None, "origin": None}


def _bundled_path():
    return Path(__file__).resolve().parent / "ibc_data.json"


def _valid(data):
    return (isinstance(data, dict)
            and data.get("dataset") == "tasklist-ibc"
            and isinstance(data.get("states"), dict)
            and isinstance(data.get("version"), int))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if _valid(data) else None
    except Exception:
        return None


def load_dataset(data_dir=None):
    """Bundled data, replaced by the cached remote copy when the
    cache is a NEWER dataset version. Never raises; returns
    (data, origin) where origin is "remote cache" or "bundled"."""
    if _cache["data"] is not None:
        return _cache["data"], _cache["origin"]
    bundled = _read_json(_bundled_path())
    data, origin = bundled, "bundled"
    if data_dir:
        cached = _read_json(Path(data_dir) / CACHE_NAME)
        if cached is not None and bundled is not None:
            if cached["version"] > bundled["version"]:
                data, origin = cached, "remote cache"
        elif cached is not None:
            data, origin = cached, "remote cache"
    _cache["data"], _cache["origin"] = data, origin
    return data, origin


def invalidate_cache():
    _cache["data"] = None
    _cache["origin"] = None


def dataset_status(data_dir=None):
    """(compiled_date, newest_verified_date, origin) for Settings."""
    data, origin = load_dataset(data_dir)
    if not data:
        return (None, None, origin)
    verified = [r.get("verified") for r in data["states"].values()
                if r.get("verified")]
    verified += [r.get("verified")
                 for r in (data.get("counties") or {}).values()
                 if r.get("verified")]
    return (data.get("compiled"),
            max(verified) if verified else None, origin)


def fetch_remote(data_dir, done=None):
    """Download the hosted dataset in a background thread; on a
    valid, newer-or-equal version, replace the cache file and the
    in-memory copy. Calls done(status) on the CALLING thread's
    context via a plain callback — callers marshal to the UI
    thread themselves. status in {"updated", "current", "failed"}.
    """
    def _work():
        status = "failed"
        try:
            req = urllib.request.Request(
                REMOTE_URL, headers={"User-Agent": "TaskList"})
            with urllib.request.urlopen(
                    req, timeout=_FETCH_TIMEOUT) as resp:
                raw = resp.read()
            data = json.loads(raw.decode("utf-8"))
            if _valid(data):
                target = Path(data_dir) / CACHE_NAME
                current = _read_json(target)
                cur_v = current["version"] if current else -1
                bundled = _read_json(_bundled_path())
                bun_v = bundled["version"] if bundled else -1
                if data["version"] >= max(cur_v, bun_v):
                    target.write_bytes(raw)
                    invalidate_cache()
                    load_dataset(data_dir)
                    status = "updated"
                else:
                    status = "current"
        except Exception:
            status = "failed"
        if done is not None:
            try:
                done(status)
            except Exception:
                pass

    threading.Thread(target=_work, daemon=True,
                     name="ibc-fetch").start()


def fetch_remote_sync(data_dir):
    """Synchronous variant (Settings 'Check now' runs it in its
    own worker; tests use it directly). Returns the status."""
    try:
        req = urllib.request.Request(
            REMOTE_URL, headers={"User-Agent": "TaskList"})
        with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as resp:
            raw = resp.read()
        data = json.loads(raw.decode("utf-8"))
        if not _valid(data):
            return "failed"
        target = Path(data_dir) / CACHE_NAME
        current = _read_json(target)
        cur_v = current["version"] if current else -1
        bundled = _read_json(_bundled_path())
        bun_v = bundled["version"] if bundled else -1
        if data["version"] >= max(cur_v, bun_v):
            target.write_bytes(raw)
            invalidate_cache()
            load_dataset(data_dir)
            return "updated"
        return "current"
    except Exception:
        return "failed"


# ------------------------------------------------------------ resolution

def _parse_day(text):
    try:
        return date.fromisoformat((text or "")[:10])
    except Exception:
        return None


def current_at(row, today):
    """The row AS OF `today`: a formally adopted next edition
    whose effective date has arrived becomes the current edition.
    Scheduled (not-final) editions never roll forward."""
    out = dict(row)
    nxt = row.get("next") or {}
    eff = _parse_day(nxt.get("effective"))
    if (nxt.get("status") == "adopted" and eff is not None
            and eff <= today):
        out["edition"] = nxt.get("edition")
        out["since"] = nxt.get("effective")
        if nxt.get("name"):
            out["name"] = nxt["name"]
        out["next"] = None
    return out


def resolve_ibc(city, state, data=None, today=None):
    """Resolve the building code for a job location.

    Returns None when the location itself is unusable (no chip).
    Otherwise a dict:
      level: "county" | "state" | "local"
      county: county name when a county row resolved, else None
      state: the state row AS OF today (post roll-forward),
      county_row: the county dataset row or None,
      city/state: the parsed location.
    For level "local" the state row's edition is deliberately
    withheld by the UI (mechanism == "local").
    """
    if data is None:
        data, _origin = load_dataset()
    if not data or not state:
        return None
    state = state.strip().upper()
    srow = (data.get("states") or {}).get(state)
    if srow is None:
        return None
    today = today or date.today()
    srow = current_at(srow, today)
    crow = None
    if city:
        crow = (data.get("counties") or {}).get(
            f"{state}|{city.strip()}")
        if crow is not None and not crow.get("verified"):
            # V1.9.53: an unverified county row does not
            # resolve -- fall through to the state row (which
            # carries its own verification state).
            crow = None
    # V1.9.53 (independence): a row whose primary-source
    # verification is gone (the repo watchdog downgrades rows
    # it can no longer re-confirm) resolves with
    # verified=False, and the chip/flag layer stays QUIET for
    # it -- never wrong beats always answered, with no Apollo
    # in the loop.
    verified = bool(srow.get("verified"))
    if crow is not None:
        return {"level": "county", "county": crow.get("county"),
                "state_row": srow, "county_row": crow,
                "city": city, "state": state,
                "verified": verified}
    if srow.get("mechanism") == "local":
        return {"level": "local", "county": None,
                "state_row": srow, "county_row": None,
                "city": city, "state": state,
                "verified": verified}
    return {"level": "state", "county": None,
            "state_row": srow, "county_row": None,
            "city": city, "state": state,
            "verified": verified}


def assess(res, today=None, lead_min_weeks=20, lead_max_weeks=22):
    """Delivery-horizon assessment for a resolved location.

    Returns a dict with:
      arrival_start / arrival_end: today + lead_min / lead_max,
      flag: True ONLY for a formally adopted switch whose
        effective date is in (today, arrival_end],
      switch: the next-edition dict when one exists post
        roll-forward (adopted or scheduled), else None,
      switch_in_window: the effective date is inside the full
        arrival window [arrival_start, arrival_end] (vs. before
        it — also flagged, worded differently by the panel).
    """
    today = today or date.today()
    try:
        lead_min_weeks = max(0, int(lead_min_weeks))
        lead_max_weeks = max(lead_min_weeks, int(lead_max_weeks))
    except Exception:
        lead_min_weeks, lead_max_weeks = 20, 22
    out = {"arrival_start": today + timedelta(weeks=lead_min_weeks),
           "arrival_end": today + timedelta(weeks=lead_max_weeks),
           "flag": False, "switch": None, "switch_in_window": False,
           "switch_before_window": False}
    if not res or res.get("level") == "local":
        return out
    if not res.get("verified", True):
        return out  # V1.9.53: unverified rows never flag
    nxt = (res.get("state_row") or {}).get("next") or {}
    if not nxt:
        return out
    out["switch"] = nxt
    eff = _parse_day(nxt.get("effective"))
    if eff is None or nxt.get("status") != "adopted":
        return out
    if today < eff <= out["arrival_end"]:
        out["flag"] = True
        out["switch_in_window"] = eff >= out["arrival_start"]
        out["switch_before_window"] = eff < out["arrival_start"]
    return out


def chip_text(res, today=None):
    """The chip's text, or None for no chip. An edition is named
    ONLY for county/state resolutions; local adoption gets a
    plain-language chip with no edition, per the accuracy rule."""
    if not res:
        return None
    if not res.get("verified", True):
        return None  # V1.9.53: downgraded row -- no chip at all
    if res.get("level") == "local":
        return "IBC: Local"
    ed = (res.get("state_row") or {}).get("edition")
    if ed is None:
        return "IBC: Local"
    return f"IBC {ed}"
