"""Native Windows Aero Snap support — REMOVED.

History: this module once restored Aero Snap for our frameless windows by
adding ``WS_THICKFRAME`` to the native window style and running a native
``WM_SYSCOMMAND``/``SC_MOVE`` caption drag. That approach was dropped after
the chrome saga (2026-09-22):

* Adding ``WS_THICKFRAME`` makes *Windows* do its own ``WM_NCHITTEST``
  hit-testing and start *native* resize loops on press, which fights the
  custom Qt chrome manager on every click (misplaced zones, hijacked drags)
  no matter how correct the Qt code is.
* Hand-rolled ``WM_NCHITTEST`` mixes physical pixels (lParam) with Qt's
  logical geometry and slides resize zones around on scaled displays.

Window snapping is now implemented in pure Qt instead: ``TitleBar`` in
``ui.py`` shows an edge preview while dragging and snaps on release
(``snap_action`` / ``snapped_rect`` — pure, unit-tested geometry helpers),
with no native style bits and no native event filter.

``enable_win_snap(window)`` is kept as a documented no-op and ``NATIVE_SNAP``
is kept as a platform flag so existing imports keep working.
"""

import sys

NATIVE_SNAP = sys.platform == "win32"


def enable_win_snap(window):
    """Deliberate no-op: native snap stays off so Windows never fights the
    pure-Qt chrome. See the module docstring for the history."""
    return None
