"""Native Windows Aero Snap for the app's frameless windows.

V1.9.51 (user, superseding the 2026-11 boundary in MEMORY.md:
"if I ask for something to be a certain way and literally any
other real program does something a certain way, there is no
reason my programs wont do it the same" -- he demanded the
standard Windows behaviour: Win+Left/Right, Snap Assist
listing, drag-to-edge snap with the native animation, resize
handles on every edge):

The 2026-09 removal note below this design's history stands as
the warning it was written as: WS_THICKFRAME *alone* made
Windows run its OWN default hit-testing, which fought the Qt
chrome. This implementation answers that failure mode directly:

* ``WS_THICKFRAME`` is added (with SYSMENU/MIN/MAX boxes, the
  set Windows requires before a window may snap, appear in
  Snap Assist, or answer Win+Arrow), AND
* an application-level native event filter answers
  ``WM_NCHITTEST`` for EVERY point of the window -- titlebar
  buttons are HTCLIENT, the rest of the titlebar is HTCAPTION,
  the edges are the resize codes, everything else HTCLIENT.
  Windows never applies a default hit test, so there is no
  second opinion to fight the chrome; non-client presses go
  to the native move/resize loops and never reach Qt widgets.
* ``WM_NCCALCSIZE`` returns 0 so the client area stays the
  whole window (the Qt chrome paints everything); maximized
  windows get the standard frame inset so nothing overhangs.
* ``WM_GETMINMAXINFO`` scales the Qt minimum size by the
  display's device pixel ratio (lParam is PHYSICAL pixels;
  the 2026-09 notes record what happens when that conversion
  is skipped) and pins maximized size/position to the work
  area.

Off Windows, or if any step fails, ``enable_win_snap`` is a
no-op and the pure-Qt chrome keeps its current behaviour --
nothing here may ever break a window for the sake of snap.
"""

import sys

NATIVE_SNAP = sys.platform == "win32"

# Logical px inside each window edge that count as the resize
# border. CHROME_MARGIN is 0, so the visible frame edge IS the
# window edge and the zone simply straddles it from inside.
_GRAB = 7

if NATIVE_SNAP:
    import ctypes
    from ctypes import wintypes

    from PySide6.QtCore import QAbstractNativeEventFilter, QPoint, QRect
    from PySide6.QtWidgets import QAbstractButton, QApplication

    _user32 = ctypes.windll.user32

    _GWL_STYLE = -16
    _WS_THICKFRAME = 0x00040000
    _WS_SYSMENU = 0x00080000
    _WS_MINIMIZEBOX = 0x00020000
    _WS_MAXIMIZEBOX = 0x00010000
    _SWP_NOSIZE = 0x0001
    _SWP_NOMOVE = 0x0002
    _SWP_NOZORDER = 0x0004
    _SWP_NOACTIVATE = 0x0010
    _SWP_FRAMECHANGED = 0x0020

    _WM_NCCALCSIZE = 0x0083
    _WM_NCHITTEST = 0x0084
    _WM_GETMINMAXINFO = 0x0024

    _HTCLIENT = 1
    _HTCAPTION = 2
    _HTLEFT = 10
    _HTRIGHT = 11
    _HTTOP = 12
    _HTTOPLEFT = 13
    _HTTOPRIGHT = 14
    _HTBOTTOM = 15
    _HTBOTTOMLEFT = 16
    _HTBOTTOMRIGHT = 17

    class _POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class _RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    class _MSG(ctypes.Structure):
        _fields_ = [("hwnd", ctypes.c_void_p),
                    ("message", ctypes.c_uint),
                    ("wParam", ctypes.c_size_t),
                    ("lParam", ctypes.c_ssize_t),
                    ("time", ctypes.c_ulong),
                    ("pt", _POINT)]

    class _MINMAXINFO(ctypes.Structure):
        _fields_ = [("ptReserved", _POINT), ("ptMaxSize", _POINT),
                    ("ptMaxPosition", _POINT), ("ptMinTrackSize", _POINT),
                    ("ptMaxTrackSize", _POINT)]

    class _MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_ulong), ("rcMonitor", _RECT),
                    ("rcWork", _RECT), ("dwFlags", ctypes.c_ulong)]

    _windows = {}          # hwnd (int) -> window (QWidget)
    _filter = None

    def _log(msg):
        try:
            from .startup_log import log_startup_event
            log_startup_event("winsnap: " + msg)
        except Exception:
            pass

    class _SnapFilter(QAbstractNativeEventFilter):
        def nativeEventFilter(self, event_type, message):  # noqa: N802
            if event_type != b"windows_generic_MSG":
                return False, 0
            try:
                msg = ctypes.cast(
                    int(message), ctypes.POINTER(_MSG)).contents
                window = _windows.get(msg.hwnd)
                if window is None:
                    return False, 0
                if msg.message == _WM_NCHITTEST:
                    return True, _hit_test(window, msg.lParam)
                if msg.message == _WM_GETMINMAXINFO:
                    _apply_minmax(window, msg.lParam, msg.hwnd)
                    return True, 0
                if msg.message == _WM_NCCALCSIZE:
                    # V1.9.52 (user: maximized/fullscreen showed
                    # the wallpaper around the edges): NO inset,
                    # in any state. The 1.9.51 maximized inset
                    # (the standard framed-window compensation)
                    # shrank the CLIENT area ~8px per side while
                    # the window rect stayed at the work area,
                    # leaving an unpainted ring the desktop
                    # showed through. This window has no frame
                    # to compensate for -- its resize zone lives
                    # INSIDE the client area, and
                    # WM_GETMINMAXINFO already pins the maximized
                    # rect to the work area exactly, so the
                    # client area is the whole window, always.
                    return True, 0
            except Exception:
                return False, 0
            return False, 0

    def _hit_test(window, lparam):
        # lParam packs the cursor's SCREEN position as two
        # signed 16-bit values (physical pixels).
        sx = ctypes.c_short(lparam & 0xFFFF).value
        sy = ctypes.c_short((lparam >> 16) & 0xFFFF).value
        dpr = window.devicePixelRatioF() or 1.0
        origin = window.mapToGlobal(QPoint(0, 0))
        # mapToGlobal works in logical coords; the cursor
        # arrives in physical px, so convert first.
        lx = int(round(sx / dpr)) - origin.x()
        ly = int(round(sy / dpr)) - origin.y()
        w, h = window.width(), window.height()
        if window.isMaximized() or not _resizable(window):
            resize = None
        else:
            top = ly < _GRAB
            bottom = ly >= h - _GRAB
            left = lx < _GRAB
            right = lx >= w - _GRAB
            if top and left:
                resize = _HTTOPLEFT
            elif top and right:
                resize = _HTTOPRIGHT
            elif bottom and left:
                resize = _HTBOTTOMLEFT
            elif bottom and right:
                resize = _HTBOTTOMRIGHT
            elif top:
                resize = _HTTOP
            elif bottom:
                resize = _HTBOTTOM
            elif left:
                resize = _HTLEFT
            elif right:
                resize = _HTRIGHT
            else:
                resize = None
        if resize is not None:
            return resize
        # Titlebar: buttons (and any other interactive child)
        # stay client; the rest of the bar is the caption.
        chrome = getattr(window, "_chrome", None)
        titlebar = chrome.get("titlebar") if chrome else None
        if titlebar is not None and titlebar.isVisible():
            bar_rect = QRect(titlebar.mapTo(window, QPoint(0, 0)),
                             titlebar.size())
            if bar_rect.contains(lx, ly):
                for btn in titlebar.findChildren(QAbstractButton):
                    if not btn.isVisible():
                        continue
                    r = QRect(btn.mapTo(window, QPoint(0, 0)),
                              btn.size())
                    if r.contains(lx, ly):
                        return _HTCLIENT
                return _HTCAPTION
        return _HTCLIENT

    def _resizable(window):
        try:
            return window.minimumSize() != window.maximumSize()
        except Exception:
            return True

    def _apply_minmax(window, lparam, hwnd):
        mmi = ctypes.cast(lparam, ctypes.POINTER(_MINMAXINFO)).contents
        dpr = window.devicePixelRatioF() or 1.0
        min_sz = window.minimumSize()
        if min_sz.width() > 0:
            mmi.ptMinTrackSize.x = int(min_sz.width() * dpr)
            mmi.ptMinTrackSize.y = int(min_sz.height() * dpr)
        max_sz = window.maximumSize()
        if max_sz.width() < 16777215:
            mmi.ptMaxTrackSize.x = int(max_sz.width() * dpr)
            mmi.ptMaxTrackSize.y = int(max_sz.height() * dpr)
        # Maximized geometry = the monitor's WORK area.
        try:
            monitor = _user32.MonitorFromWindow(
                ctypes.c_void_p(hwnd), 2)  # MONITOR_DEFAULTTONEAREST
            info = _MONITORINFO()
            info.cbSize = ctypes.sizeof(info)
            if monitor and _user32.GetMonitorInfoW(
                    monitor, ctypes.byref(info)):
                mmi.ptMaxSize.x = info.rcWork.right - info.rcWork.left
                mmi.ptMaxSize.y = info.rcWork.bottom - info.rcWork.top
                mmi.ptMaxPosition.x = (info.rcWork.left
                                       - info.rcMonitor.left)
                mmi.ptMaxPosition.y = (info.rcWork.top
                                       - info.rcMonitor.top)
        except Exception:
            pass

    def _inset_maximized(lparam):  # RETIRED in V1.9.52 -- see
        # the WM_NCCALCSIZE branch; kept only so nothing that
        # imported the name breaks.
        # NCCALCSIZE_PARAMS' first member is the proposed rect;
        # a maximized window must give back the frame thickness
        # or its edges overhang the work area on every side.
        rect = ctypes.cast(lparam, ctypes.POINTER(_RECT)).contents
        fx = _user32.GetSystemMetrics(32) + _user32.GetSystemMetrics(92)
        fy = _user32.GetSystemMetrics(33) + _user32.GetSystemMetrics(92)
        rect.left += fx
        rect.top += fy
        rect.right -= fx
        rect.bottom -= fy

    def _install_filter_once():
        global _filter
        if _filter is None:
            app = QApplication.instance()
            if app is None:
                return False
            _filter = _SnapFilter()
            app.installNativeEventFilter(_filter)
        return True

    def enable_win_snap(window):
        """Register a chromed window for native snap (Windows
        only). Safe to call for every window; any failure leaves
        the pure-Qt behaviour untouched."""
        try:
            if not _install_filter_once():
                return None
            hwnd = int(window.winId())
            get_long = getattr(_user32, "GetWindowLongPtrW",
                               _user32.GetWindowLongW)
            set_long = getattr(_user32, "SetWindowLongPtrW",
                               _user32.SetWindowLongW)
            style = get_long(ctypes.c_void_p(hwnd), _GWL_STYLE)
            new_style = (style | _WS_THICKFRAME | _WS_SYSMENU
                         | _WS_MINIMIZEBOX | _WS_MAXIMIZEBOX)
            if new_style != style:
                set_long(ctypes.c_void_p(hwnd), _GWL_STYLE, new_style)
                _user32.SetWindowPos(
                    ctypes.c_void_p(hwnd), None, 0, 0, 0, 0,
                    _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOZORDER
                    | _SWP_NOACTIVATE | _SWP_FRAMECHANGED)
            _windows[hwnd] = window
            window._snap_registered = True
            _log("registered hwnd %s" % hwnd)
        except Exception as exc:  # noqa: BLE001 - snap must never break a window
            _log("enable failed: %r" % (exc,))
        return None

else:

    def enable_win_snap(window):
        """No-op off Windows (see the module docstring)."""
        return None
