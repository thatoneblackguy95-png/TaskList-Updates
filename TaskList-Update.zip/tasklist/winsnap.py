"""Windows native snap hook — RETIRED to a true no-op (V1.9.80).

History, in order:

* 2026-09 (AGENTS.md GOTCHA): WS_THICKFRAME on the frameless
  window made Windows run its OWN WM_NCHITTEST and native
  resize loops, fighting the Qt chrome manager on every click.
  Standing conclusion: "If you want custom Qt chrome, do NOT
  set WS_THICKFRAME; go pure Qt. See enable_win_snap (no-op)
  in tasklist/winsnap.py."
* V1.9.51 reintroduced the native path anyway: WS_THICKFRAME
  plus an application-level native event filter answering
  WM_NCHITTEST / WM_NCCALCSIZE / WM_GETMINMAXINFO, in pursuit
  of native Aero Snap (Win+Arrow, Snap Assist). (The maximized
  client-area inset from that design was RETIRED in V1.9.52.)
* 2026-11-17 field defect (user, live 1.9.78, desktop at 200%
  scaling, multi-monitor): the main window could not be
  dragged, was stuck on the wrong monitor, the whole title-bar
  band showed the resize cursor, and the caption buttons were
  unclickable. W5 convicted the mechanism (sim1980/report_w5.md):
  the native _hit_test divided a virtual-desktop PHYSICAL
  cursor coordinate by the window's device pixel ratio and
  subtracted a LOGICAL window origin. That identity only holds
  under uniform DPR; on a mixed-DPI desktop (primary 200%,
  window on a 100% secondary) the title-bar centre classified
  as RESIZE-right and the close-button centre as RESIZE, so
  Windows ran its native resize loop, HTCAPTION was never
  returned, and the Qt TitleBar never saw the press.

Decision (V1.9.80, W5b): restore the GOTCHA's sanctioned
end-state. ``enable_win_snap`` is a true no-op on EVERY
platform, Windows included: it installs no native event
filter, sets no window style bits, and registers nothing, so
no native hit-test classification exists at all and the
mixed-DPI misclassification is impossible by construction.
The pure-Qt chrome owns all hit-testing — WindowChrome in
ui.py (window-local logical coordinates, W5-gated 21/21
including negative-x secondary geometry) — and pure-Qt
drag-to-edge snapping (ui.snap_action / ui.snapped_rect,
pinned by tests/test_v1931_chrome.py) provides the snap
behaviour. The accepted loss is the native-frame extras
(Win+Arrow / Snap Assist listing / native snap animation),
exactly the trade the 2026-09 GOTCHA and the standing comment
in ui.install_main_chrome ("Side-snapping needs WS_THICKFRAME,
which fights the custom Qt resize handling, so it stays off")
already recorded.

``NATIVE_SNAP`` is False: no native snap path exists. (Older
suites pinned it to ``sys.platform == "win32"``; on non-Windows
that equality still holds trivially, and on Windows those pins
are SUPERSEDED by this retirement — see sim1980/report_w5b.md.)
"""

import sys  # noqa: F401  (kept: callers historically read the platform here)

NATIVE_SNAP = False


def enable_win_snap(window):
    """No-op on every platform (see the module docstring).

    Kept as a function so every existing call site
    (``enable_win_snap(window)`` in ui.py's chrome install)
    stays valid. It must never install a native event filter,
    never add WS_THICKFRAME or any other style bits, and never
    register the window anywhere: the pure-Qt WindowChrome is
    the only hit-tester.
    """
    return None
