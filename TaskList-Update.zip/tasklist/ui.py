"""Cards, dropdowns, detail window and attachments for the Task List UI."""
import csv
import html
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import zlib
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import quote as _url_quote

from PySide6.QtCore import (
    Qt, Signal, Slot, QPoint, QPointF, QUrl, QDateTime, QDate, QSize, QObject,
    QEvent, QRect, QRectF, QMimeData, QByteArray, QStringListModel, QTimer, QThread,
    QEasingCurve, QPropertyAnimation, QParallelAnimationGroup, QModelIndex,
    Property, QItemSelectionModel,
)
from PySide6.QtGui import (
    QDesktopServices, QShortcut, QKeySequence, QPixmap, QIcon, QCursor, QColor,
    QBrush, QIntValidator, QPen, QImage, QImageReader,
    QDrag, QDoubleValidator, QFont, QStandardItem, QStandardItemModel,
    QTextCharFormat, QTextBlockFormat, QTextCursor, QTextDocument,
    QTextFormat, QTextTable,
    QTextListFormat, QTextOption, QPainter, QLinearGradient,
    QPainterPath, QGuiApplication, QPalette, QFontMetrics, QRegion,
    QPolygon,
)
from PySide6.QtWidgets import (
    QApplication, QAbstractButton, QAbstractItemView, QAbstractScrollArea,
    QAbstractSlider, QButtonGroup, QCheckBox,
    QComboBox, QCompleter, QDateEdit, QDialog, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QLineEdit, QListView, QListWidget, QListWidgetItem, QMenu,
    QMessageBox,
    QPushButton, QScrollArea, QScrollBar, QSpinBox, QStackedWidget,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QTextEdit, QVBoxLayout, QWidget, QInputDialog, QGridLayout, QSplitter,
    QSizePolicy, QToolTip, QGraphicsDropShadowEffect, QLayout,
    QRadioButton, QScroller, QColorDialog, QFontComboBox,
    QStyle, QStylePainter, QStyleOptionButton, QStyledItemDelegate,
    QStyleOptionViewItem,
)

from .db import (
    SCOPES, STATUSES, STATUS_LABELS, DEFAULT_RACK_TYPES,
    DIRECTORY_KINDS, DIRECTORY_LABELS, DIRECTORY_SINGULAR,
    QUEUE_COLUMNS, QUEUE_COLUMN_KEYS, OPEN_STATUSES, format_location,
    note_to_markdown, note_to_text, note_to_html_doc, note_to_docx,
    export_notes_to_folder,
)
from . import updater
from .icons import svg_icon
from .fonts import app_font, font_with_weight
from .themes import (saved_theme, save_theme, apply_theme, saved_font_family,
                     save_font_family, saved_font_scale, save_font_scale,
                     saved_accent, save_accent, shifted_color, themed_menu,
                     apply_menu_glass)
from .winsnap import enable_win_snap
from .toast import show_toast
from .startup_log import log_startup_event

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}


# ------------------------------------------------------------ safe dropdowns
# V1.9.29: SafeComboBox / SafeFontComboBox no longer use Qt's native
# popup at all — they open _GlassComboPopup (below, after the glass
# helpers), a popup widget this app paints itself. See its docstring
# for why the native popup + masks approach was abandoned.


# ------------------------------------------------------------ proper glass
# V1.9.25 rewrite (user standing order: dropdowns are GLASS, like
# ComfyUI — a dark tint with blur, rounded corners, a light rim).
# History, so it is never re-broken the same way twice:
# - V1.9.16/17: glass as a toggle (default off) over combo views.
# - V1.9.18: TagPopup made translucent, relying on the #scopePopup QSS
#   background to paint — on real Windows it never painted, so the
#   popup went fully see-through (user screenshot 2026-11-03).
# - V1.9.24: translucency removed (opaque) — the wrong direction:
#   the user never changed direction on glass, he wanted the glass
#   FIXED (tint + blur), not removed.
# This rewrite paints the chrome explicitly (never via QSS on a
# translucent window) and gets the blur from the OS compositor.
_GLASS_RADIUS = 10
# V1.9.34 (user): a LITTLE more frost on the glass dropdowns --
# alpha 160 (0.63) read clear-through; 194 (0.76) matches the
# combo-view tint bump in themes.py. Still glass, just frostier.
_GLASS_FILL_DARK = QColor(24, 26, 32, 217)
_GLASS_FILL_LIGHT = QColor(255, 255, 255, 217)
_GLASS_RIM_DARK = QColor(255, 255, 255, 48)
_GLASS_RIM_LIGHT = QColor(0, 0, 0, 26)


def glass_colors():
    """(fill, rim) for the current theme's glass popup chrome."""
    if saved_theme() == "light":
        return _GLASS_FILL_LIGHT, _GLASS_RIM_LIGHT
    return _GLASS_FILL_DARK, _GLASS_RIM_DARK


def enable_blur_behind(window):
    """Legacy DWM blur-behind ONLY — kept for the record.

    V1.9.45: nothing calls this anymore. The frost is painted by
    the app itself (capture_frost / paint_frost below). Do NOT
    re-add the Windows acrylic or system-backdrop calls here or
    anywhere else: they were tried twice (V1.9.30, V1.9.43) and
    both times the OS material painted a RECTANGULAR, effectively
    opaque slab behind the rounded popups on the user's machine
    -- square corners behind the radius and the glass gone. The
    window mask does not clip those layers there. The legacy call
    below is harmless (it paints nothing by itself) but does not
    produce a visible blur on current Windows either.
    """
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        hwnd = int(window.winId())
        if not hwnd:
            return False
        try:
            class _BlurBehind(ctypes.Structure):
                _fields_ = [("dwFlags", ctypes.c_uint),
                            ("fEnable", ctypes.c_bool),
                            ("hRgnBlur", ctypes.c_void_p),
                            ("fTransitionOnMaximized", ctypes.c_bool)]

            blur = _BlurBehind(0x1, True, None, False)
            if ctypes.windll.dwmapi.DwmEnableBlurBehindWindow(
                    hwnd, ctypes.byref(blur)) == 0:
                return True
        except Exception:
            pass
    except Exception:
        pass
    return False


def _grab_screen(screen, rect):
    """The screen pixels inside rect (split out for testability)."""
    return screen.grabWindow(0, rect.x(), rect.y(),
                             rect.width(), rect.height())


def _blur_image(img, factor=9):
    """A hard frost blur: crush down, smooth back up, twice. Sharp
    detail (text, edges) dissolves; only broad light and colour
    survive -- exactly what looking through frosted glass shows.
    V1.9.48 (user, twice over: "I SAID ADD A BLUR NOT MAKE THEM
    NOT GLASS" / "I STILL DONT HAVE THE GLASS BACK... IT MUST
    GO BACK TO GLASS"): the blur is the glass. V1.9.47 weakened
    it to 6 and the dropdowns read as plain tinted overlays --
    background text stayed legible, no frost, no glass. Factor
    9 restores the strong diffusion; the see-through balance is
    carried by the TINT over it (140, not the 168 slab), never
    by weakening the blur again."""
    w, h = img.width(), img.height()
    if w < 2 or h < 2:
        return img
    sw, sh = max(1, w // factor), max(1, h // factor)
    out = img.scaled(sw, sh, Qt.IgnoreAspectRatio,
                     Qt.SmoothTransformation)
    out = out.scaled(w, h, Qt.IgnoreAspectRatio,
                     Qt.SmoothTransformation)
    out = out.scaled(sw, sh, Qt.IgnoreAspectRatio,
                     Qt.SmoothTransformation)
    return out.scaled(w, h, Qt.IgnoreAspectRatio,
                      Qt.SmoothTransformation)


def _frost_log(message):
    """Frost failures go to data/startup.log (V1.9.50): the
    glass silently degrading to a clear tint was undiagnosable
    for two releases because nothing recorded it."""
    try:
        from tasklist.startup_log import log_startup_event
        log_startup_event("frost: " + message)
    except Exception:
        pass


def capture_frost(widget):
    """Snapshot the screen region a glass popup is about to cover
    and store it, blurred, as the popup's painted backdrop.

    V1.9.45 (user: "I SAID ADD A BLUR NOT MAKE THEM NOT GLASS"):
    the app paints its OWN frost now. Every compositor route
    failed on the user's machine -- legacy blur-behind does
    nothing visible there, and the acrylic/backdrop materials
    paint a rectangular opaque slab (square corners, no glass).
    A blurred snapshot of the actual pixels behind the popup,
    painted by the popup inside its own rounded shape, is frost
    by construction: a real blur of what is really behind it,
    round corners guaranteed, and still translucent glass. The
    snapshot is taken in the show event, before the popup's first
    paint is presented, and stays static while the popup is open
    (the standard behaviour of menus and dropdowns).
    """
    try:
        geo = widget.frameGeometry()
        if geo.width() < 2 or geo.height() < 2:
            return None
        screen = widget.screen()
        if screen is None:
            screen = QApplication.primaryScreen()
        if screen is None:
            return None
        shot = _grab_screen(screen, geo)
        if shot is None or shot.isNull():
            _frost_log("grab returned no image for %s"
                       % type(widget).__name__)
            return None
        # V1.9.50: validate the RAW grab, not the blurred image.
        # The V1.9.47 check sampled the BLURRED result at 9 points
        # and discarded it when every sample was near black --
        # but the blur averages sparse bright content (text on
        # this app's true-black surfaces) down to almost nothing,
        # so legitimate dark grabs were thrown away and the popup
        # fell back to a plain tint with the text behind it fully
        # readable (the user's "THE GLASS STILL DOES NOT BLUR"
        # screenshot). A genuinely DEAD grab (the Windows/driver
        # failure the check exists for) is uniformly ~0 across
        # the whole frame; a real dark scene always has borders,
        # text or icons somewhere in an 8x8 grid. Discard only
        # the dead frame, and log every discard -- a silent
        # fallback is how this went undiagnosed for two releases.
        try:
            raw = shot.toImage()
            w, h = raw.width(), raw.height()
            peak = 0
            for gx in range(8):
                for gy in range(8):
                    c = raw.pixelColor(int(w * (gx + 0.5) / 8),
                                       int(h * (gy + 0.5) / 8))
                    peak = max(peak, c.red(), c.green(), c.blue())
            if peak <= 2:
                widget._frost_pixmap = None
                _frost_log("grab was a dead (uniform black) frame "
                           "for %s" % type(widget).__name__)
                return None
        except Exception:
            pass
        blurred = _blur_image(shot.toImage())
        pm = QPixmap.fromImage(blurred)
        pm.setDevicePixelRatio(shot.devicePixelRatio())
        widget._frost_pixmap = pm
        return pm
    except Exception:
        return None


def paint_frost(widget, painter, radius):
    """Paint the captured frost backdrop inside the rounded
    shape. Returns True when a snapshot was painted -- the caller
    then lays a LIGHTER tint over it, so the blur stays visible
    (a 0.85 tint over the snapshot would bury it again)."""
    pm = getattr(widget, "_frost_pixmap", None)
    if pm is None:
        return False
    path = QPainterPath()
    path.addRoundedRect(QRectF(widget.rect()), radius, radius)
    painter.save()
    painter.setClipPath(path)
    painter.drawPixmap(widget.rect(), pm)
    painter.restore()
    return True


class _PrefixFitFilter(QObject):
    """Keeps a QLineEdit's prefix label glued to its left inside
    edge whenever the edit resizes."""

    def eventFilter(self, watched, event):  # noqa: N802 (Qt virtual)
        if event.type() == QEvent.Resize:
            lab = getattr(watched, "_prefix_label", None)
            if lab is not None:
                lab.setGeometry(4, 0, 14, watched.height())
        return False


def add_currency_prefix(edit):
    """A "$" that lives INSIDE a money line edit as unselectable
    text (V1.9.45, user: the Quote Price box showed a bare number
    -- "the $ should populate there as unselectable text").

    It is a child label, not part of the text: it can never be
    selected, edited, or leak into parsing (the edit's text stays
    purely numeric), and it hides automatically with the edit.
    """
    lab = QLabel("$", edit)
    lab.setObjectName("currencyPrefix")
    lab.setAlignment(Qt.AlignCenter)
    lab.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    lab.setGeometry(4, 0, 14, edit.height())
    edit._prefix_label = lab
    filt = _PrefixFitFilter(edit)
    edit.installEventFilter(filt)
    edit._prefix_filter = filt
    # Deliberately NO text margins: a QLineEdit's sizeHint counts
    # its text margins, and these money fields are sized to the
    # pixel by their columns (the caption-over-box centring is
    # measured) -- margins would grow the hint and shift the
    # column. The number is centre-aligned in a wide field, so it
    # never reaches the $ at the left edge in practice.
    return lab


def chrome_tab_path(body, top_radius=9.0, fillet=11.0):
    """The Google Chrome tab silhouette for a tab BODY rect.

    V1.9.46 (user, with a Chrome screenshot: the tabs must look
    IDENTICAL to Chrome's). What makes a tab read as Chrome is
    not rounded top corners alone -- it is this outline: rounded
    top corners, straight sides, and at the base the sides FLARE
    OUTWARD through concave fillets to meet the baseline `fillet`
    px beyond the body on each side, so the active tab pours into
    the surface below it. No outline stroke anywhere: Chrome's
    active tab is a solid slab of the pane colour against a
    darker strip. body.bottom() must be the baseline (one past
    the hairline row, so the fill covers it)."""
    x0, x1 = body.left(), body.right()
    y0, y1 = body.top(), body.bottom()
    path = QPainterPath()
    path.moveTo(x0 - fillet, y1)
    path.quadTo(x0, y1, x0, y1 - fillet)
    path.lineTo(x0, y0 + top_radius)
    path.quadTo(x0, y0, x0 + top_radius, y0)
    path.lineTo(x1 - top_radius, y0)
    path.quadTo(x1, y0, x1, y0 + top_radius)

    path.lineTo(x1, y1 - fillet)
    path.quadTo(x1, y1, x1 + fillet, y1)
    path.closeSubpath()
    return path


def chrome_tab_outline_path(body, top_radius=9.0, fillet=11.0):
    """The Chrome silhouette as an OPEN path (V1.9.48): the same
    outline as chrome_tab_path but WITHOUT the closing segment
    across the bottom -- the active tab merges into the pane
    below, so its outline traces the flares, sides and top only,
    continuing the pane's own border around the tab (user: "that
    gray outline around the box should also follow around the
    tab... it is hard to see the tab over the background")."""
    x0, x1 = body.left(), body.right()
    y0, y1 = body.top(), body.bottom()
    path = QPainterPath()
    path.moveTo(x0 - fillet, y1)
    path.quadTo(x0, y1, x0, y1 - fillet)
    path.lineTo(x0, y0 + top_radius)
    path.quadTo(x0, y0, x0 + top_radius, y0)
    path.lineTo(x1 - top_radius, y0)
    path.quadTo(x1, y0, x1, y0 + top_radius)
    path.lineTo(x1, y1 - fillet)
    path.quadTo(x1, y1, x1 + fillet, y1)
    return path


def _crm_tab_palette():
    """Paint colours for the CRM attached tabs -- the same values
    _crm_tabs_qss puts in the pane's QSS, as QColors for the
    custom-painted strip and tab buttons."""
    if saved_theme() == "light":
        return {"pane": QColor("#f7f7f8"), "line": QColor(0, 0, 0, 54),
                "hover": QColor(0, 0, 0, 13), "idle": QColor("#5c636d"),
                "text": QColor("#1c1f24"), "strip": QColor("#f7f7f8"),
                "sep": QColor(0, 0, 0, 34)}
    # V1.9.47 (user, both tab strips): the strip is NOT a black
    # recess any more -- painted pure black it read as a stray
    # black BOX behind the tabs, because the window surface
    # around it is #101114, not black. The strip now takes the
    # window surface itself; the baseline hairline, separators
    # and the active silhouette carry the tab read.
    return {"pane": QColor("#0c0d10"), "line": QColor(255, 255, 255, 46),
            "hover": QColor(255, 255, 255, 13),
            "idle": QColor("#8a919c"), "text": QColor("#e8ebef"),
            "strip": QColor("#101114"), "sep": QColor(255, 255, 255, 30)}


def _rounded_mask(widget, radius=_GLASS_RADIUS):
    """Clip a popup window to a rounded rect.

    The mask is the corner guarantee that does not depend on
    compositing: even if a view's QSS radius misbehaves, the window
    itself cannot show square corners outside this region.
    """
    path = QPainterPath()
    path.addRoundedRect(QRectF(widget.rect()), radius, radius)
    widget.setMask(QRegion(path.toFillPolygon().toPolygon()))


class _PopupMaskFilter(QObject):
    """Re-apply a popup container's rounded mask when it resizes.

    Qt sizes a combo popup at showPopup, but the container can resize
    afterwards (scrollbar appearing, screen-edge clamping); the mask
    set at placement then no longer matches the window and square
    corners show behind the rounded view. The filter is parented to
    the container, so it dies with it, and never consumes events.
    """

    def eventFilter(self, watched, event):  # noqa: N802 (Qt virtual)
        if event.type() in (QEvent.Resize, QEvent.Show):
            _rounded_mask(watched)
        return super().eventFilter(watched, event)


#: The #windowFrame QSS border-radius (themes.py) — the mask below
#: must use the SAME radius or the clip and the painted frame disagree.
_CHROME_RADIUS = 12


def _sync_chrome_mask(window):
    """V1.9.33 (user: the main window's corner "is still sharp and
    falling out of the rounded corner"): the #windowFrame frame is
    only PAINTED round (QSS border-radius) — nothing clipped its
    children to that arc, so an opaque child that reaches a corner
    (the sidebar at the bottom-left, scroll areas at the right)
    painted its square corner straight past the frame's arc. Popups
    got the real guarantee in V1.9.30 (a window mask); chromed
    windows now get the same: mask the whole window to the frame's
    rounded rect, reapplied on resize, cleared while maximized (the
    frame is square then too, per the squareCorners property)."""
    if window.isMaximized():
        window.clearMask()
    else:
        _rounded_mask(window, _CHROME_RADIUS)


class _ChromeMaskFilter(QObject):
    """Keep a chromed window's rounded mask matched to its size."""

    def eventFilter(self, watched, event):  # noqa: N802 (Qt virtual)
        if event.type() in (QEvent.Resize, QEvent.Show):
            _sync_chrome_mask(watched)
        return super().eventFilter(watched, event)


class _TooltipGlassFilter(QObject):
    """Paint the app's frost under a tooltip, exactly like menus
    get (V1.9.50, user: tooltips "SHOULD NOT LOOK BLAND AND
    UGLY" -- they are designed glass components in this app:
    a blurred snapshot of what is behind the tooltip under the
    glass tint, inside the rounded mask the surface filter
    applies). Installed once on the QTipLabel; Qt reuses that
    one label for every tooltip in the app."""

    def eventFilter(self, watched, event):  # noqa: N802 (Qt virtual)
        try:
            if event.type() == QEvent.Show:
                capture_frost(watched)
            elif event.type() == QEvent.Paint:
                _p = QPainter(watched)
                paint_frost(watched, _p,
                            _GlobalSurfaceFilter.TOOLTIP_RADIUS)
                _p.end()
        except Exception:
            pass
        return False


class _GlobalSurfaceFilter(QObject):
    """V1.9.31: GLOBAL rounded corners (user, in caps, repeatedly:
    "THE ROUNDED CORNERS THINGS I ASKED FOR NEED TO BE GLOBAL. I DONT
    WANT TO HEAR ANY SORRY I FORGOT ABOUT THATS").

    Per-surface fixes kept missing places — a menubar submenu here, a
    stock context menu there. This app-level filter rounds EVERY
    top-level surface at polish/show time, whoever created it:

    - every QMenu (themed, menubar, submenu, Qt-internal line-edit /
      text-edit context menus, createStandardContextMenu results) gets
      the full glass treatment via themes.apply_menu_glass;
    - QToolTip's label gets a translucent window + rounded mask;
    - popup item views (the QCompleter dropdown) get a rounded mask;
    - stock Qt dialogs are NOT rounded here — they are gone instead:
      every prompt goes through the chromed app_* dialog family below,
      so no native-frame window can appear.

    Masks follow resizes via the ``cornerRadius`` widget property.
    The filter never consumes an event and never raises.
    """

    TOOLTIP_RADIUS = 8
    POPUP_RADIUS = 8

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        try:
            t = event.type()
            if t in (QEvent.Polish, QEvent.Show):
                if isinstance(obj, QWidget) and obj.isWindow():
                    self._round_surface(obj)
            elif t == QEvent.Resize and isinstance(obj, QWidget):
                radius = obj.property("cornerRadius")
                if radius:
                    _rounded_mask(obj, int(radius))
        except Exception:
            pass
        return False

    def _round_surface(self, w):
        if isinstance(w, QMenu):
            apply_menu_glass(w)
        elif w.metaObject().className() == "QTipLabel":
            w.setProperty("cornerRadius", self.TOOLTIP_RADIUS)
            w.setAttribute(Qt.WA_TranslucentBackground, True)
            _rounded_mask(w, self.TOOLTIP_RADIUS)
            if not w.property("_tooltip_glass_filter"):
                w.installEventFilter(_TooltipGlassFilter(w))
                w.setProperty("_tooltip_glass_filter", True)
        elif isinstance(w, QAbstractItemView) and w.windowFlags() & Qt.Popup:
            w.setProperty("cornerRadius", self.POPUP_RADIUS)
            w.setAttribute(Qt.WA_TranslucentBackground, True)
            try:
                w.setWindowFlags(
                    w.windowFlags() | Qt.NoDropShadowWindowHint
                    | Qt.FramelessWindowHint)
            except Exception:
                pass
            _rounded_mask(w, self.POPUP_RADIUS)


def install_global_surface_filter(app):
    """Install the _GlobalSurfaceFilter on the application (once)."""
    existing = getattr(app, "_surface_filter", None)
    if existing is None:
        existing = _GlobalSurfaceFilter(app)
        app.installEventFilter(existing)
        app._surface_filter = existing
    return existing


class _ComboPopupDelegate(QStyledItemDelegate):
    # V1.9.29: font_mode renders each row in the font family it names
    # (the font-picker combo's popup), matching the native font list.
    """Paints combo popup rows with a rounded, inset selection.

    V1.9.17 (user screenshots): QSS ``::item:selected`` radius does NOT
    round the selected row on Windows — the blue block paints square
    and edge-to-edge, and the view's QSS padding does not inset it.
    This delegate owns the row marking outright: selected and hover
    rows get a 7px-rounded OUTLINE inset 4px horizontally -- no
    infill at all (V1.9.36, user: the filled selected row "looks
    blue" next to the status menus, and the grey hover box goes
    too; an outline with the check/bright text carries the state,
    same as the tag rows and menus). Text is drawn by hand after
    the outline so no square style background can peek out.
    """

    def __init__(self, parent=None, font_mode=False):
        super().__init__(parent)
        self._font_mode = font_mode

    def paint(self, painter, option, index):
        rect = option.rect
        selected = bool(option.state & QStyle.State_Selected)
        hover = bool(option.state & QStyle.State_MouseOver)
        if selected or hover:
            dark = saved_theme() != "light"
            # V1.9.36 (user): no infill at all -- an OUTLINE box only,
            # brighter for the selected row, fainter for hover. The
            # same language as the tag rows and the menus now.
            if selected:
                pen = QColor("#6b7280" if dark else "#9aa0a8")
            else:
                pen = QColor("#3f444e" if dark else "#c3c7cd")
            painter.save()
            painter.setRenderHint(QPainter.Antialiasing, True)
            painter.setPen(QPen(pen, 1))
            painter.setBrush(Qt.NoBrush)
            painter.drawRoundedRect(
                rect.adjusted(4, 2, -4, -2), 7, 7)
            painter.restore()
        text = index.data(Qt.DisplayRole)
        if text is None:
            return
        painter.save()
        if self._font_mode and text:
            # Base on the app font (keeps the NoSubpixelAntialias
            # strategy -- a bare font constructor would leak the OS
            # rendering back in, per the v14 light-mode rule) and
            # only swap the family to the one the row names.
            _f = app_font()
            _f.setFamily(str(text))
            _f.setPointSize(option.font.pointSize())
            painter.setFont(_f)
        else:
            painter.setFont(option.font)
        if selected:
            painter.setPen(QColor(
                "#ffffff" if saved_theme() != "light" else "#1c1f24"))
        else:
            painter.setPen(option.palette.text().color())
        icon = index.data(Qt.DecorationRole)
        x = rect.left() + 12
        if icon is not None and hasattr(icon, "pixmap"):
            try:
                pix = icon.pixmap(16, 16)
            except Exception:
                pix = None
            if pix is not None and not pix.isNull():
                y = rect.center().y() - pix.height() // 2
                painter.drawPixmap(x, y, pix)
                x += pix.width() + 8
        painter.drawText(QRect(x, rect.top(), rect.right() - x,
                               rect.height()),
                         Qt.AlignLeft | Qt.AlignVCenter, str(text))
        painter.restore()

    def sizeHint(self, option, index):
        base = super().sizeHint(option, index)
        return QSize(base.width(), max(base.height(), 36))


class _GlassComboPopup(QFrame):
    """Owned single-select popup for SafeComboBox / SafeFontComboBox.

    V1.9.29 (user, 2026-11-11 — his screenshots on V1.9.27/V1.9.28 still
    showed a sharp square rectangle behind the rounded combo popup and
    no frosted glass, after three releases of attempted fixes): Qt's
    native combo popup is a container window that Qt paints and
    positions itself. Every fix aimed at it — translucency ordering,
    window masks, hiding its chrome widgets — depended on Windows
    compositor timing this app cannot control, and none of it could be
    verified offscreen (native popup grabs return empty pixels). This
    popup removes the native container from the equation entirely:

    - It is an ordinary widget this app paints itself: paintEvent draws
      ONLY the rounded glass shape (translucent tint + rim light), the
      window is translucent from construction and has no drop shadow.
      V1.9.30 correction (user screenshots proved the original claim
      incomplete): on Windows the OS acrylic layer fills the window's
      RECTANGLE, so it also applies _rounded_mask -- with the window
      region clipped round, no layer (paint or compositor) can show a
      square corner. Its height is measured from the delegate's real
      row height, never a hardcoded constant.
    - The frost is the OS blur-behind (enable_blur_behind, best effort,
      exactly as TagPopup has always used); where blur is unavailable,
      the tinted translucency still reads as glass.
    - Because it is our widget, its rendering IS verifiable headlessly:
      tests/test_v1929_fixes.py grabs it and asserts the corner pixels
      are transparent and the middle pixel is the glass fill.

    Behaviour mirrors the native popup: opens below the field (flips
    above near the screen bottom, clamped to the screen), current item
    preselected, arrows / PageUp / PageDown / Home / End move, Enter or
    click commits (emitting the combo's activated signal, like the
    native popup), Esc or an outside click cancels, typing jumps to
    matching items.
    """

    MAX_ROWS = 10
    ROW_H = 36

    def __init__(self, combo, font_mode=False):
        super().__init__(combo, Qt.Popup | Qt.FramelessWindowHint
                         | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self._combo = combo
        self._settled = False
        # V1.9.30 (user screenshots, Sales Rep popup): the painted
        # glass is rounded, but on Windows the acrylic blur-behind
        # layer fills the whole RECTANGULAR window, so square frosted
        # corners showed behind the rounded paint. The class text
        # below claimed no square layer could exist; it was wrong --
        # the compositor layer is one. The corner guarantee is the
        # window MASK (same _rounded_mask the calendar popup uses):
        # with the window region clipped to the rounded rect, neither
        # the paint NOR the OS blur can put a square corner on screen.
        self._mask_filter = _PopupMaskFilter(self)
        self.installEventFilter(self._mask_filter)
        layout = QVBoxLayout(self)
        # V1.9.30 (user screenshot): the right margin left a wide
        # band of dead glass between the scrollbar and the popup's
        # edge. The scrollbar hugs the edge now (3px -- the window
        # mask clips anything the corner curve would catch).
        layout.setContentsMargins(5, 5, 3, 5)
        layout.setSpacing(0)
        view = QListView(self)
        self._view = view
        view.setModel(combo.model())
        view.setModelColumn(combo.modelColumn())
        view.setItemDelegate(_ComboPopupDelegate(view, font_mode=font_mode))
        view.setFrameShape(QFrame.NoFrame)
        view.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        view.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        view.setSelectionMode(QAbstractItemView.SingleSelection)
        view.setEditTriggers(QAbstractItemView.NoEditTriggers)
        view.setMouseTracking(True)
        view.setUniformItemSizes(True)
        view.setStyleSheet(
            "QListView { background: transparent; border: none; }")
        view.viewport().setAutoFillBackground(False)
        layout.addWidget(view)
        view.clicked.connect(self._commit_index)
        view.activated.connect(self._commit_index)
        view.installEventFilter(self)

    def paintEvent(self, event):
        # Identical glass recipe to TagPopup.paintEvent: the ONLY thing
        # painted is the rounded glass shape — nothing square exists.
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        fill, rim = glass_colors()
        fill = QColor(fill)
        if paint_frost(self, painter, _GLASS_RADIUS):
            # V1.9.48 (user: the glass must be BACK): tint 140
            # over the factor-9 frost. 168 buried the blur (slab);
            # 118 over a weakened blur read as no glass at all.
            # The blur carries the glass; the tint gives the
            # surface its body.
            fill.setAlpha(140)
        else:
            # No usable snapshot: the shipped fallback tint
            # (150). V1.9.50's glass fix lives in capture
            # validation -- real scenes are no longer discarded
            # as "dead frames", so this path is now the rare
            # exception, and its strength stays exactly what
            # the user accepted in V1.9.47/48 (an earlier 228
            # experiment was reverted: it changed the accepted
            # look of every glass popup, TagPopup included).
            fill.setAlpha(150)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()),
                            _GLASS_RADIUS, _GLASS_RADIUS)
        painter.setPen(Qt.NoPen)
        painter.setBrush(fill)
        painter.drawPath(path)
        # V1.9.33 (user: "a slight point sticking out" at the popup's
        # top corners): the rim used to be stroked ON the silhouette
        # path, so half the 1px pen lay outside the shape and the hard
        # window mask clipped it unevenly — a tiny spur where the arcs
        # cross. The rim is stroked on an inset path instead (rect in
        # by the half pen width, radius reduced by the same), so the
        # whole rim lives inside the silhouette, concentric with it.
        rim_path = QPainterPath()
        rim_path.addRoundedRect(
            QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
            _GLASS_RADIUS - 0.5, _GLASS_RADIUS - 0.5)
        painter.setPen(QPen(rim, 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(rim_path)
        painter.end()

    def showEvent(self, event):
        super().showEvent(event)
        capture_frost(self)

    def closeEvent(self, event):
        combo = self._combo
        if combo is not None and getattr(combo, "_glass_popup", None) is self:
            combo._glass_popup = None
            # Stamp the close so the click that caused it cannot
            # reopen the popup inside the same press (V1.9.35).
            combo._glass_closed_at = time.monotonic()
        super().closeEvent(event)

    def open_popup(self):
        combo = self._combo
        model = combo.model()
        rows = model.rowCount()
        if rows == 0:
            self.close()
            return
        visible = min(rows, self.MAX_ROWS)
        fm = QFontMetrics(self.font())
        text_w = 0
        col = combo.modelColumn()
        for i in range(rows):
            t = model.data(model.index(i, col), Qt.DisplayRole)
            if t is not None:
                text_w = max(text_w, fm.horizontalAdvance(str(t)))
        width = max(combo.width(), text_w + 64)
        if rows > visible:
            width += 18  # room for the vertical scrollbar
        width = min(width, 560)
        # V1.9.30 (user screenshot: "a huge gap under the last name"):
        # the height used a hardcoded 36px row, but the delegate's
        # real row height grows with the app's font size setting --
        # any mismatch lands as dead glass under the last row (or a
        # clipped list). Measure the view's actual row height and
        # size to it exactly: rows + the 5px top/bottom margins.
        row_h = self._view.sizeHintForRow(0)
        if row_h <= 0:
            row_h = self.ROW_H
        height = visible * row_h + 10
        self.resize(width, height)
        _rounded_mask(self)
        screen = combo.screen() or QApplication.primaryScreen()
        avail = (screen.availableGeometry() if screen is not None
                 else QRect(0, 0, 1920, 1080))
        below = combo.mapToGlobal(QPoint(0, combo.height()))
        x = min(max(below.x(), avail.left()),
                max(avail.left(), avail.right() - width + 1))
        y = below.y() + 4
        if y + height > avail.bottom() + 1:
            above_y = combo.mapToGlobal(QPoint(0, 0)).y() - height - 4
            y = (above_y if above_y >= avail.top()
                 else max(avail.top(), avail.bottom() - height + 1))
        self.move(x, y)
        idx = model.index(max(0, combo.currentIndex()), col)
        self._view.setCurrentIndex(idx)
        self._view.scrollTo(idx)
        self.show()
        # Exact-fit verification: when every row should fit without
        # scrolling, the last row's bottom must land exactly on the
        # VIEWPORT's bottom edge. (Measured against the viewport, not
        # the view: QAbstractScrollArea can hold a few pixels back
        # from the view's height, and that hidden shortfall is what
        # produced the phantom scrollbar + dead band on the user's
        # machine.) Snap the window to the measured content -- dead
        # glass under the last row, and a scrollbar that has nothing
        # to scroll, are then impossible by construction.
        if rows <= visible:
            self._view.doItemsLayout()
            last = self._view.visualRect(model.index(rows - 1, col))
            if last.isValid():
                leftover = (self._view.viewport().height()
                            - (last.bottom() + 1))
                if leftover != 0:
                    self.resize(width, self.height() - leftover)
                    _rounded_mask(self)
        self._view.setFocus()
        # V1.9.41 (user: the Sort-by popup showed a scrollbar for
        # ONE extra item): the snap above runs synchronously inside
        # show(), but on Windows the view's row heights only settle
        # after the first paint/layout pass -- the snap measured
        # pre-settle heights and locked in a too-short window. Run
        # the same exact-fit pass once more after the event loop
        # turns, when the metrics are final.
        QTimer.singleShot(0, self._refit_after_settle)

    def _refit_after_settle(self):
        if not self.isVisible():
            return
        combo = self._combo
        if combo is None:
            return
        model = combo.model()
        rows = model.rowCount()
        if rows == 0 or rows > self.MAX_ROWS:
            return
        col = combo.modelColumn()
        self._view.doItemsLayout()
        last = self._view.visualRect(model.index(rows - 1, col))
        if not last.isValid():
            return
        leftover = (self._view.viewport().height()
                    - (last.bottom() + 1))
        if leftover == 0:
            return
        new_h = self.height() - leftover
        self.resize(self.width(), new_h)
        _rounded_mask(self)
        # Growing downward must not push the popup off-screen.
        screen = combo.screen() or QApplication.primaryScreen()
        if screen is not None:
            avail = screen.availableGeometry()
            over = self.geometry().bottom() - avail.bottom()
            if over > 0:
                self.move(self.x(), max(avail.top(), self.y() - over))

    def _commit_index(self, index):
        if self._settled or index is None or not index.isValid():
            return
        self._settled = True
        combo = self._combo
        row = index.row()
        self.close()
        combo.setCurrentIndex(row)
        try:
            combo.activated[int].emit(row)
        except Exception:
            pass
        combo.setFocus()

    def _type_ahead(self, ch):
        model = self._combo.model()
        rows = model.rowCount()
        col = self._combo.modelColumn()
        cur = self._view.currentIndex()
        start = cur.row() if cur.isValid() else -1
        ch = ch.lower()
        for step in range(1, rows + 1):
            i = (start + step) % rows
            t = model.data(model.index(i, col), Qt.DisplayRole)
            if t is not None and str(t).lower().startswith(ch):
                idx = model.index(i, col)
                self._view.setCurrentIndex(idx)
                self._view.scrollTo(idx)
                return

    def eventFilter(self, obj, event):
        if obj is self._view and event.type() == QEvent.KeyPress:
            key = event.key()
            if key == Qt.Key_Escape:
                self._settled = True
                self.close()
                self._combo.setFocus()
                return True
            if key in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
                cur = self._view.currentIndex()
                if cur.isValid():
                    self._commit_index(cur)
                    return True
            text = event.text()
            if (text and text.isprintable()
                    and not (event.modifiers() & (Qt.ControlModifier
                                                  | Qt.AltModifier
                                                  | Qt.MetaModifier))):
                self._type_ahead(text)
                return True
        return super().eventFilter(obj, event)


class _GlassPopupCombo:
    """showPopup/hidePopup/wheel behaviour shared by SafeComboBox and
    SafeFontComboBox: the native popup is never used (V1.9.29)."""

    _font_mode = False

    def _init_glass_popup(self):
        self._glass_popup = None
        self._glass_closed_at = 0.0

    def wheelEvent(self, event):
        # Wheel over a closed combo never changes its value by accident
        # (standing rule since V1.9.10); with the popup open, the wheel
        # scrolls the popup's list instead of the page behind it.
        popup = getattr(self, "_glass_popup", None)
        if popup is not None and popup.isVisible():
            bar = popup._view.verticalScrollBar()
            if bar is not None:
                bar.setValue(bar.value() - event.angleDelta().y() // 4)
            event.accept()
        else:
            event.ignore()

    def showPopup(self):
        # Programmatic opens (keyboard, code) always open -- the
        # click-to-close toggle lives in mousePressEvent below.
        if self.count() == 0:
            return
        self.hidePopup()
        popup = _GlassComboPopup(self, font_mode=self._font_mode)
        self._glass_popup = popup
        popup.open_popup()

    def hidePopup(self):
        popup = getattr(self, "_glass_popup", None)
        if popup is not None:
            popup.close()

    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        # V1.9.35 (user: "if i click a drop down to open but click
        # it again it doesnt close like dropdowns normally do" --
        # global issue): Qt's press-to-toggle logic knows only its
        # native popup container, which V1.9.29 replaced with our
        # own, so a press on the open combo simply re-ran showPopup
        # and the list could never be clicked shut. Two orderings,
        # both handled here: the press reaches the combo while the
        # popup is open -> close it and consume the press; or the
        # Qt.Popup outside-press grab closes the popup FIRST and
        # the same press is then delivered here -> the close
        # timestamp (stamped in the popup's closeEvent) marks it as
        # the closing press, and it is swallowed instead of
        # reopening (~350ms, the standing house guard for popup
        # toggles). Programmatic showPopup calls never pass through
        # here, so code and keyboard opens are never eaten.
        if event.button() == Qt.LeftButton:
            popup = getattr(self, "_glass_popup", None)
            if popup is not None and popup.isVisible():
                self.hidePopup()
                event.accept()
                return
            if time.monotonic() - getattr(
                    self, "_glass_closed_at", 0.0) < 0.35:
                event.accept()
                return
        super().mousePressEvent(event)



class SafeComboBox(_GlassPopupCombo, QComboBox):
    """QComboBox that ignores the mouse wheel while its popup is
    closed — scrolling a form or window past a combo must never change
    its value by accident. (Upstream Qt passes wheel events to the
    combo's own handler, which both steps the value AND swallows the
    event so the page behind doesn't scroll; verified against real
    Windows behaviour in V1.9.0.) The wheel only works while the list
    is open, where it scrolls the list.

    V1.9.29: the dropdown is the owned glass popup (_GlassComboPopup)
    — rounded frosted glass by construction, replacing the native
    popup whose square container kept showing behind the rounded list
    on real Windows despite 1.9.25/1.9.27/1.9.28. Editable combos keep
    their line edit and completers unchanged; only the dropdown
    surface is ours now."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_glass_popup()


class SafeFontComboBox(_GlassPopupCombo, QFontComboBox):
    """QFontComboBox with the same wheel safety and the same owned
    glass popup as SafeComboBox (rows render in the font they name)."""

    _font_mode = True

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_glass_popup()



class SafeDateEdit(QDateEdit):
    """QDateEdit that ignores the mouse wheel while its calendar popup
    is closed.

    V1.9.16 (user report): the V1.9.10 wheel fix covered dropdowns
    only, so the reminder and due-date edits — plain QDateEdits with
    the same hover-scroll hazard — kept changing value under the
    wheel. Scrolling a quote's detail page with the cursor over the
    reminder field silently changed the reminder. The wheel now only
    works while the calendar popup is open; over a closed edit the
    event is ignored and the page keeps scrolling.
    """

    def wheelEvent(self, event):  # noqa: N802 (Qt virtual)
        cal = self.calendarWidget()
        if cal is not None and cal.isVisible():
            super().wheelEvent(event)
        else:
            event.ignore()


# ------------------------------------------------------- pure snap geometry
# Pure-Qt window snapping (see the winsnap module docstring for why the
# native approach was removed). These helpers are deliberately free of any
# Qt-widget state so they can be unit-tested headlessly.

SNAP_THRESHOLD = 8  # px from a screen edge that counts as "dragged to the edge"


def _snap_platform_ok():
    """Snap only engages on real display servers — never in headless tests,
    where synthetic mouse events carry meaningless global positions."""
    return QApplication.platformName() not in ("offscreen", "minimal")


def snap_action(screen_geom, cursor, threshold=SNAP_THRESHOLD):
    """What a title-bar drag released at ``cursor`` should do.

    ``screen_geom`` is the QRect of the screen under the cursor (global
    coords), ``cursor`` the global cursor QPoint. Returns "max", "left",
    "right", or None.
    """
    if screen_geom is None:
        return None
    if cursor.y() <= screen_geom.top() + threshold:
        return "max"
    if cursor.x() <= screen_geom.left() + threshold:
        return "left"
    if cursor.x() >= screen_geom.right() - threshold:
        return "right"
    return None


def snapped_rect(screen_geom, side):
    """Window geometry for a snapped window. Pure QRect math."""
    if screen_geom is None or side not in ("max", "left", "right"):
        return None
    if side == "max":
        return QRect(screen_geom.topLeft(), screen_geom.size())
    half = screen_geom.width() // 2
    if side == "left":
        return QRect(screen_geom.left(), screen_geom.top(), half,
                     screen_geom.height())
    return QRect(screen_geom.left() + half, screen_geom.top(),
                 screen_geom.width() - half, screen_geom.height())


# ------------------------------------------------------- small format helpers
def due_chip_info(due_iso, today=None):
    """(text, urgent) for a task's due-date chip. Pure and unit-testable."""
    try:
        due = date.fromisoformat((due_iso or "")[:10])
    except ValueError:
        return ("", False)
    today = today or date.today()
    delta = (due - today).days
    if delta < 0:
        return (f"Overdue {-delta}d", True)
    if delta == 0:
        return ("Due today", True)
    if delta <= 7:
        return (f"Due {due.strftime('%a')}", False)
    return (f"Due in {delta}d", False)


def due_this_week(due_date_iso, today=None):
    """True when a task is due within the next 7 days — or already overdue.

    Powers the queue's "Due this week" chip. Blank/unparseable dates never
    match. Pure date math, unit-testable.
    """
    try:
        due = date.fromisoformat((due_date_iso or "")[:10])
    except ValueError:
        return False
    today = today or date.today()
    return due <= today + timedelta(days=7)


class _EmptyDatePopupFilter(QObject):
    """Event filter on a QDateEdit's calendar popup.

    A clearable date edit keeps its empty state on the minimum date
    (year 1752). When the calendar popup opens while the edit is empty,
    navigate the popup to the current month/year so the user never sees
    1752 — the edit's value is left untouched.

    Also highlights today's date (v1.4.0 item 3): the app's custom
    calendar stylesheet suppressed QCalendarWidget's default today
    indicator, so it is re-applied here per-popup-show via
    setDateTextFormat (Qt has no QSS "today" selector). The highlight
    is theme-aware and deliberately distinct from the blue selection.
    """

    def __init__(self, date_edit, parent=None):
        super().__init__(parent)
        self._edit = date_edit

    def eventFilter(self, watched, event):
        if event.type() == QEvent.Show:
            edit = self._edit
            try:
                if edit is not None and edit.date() <= edit.minimumDate():
                    today = QDate.currentDate()
                    watched.setCurrentPage(today.year(), today.month())
                _highlight_today(watched)
                # V1.9.27: the calendar popup gets the same rounded
                # window mask as every other dropdown (mask only —
                # its themed solid background is untouched, so no
                # glass readability risk on the calendar grid).
                win = watched.window()
                if win is not None and win is not watched:
                    _rounded_mask(win)
                    if not win.property("_glass_mask_filter"):
                        win.installEventFilter(_PopupMaskFilter(win))
                        win.setProperty("_glass_mask_filter", True)
            except RuntimeError:
                pass  # edit already destroyed; nothing to do
        return super().eventFilter(watched, event)


def _highlight_today(calendar):
    """Visibly mark today's date in a QCalendarWidget popup.

    Called on every popup show so the highlight follows the live theme.
    When today is also the selected date, the selection paint wins —
    selected and today are never confused.
    """
    fmt = QTextCharFormat()
    if saved_theme() == "light":
        fmt.setBackground(QColor("#dbe4f3"))
        fmt.setForeground(QColor("#16233f"))
    else:  # dark: true-black surfaces, no blue tint
        fmt.setBackground(QColor("#333a45"))
        fmt.setForeground(QColor("#f4f5f7"))
    font = fmt.font()
    font.setBold(True)
    fmt.setFont(font)
    calendar.setDateTextFormat(QDate.currentDate(), fmt)


def hook_empty_date_popup(date_edit):
    """Make a clearable QDateEdit's popup open on today when empty.

    Safe for any QDateEdit with a calendar popup; edits that always hold
    a real date are unaffected (the filter only acts in the empty /
    minimum-date state).
    """
    cal = date_edit.calendarWidget()  # creates the popup calendar
    cal.installEventFilter(_EmptyDatePopupFilter(date_edit, cal))
    return date_edit


# ------------------------------------------------------------ IBC chip
# V1.9.52 (user): a chip like the SDC chip showing the IBC edition
# in force at the job location ("IBC 2021"), with a warning state
# when a VERIFIED edition switch lands inside the order's delivery
# horizon. The accuracy contract lives in building_codes.py: the
# chip never states an unverified edition.

def lead_time_settings(db):
    """(min_weeks, max_weeks) from Settings; defaults 20/22 (the
    user's current typical lead range). Never raises."""
    try:
        lo = int(db.get_setting("lead_min_weeks", "20"))
        hi = int(db.get_setting("lead_max_weeks", "22"))
    except Exception:
        lo, hi = 20, 22
    lo = min(max(lo, 1), 104)
    hi = min(max(hi, 1), 104)
    if hi < lo:
        lo, hi = hi, lo
    return lo, hi


def resolve_ibc_for_name(db, name):
    """(res, assessment) for an end-user name, mirroring the SDC
    chain: the linked CRM contact's city/state first, else the
    parsed field text. (None, None) when nothing resolves."""
    try:
        from . import building_codes as _bc
        from .seismic import parse_location as _parse_loc
    except Exception:
        return None, None
    name = (name or "").strip()
    city = state = None
    if name:
        try:
            contact = db.directory_get_by_name("customer", name)
        except Exception:
            contact = None
        if contact:
            city = (contact.get("city") or "").strip() or None
            state = (contact.get("state") or "").strip() or None
        if not state:
            city, state = _parse_loc(name)
    if not state:
        return None, None
    try:
        data_dir = None
        try:
            data_dir = str(db.path.parent)
        except Exception:
            data_dir = None
        data, _origin = _bc.load_dataset(data_dir)
        res = _bc.resolve_ibc(city, state, data)
        if res is None:
            return None, None
        lo, hi = lead_time_settings(db)
        return res, _bc.assess(res, lead_min_weeks=lo,
                               lead_max_weeks=hi)
    except Exception:
        return None, None


def _fmt_day_long(d):
    """date -> 'January 1, 2027' (portable; no %-d / %#d)."""
    try:
        return f"{d.strftime('%B')} {d.day}, {d.year}"
    except Exception:
        return str(d)


def _fmt_iso_long(iso):
    d = None
    try:
        from datetime import date as _date
        d = _date.fromisoformat((iso or "")[:10])
    except Exception:
        d = None
    return _fmt_day_long(d) if d else (iso or "")


class IbcChip(QPushButton):
    """The IBC chip: a chip-styled button (click opens the code
    panel). The alert icon appears ONLY in the flagged state."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ibcChip")
        self.setCursor(Qt.PointingHandCursor)
        self.setVisible(False)
        chip_font(self)
        self._res = None
        self._assess = None
        self.clicked.connect(self._open_panel)

    def set_ibc(self, res, assess):
        self._res = res
        self._assess = assess
        if res is None:
            self.setVisible(False)
            return
        from . import building_codes as _bc
        text = _bc.chip_text(res)
        if not text:
            self.setVisible(False)
            return
        flagged = bool(assess and assess.get("flag"))
        self.setText(text)
        self.setProperty("flag", "true" if flagged else "false")
        if flagged:
            self.setIcon(svg_icon("alert", "#e0a92e", 12))
        else:
            self.setIcon(QIcon())
        if res.get("level") == "local":
            self.setToolTip(
                "Building-code adoption is local here — click "
                "for what is verified")
        elif flagged:
            self.setToolTip(
                "Warning: the building code changes during this "
                "order's lead time — click for details")
        else:
            self.setToolTip("Building code at this location — "
                            "click for details")
        self.style().unpolish(self)
        self.style().polish(self)
        self.setVisible(True)

    def _open_panel(self):
        if self._res is not None:
            show_ibc_panel(self, self._res, self._assess)


def _ibc_panel_content(res, assess):
    """(title, [lines]) for the code panel — the foolproof
    wording. Every claim traces to the dataset row; scheduled
    changes are disclosed as not final; adopted-without-a-date
    (NC) is stated as exactly that."""
    from . import building_codes as _bc
    srow = res.get("state_row") or {}
    crow = res.get("county_row") or {}
    place = f"{res.get('city') or ''}, {res.get('state') or ''}"
    if res.get("county"):
        place += f" — {res['county']}"
    if res.get("level") == "local":
        lines = [
            f"Building-code adoption is local in "
            f"{res.get('state') or 'this state'} — there is no "
            f"single statewide edition to show for {place}."]
        if srow.get("note"):
            lines.append(srow["note"])
        lines.append(
            "No edition is shown rather than guessed. Confirm "
            "the edition with the local building department.")
        if srow.get("source"):
            lines.append(
                f"Source: {srow['source']}. Verified "
                f"{_fmt_iso_long(srow.get('verified'))}.")
        return (f"Building code — {place}", lines)
    ed = srow.get("edition")
    name = srow.get("name") or "State building code"
    cur = (f"Current: {name} — IBC {ed} "
           f"(in effect since {_fmt_iso_long(srow.get('since'))})."
           if srow.get("since") else
           f"Current: {name} — IBC {ed}.")
    lines = [cur]
    nxt = (assess or {}).get("switch") or srow.get("next") or {}
    if nxt:
        nname = nxt.get("name") or name
        if nxt.get("status") == "adopted" and nxt.get("effective"):
            lines.append(
                f"Next: {nname} — IBC {nxt.get('edition')}, "
                f"effective {_fmt_iso_long(nxt.get('effective'))} "
                f"(formally adopted).")
        elif nxt.get("status") == "adopted":
            lines.append(
                f"Adopted, date not set: {nname} — IBC "
                f"{nxt.get('edition')}. It has been formally "
                f"adopted but no effective date exists yet.")
        else:
            lines.append(
                f"Announced, not final: {nname} — IBC "
                f"{nxt.get('edition')}, scheduled for "
                f"{_fmt_iso_long(nxt.get('effective'))}. The "
                f"adopting rule was not final when this data "
                f"was verified — treat the date as unconfirmed.")
    if assess and assess.get("flag"):
        a = assess
        lines.append(
            f"Orders placed today arrive in "
            f"{_fmt_day_long(a['arrival_start'])} – "
            f"{_fmt_day_long(a['arrival_end'])} at the current "
            f"lead times.")
        if a.get("switch_before_window"):
            lines.append(
                "The new code takes effect BEFORE this order "
                "would arrive — it will be received under the "
                f"IBC {nxt.get('edition')} code.")
        else:
            lines.append(
                "The new code takes effect INSIDE that window — "
                "this order may be received under the "
                f"IBC {nxt.get('edition')} code.")
    note = crow.get("note") or srow.get("note")
    if note:
        lines.append(note)
    src = crow.get("source") or srow.get("source")
    ver = crow.get("verified") or srow.get("verified")
    if src:
        lines.append(f"Source: {src}. Verified "
                     f"{_fmt_iso_long(ver)}.")
    title = ("Warning: building code change during this order's "
             "lead time" if (assess and assess.get("flag"))
             else f"Building code — {place}")
    return (title, lines)


def show_ibc_panel(parent, res, assess):
    """The IBC detail panel (app chrome, glass family)."""
    title, lines = _ibc_panel_content(res, assess)
    dlg, layout = _app_dialog(parent, title)
    for line in lines:
        _app_dialog_text(layout, line)
    _app_dialog_buttons(layout, dlg, [
        ("Close", "primary", dlg.accept, True)])
    dlg.exec()


def ibc_warning_toast_text(res, assess):
    """(title, text) for the auto-popup toast on a flagged task."""
    srow = res.get("state_row") or {}
    nxt = (assess or {}).get("switch") or {}
    place = f"{res.get('city') or ''}, {res.get('state') or ''}"
    title = "Building code change during lead time"
    text = (f"{place}: IBC {srow.get('edition')} → IBC "
            f"{nxt.get('edition')} on "
            f"{_fmt_iso_long(nxt.get('effective'))}. Orders "
            f"placed now arrive "
            f"{_fmt_day_long(assess['arrival_start'])} – "
            f"{_fmt_day_long(assess['arrival_end'])} — this "
            f"order will be received under the new code.")
    return title, text


def _outcome_row_background(outcome, dark):
    """V1.9.34 (user): list-row wash per outcome -- green won, red
    lost, yellow on hold, gray dead; None leaves the row plain.
    Translucent over the table's own base so both themes keep
    their character and the text stays readable."""
    if outcome == "won":
        return (QColor(52, 168, 96, 46) if dark
                else QColor(34, 139, 76, 40))
    if outcome == "lost":
        return (QColor(214, 69, 69, 44) if dark
                else QColor(198, 48, 48, 36))
    if outcome == "on_hold":
        return (QColor(224, 178, 44, 42) if dark
                else QColor(190, 145, 20, 42))
    if outcome == "dead":
        return (QColor(148, 152, 160, 38) if dark
                else QColor(110, 114, 122, 40))
    return None


def follow_up_due(task, today=None):
    """True when a task's follow-up reminder is due.

    remind_at <= today and the task is still open (in_process/on_hold).
    Blank/unparseable dates never match. Pure logic, unit-testable.
    """
    try:
        remind = date.fromisoformat((task.get("remind_at") or "")[:10])
    except ValueError:
        return False
    today = today or date.today()
    return remind <= today and task.get("status") in ("in_process", "on_hold")


def short_date(iso_date):
    """'2026-09-20' -> '09/20/2026' — the global display format
    (Month/Day/Year) the user set as the standard in V1.9.30."""
    try:
        d = date.fromisoformat((iso_date or "")[:10])
    except ValueError:
        return iso_date or "—"
    return d.strftime("%m/%d/%Y")


def fmt_date_mdy(iso):
    """'09/28/2026' from an ISO date/datetime string; '' when invalid."""
    try:
        return date.fromisoformat((iso or "")[:10]).strftime("%m/%d/%Y")
    except ValueError:
        return ""


# ------------------------------------------------------- "/" search shortcut
def slash_search_target(queue_visible, queue_search, main_search):
    """Which search box a bare '/' press should focus.

    Queue page visible -> the queue's filter field; otherwise the main
    task-list search. Pure logic so the context rule is unit-testable.
    """
    return queue_search if queue_visible else main_search


def focus_in_editable_widget():
    """True when keyboard focus sits inside a text-editing widget.

    Used to suppress the '/' shortcut while the user is typing, so a '/'
    typed into a field lands in the field.
    """
    w = QApplication.focusWidget()
    while w is not None:
        if isinstance(w, (QLineEdit, QTextEdit, QComboBox)):
            return True
        w = w.parentWidget()
    return False


class SearchSlashFilter(QObject):
    """Bare '/' focuses the context-appropriate search box.

    Installed on the main window. The target callback decides which search
    gets focus (queue filter when the queue page is visible, the main
    search otherwise). Never fires while focus is inside an editable
    widget, so typing '/' in text fields keeps working. Esc is untouched.
    """

    def __init__(self, target_fn, parent=None):
        super().__init__(parent)
        self._target_fn = target_fn

    def eventFilter(self, obj, event):
        if (event.type() == QEvent.KeyPress
                and event.key() == Qt.Key_Slash
                and event.modifiers() == Qt.NoModifier
                and not focus_in_editable_widget()):
            target = self._target_fn()
            if isinstance(target, QWidget):
                target.setFocus(Qt.ShortcutFocusReason)
                if isinstance(target, QLineEdit):
                    target.selectAll()
                return True
        return super().eventFilter(obj, event)


def format_hours(value):
    """'2.5h' style estimate text, '' when unset."""
    if value is None:
        return ""
    try:
        return f"{float(value):g}h"
    except (TypeError, ValueError):
        return ""


def format_price(value):
    """'$1,500.00' style price text, '' when unset."""
    if value is None:
        return ""
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return ""


def esc_plain(text):
    """Escape user data for plain QLabel/QPushButton text.

    Qt treats ``&`` as a mnemonic marker, so "S&S Activewear" would
    render as "SS" with an underlined S. Doubling the ampersand shows
    a literal ``&``. For RichText labels use esc_html() instead --
    ``&&`` would render literally there.
    """
    return str(text).replace("&", "&&")


def esc_html(text):
    """Escape user data for Qt.RichText labels (``&`` -> ``&amp;`` etc.)."""
    return html.escape(str(text), quote=False)


def format_activity_time(iso):
    """'Sep 23, 14:05' from an ISO datetime string."""
    try:
        dt = datetime.fromisoformat(iso)
    except (TypeError, ValueError):
        return (iso or "")[:16].replace("T", " ")
    return dt.strftime("%m/%d/%Y, %I:%M %p")


def format_iso_day(iso):
    """'09/20/2026' from an ISO date/datetime string (global format)."""
    return fmt_date_mdy(iso)


# ------------------------------------------------------- thumbnail cache (§4.2)
_thumb_cache = {}
_THUMB_CACHE_MAX = 256


def _cached_thumbnail(path):
    """112px thumbnail icon cached by path+mtime (regenerated on change)."""
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return None
    key = (str(path), mtime)
    icon = _thumb_cache.get(key)
    if icon is None:
        # V1.9.48: decode through QImageReader at thumbnail
        # scale instead of a full-size QPixmap -- a 20,000px or
        # malformed image made the codec allocate/decode the
        # whole thing for a 112px icon (native-code risk and
        # memory spike in the same class as the file-picker
        # crash). Scaled decode bounds both.
        reader = QImageReader(str(path))
        if not reader.canRead():
            return None
        _src_size = reader.size()
        if _src_size.isValid() and (_src_size.width() > 112
                                    or _src_size.height() > 112):
            reader.setScaledSize(_src_size.scaled(
                112, 112, Qt.KeepAspectRatio))
        _img = reader.read()
        if _img.isNull():
            return None
        icon = QIcon(QPixmap.fromImage(_img))
        if len(_thumb_cache) >= _THUMB_CACHE_MAX:
            _thumb_cache.clear()
        _thumb_cache[key] = icon
    return icon


# ------------------------------------------------------- startup maintenance
def sweep_staging_dirs():
    """Delete tasklist_stage_* temp dirs older than a day (crash orphans)."""
    tmp = Path(tempfile.gettempdir())
    cutoff = time.time() - 86400
    for d in tmp.glob("tasklist_stage_*"):
        try:
            if d.is_dir() and d.stat().st_mtime < cutoff:
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


def verify_attachments(db):
    """Attachment integrity sweep.

    Returns (missing, orphans): DB attachment records whose file is gone,
    and files on disk under attachments/ with no DB record.
    """
    root = attachments_root(db)
    records = {}  # (task_id, stored) -> record
    missing = []
    try:
        tasks = db.list_tasks(view="all")
    except Exception:
        return [], []
    for task in tasks:
        tid = task["id"]
        try:
            atts = db.list_attachments(tid)
        except Exception:
            continue
        for att in atts:
            stored = att.get("stored")
            records[(tid, stored)] = att
            if not (root / str(tid) / (stored or "")).is_file():
                missing.append({
                    "task_id": tid, "id": att.get("id"),
                    "filename": att.get("filename"), "stored": stored,
                })
    orphans = []
    if root.is_dir():
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            try:
                tid = int(p.parent.name)
            except ValueError:
                orphans.append(p)
                continue
            if (tid, p.name) not in records:
                orphans.append(p)
    return missing, orphans


def cleanup_attachments(db, missing, orphans):
    """Remove missing-file DB records and delete orphaned files. Returns
    (records_removed, files_deleted)."""
    removed = 0
    for rec in missing:
        try:
            if rec.get("id") is not None:
                db.delete_attachment(rec["id"])
                removed += 1
        except Exception:
            pass
    deleted = 0
    for p in orphans:
        try:
            p.unlink()
            deleted += 1
        except OSError:
            pass
    return removed, deleted


def queue_columns_normalized(db):
    """[[key, label], ...] for the queue board, falling back to defaults."""
    try:
        cols = db.get_queue_columns()
    except Exception:
        cols = None
    cleaned = []
    if cols:
        for c in cols:
            if isinstance(c, (list, tuple)) and len(c) == 2:
                cleaned.append([str(c[0]), str(c[1])])
    return cleaned or [list(c) for c in QUEUE_COLUMNS]


# ------------------------------------------------------- price-on-complete (§B)
class PriceDialog(QDialog):
    """Small themed prompt: 'Quote price for 26-1111?' + amount + Save/Skip."""

    def __init__(self, parent=None, quote_number=""):
        super().__init__(parent)
        self.setModal(True)
        self.setMinimumWidth(360)
        layout = install_chrome(self, "Quote Price")

        title = QLabel(f"Quote price for {quote_number}?" if quote_number
                       else "Quote price?")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)
        hint = QLabel("Record what this quote was worth. Skip if you don't "
                      "track value for this one.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self._edit = QLineEdit()
        self._edit.setPlaceholderText("e.g. 1500.00")
        self._edit.setValidator(QDoubleValidator(0.0, 1e12, 2, self._edit))
        layout.addWidget(self._edit)
        layout.addStretch(1)

        row = QHBoxLayout()
        row.addStretch(1)
        skip_btn = QPushButton("Skip")
        skip_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save")
        save_btn.setObjectName("primary")
        save_btn.setDefault(True)
        save_btn.clicked.connect(self._on_save)
        row.addWidget(skip_btn)
        row.addWidget(save_btn)
        _equalize_button_heights([skip_btn, save_btn])
        layout.addLayout(row)
        self._edit.setFocus()

    def _on_save(self):
        if self.value() is None:
            show_toast(self, "warning", "Quote price",
                       "Enter an amount, or Skip.")
            self._edit.setFocus()
            return
        self.accept()

    def value(self):
        text = self._edit.text().strip().replace(",", "")
        try:
            return float(text) if text else None
        except ValueError:
            return None


# --------------------------------- freight / lead-time scope details (V1.9.5)
class ScopeInfoDialog(QDialog):
    """Small themed prompt for freight / lead-time scope details.

    Shown when the matching scope step is checked off; existing values are
    pre-filled so re-checking a step edits rather than wipes. Save returns
    the field dict, Cancel/Skip returns None (previous values kept).
    """

    def __init__(self, parent, title, subtitle, fields, existing):
        # fields: [(key, label, placeholder, numeric)]
        super().__init__(parent)
        self.setModal(True)
        self.setMinimumWidth(380)
        layout = install_chrome(self, title)

        head = QLabel(subtitle)
        head.setObjectName("dialogTitle")
        layout.addWidget(head)
        hint = QLabel("Saved on this task — hover the scope chip to review.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self._edits = {}
        for key, label, placeholder, numeric in fields:
            lab = QLabel(label)
            lab.setObjectName("fieldLabel")
            layout.addWidget(lab)
            edit = QLineEdit()
            edit.setText(str(existing.get(key, "")))
            edit.setPlaceholderText(placeholder)
            if numeric:
                edit.setValidator(QIntValidator(0, 999999, edit))
            layout.addWidget(edit)
            self._edits[key] = edit
        layout.addStretch(1)

        row = QHBoxLayout()
        row.addStretch(1)
        skip_btn = QPushButton("Skip")
        skip_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save")
        save_btn.setObjectName("primary")
        save_btn.setDefault(True)
        save_btn.clicked.connect(self.accept)
        row.addWidget(skip_btn)
        row.addWidget(save_btn)
        _equalize_button_heights([skip_btn, save_btn])
        layout.addLayout(row)
        first = next(iter(self._edits.values()), None)
        if first is not None:
            first.setFocus()

    def values(self):
        return {k: e.text().strip() for k, e in self._edits.items()}


def _scope_info_json(raw):
    try:
        data = json.loads(raw or "")
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def prompt_freight_info(parent, existing):
    """Ask for freight details. Returns dict or None when skipped."""
    dlg = ScopeInfoDialog(
        parent, "Freight Details", "Freight checked off — record the details:",
        [("cost_per_truck", "Est. Cost per Truck", "e.g. 1450.00", False),
         ("num_trucks", "Est. Number of Trucks", "e.g. 3", True)],
        existing)
    if dlg.exec() != QDialog.Accepted:
        return None
    return dlg.values()


def prompt_leadtime_info(parent, existing):
    """Ask for lead-time details. Returns dict or None when skipped."""
    dlg = ScopeInfoDialog(
        parent, "Lead-Time Details", "Lead-Time checked off — record the details:",
        [("weeks", "Weeks", "e.g. 14-16", False),
         ("ship_weeks", "Shipping duration (weeks)", "e.g. 2", True)],
        existing)
    if dlg.exec() != QDialog.Accepted:
        return None
    return dlg.values()


def maybe_prompt_scope_info(parent, db, task_id, scope):
    """V1.9.5: when the Freight / Lead-Time scope step is checked off, prompt
    for its details and store them on the task. No-op for other steps."""
    key = (scope or "").strip().lower()
    task = db.get_task(task_id)
    if not task:
        return
    if key == "freight":
        result = prompt_freight_info(parent, _scope_info_json(task.get("freight_info")))
        if result is not None:
            db.set_freight_info(task_id, json.dumps(result))
            db.log_activity(task_id, "scope",
                            f"Freight details: ${result.get('cost_per_truck') or '—'} x "
                            f"{result.get('num_trucks') or '—'} trucks")
    elif key in ("lead-time", "lead time"):
        result = prompt_leadtime_info(parent, _scope_info_json(task.get("leadtime_info")))
        if result is not None:
            db.set_leadtime_info(task_id, json.dumps(result))
            db.log_activity(task_id, "scope",
                            f"Lead-Time details: {result.get('weeks') or '—'} weeks, "
                            f"ships in {result.get('ship_weeks') or '—'} weeks")


def scope_info_tooltip(scope, task):
    """V1.9.5: hover text for Freight / Lead-Time chips showing saved details.

    V1.9.12: the tooltip is the card's freight/lead-time display now that
    the pill row is gone. V1.9.16: the card shows lead-time only and
    the freight cost + truck count, cleanly — no shipping on the card,
    no computed lead-time total anywhere.
    """
    key = (scope or "").strip().lower()
    if key == "freight":
        # V1.9.16: the card's freight line is the clean cost + trucks
        # summary (same string as the detail window): per-truck cost,
        # truck count, and total — no raw unformatted values.
        return freight_card_text(task)
    elif key in ("lead-time", "lead time"):
        info = _scope_info_json((task or {}).get("leadtime_info"))
        if info.get("weeks"):
            # V1.9.16: the card shows lead-time ONLY. Shipping duration
            # is not on the card at all (it lives on the opened quote),
            # and no total is computed from it.
            lines = ["Lead-Time",
                     f"Weeks: {info.get('weeks') or '—'}"]
            return "\n".join(lines)
    return None


# ------------------------------------------- freight / lead-time display math
# V1.9.10: the details recorded by the Freight / Lead-Time prompts were
# previously visible only as a hover tooltip. These pure helpers turn the
# stored strings into card/dashboard display values and aggregates. They
# never raise: unparseable input yields None and the UI falls back to the
# raw text (or hides the metric).

def parse_money_value(raw):
    """Parse a stored money string ('1450', '$1,450.00') to float or None."""
    if raw is None:
        return None
    text = str(raw).strip().replace("$", "").replace(",", "")
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def parse_count_value(raw):
    """Parse a stored count string ('3') to int or None."""
    if raw is None:
        return None
    text = str(raw).strip().replace(",", "")
    if not text:
        return None
    try:
        return int(float(text))
    except ValueError:
        return None


def parse_week_range(raw):
    """Parse a weeks string to (low, high) floats or None.

    '14-16' -> (14.0, 16.0); '14' -> (14.0, 14.0); '14 - 16 wks' works too.
    A reversed range is normalised. Anything without exactly 1-2 numbers
    yields None.
    """
    if raw is None:
        return None
    nums = re.findall(r"\d+(?:\.\d+)?", str(raw))
    if len(nums) == 1:
        v = float(nums[0])
        return (v, v)
    if len(nums) == 2:
        a, b = float(nums[0]), float(nums[1])
        return (min(a, b), max(a, b))
    return None


def _fmt_num(v):
    """Format a float compactly: 14.0 -> '14', 14.5 -> '14.5'."""
    if v is None:
        return "—"
    if float(v) == int(v):
        return str(int(v))
    return f"{float(v):.1f}"


def format_week_range(rng):
    """(14, 16) -> '14–16'; (14, 14) -> '14'; None -> '—'."""
    if not rng:
        return "—"
    low, high = rng
    if low == high:
        return _fmt_num(low)
    return f"{_fmt_num(low)}–{_fmt_num(high)}"


def format_money_value(v):
    """1450.0 -> '$1,450'; 1450.5 -> '$1,450.50'; None -> '—'."""
    if v is None:
        return "—"
    if float(v) == int(v):
        return f"${int(v):,}"
    return f"${float(v):,.2f}"


def freight_total(task):
    """Estimated total freight for a task (cost/truck x trucks) or None."""
    info = _scope_info_json((task or {}).get("freight_info"))
    cost = parse_money_value(info.get("cost_per_truck"))
    trucks = parse_count_value(info.get("num_trucks"))
    if cost is None or trucks is None:
        return None
    return cost * trucks


def freight_card_text(task):
    """One-line freight summary for a card, or None when nothing recorded.

    '$1,450 × 3 trucks · $4,350 total' when both values parse; degrades to
    whichever part is known.
    """
    info = _scope_info_json((task or {}).get("freight_info"))
    cost_raw = str(info.get("cost_per_truck") or "").strip()
    trucks_raw = str(info.get("num_trucks") or "").strip()
    if not cost_raw and not trucks_raw:
        return None
    cost = parse_money_value(cost_raw)
    trucks = parse_count_value(trucks_raw)
    parts = []
    if cost is not None and trucks is not None:
        parts.append(f"{format_money_value(cost)} × {trucks} truck"
                     f"{'s' if trucks != 1 else ''}")
        parts.append(f"{format_money_value(cost * trucks)} total")
    elif cost is not None:
        parts.append(f"{format_money_value(cost)} per truck")
        if trucks_raw:
            parts.append(f"{trucks_raw} trucks")
    elif trucks is not None:
        parts.append(f"{trucks} truck{'s' if trucks != 1 else ''}")
        if cost_raw:
            parts.append(f"{cost_raw} per truck")
    else:
        parts.append(f"{cost_raw} per truck × {trucks_raw} trucks")
    return "Freight: " + " · ".join(parts)


def leadtime_card_text(task):
    """One-line lead-time summary, or None when nothing recorded.

    V1.9.16: the recorded lead-time range ONLY. Shipping is a separate
    fact (see leadtime_ship_text, shown on its own line in the detail
    window) and is never added to the lead time: no summed total
    exists in the recorded data, and none is shown. (V1.9.10–V1.9.15
    computed 'lead + shipping' totals here; that addition was never
    ordered and is removed.)
    """
    info = _scope_info_json((task or {}).get("leadtime_info"))
    weeks_raw = str(info.get("weeks") or "").strip()
    if not weeks_raw:
        return None
    rng = parse_week_range(weeks_raw)
    if rng:
        return "Lead time: " + format_week_range(rng) + " wks"
    return "Lead time: " + weeks_raw + " wks"


def leadtime_ship_text(task):
    """The recorded shipping duration as its own line, or None.

    Shown only in the opened quote's detail block, never on the card,
    and never combined with the lead time."""
    info = _scope_info_json((task or {}).get("leadtime_info"))
    ship_raw = str(info.get("ship_weeks") or "").strip()
    if not ship_raw:
        return None
    ship = parse_week_range(ship_raw)
    if ship:
        return "Shipping duration: " + _fmt_num(ship[1]) + " wks"
    return "Shipping duration: " + ship_raw + " wks"


def maybe_ask_price(parent, db, task_id):
    """Price-on-complete flow: if the setting is on and the task has no
    quote value yet, ask for it. Returns True when a price was saved."""
    try:
        if db.get_setting("ask_price_on_complete", "1") != "1":
            return False
    except Exception:
        return False
    task = db.get_task(task_id)
    if not task or task.get("quote_value") not in (None, ""):
        return False
    dlg = PriceDialog(parent, task.get("quote_number", ""))
    if dlg.exec() != QDialog.Accepted:
        return False
    value = dlg.value()
    if value is None:
        return False
    db.set_quote_value(task_id, value)
    db.log_activity(task_id, "price", f"Quote price set: {format_price(value)}")
    return True


# ------------------------------------------------------- on-hold reason (§1.10)
class HoldReasonDialog(QDialog):
    """Ask why a task is going on hold. The reason lands in the task notes."""

    def __init__(self, parent=None, quote_number=""):
        super().__init__(parent)
        self.setModal(True)
        self.setMinimumWidth(400)
        title = f"On Hold {quote_number}" if quote_number else "On Hold"
        layout = install_chrome(self, title, show_max=False)

        lab = QLabel("Why is this task going on hold?")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        self._edit = QLineEdit()
        self._edit.setPlaceholderText("Reason for the hold… (optional)")
        layout.addWidget(self._edit)
        hint = QLabel("This will be added to the task notes as *On hold:* …")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addStretch(1)

        row = QHBoxLayout()
        row.addStretch(1)
        keep_btn = QPushButton("Keep Working")
        keep_btn.clicked.connect(self.reject)
        hold_btn = QPushButton("Put On Hold")
        hold_btn.setObjectName("primary")
        hold_btn.setDefault(True)
        hold_btn.clicked.connect(self.accept)
        row.addWidget(keep_btn)
        row.addWidget(hold_btn)
        _equalize_button_heights([keep_btn, hold_btn])
        layout.addLayout(row)
        self._edit.setFocus()

    def reason(self):
        return self._edit.text().strip()


def confirm_hold_with_reason(parent, db, task_id):
    """Mirror of confirm_cancel_with_reason for the On Hold status.

    Returns True when the task was put on hold, False when the user backed
    out (caller should revert any optimistic UI change).
    """
    task = db.get_task(task_id)
    dlg = HoldReasonDialog(parent, task["quote_number"] if task else "")
    if dlg.exec() != QDialog.Accepted:
        return False
    reason = dlg.reason()
    db.set_status(task_id, "on_hold")
    if reason:
        db.append_note(task_id, f"*On hold:* {reason}")
    db.log_activity(task_id, "hold",
                    f"On hold: {reason}" if reason else "Put on hold")
    return True


def scope_key(scope):
    return scope.lower().replace(" ", "-")


# Scopes with a dedicated pill color; anything else gets a stable generic one.
SCOPE_CHIP_KNOWN = {"quote", "re-quote", "cad", "configura", "prelims", "misc"}


def scope_chip_key(scope):
    """QSS key for a scope chip. Custom scopes hash to custom-0..3 so every
    scope of work renders as a pill, with a consistent color per name."""
    key = scope_key(scope)
    if key in SCOPE_CHIP_KNOWN:
        return key
    return f"custom-{zlib.crc32(key.encode('utf-8')) % 4}"


def is_image_file(filename):
    return Path(filename).suffix.lower() in IMAGE_EXTS


def attachments_root(db):
    return db.path.parent / "attachments"


def task_attachments_dir(db, task_id):
    d = attachments_root(db) / str(task_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


_TAB_SCRIPT_TIMEOUT_S = 35


def _tab_script_path():
    """Bundled PowerShell opener: new tab in the open Explorer window."""
    return os.path.join(os.path.dirname(__file__), "open_in_tab.ps1")


def _launch_tab_script(path_str):
    """Start open_in_tab.ps1 detached (no console window).

    Returns the Popen handle, or None when PowerShell/the script could not
    be started at all (missing powershell.exe, missing .ps1, spawn error).
    stderr is piped so _tab_script_outcome can log the script's failure
    reason (v1.4.0 item 7 diagnostics).
    """
    script = _tab_script_path()
    if not os.path.isfile(script):
        log_startup_event(f"open-folder: tab script missing, fallback ({path_str})")
        return None
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        proc = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-File", script, path_str],
            creationflags=flags,
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        log_startup_event(f"open-folder: tab script launched ({path_str})")
        return proc
    except Exception as e:
        log_startup_event(f"open-folder: tab script spawn failed ({e}), fallback")
        return None


def _open_folder_fallback(path_str):
    """explorer.exe (detached) then QDesktopServices.openUrl. Never raises."""
    log_startup_event(f"open-folder: FALLBACK new window ({path_str})")
    try:
        # (getattr fallbacks: these constants only exist in subprocess
        # on Windows; the literal values keep this branch testable off
        # Windows, where sys.platform is patched.)
        flags = (getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
                 | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
        subprocess.Popen(["explorer.exe", path_str], creationflags=flags)
        return
    except Exception:
        pass
    try:
        QDesktopServices.openUrl(QUrl.fromLocalFile(path_str))
    except Exception:
        pass


def _tab_script_outcome(proc, path_str):
    """Wait for the tab script, then run the fallback chain unless it exited 0.

    Exit 0 means the folder opened in a new tab: done. Exit 2 means no
    Explorer window was open; exit 1 (or a timeout/kill) means the attempt
    failed: either way the explorer.exe -> openUrl fallback runs.
    The script's stderr failure reason is written to the log (v1.4.0
    item 7) so a real-Windows failure names its failing step.
    Runs off the UI thread. Never raises.
    """
    try:
        rc = proc.wait(timeout=_TAB_SCRIPT_TIMEOUT_S)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
        rc = -1
    err = ""
    try:
        raw = proc.stderr.read() if proc.stderr else b""
        err = (raw or b"").decode("utf-8", "replace").strip()
    except Exception:
        pass
    if rc == 0:
        log_startup_event(f"open-folder: NEW TAB ok ({path_str})")
    else:
        reason = err.splitlines()[-1][:200] if err else (
            "no Explorer open" if rc == 2 else "failed/timeout")
        log_startup_event(f"open-folder: tab script rc={rc} ({reason}), fallback")
        _open_folder_fallback(path_str)


def open_folder(path):
    """Open a folder in the system file explorer. Returns True on success.

    On Windows the folder is opened as a NEW TAB in the already-open
    Explorer window via the bundled ``open_in_tab.ps1`` (COM tab
    enumeration + WM_COMMAND 0xA21B), launched detached off the UI thread
    so the interface never blocks. When no Explorer window is open, the
    script fails, or PowerShell is unavailable, it falls back to
    ``explorer.exe <path>`` and then QDesktopServices.openUrl. Everywhere
    else the existing QDesktopServices.openUrl behavior is kept.
    """
    p = Path(path) if path else None
    if not (p and p.is_dir()):
        # V1.9.50: the live folder is unreachable (offline) --
        # open its cached copy if the folder cache has one.
        try:
            from tasklist import foldercache as _fc
            _cached = _fc.resolve_folder(path)
        except Exception:
            _cached = None
        if _cached is None:
            return False
        p = _cached
    else:
        # Connected open of a folder under a cache root: keep
        # its cached copy fresh in the background.
        try:
            from tasklist import foldercache as _fc2
            from tasklist import datahome as _dh
            _cfg = _dh.read_cache_config()
            if _cfg.get("enabled", True) and _fc2._under_roots(
                    p, _cfg.get("roots") or []):
                threading.Thread(target=_fc2.cache_folder,
                                 args=(str(p),), daemon=True).start()
        except Exception:
            pass
    if sys.platform == "win32":
        try:
            proc = _launch_tab_script(str(p))
        except Exception:
            proc = None
        if proc is None:
            _open_folder_fallback(str(p))
        else:
            threading.Thread(target=_tab_script_outcome,
                             args=(proc, str(p)),
                             daemon=True).start()
        return True
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))
    return True


# ------------------------------------------------------- automatic quote folders
# Shared flow used by new-task save, the detail-window "Create folder"
# button, Settings "Retry now", and startup queue processing.
#
# HARD RULES (never relax these):
# - Task creation/saving is never blocked by folder work.
# - SMB reachability checks run OFF the UI thread.
# - SQLite writes happen ONLY on the main thread.
# - folder_path is set ONLY when the folder truly exists (created, or
#   "use existing"). Queued items get linked at processing time, never a
#   phantom path.

FOLDER_USE = "use"
FOLDER_DUPLICATE = "duplicate"
FOLDER_CANCEL = "cancel"


def folder_creation_enabled(db):
    """Master toggle for automatic quote folder creation (Settings)."""
    try:
        return db.get_setting("folder_creation_enabled", "0") == "1"
    except Exception:
        return False


def _folders_module():
    """Lazy import so the data-layer module is only needed when the flow runs."""
    from tasklist import folders as folders_mod
    return folders_mod


def quote_folder_name_for(db, task):
    """Build the folder name for a task via the data-layer contract.

    ``task`` is a mapping with quote_number / distributor / end_user /
    created_at; the task's created date is passed through as a datetime.date.
    """
    folders_mod = _folders_module()
    created = str(task.get("created_at") or "")[:10]
    try:
        created_date = date.fromisoformat(created)
    except ValueError:
        created_date = date.today()
    initials = (db.get_setting("folder_initials", "") or "").strip()
    return folders_mod.build_quote_folder_name(
        task.get("quote_number") or "",
        task.get("distributor") or "",
        task.get("end_user") or "",
        created_date,
        initials,
    )


def log_folder_activity(db, task_id, detail):
    """Activity-log a folder event. Never raises: the contract kind may not
    exist yet in db.ACTIVITY_KINDS (data worker adds it), so fall back to a
    safe built-in kind instead of breaking the flow."""
    for kind in ("quote_folder", "note"):
        try:
            db.log_activity(task_id, kind, detail)
            return
        except ValueError:
            continue  # unknown kind — try the next one
        except Exception:
            return  # never let logging break the folder flow


def show_notice(parent, title, text, warning=False):
    """Deprecated compatibility shim: the old non-modal QMessageBox popup.

    Kept so any straggler call sites keep working; it now shows a
    bottom-edge toast instead of a message box. New code should call
    ``show_toast(parent, kind, title, text)`` directly with one of the
    toast kinds ("success" | "info" | "warning" | "error").
    """
    return show_toast(parent, "warning" if warning else "info",
                      title, text)


# ------------------------------------------------- app dialog family ----
# V1.9.31: stock Qt dialogs (QMessageBox / QInputDialog / QColorDialog)
# carry a native window frame — square corners, foreign title bar —
# and the user has (loudly, repeatedly) required the app's own chrome
# and rounded corners GLOBALLY. Every prompt in the app goes through
# these helpers: same questions, same answers, install_chrome dialogs.

def _app_dialog(parent, title):
    dlg = QDialog(parent)
    dlg.setAttribute(Qt.WA_DeleteOnClose)
    layout = install_chrome(dlg, title)
    return dlg, layout


def _equalize_button_heights(buttons):
    """Force ONE height across a dialog button row (V1.9.35).

    #primary is padded 9px with a heavier font while #ghost,
    #danger and plain buttons are padded less, so every row that
    paired them showed two different heights (user, on the update
    prompt: "Later" shorter than "Restart now" -- "THINGS MUST
    LOOK GREAT EVERYWHERE WITHOUT SLOP LIKE THAT"). Each button
    takes the row's tallest natural height. Scoped to dialog
    button rows: the small #ghost utility buttons in toolbars
    (PDF viewer etc.) keep their own size.
    """
    btns = [b for b in buttons if b is not None]
    if len(btns) < 2:
        return
    h = max(b.sizeHint().height() for b in btns)
    if h > 0:
        for b in btns:
            b.setFixedHeight(h)


def _app_dialog_buttons(layout, dlg, specs):
    """specs: [(label, objectName, callback, is_default)]."""
    row = QHBoxLayout()
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(8)
    row.addStretch(1)
    btns = []
    for label, objname, callback, is_default in specs:
        btn = QPushButton(label)
        btn.setObjectName(objname)
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(callback)
        if is_default:
            btn.setDefault(True)
        row.addWidget(btn)
        btns.append(btn)
    _equalize_button_heights(btns)
    layout.addLayout(row)
    return row


def _app_dialog_text(layout, text, rich=False):
    lab = QLabel(text)
    lab.setObjectName("dialogText")
    lab.setWordWrap(True)
    if rich:
        lab.setTextFormat(Qt.RichText)
    layout.addWidget(lab)
    return lab


def app_confirm(parent, title, text, confirm_label="Yes",
                cancel_label="No", danger=False, informative=None):
    """Yes/No question in app chrome. Returns True for the confirm."""
    dlg, layout = _app_dialog(parent, title)
    _app_dialog_text(layout, text)
    if informative:
        sub = QLabel(informative)
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)
    _app_dialog_buttons(layout, dlg, [
        (cancel_label, "ghost", dlg.reject, False),
        (confirm_label, "danger" if danger else "primary",
         dlg.accept, True),
    ])
    return dlg.exec() == QDialog.Accepted


def app_message(parent, title, text, button_label="OK", rich=False):
    """One-button information dialog in app chrome (About, errors)."""
    dlg, layout = _app_dialog(parent, title)
    _app_dialog_text(layout, text, rich=rich)
    _app_dialog_buttons(layout, dlg, [
        (button_label, "primary", dlg.accept, True),
    ])
    dlg.exec()


def app_choose(parent, title, text, buttons):
    """Multi-button choice in app chrome (Save / Discard / Cancel).

    ``buttons``: [(label, kind)] with kind "primary" | "ghost" |
    "danger"; the first button is the default. Returns the chosen
    label, or None on Esc/close.
    """
    dlg, layout = _app_dialog(parent, title)
    _app_dialog_text(layout, text)
    chosen = {"label": None}

    def _pick(label):
        chosen["label"] = label
        dlg.accept()

    specs = []
    for i, (label, kind) in enumerate(buttons):
        # clicked() passes its checked flag positionally — swallow it.
        specs.append((label, kind,
                      (lambda _checked=False, lb=label: _pick(lb)),
                      i == 0))
    _app_dialog_buttons(layout, dlg, specs)
    if dlg.exec() != QDialog.Accepted:
        return None
    return chosen["label"]


def _relaunch_app():
    """Relaunch via the real launcher and quit this process
    (V1.9.50: after a data-folder move or an offline merge, the
    restart IS the switch to the new/live data). No-op beyond
    quitting when no launcher exists (dev layout)."""
    try:
        from tasklist.taskbar import launcher_target
        target = launcher_target()
        if target.is_file():
            flags = 0
            if sys.platform == "win32":
                flags = 0x00000008 | 0x08000000  # DETACHED | NO_WINDOW
            subprocess.Popen([str(target)], cwd=str(target.parent),
                             creationflags=flags, close_fds=True)
    except Exception:
        pass
    try:
        QApplication.instance().quit()
    except Exception:
        pass


def app_get_text(parent, title, label, text=""):
    """Text prompt in app chrome. Returns (value, accepted)."""
    dlg, layout = _app_dialog(parent, title)
    _app_dialog_text(layout, label)
    edit = QLineEdit(text)
    layout.addWidget(edit)
    edit.selectAll()
    _app_dialog_buttons(layout, dlg, [
        ("Cancel", "ghost", dlg.reject, False),
        ("OK", "primary", dlg.accept, True),
    ])
    edit.returnPressed.connect(dlg.accept)
    # V1.9.38: capture the value while the dialog is alive. These
    # dialogs are WA_DeleteOnClose, so reading the widget AFTER
    # exec() returns races the deferred delete -- on the user's
    # machine it raised "QLineEdit already deleted", the caller's
    # slot died silently, and New Notebook / Rename simply did
    # nothing (the app_choose closure pattern, applied here).
    got = {"text": text}
    dlg.accepted.connect(lambda: got.__setitem__("text", edit.text()))
    if dlg.exec() == QDialog.Accepted:
        return got["text"], True
    return text, False


def app_get_int(parent, title, label, value=1, minimum=1, maximum=99):
    """Integer prompt in app chrome. Returns (value, accepted)."""
    dlg, layout = _app_dialog(parent, title)
    _app_dialog_text(layout, label)
    spin = QSpinBox()
    spin.setRange(minimum, maximum)
    spin.setValue(value)
    layout.addWidget(spin)
    _app_dialog_buttons(layout, dlg, [
        ("Cancel", "ghost", dlg.reject, False),
        ("OK", "primary", dlg.accept, True),
    ])
    got = {"value": value}  # capture-while-alive: see app_get_text
    dlg.accepted.connect(lambda: got.__setitem__("value", spin.value()))
    if dlg.exec() == QDialog.Accepted:
        return got["value"], True
    return value, False


def app_get_item(parent, title, label, items, current=0):
    """List picker in app chrome. Returns (item, accepted)."""
    dlg, layout = _app_dialog(parent, title)
    _app_dialog_text(layout, label)
    lst = QListWidget()
    lst.addItems(list(items))
    if items:
        lst.setCurrentRow(max(0, min(current, len(items) - 1)))
    lst.itemDoubleClicked.connect(lambda _i: dlg.accept())
    layout.addWidget(lst)
    _app_dialog_buttons(layout, dlg, [
        ("Cancel", "ghost", dlg.reject, False),
        ("OK", "primary", dlg.accept, True),
    ])
    got = {"item": None}  # capture-while-alive: see app_get_text

    def _capture():
        it = lst.currentItem()
        got["item"] = it.text() if it is not None else None

    dlg.accepted.connect(_capture)
    if dlg.exec() == QDialog.Accepted and got["item"] is not None:
        return got["item"], True
    return (items[current] if items else ""), False


def app_get_color(parent, initial, title="Choose a color"):
    """Color picker in app chrome (the QColorDialog widget hosted in
    an install_chrome dialog, so no native frame appears). Returns the
    chosen QColor, or an invalid QColor on cancel."""
    dlg, layout = _app_dialog(parent, title)
    picker = QColorDialog(initial, dlg)
    picker.setOption(QColorDialog.NoButtons, True)
    picker.setOption(QColorDialog.ShowAlphaChannel, False)
    layout.addWidget(picker)
    _app_dialog_buttons(layout, dlg, [
        ("Cancel", "ghost", dlg.reject, False),
        ("OK", "primary", dlg.accept, True),
    ])
    got = {"color": QColor()}  # capture-while-alive: see app_get_text
    dlg.accepted.connect(
        lambda: got.__setitem__("color", picker.currentColor()))
    if dlg.exec() == QDialog.Accepted:
        return got["color"]
    return QColor()


class _FolderBgWorker(QObject):
    """Runs one callable off the UI thread and emits the payload back."""
    finished = Signal(object)

    def __init__(self, func, args, kwargs):
        super().__init__()
        self._func = func
        self._args = args
        self._kwargs = kwargs

    @Slot()
    def run(self):
        try:
            self.finished.emit(
                {"ok": True, "value": self._func(*self._args, **self._kwargs)})
        except Exception as exc:  # noqa: BLE001
            self.finished.emit(
                {"ok": False, "error": f"{type(exc).__name__}: {exc}"})


class _ResultBridge(QObject):
    """Lives on the main thread; re-emits the worker payload there.

    A plain-Python callback connected straight to the worker's signal would
    run in the WORKER thread (AutoConnection can't infer affinity for a
    non-QObject callable). Routing through this bridge's signal guarantees
    the callback — and all SQLite writes it performs — happen on the main
    thread.
    """
    delivered = Signal(object)

    def __init__(self, callback):
        super().__init__()
        self.delivered.connect(callback)


def run_folder_background(func, callback, *args, **kwargs):
    """Run ``func(*args, **kwargs)`` off the UI thread; ``callback(payload)``
    is invoked on the main thread with {"ok", "value"} or {"ok", "error"}."""
    thread = QThread()
    worker = _FolderBgWorker(func, args, kwargs)

    def _on_delivered(payload):
        try:
            callback(payload)
        finally:
            thread.quit()

    bridge = _ResultBridge(_on_delivered)
    # Keep the wrappers alive until the thread finishes: PySide signal
    # connections alone do not guarantee the worker outlives this call, and
    # a collected worker means `started` fires into nothing (the thread then
    # never finishes).
    thread._folder_worker = worker
    thread._result_bridge = bridge
    _bg_threads.add(thread)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    # Signal-to-signal: emitted in the worker thread, re-emitted by the
    # bridge on the main thread (queued by thread affinity).
    worker.finished.connect(bridge.delivered)
    worker.finished.connect(worker.deleteLater)
    thread.finished.connect(bridge.deleteLater)
    thread.finished.connect(lambda: _bg_threads.discard(thread))
    thread.finished.connect(thread.deleteLater)
    thread.start()
    return thread


# Live background folder threads, kept referenced so the QThread wrapper is
# never garbage-collected while the native thread is still running.
_bg_threads = set()


class FolderCollisionDialog(QDialog):
    """Themed collision dialog: a folder with this name already exists."""

    def __init__(self, parent, folder_name):
        super().__init__(parent)
        self.setWindowTitle("Folder already exists")
        self.setModal(True)
        self.setMinimumWidth(440)
        self.choice = FOLDER_CANCEL
        layout = install_chrome(self, "Folder already exists")

        title = QLabel("Folder already exists")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)

        body = QLabel(
            f"A folder named '{folder_name}' already exists in the "
            "destination.")
        body.setWordWrap(True)
        layout.addWidget(body)
        layout.addSpacing(6)

        dup_label = f"Create as '{folder_name} (2)'"
        if len(dup_label) > 52:
            dup_label = dup_label[:49] + "…'"
        self.use_btn = QPushButton("Use existing folder")
        self.use_btn.setDefault(True)
        self.use_btn.clicked.connect(self._choose_use)
        self.dup_btn = QPushButton(dup_label)
        self.dup_btn.clicked.connect(self._choose_duplicate)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self._choose_cancel)
        for btn in (self.use_btn, self.dup_btn, self.cancel_btn):
            btn.setCursor(Qt.PointingHandCursor)
            layout.addWidget(btn)

    def _choose_use(self):
        self.choice = FOLDER_USE
        self.accept()

    def _choose_duplicate(self):
        self.choice = FOLDER_DUPLICATE
        self.accept()

    def _choose_cancel(self):
        self.choice = FOLDER_CANCEL
        self.reject()


def ask_folder_collision(parent, folder_name):
    """Show the collision dialog; returns "use" | "duplicate" | "cancel"."""
    dlg = FolderCollisionDialog(parent, folder_name)
    dlg.exec()
    return dlg.choice


class FolderQuoteMatchDialog(QDialog):
    """Themed picker: several folders already exist for this quote number.

    The user picks which folder the task belongs to, or chooses to create
    a new one. ``result`` is ("use", folder_name), ("new", None), or
    ("cancel", None).
    """

    def __init__(self, parent, quote_number, matches):
        super().__init__(parent)
        self.setWindowTitle("Pick the quote folder")
        self.setModal(True)
        self.setMinimumWidth(480)
        self.result = ("cancel", None)
        layout = install_chrome(self, "Pick the quote folder")

        title = QLabel(f"Existing folders for quote {quote_number}")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)

        body = QLabel(
            "More than one folder already exists for this quote number. "
            "Pick the one this task belongs to — nothing will be created "
            "or overwritten.")
        body.setWordWrap(True)
        layout.addWidget(body)
        layout.addSpacing(6)

        self._group = QButtonGroup(self)
        self._radios = []
        for i, name in enumerate(matches):
            radio = QRadioButton(name)
            radio.setCursor(Qt.PointingHandCursor)
            if i == 0:
                radio.setChecked(True)
            self._group.addButton(radio, i)
            self._radios.append(radio)
            layout.addWidget(radio)
        self._new_radio = QRadioButton("Create a new folder instead")
        self._new_radio.setCursor(Qt.PointingHandCursor)
        self._group.addButton(self._new_radio, len(matches))
        layout.addWidget(self._new_radio)
        layout.addSpacing(6)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.ok_btn = QPushButton("Continue")
        self.ok_btn.setDefault(True)
        self.ok_btn.setObjectName("primary")
        self.ok_btn.clicked.connect(self._choose_ok)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        for btn in (self.ok_btn, self.cancel_btn):
            btn.setCursor(Qt.PointingHandCursor)
            btn_row.addWidget(btn)
        _equalize_button_heights([self.ok_btn, self.cancel_btn])
        layout.addLayout(btn_row)
        self._matches = list(matches)

    def _choose_ok(self):
        checked = self._group.checkedId()
        if checked == len(self._matches):
            self.result = ("new", None)
        else:
            self.result = ("use", self._matches[checked])
        self.accept()


def ask_folder_quote_match(parent, quote_number, matches):
    """Show the quote-match picker; returns ("use"|"new"|"cancel", name)."""
    dlg = FolderQuoteMatchDialog(parent, quote_number, matches)
    dlg.exec()
    return dlg.result


def _link_folder_path(db, task_id, path, detail):
    """Set folder_path on the task and log it. folder_path is only ever set
    here — i.e. only when the folder truly exists."""
    task = db.get_task(task_id)
    if not task:
        return False
    db.update_task(
        task_id,
        task["quote_number"], task["distributor"], task["end_user"],
        task["notes"], task.get("scope", []), task.get("scope_done", []),
        folder_path=path,
    )
    log_folder_activity(db, task_id, detail)
    return True


def _looks_like_unc(path):
    """True for ``\\\\server\\share`` / ``//server/share`` network paths.

    Used to decide whether a path may be stat'ed synchronously (local —
    cheap) or must be probed off the UI thread (network — a dead fileshare
    can block the event loop for a long time). Syntactic only: no I/O.
    """
    return path.startswith("\\\\") or path.startswith("//")


def _probe_dir_exists(path):
    """Off-UI-thread single-dir existence check. Never raises."""
    try:
        return bool(path) and os.path.isdir(path)
    except Exception:
        return False


def _probe_destination(dest, folder_name, template=None, quote_number=None):
    """Off-UI-thread probe: is the destination reachable, does the
    target folder already exist, are there other folders for the same
    quote number, and is the template dir usable?
    Never raises. (v1.2.9: the template check moved here from
    begin_quote_folder_flow so no network stat ever runs on the UI thread.)
    """
    folders_mod = _folders_module()
    reachable = bool(folders_mod.dest_reachable(dest or ""))
    exists = False
    qn_matches = []
    if reachable and dest:
        try:
            exists = os.path.exists(os.path.join(dest, folder_name))
        except Exception:
            exists = False
        if not exists and quote_number:
            # Same quote, different date/distributor spelling: the exact
            # generated name misses, but a folder for this quote number
            # may already be there (addition to an old quote, revision).
            qn_matches = folders_mod.find_folders_for_quote(
                dest, quote_number)
    template_ok = True
    if template is not None:
        try:
            template_ok = bool(template) and os.path.isdir(template)
        except Exception:
            template_ok = False
    return {"reachable": reachable, "exists": exists,
            "qn_matches": qn_matches, "template_ok": template_ok}


def _copy_from_template(template, dest, folder_name, unique=False):
    """Off-UI-thread copy. Returns {"path", "name"}; raises on failure."""
    folders_mod = _folders_module()
    name = folder_name
    if unique:
        name = folders_mod.next_available_name(dest, folder_name)
    final = folders_mod.copy_template(template, dest, name)
    return {"path": final, "name": name}


def _folder_flow_unexpected(db, task_id, interactive, parent, settle, exc):
    """Catch-all for the quote-folder flow: an unexpected exception can never
    be a silent no-op. The failure is logged to the task's activity log,
    surfaced as a single failure notice in interactive mode (unattended
    contexts such as startup stay dialog-free), then the flow settles."""
    err = f"{type(exc).__name__}: {exc}"
    log_folder_activity(
        db, task_id, f"Quote folder failed (unexpected error): {err}")
    if interactive:
        show_toast(
            parent, "error", "Quote folder failed",
            "Could not create the quote folder:\n"
            f"An unexpected error occurred:\n{err}")
    if settle is not None:
        try:
            settle(None)
        except Exception:
            pass


def begin_quote_folder_flow(db, task, *, interactive, parent=None,
                            pending_row_id=None, folder_name=None,
                            on_done=None):
    """Kick off automatic quote folder creation for an existing task.

    ``task`` is a mapping with id / quote_number / distributor / end_user /
    created_at. ``interactive`` selects the collision behavior: interactive
    contexts (new-task save, detail button, manual Retry) may show the
    collision dialog; unattended contexts (startup) auto-use the existing
    folder and never show dialogs. ``on_done(final_path_or_None)`` is always
    invoked on the main thread when the flow settles — ``final_path`` is
    non-None only when the task was actually linked to a real folder.

    Audit-trail guarantees: "Quote folder creation started" is always logged
    to the task's activity log when the flow runs, even when a later guard
    bails out; any unexpected exception is caught, logged, and (in
    interactive mode) surfaced as a single failure notice — never silence.
    """
    def _done(path):
        if on_done is not None:
            try:
                on_done(path)
            except Exception:
                pass

    task_id = (task or {}).get("id")
    # Always audit that the flow ran — fires before every guard, so a missing
    # folder always leaves a trace on the task.
    log_folder_activity(db, task_id, "Quote folder creation started")

    def _unexpected(exc):
        _folder_flow_unexpected(db, task_id, interactive, parent, _done, exc)

    def _probed(res):
        # Async settle step (main thread): any unexpected failure here —
        # probe handling, collision dialog, link — is caught, logged, and
        # notified exactly once rather than vanishing silently.
        try:
            _on_folder_probed(
                db, task, name, dest, template, interactive, parent,
                pending_row_id, res, _done)
        except Exception as exc:  # noqa: BLE001
            _unexpected(exc)

    try:
        if not folder_creation_enabled(db):
            log_folder_activity(
                db, task_id,
                "Quote folder not created — automatic folder creation is off")
            _done(None)
            return
        try:
            _folders_module()
        except ImportError:
            log_folder_activity(
                db, task_id,
                "Quote folder not created — folder module missing")
            _done(None)
            return
        template = (db.get_setting("folder_template_dir", "") or "").strip()
        if not template:
            # Synchronous only because it performs no I/O: an empty template
            # needs no network stat. Reachability of a SET template is
            # probed off the UI thread (see _probe_destination) — v1.2.9.
            if interactive:
                show_toast(
                    parent, "warning", "Quote folder skipped",
                    "The template folder isn't set or can't be reached, so no "
                    "quote folder was created. Set it under File > Settings.")
            log_folder_activity(
                db, task_id,
                "Quote folder not created — template folder missing or "
                "unreachable")
            _done(None)
            return
        name = folder_name or quote_folder_name_for(db, task)
        dest = (db.get_setting("folder_dest_dir", "") or "").strip()
        quote_number = (task or {}).get("quote_number") or ""
    except Exception as exc:  # noqa: BLE001
        _unexpected(exc)
        return

    run_folder_background(_probe_destination, _probed, dest, name, template,
                          quote_number)


def _queue_unreachable(db, task_id, name, pending_row_id, parent, interactive,
                       _done):
    if pending_row_id is not None:
        try:
            db.bump_pending_folder(pending_row_id, "destination unreachable")
        except Exception:
            pass
    else:
        try:
            db.add_pending_folder(task_id, name)
        except Exception:
            pass
    log_folder_activity(
        db, task_id,
        f"Quote folder queued ({name}) — destination unreachable")
    if interactive:
        show_toast(
            parent, "info", "Quote folder queued",
            "Quote folder queued — will be created when you're connected "
            "to the work network.")
    _done(None)


def _on_folder_probed(db, task, name, dest, template, interactive, parent,
                      pending_row_id, res, _done):
    task_id = task.get("id")
    value = res.get("value") or {}
    if res.get("ok") and not value.get("template_ok", True):
        # Template dir missing/unreachable — the stat ran off the UI thread
        # (v1.2.9); same branch the old synchronous guard produced.
        if interactive:
            show_toast(
                parent, "warning", "Quote folder skipped",
                "The template folder isn't set or can't be reached, so no "
                "quote folder was created. Set it under File > Settings.")
        log_folder_activity(
            db, task_id,
            "Quote folder not created — template folder missing or "
            "unreachable")
        _done(None)
        return
    if not res.get("ok") or not value.get("reachable"):
        _queue_unreachable(db, task_id, name, pending_row_id, parent,
                           interactive, _done)
        return
    target = os.path.join(dest, name)
    if value.get("exists"):
        if not interactive:
            # Unattended (startup): auto "use existing", never a dialog.
            _link_folder_path(
                db, task_id, target,
                f"Quote folder linked to existing folder: {name}")
            if pending_row_id is not None:
                try:
                    db.remove_pending_folder(pending_row_id)
                except Exception:
                    pass
            _done(target)
            return
        choice = ask_folder_collision(parent, name)
        if choice == FOLDER_USE:
            _link_folder_path(
                db, task_id, target,
                f"Quote folder linked to existing folder: {name}")
            if pending_row_id is not None:
                try:
                    db.remove_pending_folder(pending_row_id)
                except Exception:
                    pass
            if interactive:
                show_toast(
                    parent, "success", "Quote folder linked",
                    f"Quote folder linked to the existing folder:\n{name}")
            _done(target)
        elif choice == FOLDER_DUPLICATE:
            _copy_folder_background(
                db, task, name, dest, template, interactive, parent,
                pending_row_id, unique=True, on_done=_done)
        else:  # cancel — the task was already saved; never undone
            log_folder_activity(
                db, task_id, f"Quote folder skipped by user ({name})")
            _done(None)
        return
    qn_matches = value.get("qn_matches") or []
    if qn_matches:
        # The exact generated name is free, but folder(s) for this quote
        # number already exist (addition to an old quote, or a revision —
        # revisions keep the same quote number). Never create a duplicate
        # silently and never touch the existing folder: link to it.
        quote_number = task.get("quote_number") or ""
        if len(qn_matches) == 1:
            match = qn_matches[0]
            _link_folder_path(
                db, task_id, os.path.join(dest, match),
                f"Quote folder linked to existing folder for quote "
                f"{quote_number}: {match}")
            if pending_row_id is not None:
                try:
                    db.remove_pending_folder(pending_row_id)
                except Exception:
                    pass
            if interactive:
                show_toast(
                    parent, "success", "Quote folder linked",
                    f"This quote already has a folder — linked to it, "
                    f"nothing was created or overwritten:\n{match}")
            _done(os.path.join(dest, match))
            return
        choice, selected = ask_folder_quote_match(
            parent, quote_number, qn_matches)
        if choice == "use":
            _link_folder_path(
                db, task_id, os.path.join(dest, selected),
                f"Quote folder linked to existing folder for quote "
                f"{quote_number}: {selected}")
            if pending_row_id is not None:
                try:
                    db.remove_pending_folder(pending_row_id)
                except Exception:
                    pass
            if interactive:
                show_toast(
                    parent, "success", "Quote folder linked",
                    f"Quote folder linked to the existing folder:\n{selected}")
            _done(os.path.join(dest, selected))
        elif choice == "new":
            _copy_folder_background(
                db, task, name, dest, template, interactive, parent,
                pending_row_id, unique=False, on_done=_done)
        else:  # cancel — the task was already saved; never undone
            log_folder_activity(
                db, task_id,
                f"Quote folder skipped by user (quote {quote_number})")
            _done(None)
        return
    _copy_folder_background(
        db, task, name, dest, template, interactive, parent,
        pending_row_id, unique=False, on_done=_done)


def _copy_folder_background(db, task, name, dest, template, interactive,
                            parent, pending_row_id, unique, on_done):
    task_id = task.get("id")

    def _after_copy(res):
        if res.get("ok"):
            path = res["value"]["path"]
            used_name = res["value"]["name"]
            _link_folder_path(
                db, task_id, path, f"Quote folder created: {used_name}")
            if pending_row_id is not None:
                try:
                    db.remove_pending_folder(pending_row_id)
                except Exception:
                    pass
            elif interactive:
                # Direct user action only (new-task save, detail button):
                # a queued retry reports through the summary notice instead
                # of one notice per folder.
                show_toast(
                    parent, "success", "Quote folder created",
                    f"Quote folder created and linked:\n{used_name}")
            on_done(path)
            return
        err = res.get("error", "unknown error")
        log_folder_activity(
            db, task_id, f"Quote folder failed ({name}): {err}")
        if pending_row_id is not None:
            # Retry/startup context: re-queue with attempt bookkeeping.
            try:
                db.bump_pending_folder(pending_row_id, err)
            except Exception:
                pass
            if interactive:
                show_toast(
                    parent, "error", "Quote folder failed",
                    f"Could not create the quote folder:\n{err}\n"
                    "It will be retried later.")
        else:
            # Interactive single shot: message only, nothing queued.
            if interactive:
                show_toast(
                    parent, "error", "Quote folder failed",
                    f"Could not create the quote folder:\n{err}")
        on_done(None)

    def _after_copy_safe(res):
        # Async settle step (main thread): exceptions in the copy / link /
        # settle logic are caught, logged, and notified exactly once rather
        # than vanishing silently (or escaping through the bridge).
        try:
            _after_copy(res)
        except Exception as exc:  # noqa: BLE001
            _folder_flow_unexpected(
                db, task_id, interactive, parent, on_done, exc)

    run_folder_background(
        _copy_from_template, _after_copy_safe, template, dest, name, unique)


def _pending_rows(db):
    try:
        rows = db.get_pending_folders() or []
    except Exception:
        return []
    return list(rows)


def _drain_pending(db, rows, *, interactive, parent, on_done):
    """Process pending rows one at a time. ``on_done(summary)`` fires on the
    main thread with {"created", "waiting"} once every row has settled."""
    created = 0
    waiting = 0

    def _finish():
        if on_done is not None:
            try:
                on_done({"created": created, "waiting": waiting})
            except Exception:
                pass

    def _advance(i):
        nonlocal created, waiting
        if i >= len(rows):
            _finish()
            return
        row = rows[i]
        row_id = row.get("id")
        task = None
        try:
            task = db.get_task(row.get("task_id"))
        except Exception:
            task = None
        if not task:
            try:
                db.remove_pending_folder(row_id)
            except Exception:
                pass
            _advance(i + 1)
            return

        def _row_done(path):
            nonlocal created, waiting
            if path:
                created += 1
            else:
                waiting += 1
            _advance(i + 1)

        begin_quote_folder_flow(
            db, task, interactive=interactive, parent=parent,
            pending_row_id=row_id,
            folder_name=row.get("folder_name"),
            on_done=_row_done)

    _advance(0)


def process_pending_folders_startup(db, parent=None, on_done=None):
    """Unattended startup processing of the folder queue. No dialogs, ever —
    collisions auto-use the existing folder. Ends with ONE summary notice."""

    def _done(summary):
        if summary and (summary.get("created") or summary.get("waiting")):
            parts = []
            if summary["created"]:
                n = summary["created"]
                parts.append(
                    f"Created {n} quote folder{'s' if n != 1 else ''}")
            if summary["waiting"]:
                parts.append(
                    f"{summary['waiting']} still waiting — will retry when "
                    "you're connected to the work network")
            show_toast(parent, "info", "Quote folders",
                       ". ".join(parts) + ".")
        if on_done is not None:
            try:
                on_done(summary)
            except Exception:
                pass

    if not folder_creation_enabled(db):
        _done(None)
        return
    rows = _pending_rows(db)
    if not rows:
        _done(None)
        return
    _drain_pending(db, rows, interactive=False, parent=None, on_done=_done)


def retry_pending_folders(db, parent=None, on_done=None):
    """Manual retry of the folder queue (Settings > Retry now). Interactive:
    collisions may show the collision dialog.

    The summary goes to ``on_done``; the caller (SettingsDialog) owns the
    single summary notice so a manual retry never shows two notices."""

    def _done(summary):
        if on_done is not None:
            try:
                on_done(summary)
            except Exception:
                pass

    rows = _pending_rows(db)
    if not rows:
        if on_done is not None:
            try:
                on_done({"created": 0, "waiting": 0})
            except Exception:
                pass
        return
    _drain_pending(db, rows, interactive=True, parent=parent, on_done=_done)


def verify_folder_setup(master, template, dest, initials):
    """Read-only diagnostic for Settings → Folder Creation → Verify setup.

    Purely diagnostic: never creates folders, writes files, or changes
    settings. Destination writability is probed with os.access() — no
    probe files are ever created. Touches no Qt objects, so it is safe to
    run off the UI thread (the caller snapshots the field values first).

    Returns [(key, label, ok, detail), ...] in display order.
    """
    template = (template or "").strip()
    dest = (dest or "").strip()
    initials = (initials or "").strip()
    template_ok = bool(template) and os.path.isdir(template)
    dest_ok = bool(dest) and os.path.isdir(dest) and os.access(dest, os.W_OK)
    return [
        ("master",
         "Master toggle is on",
         bool(master),
         "" if master
         else 'Turn on "Enable automatic quote folder creation" first.'),
        ("template",
         "Template folder is an existing directory",
         template_ok,
         "" if template_ok else "Pick an existing template folder."),
        ("dest",
         "Destination is reachable and writable",
         dest_ok,
         "" if dest_ok else "Pick a reachable, writable destination folder."),
        ("initials",
         "Initials are set",
         bool(initials),
         "" if initials else "Enter your initials."),
    ]


def format_size(num):
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
        num /= 1024


# ------------------------------------------------------- custom window chrome
# V1.9.2: the visible frame ends AT the window edge with rounded corners
# when windowed (the way standard Windows 11 apps look). The old 10px
# transparent shadow margin left the painted frame floating 10px inside
# the real window edge on every side, which is what the user flagged.
# Trade-off: no room remains for the Qt drop shadow, so windows get a
# clean hard edge (1px border) instead. Maximized is unchanged (margins
# were already 0 and the frame squares off via [squareCorners="true"]).
CHROME_MARGIN = 0


class TitleBar(QFrame):
    """Custom title bar: window title on the left, min/max/close on the right."""

    def __init__(self, window, title_text, show_max=True, parent=None):
        super().__init__(parent)
        self.setObjectName("titleBar")
        self._window = window
        self.setFixedHeight(42)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 8, 0)
        layout.setSpacing(2)
        self._label = QLabel(title_text)
        self._label.setObjectName("titleBarLabel")
        layout.addWidget(self._label)
        layout.addStretch(1)

        self._min_btn = self._make_btn("minus", "Minimize")
        self._min_btn.clicked.connect(window.showMinimized)
        layout.addWidget(self._min_btn)
        if show_max:
            self._max_btn = self._make_btn("square", "Maximize")
            self._max_btn.clicked.connect(self._toggle_max)
            layout.addWidget(self._max_btn)
        else:
            self._max_btn = None
        self._close_btn = self._make_btn("x", "Close")
        self._close_btn.setObjectName("winCloseBtn")
        self._close_btn.clicked.connect(window.close)
        layout.addWidget(self._close_btn)
        self._drag_last = None
        self._max_drag_press = None
        # pure-Qt snap state (see _apply_snap): the preview follows the drag,
        # _preview_action is what a release would do.
        self._preview = None
        self._preview_action = None
        self._preview_pos = None
        # The screen the drag STARTED on — kept only as a fallback for
        # the moments the cursor sits between screens. V1.9.33: edge
        # detection itself follows the screen under the CURSOR (see
        # _snap_screen). The V1.9.31 press-screen anchoring made
        # cross-monitor drags snap back into the monitor the drag
        # started on (user: dragging to the left monitor snapped the
        # window to the left edge of the right one).
        self._drag_screen_geom = None
        self._drag_screen_avail = None
        self._preview_avail = None

    def _make_btn(self, icon_name, tip):
        btn = QPushButton()
        btn.setObjectName("winBtn")
        btn.setToolTip(tip)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setFixedSize(40, 28)
        btn.setFocusPolicy(Qt.NoFocus)
        btn.setIconSize(QSize(13, 13))
        # Icon buttons render uniformly (same stroke/size); the glyph name
        # and hover color ride along as properties for the hover recolor.
        btn.setProperty("iconName", icon_name)
        self._paint_btn_icon(btn, False)
        btn.installEventFilter(self)
        return btn

    def make_chrome_button(self, icon_name, tip):
        """A button in this bar's own style (hover recolor included),
        for windows that put an action in the title bar."""
        return self._make_btn(icon_name, tip)

    def add_before_min(self, btn):
        """Insert a chrome button immediately left of Minimize."""
        layout = self.layout()
        idx = layout.indexOf(self._min_btn)
        layout.insertWidget(max(0, idx), btn)

    def _paint_btn_icon(self, btn, hovered):
        color = "#ffffff" if hovered else "#9ba1ab"
        btn.setIcon(svg_icon(btn.property("iconName"), color, 13))

    def eventFilter(self, obj, event):
        if isinstance(obj, QPushButton) and obj.property("iconName"):
            if event.type() == QEvent.Enter:
                self._paint_btn_icon(obj, True)
            elif event.type() == QEvent.Leave:
                self._paint_btn_icon(obj, False)
        return super().eventFilter(obj, event)

    def set_title(self, text):
        self._label.setText(text)

    def set_maximized(self, maximized):
        if self._max_btn is not None:
            self._max_btn.setProperty(
                "iconName", "restore" if maximized else "square")
            self._paint_btn_icon(self._max_btn, False)
            self._max_btn.setToolTip("Restore" if maximized else "Maximize")

    def _toggle_max(self):
        window = self._window
        if window.isMaximized():
            window.showNormal()
        else:
            window.showMaximized()

    def mousePressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        window = self._window
        snap_side = getattr(window, "_snap_side", None)
        if snap_side:
            # dragging a snapped window restores it first (cursor stays
            # anchored over the title bar), then the drag continues
            self._restore_from_snap(event, snap_side)
            return
        if not window.isMaximized():
            # Pure manual drag using titlebar-local coords only. The delta
            # between press and move positions is DPI-proof (no global
            # pixels involved), so the whole title bar drags reliably.
            self._drag_last = event.position()
            self._preview_action = None
            self._preview_pos = None
            self._capture_drag_screen()
            event.accept()
        else:
            # V1.9.30 (user): a maximized window must drag away from
            # the top edge like Chrome / Explorer / Edge -- grab the
            # title bar, pull, and the window un-maximizes under the
            # cursor and follows. A plain click (no drag) changes
            # nothing, so this only arms a pending restore; the move
            # handler performs it once the drag threshold is crossed.
            self._max_drag_press = event.position()
            event.accept()

    def _capture_drag_screen(self):
        """Remember the screen this drag belongs to (see __init__ note)."""
        window = self._window
        screen = None
        try:
            screen = window.screen()
        except Exception:
            screen = None
        if screen is None:
            screen = QApplication.screenAt(window.frameGeometry().center())
        if screen is not None:
            self._drag_screen_geom = QRect(screen.geometry())
            self._drag_screen_avail = QRect(screen.availableGeometry())

    def _restore_from_snap(self, event, snap_side):
        """Un-snap on drag start: restore the pre-snap geometry and keep
        the cursor proportionally anchored over the title bar."""
        window = self._window
        try:
            gx = event.globalPosition().x()
            gy = event.globalPosition().y()
        except Exception:
            gx, gy = None, None
        cur = window.geometry()
        ratio = 0.5
        if gx is not None and cur.width() > 0:
            ratio = min(max((gx - cur.x()) / cur.width(), 0.0), 1.0)
        if window.isMaximized():
            window.showNormal()
        pre = getattr(window, "_snap_geom", None)
        if snap_side != "max" and isinstance(pre, QRect) and not pre.isNull():
            window.setGeometry(pre)
        window._snap_side = None
        window._snap_geom = None
        if gx is not None and gy is not None:
            g = window.geometry()
            new_left = int(gx - ratio * g.width())
            new_top = int(gy - 21)  # keep the title bar under the cursor
            screen = QApplication.screenAt(QPoint(int(gx), int(gy)))
            if screen is not None:
                sg = screen.geometry()
                new_left = min(max(new_left, sg.left()), sg.right() - 100)
                new_top = min(max(new_top, sg.top()), sg.bottom() - 60)
            window.move(new_left, new_top)
        self._drag_last = event.position()
        self._preview_action = None
        self._preview_pos = None
        self._capture_drag_screen()
        event.accept()

    def mouseMoveEvent(self, event):
        if self._max_drag_press is not None:
            if not (event.buttons() & Qt.LeftButton):
                self._max_drag_press = None
                return
            press = self._max_drag_press
            if (event.position() - press).manhattanLength() \
                    >= QApplication.startDragDistance():
                self._max_drag_press = None
                # Same restore path as an app-snapped max window:
                # showNormal + proportional cursor anchoring, and it
                # arms _drag_last so the drag continues seamlessly.
                self._restore_from_snap(event, "max")
            event.accept()
            return
        if self._drag_last is not None and event.buttons() & Qt.LeftButton:
            delta = (event.position() - self._drag_last).toPoint()
            if not delta.isNull():
                self._window.move(self._window.pos() + delta)
            if _snap_platform_ok():
                try:
                    gp = event.globalPosition().toPoint()
                except Exception:
                    gp = None
                if gp is not None:
                    self._update_snap_preview(gp)
            event.accept()

    def _snap_screen(self, global_pos):
        """(geometry, availableGeometry) of the screen the cursor is
        on RIGHT NOW. Snapping follows the cursor's screen, like
        Windows: drag onto another monitor and that monitor's edges
        are the snap targets. Falls back to the drag-start screen
        when the cursor is over no screen (a gap between displays)."""
        screen = QApplication.screenAt(global_pos)
        if screen is not None:
            return (QRect(screen.geometry()),
                    QRect(screen.availableGeometry()))
        if self._drag_screen_geom is not None:
            return self._drag_screen_geom, self._drag_screen_avail
        return None, None

    def _update_snap_preview(self, global_pos):
        """Translucent edge preview while dragging near a screen edge."""
        geom, avail = self._snap_screen(global_pos)
        if geom is None:
            return
        action = snap_action(geom, global_pos)
        if action == self._preview_action:
            self._preview_avail = avail if action else None
            return
        self._preview_action = action
        self._preview_avail = avail if action else None
        self._preview_pos = global_pos
        if self._preview is not None:
            self._preview.hide()
        if action is None:
            return
        rect = snapped_rect(avail, action)
        if rect is None:
            return
        if self._preview is None:
            self._preview = QWidget(None)
            self._preview.setObjectName("snapPreview")
            self._preview.setAttribute(Qt.WA_TranslucentBackground, True)
            self._preview.setWindowFlags(
                Qt.ToolTip | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self._preview.setGeometry(rect)
        self._preview.show()
        self._preview.raise_()

    def _apply_snap(self, action):
        window = self._window
        if getattr(window, "_snap_side", None):
            return
        # V1.9.33: the snapped rect comes from the screen the drag
        # ENDED on (tracked by the preview), not the start screen.
        avail = self._preview_avail or self._drag_screen_avail
        if avail is None:
            pos = self._preview_pos or window.frameGeometry().center()
            screen = QApplication.screenAt(pos)
            if screen is None:
                return
            avail = screen.availableGeometry()
        # snapped rect = the drag screen's WORK AREA, so a side-snapped
        # window never slides under the taskbar
        rect = snapped_rect(avail, action)
        if rect is None:
            return
        window._snap_geom = window.geometry()
        window._snap_side = action
        if action == "max":
            window.showMaximized()
        else:
            window.setGeometry(rect)

    def mouseReleaseEvent(self, event):
        self._max_drag_press = None
        if self._drag_last is not None and _snap_platform_ok():
            # V1.9.33: re-evaluate at the RELEASE point — a fast flick
            # can end on a different monitor than the last move event
            # reported, and that monitor's edges are the ones that
            # count.
            try:
                self._update_snap_preview(
                    event.globalPosition().toPoint())
            except Exception:
                pass
            action = self._preview_action
            if self._preview is not None:
                self._preview.hide()
            self._preview_action = None
            self._preview_pos = None
            if action and event.button() == Qt.LeftButton:
                self._apply_snap(action)
            self._preview_avail = None
        self._drag_last = None

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self._max_btn is not None:
            self._toggle_max()
            event.accept()


class WindowChrome(QObject):
    """Edge-resizing for one frameless window.

    V1.9.31: installed on the QApplication, not on the window. Since
    V1.9.2 the visible frame edge IS the window edge (CHROME_MARGIN 0)
    and child widgets cover every pixel of the window, so a filter on
    the window itself only ever saw the rare presses that child widgets
    ignored — top/bottom/corner resizing was effectively dead (user:
    "I also get no resize/drag handles to resize up/down or by the
    corners"). The app filter sees every press/hover first, maps it
    into window-local logical coordinates (obj.mapTo — never global
    pixels, per the chrome lessons), and hit-tests the outer band.
    Presses on interactive controls (buttons, scrollbars, sliders) are
    never stolen; the title bar keeps its own drags because only the
    outer EDGE px band is claimed — exactly like a native frame.
    """

    EDGE = 8  # resize grab half-width around the visible frame edge

    CURSORS = {
        "left": Qt.SizeHorCursor, "right": Qt.SizeHorCursor,
        "top": Qt.SizeVerCursor, "bottom": Qt.SizeVerCursor,
        "top-left": Qt.SizeFDiagCursor, "bottom-right": Qt.SizeFDiagCursor,
        "top-right": Qt.SizeBDiagCursor, "bottom-left": Qt.SizeBDiagCursor,
    }

    #: widget classes whose presses the resize band must never steal
    _NEVER_STEAL = (QAbstractButton, QScrollBar, QAbstractSlider)

    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self._mode = None
        self._geom = None
        self._press_pos = None
        self._cursor = None
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)
        else:  # pragma: no cover — a QApplication always exists here
            window.installEventFilter(self)

    def _local_pos(self, obj, ev):
        """Event position in window-local logical coordinates."""
        try:
            p = ev.position().toPoint()
        except AttributeError:
            p = ev.pos()
        if obj is self.window or not isinstance(obj, QWidget):
            return p
        if obj.window() is not self.window:
            # mid-resize stream landing outside our window: fall back to
            # the global position (mapped, still logical coordinates)
            try:
                return self.window.mapFromGlobal(
                    ev.globalPosition().toPoint())
            except Exception:
                return p
        return obj.mapTo(self.window, p)

    def _edge_at(self, p):
        """Window-local point -> edge name or None. Zones straddle the
        visible frame edge (which is the window edge itself since
        V1.9.2). The title bar is NOT excluded: its outer band is the
        resize zone, like a native caption — the inner part still drags.
        """
        w = self.window
        if w.isMaximized() or w.isFullScreen():
            return None
        ww, hh = w.width(), w.height()
        v, g = CHROME_MARGIN, self.EDGE
        left = abs(p.x() - v) <= g
        right = abs(p.x() - (ww - v)) <= g
        top = abs(p.y() - v) <= g
        bottom = abs(p.y() - (hh - v)) <= g
        if top and left:
            return "top-left"
        if top and right:
            return "top-right"
        if bottom and left:
            return "bottom-left"
        if bottom and right:
            return "bottom-right"
        if left:
            return "left"
        if right:
            return "right"
        if top:
            return "top"
        if bottom:
            return "bottom"
        return None

    def _set_cursor(self, mode):
        want = self.CURSORS.get(mode) if mode else None
        if want != self._cursor:
            if self._cursor is not None:
                QApplication.restoreOverrideCursor()
            if want is not None:
                QApplication.setOverrideCursor(QCursor(want))
            self._cursor = want

    def eventFilter(self, obj, ev):
        # App-level filter (V1.9.31): only events belonging to OUR window
        # matter. Popups/menus/other windows have their own top-level and
        # are ignored, as are non-widget objects.
        window = getattr(self, "window", None)
        if window is None:
            return False
        t = ev.type()
        if obj is window and t == QEvent.WindowStateChange:
            self._on_state_change()
            return False
        if not isinstance(obj, QWidget) or obj.window() is not window:
            # While a resize is running the stream belongs to us wherever
            # it lands; everything else is not ours to touch.
            if self._mode and t in (QEvent.MouseMove,
                                    QEvent.MouseButtonRelease):
                pass
            else:
                return False
        if t == QEvent.MouseButtonPress and ev.button() == Qt.LeftButton:
            if isinstance(obj, self._NEVER_STEAL):
                return False
            p = self._local_pos(obj, ev)
            mode = self._edge_at(p)
            if mode:
                self._mode = mode
                self._geom = window.frameGeometry()
                self._press_pos = p
                self._set_cursor(mode)
                try:
                    window.grabMouse()
                except Exception:
                    pass
                return True  # consume: we're resizing
            return False
        if t == QEvent.MouseMove:
            if self._mode:
                self._do_resize(self._local_pos(obj, ev))
                return True
            if not ev.buttons():
                # mouse-tracked children report moves instead of hovers;
                # the resize cursor follows those too
                self._set_cursor(self._edge_at(self._local_pos(obj, ev)))
            return False
        if t == QEvent.MouseButtonRelease and ev.button() == Qt.LeftButton:
            if self._mode:
                self._mode = None
                try:
                    window.releaseMouse()
                except Exception:
                    pass
            self._set_cursor(None)
            return False
        if t == QEvent.HoverMove:
            if self._mode:
                return False
            self._set_cursor(self._edge_at(self._local_pos(obj, ev)))
            return False
        if t in (QEvent.HoverLeave, QEvent.Leave) and obj is window:
            self._set_cursor(None)
            return False
        return False

    def _on_state_change(self):
        w = self.window
        chrome = w._chrome
        maximized = w.isMaximized()
        if maximized:
            chrome["root"].setContentsMargins(0, 0, 0, 0)
            chrome["titlebar"].set_maximized(True)
        else:
            chrome["root"].setContentsMargins(
                CHROME_MARGIN, CHROME_MARGIN, CHROME_MARGIN, CHROME_MARGIN
            )
            chrome["titlebar"].set_maximized(False)
        # v1.4.0 item 12: square the frame's corners when maximized (the
        # rounded 12px radius would leave gaps at the screen edges);
        # restore the radius when windowed. Unpolish/polish applies it.
        frame = chrome["frame"]
        if frame.property("squareCorners") != maximized:
            frame.setProperty("squareCorners", maximized)
            frame.style().unpolish(frame)
            frame.style().polish(frame)
        # V1.9.33: the window mask follows the same state — cleared
        # while maximized (square), rounded again when restored.
        _sync_chrome_mask(w)

    def _do_resize(self, cur):
        mode = self._mode
        orig = self._geom
        dx = cur.x() - self._press_pos.x()
        dy = cur.y() - self._press_pos.y()
        w = self.window
        geom = QRect(orig)
        if "left" in mode:
            geom.setLeft(min(orig.left() + dx, orig.right() - w.minimumWidth()))
        if "right" in mode:
            geom.setRight(max(orig.right() + dx, orig.left() + w.minimumWidth()))
        if "top" in mode:
            geom.setTop(min(orig.top() + dy, orig.bottom() - w.minimumHeight()))
        if "bottom" in mode:
            geom.setBottom(max(orig.bottom() + dy, orig.top() + w.minimumHeight()))
        w.setGeometry(geom)


def _install_chrome_frame(window, title_text, show_max, flags,
                          layout_host=None, main_window=False):
    window.setWindowFlags(flags)
    # V1.9.52 (user: snap "animation look" must match normal
    # programs; maximized showed wallpaper at the edges): on
    # Windows a translucent top-level becomes WS_EX_LAYERED,
    # and DWM withholds the snap transition animations from
    # layered windows. The rounded corners do not need it --
    # _sync_chrome_mask (V1.9.33) clips every chromed window to
    # its rounded region -- so on Windows the window stays a
    # normal opaque window and gets the full native behaviour.
    # Other platforms keep the translucent path they have.
    # V1.9.54 (user, image-467: "sharp black corners behind
    # the glass... you have a layer or something"): the layer
    # was this 1.9.52 change itself. An opaque window's backing
    # store is BLACK, and any frame that paints only its
    # rounded shape -- the Settings frost above all -- shows
    # that black through every corner triangle the mask does
    # not perfectly clip. Dialogs do not need snap animations,
    # so chromed DIALOGS are translucent on Windows again:
    # their corner triangles composite to nothing, mask or no
    # mask. The MAIN window (install_main_chrome passes
    # main_window=True) keeps the opaque path -- it is the
    # snap surface 1.9.52 was for, and its frame paints a
    # solid colour, so there is nothing foreign to show
    # through. Non-Windows platforms are unchanged.
    import sys as _sys
    if _sys.platform != "win32" or not main_window:
        window.setAttribute(Qt.WA_TranslucentBackground, True)
    window.setAttribute(Qt.WA_Hover, True)  # needed for resize hover cursors
    # V1.9.3: re-assert the app icon on the window AFTER setWindowFlags.
    # Changing flags can recreate the native window handle on Windows,
    # which may drop the taskbar icon association; re-applying the icon
    # here (after any handle recreation) keeps every chromed window —
    # main window and dialogs — pinned to the Task List icon.
    _app = QApplication.instance()
    if _app is not None:
        _icon = _app.windowIcon()
        if _icon is not None and not _icon.isNull():
            window.setWindowIcon(_icon)
    host = layout_host if layout_host is not None else window
    root = QVBoxLayout(host)
    root.setContentsMargins(CHROME_MARGIN, CHROME_MARGIN, CHROME_MARGIN, CHROME_MARGIN)
    root.setSpacing(0)
    frame = QFrame()
    frame.setObjectName("windowFrame")
    # v1.4.0 item 12: initialize the maximized property from the startup
    # state so a window that opens maximized starts square-cornered.
    frame.setProperty("squareCorners", bool(window.isMaximized()))
    root.addWidget(frame)
    frame_layout = QVBoxLayout(frame)
    frame_layout.setContentsMargins(0, 0, 0, 0)
    frame_layout.setSpacing(0)
    titlebar = TitleBar(window, title_text, show_max)
    frame_layout.addWidget(titlebar)
    window._chrome = {
        "root": root, "frame": frame, "titlebar": titlebar,
    }
    # V1.9.33: the window mask is the corner guarantee (see
    # _sync_chrome_mask) — installed here so EVERY chromed window
    # (main window + all dialogs) gets it, not just popups.
    window._chrome_mask_filter = _ChromeMaskFilter(window)
    window.installEventFilter(window._chrome_mask_filter)
    _sync_chrome_mask(window)
    window._chrome["resizer"] = WindowChrome(window)
    # Windows native chrome is disabled (enable_win_snap is a no-op):
    # pure Qt chrome avoids Windows fighting us with its own hit-testing.
    enable_win_snap(window)
    return frame_layout, titlebar


#: V1.9.10: px of breathing room kept between a bled scroll area's
#: scrollbar and the window frame's inner edge. The bleed used to park the
#: bar exactly ON the frame edge (user: "the scrollbar is right on the
#: edge of the window"); it now stops this far short of it — close to the
#: edge, clearly inside the window, never clipped by the frame.
SCROLLBAR_EDGE_GAP = 8


class _ScrollBleedLayout(QVBoxLayout):
    """QVBoxLayout whose direct-child scroll areas bleed to the right edge.

    The vertical scrollbar of a QScrollArea/QTableWidget sits at the scroll
    area's own right edge, but the chrome content layouts inset every dialog
    ~24px from the window frame — so the bar reads as floating ~1/4" left of
    the window's right edge. QSS cannot alter layout geometry, so this one
    shared layout extends each direct-child QAbstractScrollArea rightward
    through the layout's right content margin, parking the scrollbar near
    the frame's inner right edge. Every other child is laid out exactly
    like a plain QVBoxLayout.

    V1.9.10: the bleed stops SCROLLBAR_EDGE_GAP px short of the frame —
    flush against the window edge read as broken/clipped to the user.

    ``bleed_right`` overrides how far (px) scroll areas extend; the default
    is the layout's own right content margin minus SCROLLBAR_EDGE_GAP.
    """

    def __init__(self, parent=None, bleed_right=None):
        super().__init__(parent)
        self._bleed_right = bleed_right

    def setGeometry(self, rect):
        super().setGeometry(rect)
        bleed = self._bleed_right
        if bleed is None:
            bleed = max(0, self.contentsMargins().right() - SCROLLBAR_EDGE_GAP)
        if bleed <= 0:
            return
        for i in range(self.count()):
            item = self.itemAt(i)
            w = item.widget() if item is not None else None
            if isinstance(w, QAbstractScrollArea):
                g = w.geometry()
                w.setGeometry(g.x(), g.y(), g.width() + bleed, g.height())


def install_chrome(window, title_text, show_max=True):
    """Make a QDialog frameless with a custom title bar.

    Returns the content QVBoxLayout to build the dialog body into.
    """
    frame_layout, _ = _install_chrome_frame(
        window, title_text, show_max, Qt.Dialog | Qt.FramelessWindowHint
    )
    # Scroll-bleed content: any direct-child scroll area extends through
    # most of the right content margin so its vertical scrollbar sits near
    # the window frame's inner right edge (SCROLLBAR_EDGE_GAP short of it)
    # instead of floating in the content column. (QSS cannot move layout
    # geometry, so this is done in the one shared layout rather than per
    # dialog.)
    content = _ScrollBleedLayout()
    content.setContentsMargins(24, 14, 24, 18)
    content.setSpacing(8)
    frame_layout.addLayout(content)
    return content


def install_main_chrome(window, title_text):
    """Make the QMainWindow frameless with a custom title bar.

    Returns (content_layout, frame_layout); the caller inserts its menu bar
    as frame_layout item 1 (right under the title bar).
    """
    central = QWidget()
    central.setAttribute(Qt.WA_TranslucentBackground, True)
    window.setCentralWidget(central)
    # WindowMinimizeButtonHint/WindowMaximizeButtonHint set the native
    # WS_MINIMIZEBOX/WS_MAXIMIZEBOX style bits, which is what lets a click on
    # the taskbar icon minimize/restore the window like a normal window.
    # They draw nothing on a frameless window, so the custom chrome is
    # untouched. (Side-snapping needs WS_THICKFRAME, which fights the custom
    # Qt resize handling, so it stays off per the user's call.)
    frame_layout, _ = _install_chrome_frame(
        window, title_text, True,
        Qt.Window | Qt.FramelessWindowHint
        | Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint,
        layout_host=central, main_window=True,
    )
    # Plain layout here: the main window's direct children are the sidebar
    # pages, not scroll areas (nested scroll areas cannot bleed past their
    # page widget — child widgets clip at the parent's bounds). Dialogs use
    # _ScrollBleedLayout via install_chrome instead.
    content = QVBoxLayout()
    content.setContentsMargins(20, 12, 20, 16)
    content.setSpacing(10)
    frame_layout.addLayout(content)
    return content, frame_layout


# ------------------------------------------------- scroll content insets ----
#: Standard content insets (left, top, right, bottom, in px) for the content
#: widget of every QScrollArea in the app. One shared convention, applied
#: via set_scroll_content_margins(): no scroll-hosted content may sit within
#: a few px of the viewport edge or the vertical scrollbar, in either theme,
#: with the scrollbar shown or hidden. The 16px sides also keep the content
#: edge stable when the scrollbar appears/disappears (the right gap is the
#: same either way, so nothing reflows).
SCROLL_CONTENT_INSETS = (16, 12, 16, 12)

#: Floor (px) the padding sweep test (tests/test_v13_padding_sweep.py)
#: enforces between scroll-hosted content and the viewport/scrollbar edges.
#: The standard insets sit comfortably above it; any per-view tweak must
#: stay at or above it too.
MIN_SCROLL_CONTENT_INSET = 8


def set_scroll_content_margins(scroll_area, insets=SCROLL_CONTENT_INSETS):
    """Apply the app-wide scroll-content inset convention to a QScrollArea.

    Sets the contents margins of the scroll area's content-widget layout to
    *insets* (default SCROLL_CONTENT_INSETS), so children keep clear of the
    viewport edges and the vertical scrollbar whether the bar is shown or
    hidden. Creates the content widget / layout if missing. Returns the
    content widget. Spacing, stretches and alignments are left untouched.
    """
    content = scroll_area.widget()
    if content is None:
        content = QWidget(scroll_area)
        scroll_area.setWidget(content)
    layout = content.layout()
    if layout is None:
        layout = QVBoxLayout(content)
    layout.setContentsMargins(*insets)
    return content


def enable_touch_scroll(scrollable, mouse_drag=True):
    """Kinetic pen/finger scrolling for a scrollable view (Surface-friendly).

    Grabs QScroller's LeftMouseButtonGesture on the viewport: a press-drag
    scrolls with momentum, while a tap without dragging still clicks through
    normally. This one gesture covers all three inputs — the pen arrives as
    mouse events, and unhandled finger touches are synthesized into mouse
    events by Qt (AA_SynthesizeMouseForUnhandledTouchEvents).

    Only ONE gesture type can be active per viewport (a second grabGesture
    kills the first), so pass mouse_drag=False where the view already uses
    mouse-drag for something else (queue card dragging, attachment
    drag-out): those views get TouchGesture instead — finger drags scroll
    natively there, while pen/mouse drags keep their existing meaning.
    Accepts a QScrollArea (or any QAbstractScrollArea, e.g. a table — the
    gesture goes on its viewport).
    """
    # V1.9.68 (user: pen scrolling in list mode "SHOOTS TO THE
    # TOP AND BOTTOM"): QAbstractItemView defaults to
    # ScrollPerItem, where one scrollbar unit is a whole ROW --
    # but QScroller drags in PIXELS, so a 100px pen drag
    # scrolled ~100 rows, half the list in one drag (verified
    # on the bench: per-item 100px -> 100 rows; per-pixel
    # 100px -> 100px). Per-pixel mode makes the drag track
    # the pen 1:1, the way a chat scroll feels.
    if isinstance(scrollable, QAbstractItemView):
        try:
            scrollable.setVerticalScrollMode(
                QAbstractItemView.ScrollPerPixel)
            scrollable.setHorizontalScrollMode(
                QAbstractItemView.ScrollPerPixel)
            scrollable.verticalScrollBar().setSingleStep(28)
            scrollable.horizontalScrollBar().setSingleStep(28)
        except Exception:
            pass
    viewport = scrollable.viewport()
    if mouse_drag:
        QScroller.grabGesture(viewport, QScroller.LeftMouseButtonGesture)
    else:
        QScroller.grabGesture(viewport, QScroller.TouchGesture)
    _tune_scroller(viewport)


def _tune_scroller(viewport):
    """V1.9.65 (user: pen scrolling "SHOOTS TO THE BOTTOM OR
    THE TOP... NOT SMOOTH SCROLLING"): every scroller in the
    app ran Qt's STOCK QScrollerProperties, whose defaults are
    built for phone flicks -- most importantly
    AcceleratingFlickSpeedupFactor 3.0 (a repeat flick TRIPLES
    the velocity) with MaximumVelocity 0.5 m/s and
    DecelerationFactor 0.125, so one pen flick crosses a whole
    list. One tuned profile everywhere: no flick acceleration,
    smoothed drag velocity (a pen lift-off spike no longer
    becomes a launch), stronger deceleration, axis locking for
    mostly-vertical drags, and no overshoot past the ends."""
    from PySide6.QtWidgets import QScrollerProperties
    scroller = QScroller.scroller(viewport)
    if scroller is None:
        return
    M = QScrollerProperties.ScrollMetric
    props = scroller.scrollerProperties()
    # V1.9.68: tightened further (0.45/0.30/0.4 in 1.9.65 was
    # not enough on the real pen) -- with the drag itself now
    # 1:1 (per-pixel, above), these caps only bound the glide
    # after a flick: at most a short, gentle settle.
    props.setScrollMetric(M.MaximumVelocity, 0.22)
    props.setScrollMetric(M.DecelerationFactor, 0.60)
    props.setScrollMetric(M.DragVelocitySmoothingFactor, 0.7)
    props.setScrollMetric(M.AcceleratingFlickSpeedupFactor, 1.0)
    props.setScrollMetric(M.AcceleratingFlickMaximumTime, 0.0)
    props.setScrollMetric(M.AxisLockThreshold, 0.3)
    props.setScrollMetric(M.DragStartDistance, 0.004)
    props.setScrollMetric(
        M.VerticalOvershootPolicy,
        QScrollerProperties.OvershootPolicy.OvershootAlwaysOff)
    props.setScrollMetric(
        M.HorizontalOvershootPolicy,
        QScrollerProperties.OvershootPolicy.OvershootAlwaysOff)
    scroller.setScrollerProperties(props)


class _HWheelScroll(QObject):
    """V1.9.30 (user): a scrollbar-free horizontal strip -- hovering
    it and rolling the mouse wheel scrolls it sideways. When the
    strip's content fits, the wheel passes through untouched (the
    page scrolls as usual)."""

    def __init__(self, area):
        super().__init__(area)
        self._area = area

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Wheel:
            bar = self._area.horizontalScrollBar()
            if bar is not None and bar.maximum() > 0:
                delta = (event.angleDelta().y()
                         or event.angleDelta().x())
                if delta:
                    bar.setValue(bar.value() - delta)
                    event.accept()
                    return True
        return False


# ---------------------------------------------------------------- scope chips
def chip_font(widget):
    """Render chip/pill text with grayscale (not subpixel) antialiasing.

    Qt's default subpixel (ClearType-style) rendering tints glyph edges
    with red/blue fringes. On small light-on-dark chip labels this reads
    as a colored fringe/ghost around the text — most visible on the "Has
    attachments" chip and the quote pills. Grayscale antialiasing is
    subpixel-order independent, so chip text renders cleanly on any
    display.

    Targeted backstop for widgets whose font was set explicitly. The central
    mechanism is fonts.app_font(), applied once at the QApplication level in
    main(), which every chip/pill/label already inherits; this helper just
    re-asserts the strategy on the widget's own font for safety.
    """
    font = widget.font()
    font.setStyleStrategy(QFont.StyleStrategy.NoSubpixelAntialias)
    widget.setFont(font)


def _chip_font_tree(root):
    """Apply chip_font() to every text-bearing widget under `root`.

    V1.9.2 coverage sweep. The grayscale-AA strategy used to be applied
    per widget at a couple of dozen call sites, which left page titles,
    dialog/field labels, settings text, dashboard KPIs, notes labels and
    table headers unprotected — the "text artifacts everywhere" reports.
    Windows and pages call this at the end of setup so their whole
    subtree carries the strategy; widgets created later (dynamic rows,
    cards) call chip_font() in their own constructors as before.
    chip_font() only flips the style strategy on a copy of the widget's
    existing font, so sizes/weights/letter-spacing are preserved.
    """
    for cls in (QLabel, QAbstractButton, QComboBox, QListWidget,
                QHeaderView, QLineEdit, QTextEdit, QDateEdit):
        for w in root.findChildren(cls):
            chip_font(w)


class ToggleChip(QLabel):
    """QLabel-based checkable chip toggle.

    QPushButton text goes through QStyle, which on Windows can ignore the
    font's NoSubpixelAntialias strategy (see the "Has attachments" fringe
    regression). QLabel renders text directly with QPainter, which always
    respects the strategy — so this chip is guaranteed grayscale.

    API mirrors the QPushButton bits used by callers: setCheckable (no-op,
    always checkable), isChecked/setChecked, toggled signal, setToolTip,
    setCursor. Styled via QLabel#chipToggle in themes.py.
    """

    toggled = Signal(bool)

    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.setObjectName("chipToggle")
        self._checked = False
        self.setCursor(Qt.PointingHandCursor)
        chip_font(self)
        # QLabel centers via alignment; match the button's padding via QSS.
        self.setAlignment(Qt.AlignCenter)

    def isChecked(self):
        return self._checked

    def setChecked(self, checked):
        checked = bool(checked)
        if checked != self._checked:
            self._checked = checked
            self.setProperty("checked", checked)
            # Re-polish so the [checked="true"] QSS rule applies.
            self.style().unpolish(self)
            self.style().polish(self)
            self.toggled.emit(self._checked)

    def setCheckable(self, checkable):
        pass  # always checkable

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.setChecked(not self._checked)
            event.accept()
        else:
            super().mousePressEvent(event)


class ToggleSwitch(QAbstractButton):
    """A real on/off switch: rounded track, sliding knob, accent when on.

    V1.9.16 (user request): the "Has attachments" filter was a chip
    button; he asked for a proper toggle, toggle preferred over a
    checkbox. QAbstractButton supplies the checkable API callers use
    (isChecked/setChecked, toggled, Space to toggle, focus) — this class
    only paints: a 46x26 track, gray when off, theme accent when on,
    white knob sliding between the ends, focus ring on keyboard focus.
    Colors follow the saved theme at paint time, so a theme change
    applies without a restart. V1.9.17: the knob animates (140ms
    ease-out) instead of snapping — the same sliding treatment as the
    segmented controls, applied to every toggle.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self._knob_t = 0.0
        self._knob_anim = QPropertyAnimation(self, b"knob_t")
        self._knob_anim.setDuration(140)
        self._knob_anim.setEasingCurve(QEasingCurve.OutCubic)
        self.toggled.connect(self._animate_knob)

    def _get_knob_t(self):
        return self._knob_t

    def _set_knob_t(self, value):
        self._knob_t = float(value)
        self.update()

    knob_t = Property(float, _get_knob_t, _set_knob_t)

    def _animate_knob(self, on):
        target = 1.0 if on else 0.0
        if not self.isVisible():
            self._knob_t = target
            self.update()
            return
        self._knob_anim.stop()
        self._knob_anim.setStartValue(self._knob_t)
        self._knob_anim.setEndValue(target)
        self._knob_anim.start()

    def sizeHint(self):  # noqa: N802 (Qt virtual)
        return QSize(46, 26)

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        dark = saved_theme() != "light"
        on = self.isChecked()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = self.rect().adjusted(1, 1, -1, -1)
        track = QColor("#2f6fed" if dark else "#2563eb") if on else \
            QColor("#3a3e47" if dark else "#c9ced6")
        p.setPen(Qt.NoPen)
        p.setBrush(track)
        p.drawRoundedRect(rect, 12, 12)
        knob_d = rect.height() - 6
        left = rect.left() + 3
        right = rect.right() - 3 - knob_d
        knob_x = int(round(left + (right - left) * self._knob_t))
        p.setBrush(QColor("#ffffff"))
        p.drawEllipse(knob_x, rect.top() + 3, knob_d, knob_d)
        if self.hasFocus():
            p.setPen(QPen(QColor("#2f6fed" if dark else "#2563eb"), 1))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(rect.adjusted(-1, -1, 1, 1), 13, 13)


class AccentSwatch(QAbstractButton):
    """Circular accent-color swatch, painted — never a stylesheet.

    V1.9.16: the old QPushButton swatches set their color via
    setStyleSheet, and Qt leaks a hovered widget's own stylesheet into
    its tooltip — hovering Teal showed a bright-teal tooltip box (with
    square window corners behind its rounded paint). Painting the
    circle keeps tooltips on the theme's tooltip style, and a painted
    circle is round by construction. The ring marks the current accent.
    """

    def __init__(self, hexv, parent=None):
        super().__init__(parent)
        self._hexv = hexv
        self.setCheckable(True)
        self.setFixedSize(22, 22)
        self.setCursor(Qt.PointingHandCursor)

    def sizeHint(self):  # noqa: N802 (Qt virtual)
        return QSize(22, 22)

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        dark = saved_theme() != "light"
        rect = self.rect().adjusted(1, 1, -1, -1)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(self._hexv))
        p.drawEllipse(rect)
        if self.isChecked():
            ring = QColor("#f4f5f7" if dark else "#1c1f24")
        else:
            ring = QColor(127, 127, 127, 89)
        p.setPen(QPen(ring, 2))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(rect.adjusted(1, 1, -1, -1))


class PainterTextButton(QPushButton):
    """QPushButton that paints its label text itself (QPainter) instead of
    letting QStyle draw it.

    On Windows, QStyle button text can ignore the font's
    NoSubpixelAntialias strategy and render with ClearType fringes — the
    same finding that produced ToggleChip. Here the stylesheet still
    paints the button's background/border/state via the normal style pass
    (with an empty label), then the text is drawn with QPainter using the
    widget's own font, which always honors the strategy.

    All button behavior (checkable state, signals, menus, drag) is
    untouched — only the text rasterizer changes. Text color comes from
    the widget palette: the stylesheet style keeps palette ButtonText in
    sync with property-based rules such as [statusState=...]. Colors that
    depend on pseudo-states (:checked/:hover), which the palette does
    not track, are resolved by overriding _painter_text_color().
    """

    def _painter_text_color(self):
        group = (QPalette.Active if self.isEnabled()
                 else QPalette.Disabled)
        return self.palette().color(group, QPalette.ButtonText)

    def paintEvent(self, event):
        opt = QStyleOptionButton()
        self.initStyleOption(opt)
        text = opt.text
        icon = opt.icon
        opt.text = ""
        opt.icon = QIcon()
        painter = QStylePainter(self)
        painter.drawControl(QStyle.CE_PushButton, opt)
        has_icon = icon is not None and not icon.isNull()
        if not text and not has_icon:
            return
        rect = self.style().subElementRect(
            QStyle.SE_PushButtonContents, opt, self)
        painter.setFont(self.font())
        painter.setPen(self._painter_text_color())
        if has_icon:
            isize = self.iconSize()
            iy = rect.center().y() - isize.height() // 2
            mode = QIcon.Normal if self.isEnabled() else QIcon.Disabled
            icon.paint(painter, rect.left(), iy,
                       isize.width(), isize.height(),
                       Qt.AlignCenter, mode, QIcon.Off)
            rect = rect.adjusted(isize.width() + 4, 0, 0, 0)
        if text:
            # Match QStyle mnemonic handling: a lone & marks a shortcut
            # (not drawn), && draws one literal &.
            display = (text.replace("&&", "\x00")
                       .replace("&", "").replace("\x00", "&"))
            self._draw_text(painter, rect, display)

    def _draw_text(self, painter, rect, display):
        painter.drawText(rect, Qt.AlignCenter | Qt.TextSingleLine,
                         display)


# #seg text colors per theme/state. QPushButton#seg in themes.py colors
# text via :checked/:hover pseudo-states, which the widget palette does
# not track, so SegButton resolves the painter color itself. These values
# mirror the #seg rules in themes.py (including the [attention="true"]
# variants) — keep the two in sync.
_SEG_TEXT = {
    "dark": {"base": "#9ba1ab", "hover": "#d5d9e0", "checked": "#ffffff",
             "attn": "#ef9a9a", "attn_hover": "#ffb4b4",
             "attn_checked": "#ffc9c9"},
    "light": {"base": "#474c54", "hover": "#272b33", "checked": "#1d4ed8",
              "attn": "#b42318", "attn_hover": "#912018",
              "attn_checked": "#912018"},
}


class SegButton(PainterTextButton):
    """Segmented filter chip (objectName "seg") with painter-drawn text.

    Behavior is a stock checkable QPushButton (QButtonGroup exclusivity
    and clicked signals unchanged); only the text rasterizer and its
    color resolution differ. Cascade mirrors the stylesheet: checked
    beats hover, attention beats both.
    """

    def _draw_text(self, painter, rect, display):
        # V1.9.18 (user report: "Overdue (2)" text not centered):
        # AlignCenter centers the font's LINE box, which reserves
        # descender space these labels never use — so no-descender
        # labels sat ~1.5px low (measured on Inter). Center the actual
        # ink instead, from tightBoundingRect: work out where
        # AlignCenter would put the baseline, where the ink center
        # lands from it, and shift by the difference. Per-string, so
        # "In Progress" (descender) and column names shift by their
        # own correct amount (near zero), not by a fixed guess.
        try:
            fm = painter.fontMetrics()
            tight = fm.tightBoundingRect(display)
            base_x = rect.left() + (rect.width()
                                    - fm.horizontalAdvance(display)) / 2
            base_y = rect.top() + (rect.height() - fm.height()) / 2 \
                + fm.ascent()
            ink_cx = base_x + tight.x() + tight.width() / 2
            ink_cy = base_y + tight.y() + tight.height() / 2
            # V1.9.47 (user: the seg labels read shifted UP):
            # measured on a render, the ink still landed 1.0px
            # above the button centre -- the round() here plus
            # drawText's own baseline rounding each eat half a
            # pixel the same way. +1 puts the ink dead centre.
            rect = rect.translated(
                round(rect.center().x() - ink_cx),
                round(rect.center().y() - ink_cy) + 1)
        except Exception:
            pass
        painter.drawText(rect, Qt.AlignCenter | Qt.TextSingleLine,
                         display)

    def _painter_text_color(self):
        table = _SEG_TEXT["light" if saved_theme() == "light" else "dark"]
        if bool(self.property("attention")):
            if self.isChecked():
                return QColor(table["attn_checked"])
            if self.isEnabled() and self.underMouse():
                return QColor(table["attn_hover"])
            return QColor(table["attn"])
        if self.isChecked():
            return QColor(table["checked"])
        if self.isEnabled() and self.underMouse():
            return QColor(table["hover"])
        return QColor(table["base"])


class _SegPill(QWidget):
    """Sliding pill behind an AnimatedSegControl's buttons."""

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        dark = saved_theme() != "light"
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#23252b" if dark else "#ffffff"))
        p.drawRoundedRect(self.rect(), 8, 8)


class AnimatedSegControl(QFrame):
    """Segmented switch whose highlight SLIDES between options.

    V1.9.17 (user report): switching segments flashed the highlight
    from one option to the other; he wants a clean sliding animation,
    done globally for selections like this. The pill is a real child
    widget behind the buttons; on selection it animates its geometry
    (180ms ease-out) to the newly checked button. Buttons keep their
    SegButton text colors; their checked background is forced
    transparent so only the sliding pill shows. API mirrors the old
    segBar + QButtonGroup construction: ``.buttons`` maps keys to
    buttons, and checking a button (by click or setChecked) moves the
    pill.
    """

    def __init__(self, items, parent=None):
        super().__init__(parent)
        self.setObjectName("segBar")
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(2)
        self._pill = _SegPill(self)
        self._pill.lower()
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self.buttons = {}
        for key, label in items:
            btn = SegButton(label)
            btn.setObjectName("seg")
            btn.setCheckable(True)
            chip_font(btn)
            btn.setCursor(Qt.PointingHandCursor)
            # Transparent checked background: the pill IS the highlight.
            btn.setStyleSheet(
                "QPushButton#seg:checked { background: transparent; }")
            btn.toggled.connect(self._on_toggled)
            self._group.addButton(btn)
            lay.addWidget(btn)
            self.buttons[key] = btn
        self._anim = QPropertyAnimation(self._pill, b"geometry")
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._current_key = None

    def _on_toggled(self, checked):
        if not checked:
            return
        btn = self.sender()
        key = next((k for k, b in self.buttons.items() if b is btn), None)
        if key is None:
            return
        self._current_key = key
        self._move_pill(btn.geometry(), animate=self.isVisible())

    def _move_pill(self, rect, animate=True):
        if rect.isEmpty():
            return
        if not animate:
            self._anim.stop()
            self._pill.setGeometry(rect)
            return
        self._anim.stop()
        self._anim.setStartValue(self._pill.geometry())
        self._anim.setEndValue(rect)
        self._anim.start()

    def set_checked(self, key):
        btn = self.buttons.get(key)
        if btn is not None:
            btn.setChecked(True)

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # Layout shifts (window resize, font change): snap, don't slide.
        if self._current_key is not None:
            btn = self.buttons.get(self._current_key)
            if btn is not None:
                self._pill.setGeometry(btn.geometry())

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        # First show: pill snaps to the checked button (no slide-in).
        for key, btn in self.buttons.items():
            if btn.isChecked():
                self._current_key = key
                self._pill.setGeometry(btn.geometry())
                break


class _PillWidget(QWidget):
    """Plain rounded-rect pill with caller-chosen theme colors.

    V1.9.47: an outline mode -- a 1px rounded-rect stroke instead
    of a fill (the notes scope selection, per the user's
    outline-only ruling for selection states)."""

    def __init__(self, parent, dark_bg, light_bg, radius=8,
                 outline=False):
        super().__init__(parent)
        self._dark_bg = dark_bg
        self._light_bg = light_bg
        self._radius = radius
        self._outline = outline

    def set_backgrounds(self, dark_bg, light_bg):
        self._dark_bg = dark_bg
        self._light_bg = light_bg
        self.update()

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        dark = saved_theme() != "light"
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        col = QColor(self._dark_bg if dark else self._light_bg)
        if self._outline:
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(col, 1))
            p.drawRoundedRect(
                QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
                self._radius, self._radius)
        else:
            p.setPen(Qt.NoPen)
            p.setBrush(col)
            p.drawRoundedRect(self.rect(), self._radius, self._radius)


class _SlidingButtonPill(QObject):
    """Sliding highlight behind an existing group of checkable buttons.

    V1.9.18 (user order: sliding selections everywhere): the
    AnimatedSegControl treatment generalized to button groups that
    already live in a layout — notes scope buttons (vertical),
    settings nav (vertical), filter chips (horizontal). The pill is
    a real child of the buttons' parent, lowered behind them; on
    toggle it animates its geometry (180ms ease-out) to the newly
    checked button. Buttons keep their QSS text colors; only their
    checked background goes transparent, so the pill IS the highlight.
    Parent resizes snap, never slide. Buttons may be added later via
    add_button (filter chips arrive after their strip is built).
    """

    def __init__(self, parent, buttons, dark_bg, light_bg, radius=8,
                 object_name=None, attn_dark_bg=None, attn_light_bg=None,
                 outline=False):
        super().__init__(parent)
        self._parent = parent
        self._dark_bg = dark_bg
        self._light_bg = light_bg
        self._attn_dark_bg = attn_dark_bg
        self._attn_light_bg = attn_light_bg
        self._pill = _PillWidget(parent, dark_bg, light_bg, radius,
                                 outline=outline)
        self._pill.lower()
        self._anim = QPropertyAnimation(self._pill, b"geometry")
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._object_name = object_name
        self._buttons = []
        for btn in buttons:
            self.add_button(btn)
        parent.installEventFilter(self)
        QTimer.singleShot(0, self.snap)

    def add_button(self, btn):
        if btn in self._buttons:
            return
        self._buttons.append(btn)
        if self._object_name:
            # The pill IS the checked highlight. The attention variant
            # matters: #seg[attention="true"]:checked has its own
            # background that would otherwise cover the pill on
            # attention chips (Overdue), hiding the slide.
            btn.setStyleSheet(
                f"QPushButton#{self._object_name}:checked "
                "{ background: transparent; } "
                f"QPushButton#{self._object_name}[attention=\"true\"]"
                ":checked { background: transparent; }")
        btn.toggled.connect(self._on_toggled)

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        if obj is self._parent and event.type() == QEvent.Resize:
            self.snap()
        return super().eventFilter(obj, event)

    def _backgrounds_for(self, btn):
        # V1.9.18 fix: the attention chip (Overdue) has its own checked
        # background (red-tinted) — a single pill color for every chip
        # would silently erase it. The pill takes the attention colors
        # when the checked button carries the attention property.
        if (btn is not None and bool(btn.property("attention"))
                and self._attn_dark_bg is not None):
            return self._attn_dark_bg, self._attn_light_bg
        return self._dark_bg, self._light_bg

    def _on_toggled(self, checked):
        if not checked:
            return
        btn = self.sender()
        if btn is None:
            return
        dark_bg, light_bg = self._backgrounds_for(btn)
        self._pill.set_backgrounds(dark_bg, light_bg)
        self._move_pill(btn.geometry(), animate=self._parent.isVisible())

    def _move_pill(self, rect, animate=True):
        if rect.isEmpty():
            return
        if not animate:
            self._anim.stop()
            self._pill.setGeometry(rect)
            return
        self._anim.stop()
        self._anim.setStartValue(self._pill.geometry())
        self._anim.setEndValue(rect)
        self._anim.start()

    def snap(self):
        for btn in self._buttons:
            if btn.isChecked():
                dark_bg, light_bg = self._backgrounds_for(btn)
                self._pill.set_backgrounds(dark_bg, light_bg)
                self._pill.setGeometry(btn.geometry())
                return


def _opaque_pixmap(pix, bg):
    """Return an opaque copy of ``pix`` composited over ``bg``."""
    out = QPixmap(pix.size())
    out.fill(bg)
    painter = QPainter(out)
    painter.drawPixmap(0, 0, pix)
    painter.end()
    return out


def grab_without_scrollbars(widget):
    """widget.grab() with every scrollbar inside it hidden.

    V1.9.37 (user): page grabs feed the slide_swap transition, and
    a scrollbar baked into a snapshot streaks across the screen as
    the slide moves -- it reads as the scrollbar itself flying
    sideways. Hide the bars for the grab and restore them right
    after; the grab is synchronous, so the live UI never flickers.
    """
    bars = []
    areas = []
    if isinstance(widget, QAbstractScrollArea):
        areas.append(widget)
    areas += widget.findChildren(QAbstractScrollArea)
    for area in areas:
        for bar in (area.verticalScrollBar(),
                    area.horizontalScrollBar()):
            if bar is not None and bar.isVisible():
                bars.append(bar)
                bar.setVisible(False)
    try:
        return widget.grab()
    finally:
        for bar in bars:
            bar.setVisible(True)


def slide_swap(parent, rect, old_pix, new_pix, duration=250):
    """Cross-slide a content change: old slides left out, new in from right.

    V1.9.18 (user order): filter/tab/kind switches must slide, not
    flash. Callers grab the old snapshot, perform the switch, grab the
    new snapshot, then call this with both pixmaps over the content
    rect (in parent coordinates). Two opaque overlays cover the live
    content for the slide, so no half-built frame ever shows; on
    finish the overlays delete, revealing live content identical to
    the new snapshot, so the handoff is invisible. No-op when either
    snapshot is missing or the rect is empty.
    """
    if parent is None or rect.isEmpty():
        return
    if old_pix is None or new_pix is None:
        return
    if old_pix.isNull() or new_pix.isNull():
        return
    size = rect.size()
    if old_pix.size() != size:
        old_pix = old_pix.scaled(size, Qt.IgnoreAspectRatio,
                                 Qt.SmoothTransformation)
    if new_pix.size() != size:
        new_pix = new_pix.scaled(size, Qt.IgnoreAspectRatio,
                                 Qt.SmoothTransformation)
    # V1.9.27: page grabs carry transparent regions (pages paint no
    # background of their own), and during the slide those regions
    # showed the default light widget background behind the tab
    # pages. Composite both snapshots onto the opaque dashboard
    # background first, so the slide can only ever show theme colors.
    bg = QColor("#0b0c0e" if saved_theme() != "light" else "#f5f5f6")
    old_pix = _opaque_pixmap(old_pix, bg)
    new_pix = _opaque_pixmap(new_pix, bg)
    # V1.9.18 fix (v1917 regression: CRM double-click stopped opening
    # cards): the overlays covered the live content for the slide's
    # 250ms and swallowed clicks. Click-through, so a click during a
    # slide acts on the live new content underneath (identical to the
    # new snapshot, so the handoff stays invisible).
    # V1.9.51: a switch landing mid-slide used to stack a SECOND
    # pair of overlays over the still-animating first pair -- two
    # slides fighting read as the "visually glitchy" bounce the
    # user reported on tab switches. Retire any live pair on this
    # parent first; the new slide is the only motion on screen.
    for stale in parent.findChildren(
            QLabel, options=Qt.FindDirectChildrenOnly):
        if stale.property("_slide_swap_overlay"):
            stale.hide()
            stale.deleteLater()
    old_lab = QLabel(parent)
    old_lab.setProperty("_slide_swap_overlay", True)
    old_lab.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    old_lab.setPixmap(old_pix)
    old_lab.setGeometry(rect)
    old_lab.show()
    old_lab.raise_()
    new_lab = QLabel(parent)
    new_lab.setProperty("_slide_swap_overlay", True)
    new_lab.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    new_lab.setPixmap(new_pix)
    new_lab.setGeometry(rect.translated(rect.width(), 0))
    new_lab.show()
    new_lab.raise_()
    anim_old = QPropertyAnimation(old_lab, b"geometry", old_lab)
    anim_old.setDuration(duration)
    anim_old.setEasingCurve(QEasingCurve.OutCubic)
    anim_old.setStartValue(rect)
    anim_old.setEndValue(rect.translated(-rect.width(), 0))
    anim_new = QPropertyAnimation(new_lab, b"geometry", new_lab)
    anim_new.setDuration(duration)
    anim_new.setEasingCurve(QEasingCurve.OutCubic)
    anim_new.setStartValue(rect.translated(rect.width(), 0))
    anim_new.setEndValue(rect)

    def _cleanup():
        # V1.9.51: a newer slide may have already retired this
        # pair (see above); deleting a dead label must not raise.
        for lab in (old_lab, new_lab):
            try:
                lab.deleteLater()
            except RuntimeError:
                pass

    anim_new.finished.connect(_cleanup)
    anim_old.start()
    anim_new.start()


class FlowLayout(QLayout):
    """Left-to-right layout that WRAPS to a second row when the row
    runs out of width (the classic Qt flow pattern).

    V1.9.36 (user: "Can't see all the options?" -- the task-list
    filter toolbar is one QHBoxLayout holding the status chips,
    Outcome, Scope, Has attachments, Sort and Search; below ~1600px
    the fixed items alone exceed the row, so the box layout let the
    tail -- Sort, then Search -- fall off the window's right edge,
    invisible). In a flow layout nothing is ever pushed off-screen:
    items that do not fit wrap to the next row, and a shrinkable
    item wider than the row (the chip strip) is capped at the row
    width and scrolls internally as designed. At desktop widths
    everything sits on one row exactly as before.
    """

    def __init__(self, parent=None, h_spacing=10, v_spacing=8):
        super().__init__(parent)
        self._h = h_spacing
        self._v = v_spacing
        self._items = []

    def addItem(self, item):  # noqa: N802 (Qt name)
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):  # noqa: N802 (Qt name)
        if 0 <= index < len(self._items):
            return self._items[index]
        return None

    def takeAt(self, index):  # noqa: N802 (Qt name)
        if 0 <= index < len(self._items):
            return self._items.pop(index)
        return None

    def expandingDirections(self):  # noqa: N802 (Qt name)
        return Qt.Orientations()

    def hasHeightForWidth(self):  # noqa: N802 (Qt name)
        return True

    def heightForWidth(self, width):  # noqa: N802 (Qt name)
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect):  # noqa: N802 (Qt name)
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)

    def sizeHint(self):  # noqa: N802 (Qt name)
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.sizeHint())
        m = self.contentsMargins()
        return QSize(size.width() + m.left() + m.right(),
                     size.height() + m.top() + m.bottom())

    def minimumSize(self):  # noqa: N802 (Qt name)
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        m = self.contentsMargins()
        return QSize(size.width() + m.left() + m.right(),
                     size.height() + m.top() + m.bottom())

    @staticmethod
    def _is_spring(item):
        return item.spacerItem() is not None

    def _do_layout(self, rect, test_only):
        m = self.contentsMargins()
        eff = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        avail = eff.width()
        items = list(self._items)
        if not items:
            return m.top() + m.bottom()
        widths = [0 if self._is_spring(it) else it.sizeHint().width()
                  for it in items]
        mins = [0 if self._is_spring(it) else it.minimumSize().width()
                for it in items]
        heights = [it.sizeHint().height() for it in items]

        def _total(ws):
            return sum(ws) + self._h * (len(ws) - 1)

        # One row ONLY if it fits at natural widths. V1.9.37: the
        # shrink-to-fit cascade is GONE -- on the user's machine it
        # squeezed the chip strip until chips were sliced mid-word
        # ("Cance...") with no wrap and no visible scroll, which read
        # as broken. Wrapping to a second row beats crushing a
        # control, every time: nothing is ever cut off.
        if _total(widths) <= avail:
            rows = [list(range(len(items)))]
        else:
            # Even fully shrunk it cannot fit: wrap. Shrinkable
            # items go back to their hints (capped at the row width,
            # where they scroll internally as designed).
            widths = [0 if self._is_spring(it)
                      else min(it.sizeHint().width(),
                               max(it.minimumSize().width(), avail))
                      if it.sizeHint().width() > avail
                      else it.sizeHint().width()
                      for it in items]
            rows = []
            row = []
            row_w = 0
            for i in range(len(items)):
                w = widths[i]
                add = w if not row else w + self._h
                if row and row_w + add > avail:
                    rows.append(row)
                    row, row_w = [], 0
                    add = w
                row.append(i)
                row_w += add
            if row:
                rows.append(row)
        spring_idx = next(
            (i for i, it in enumerate(items) if self._is_spring(it)),
            None)
        y = eff.y()
        for row in rows:
            used = sum(widths[i] for i in row) + self._h * (len(row) - 1)
            springs = [i for i in row if self._is_spring(items[i])]
            leftover = max(0, avail - used)
            line_h = max((heights[i] for i in row), default=0)
            x = eff.x()
            if not springs and spring_idx is not None and row \
                    and min(row) > spring_idx:
                # The post-spring group wrapped onto its own row:
                # keep it right-aligned (Search belongs under the
                # header's right edge, not orphaned at the left).
                x += leftover
            for i in row:
                w = widths[i]
                if self._is_spring(items[i]) and springs:
                    w = leftover // len(springs)
                if not test_only:
                    # Centre each item vertically in the line, so a
                    # short control (the attachments toggle) aligns
                    # with the combos instead of riding the top.
                    iy = y + (line_h - heights[i]) // 2
                    items[i].setGeometry(
                        QRect(QPoint(x, iy), QSize(w, heights[i])))
                x += w + self._h
            y += line_h + self._v
        return y - self._v - rect.y() + m.bottom()


# ------------------------------------------------- chip strip (scrollable row)
_CHIP_STRIP_MIN_W = 120   # narrowest the strip shrinks to before scrolling


class ChipStrip(QFrame):
    """Horizontally scrollable row of seg-style filter chips.

    Replaces a fixed-width segBar frame: the strip reports the full
    content width as its size hint but shrinks (down to a small minimum)
    when the layout gets narrow, scrolling horizontally instead of
    cramming/clipping chip text. Chips keep their natural size at every
    width -- text is never squeezed.

    Details:
    - objectName stays "segBar" so the existing per-theme QSS (background,
      border, radius) applies unchanged; chips keep objectName "seg".
    - Both scrollbars are hidden; trackpad / horizontal mouse-wheel still
      scroll natively, and arrow keys work when the strip has focus.
    - V1.9.29 (user screenshot): the old gradient edge fades are
      REMOVED -- the right fade painted a translucent wash over the
      last visible chip ("Needs attention" in his shot) that read as
      fog over the chip, not as a scroll hint. Chips now clip cleanly
      at the strip's edge; nothing paints over them.
    - The inner content widget is NOT widget-resized: it is kept at its
      layout's size hint (via LayoutRequest), so chip labels re-flowing
      (e.g. counts changing on refresh) can never be clipped inside.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("segBar")
        # V1.9.18 (user report): the bar stretched far past the last
        # chip. Preferred lets a layout grow the strip past its
        # content once the expanding search field hits its maximum
        # width; Maximum caps the strip at its content width, so the
        # bar hugs the chips. Shrinking below content still works
        # (minimumSizeHint) and scrolls instead of cramming.
        self.setSizePolicy(QSizePolicy(QSizePolicy.Maximum,
                                       QSizePolicy.Fixed))
        self._chip_pill = None

        self._scroll = QScrollArea(self)
        self._scroll.setFrameShape(QFrame.NoFrame)
        # V1.9.37 (user): when the strip genuinely cannot fit -- the
        # small Surface screen is the case he named -- a horizontal
        # scrollbar APPEARS so every chip stays reachable. At normal
        # widths nothing changes: the bar stays hidden, the strip
        # looks exactly as before. resizeEvent grows the strip's
        # hinted height by the bar's height while it is shown, so
        # the chips are never vertically cropped by it.
        self._hbar_extra = 0
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setWidgetResizable(False)
        # App-wide QSS already makes QScrollArea (and its QWidget children)
        # borderless and transparent, so the segBar background shows through.

        self._content = QWidget()
        self.chips_layout = QHBoxLayout(self._content)
        self.chips_layout.setContentsMargins(4, 4, 4, 4)
        self.chips_layout.setSpacing(2)
        self._scroll.setWidget(self._content)
        self._content.installEventFilter(self)
        # Finger/pen drag scrolls the chip row (chips are plain buttons,
        # no drag interactions to protect).
        enable_touch_scroll(self._scroll)

        fill = QHBoxLayout(self)
        fill.setContentsMargins(0, 0, 0, 0)
        fill.setSpacing(0)
        fill.addWidget(self._scroll)

        self._fit_content()

    # ---- content sizing: never let the layout squeeze the chips ----
    def eventFilter(self, obj, event):
        if obj is self._content and event.type() == QEvent.LayoutRequest:
            self._fit_content()
        if obj is self._content and event.type() == QEvent.ChildAdded:
            # V1.9.18: filter chips arrive after the strip is built
            # (the main page adds SegButtons to chips_layout). Give
            # every chip the sliding pill: the pill IS the checked
            # highlight, so chip switches slide like the CRM segments.
            child = event.child()
            if isinstance(child, SegButton):
                if self._chip_pill is None:
                    self._chip_pill = _SlidingButtonPill(
                        self._content, [], "#23252b", "#ffffff",
                        radius=8, object_name="seg",
                        attn_dark_bg="#3a2224", attn_light_bg="#ececee")
                self._chip_pill.add_button(child)
        return super().eventFilter(obj, event)

    def _fit_content(self):
        hint = self._content.sizeHint()
        if self._content.size() != hint:
            self._content.resize(hint)
        self._update_hbar_extra()
        self.updateGeometry()

    def _update_hbar_extra(self):
        # The scrollbar's height joins the strip's hinted height
        # only while the content genuinely overflows the viewport
        # (see the V1.9.37 note at the scroll area's creation).
        # Runs from resizeEvent AND from _fit_content: chips added
        # after the strip was placed change the overflow without
        # the strip itself resizing.
        if not hasattr(self, "_scroll"):
            return
        need = self._content.width() > self._scroll.viewport().width()
        extra = (self._scroll.horizontalScrollBar().sizeHint().height()
                 if need else 0)
        if extra != self._hbar_extra:
            self._hbar_extra = extra
            self.updateGeometry()

    # ---- geometry: ask for the full row, shrink gracefully ----
    def _frame_extra(self):
        # The QSS border (1px each side) is NOT part of the content's
        # hint. Omitting it made the strip 2px shorter than its
        # content, and the scroll area top-anchored the overflow --
        # chips rendered with a 4px gap on top and 2px on the bottom
        # (measured on the user's screenshot, V1.9.30 report).
        fw = self.frameWidth()
        return 2 * fw if fw > 0 else 2

    def sizeHint(self):
        s = self._content.sizeHint()
        e = self._frame_extra()
        return QSize(s.width() + e, s.height() + e + self._hbar_extra)

    def minimumSizeHint(self):
        s = self._content.sizeHint()
        e = self._frame_extra()
        return QSize(min(_CHIP_STRIP_MIN_W, s.width()) + e,
                     s.height() + e + self._hbar_extra)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_hbar_extra()

    def refresh_theme(self):
        # Kept for caller compatibility (app calls this after a theme
        # switch). The strip has no painted chrome of its own since
        # the V1.9.29 fade removal — the QSS restyles the frame and
        # chips automatically, so there is nothing to recolour.
        return None

    # ---- small accessors for tests ----
    def scroll_area(self):
        return self._scroll


# ------------------------------------------------- corner quote pill (shared)
# Card corner radii — must match the QFrame#card / QFrame#queueCard
# border-radius values in themes.py (identical in both themes).
CARD_RADIUS = 14
QUEUE_CARD_RADIUS = 12
# Bottom-right tab radius of the corner quote pill — mirrors the
# border-bottom-right-radius in the QLabel#queueQuote theme rules
# (identical in both themes). The pill's top-left radius always equals
# the card's own corner radius (concentric arcs); top-right and
# bottom-left stay square (folder-tab look).
PILL_TAB_RADIUS = 11


def make_corner_quote_pill(quote_number, card_radius):
    """Corner-tab quote pill shared by every task card in every module.

    Geometry contract (V1.9.31): the pill sits AT the card's (0, 0) and
    paints the corner itself — an outer tab path in the card's current
    border color (radius = the card's corner radius) and the blue tab
    inset by exactly 1px inside it (radius − 1, same arc center). One
    painter owns the whole corner, so the border arc and the blue arc
    are concentric BY CONSTRUCTION on every platform. The previous
    design let the QSS border arc and the pill's painted arc meet at
    the corner, and on Windows they rasterize differently — the user
    kept photographing the mismatch ("the outline of the corners is
    still not perfect so the blue doesn't look correct"). The right
    edge runs straight up to the card's top edge like a folder tab —
    radius ONLY on the pill's bottom-right corner.
    Pill text renders through chip_font() (grayscale AA).
    """
    return _CornerQuotePill(quote_number, card_radius)


def _place_corner_pill(card, pill, header):
    """Position a corner quote pill as a direct card child at (0, 0).

    The pill's widget is 1px wider/taller than its text hint: the extra
    ring is where it paints the card's border arc (see
    make_corner_quote_pill). It must be a direct child (not in the
    header layout) so it can paint over the header area; the header
    reserves the pill's full footprint with a leading spacer so rack
    tags/buttons keep their seats.
    """
    pill.setParent(card)
    pill.sync_border_state(card)
    hint = pill.sizeHint()
    pill.setGeometry(0, 0, hint.width() + 1, hint.height() + 1)
    header.addSpacing(hint.width() + 1)


class _CornerQuotePill(QLabel):
    """Folder-tab quote pill that paints the card's whole corner.

    V1.9.31 (user: "the outline of the corners is still not perfect so
    the blue doesn't look correct"): the pill sits at the card's (0, 0)
    and paints BOTH arcs itself — the card's border arc (outer tab
    path, radius = card radius, in the card's live border color:
    normal / hover / hot, parsed from the same QSS rules the card
    uses) and the blue tab inset 1px inside it (radius − 1, identical
    arc center). QSS and QPainter rasterize arcs differently on
    Windows, which is why every two-renderer version of this corner
    mismatched; with one painter the arcs are concentric by
    construction. Top-right and bottom-left stay square; bottom-right
    radius == PILL_TAB_RADIUS (folder-tab look).

    Text styling (color/size/padding) still comes from the
    ``QLabel#queueQuote`` theme rules; the theme's square background is
    neutralized with a widget-level ``background: transparent`` and the
    fill is painted here from the theme's pill color (re-read from the
    live application stylesheet, so theme switches apply instantly).
    The 1px contents margin keeps the text exactly where it sat when
    the widget was only the blue area.
    """

    _bg_cache = {}
    _border_cache = {}

    def __init__(self, quote_number, card_radius, parent=None):
        super().__init__(esc_plain(str(quote_number)), parent)
        self.setObjectName("queueQuote")
        self._card_radius = int(card_radius)
        self._border_hot = False
        self._border_hover = False
        # Neutralize the theme's square background; the folder-tab fill
        # is painted in paintEvent (see the class docstring).
        self.setStyleSheet("background: transparent;")
        self.setContentsMargins(1, 1, 0, 0)
        chip_font(self)

    # ---------------------------------------------------- border state
    def sync_border_state(self, card):
        """Pull the border state from the card (hot property now; the
        card pushes hover/hot changes as they happen)."""
        self._border_hot = str(card.property("hot")) == "true"

    def set_border_state(self, hot=None, hover=None):
        changed = False
        if hot is not None and bool(hot) != self._border_hot:
            self._border_hot = bool(hot)
            changed = True
        if hover is not None and bool(hover) != self._border_hover:
            self._border_hover = bool(hover)
            changed = True
        if changed:
            self.update()

    @classmethod
    def _border_color(cls, hot, hover):
        """The card frame's border color for a state, parsed from the
        live ``QFrame#card`` QSS rules (hot beats hover, as in QSS)."""
        app = QApplication.instance()
        ss = app.styleSheet() if app is not None else ""
        key = (hash(ss), bool(hot), bool(hover))
        color = cls._border_cache.get(key)
        if color is not None:
            return color

        def _from_rule(selector):
            m = re.search(re.escape(selector) + r"\s*\{(.*?)\}", ss, re.S)
            if not m:
                return None
            cm = re.search(r"border(?:-color)?\s*:\s*[^;]*?(#[0-9a-fA-F]{6})",
                           m.group(1))
            return cm.group(1) if cm else None

        hexcol = None
        if hot:
            hexcol = _from_rule('QFrame#card[hot="true"]')
        if hexcol is None and hover:
            hexcol = _from_rule("QFrame#card:hover")
        if hexcol is None:
            hexcol = _from_rule("QFrame#card")
        color = QColor(hexcol or "#23252b")
        cls._border_cache[key] = color
        return color

    @classmethod
    def _pill_bg(cls):
        """Pill fill color from the live ``QLabel#queueQuote`` theme rule."""
        app = QApplication.instance()
        ss = app.styleSheet() if app is not None else ""
        key = hash(ss)
        color = cls._bg_cache.get(key)
        if color is None:
            bg = "#1a2c4e"  # dark-theme fallback
            m = re.search(r"QLabel#queueQuote\s*\{(.*?)\}", ss, re.S)
            if m:
                cm = re.search(
                    r"(?<![\w-])background\s*:\s*(#[0-9a-fA-F]{6})",
                    m.group(1))
                if cm:
                    bg = cm.group(1)
            color = QColor(bg)
            cls._bg_cache[key] = color
        return color

    @staticmethod
    def _tab_path(x, y, w, h, r_tl, r_br):
        """The folder-tab shape in rect (x, y, w, h): top-left radius
        r_tl (arc center (x + r_tl, y + r_tl)), bottom-right r_br,
        top-right and bottom-left square."""
        cx, cy = x + r_tl, y + r_tl
        path = QPainterPath()
        path.moveTo(cx, y)
        path.lineTo(x + w, y)                # top edge to top-right
        path.lineTo(x + w, y + h - r_br)     # right edge down
        path.arcTo(x + w - 2.0 * r_br, y + h - 2.0 * r_br,
                   2.0 * r_br, 2.0 * r_br, 0.0, -90.0)
        path.lineTo(x, y + h)                # bottom edge
        path.lineTo(x, cy)                   # left edge up to the arc
        path.arcTo(cx - r_tl, cy - r_tl, 2.0 * r_tl, 2.0 * r_tl,
                   180.0, -90.0)
        path.closeSubpath()
        return path

    def paintEvent(self, event):
        w = float(self.width())
        h = float(self.height())
        if w <= 2 or h <= 2:
            return
        r_out = float(self._card_radius)
        r_in = float(max(0, self._card_radius - 1))
        r_br = float(PILL_TAB_RADIUS)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        # 1) the border ring: the full tab in the card's border color —
        #    its outer arc (radius R, center (R, R)) IS the card corner.
        painter.fillPath(self._tab_path(0.0, 0.0, w, h, r_out, r_br),
                         self._border_color(self._border_hot,
                                            self._border_hover))
        # 2) the blue tab inset by the 1px border: same arc center,
        #    radius R − 1; right/bottom edges coincide with the ring's,
        #    so no border line shows there (folder tab).
        painter.fillPath(self._tab_path(1.0, 1.0, w - 1.0, h - 1.0,
                                        r_in, r_br),
                         self._pill_bg())
        painter.end()
        super().paintEvent(event)


class ScopeChip(PainterTextButton):
    """A scope tag that toggles its done-state when clicked.

    In edit mode (draggable=True) a chip can also be drag-reordered; the
    drop container (ScopeChipTray) then emits the new order.

    Text is painter-drawn (PainterTextButton): chip text is the most
    fringe-prone small text in the app.
    """

    toggled_scope = Signal(str, bool)

    MIME = "application/x-tasklist-scope-chip"

    def __init__(self, scope, done=False, parent=None, draggable=False):
        super().__init__(parent)
        self._scope = scope
        self.setCheckable(True)
        self.setChecked(done)
        self.setProperty("role", "scopeChip")
        self.setProperty("scopeKey", scope_chip_key(scope))
        self._press_pos = None
        self._dragged = False
        chip_font(self)
        self.set_draggable(draggable)
        self._render()
        self.clicked.connect(lambda: (self._render(), self.toggled_scope.emit(self._scope, self.isChecked())))

    def scope_name(self):
        return self._scope

    def set_draggable(self, enabled):
        """Enable/disable drag-reorder. Edit mode only — view mode stays fixed."""
        self._draggable = bool(enabled)
        self.setCursor(Qt.OpenHandCursor if enabled else Qt.PointingHandCursor)
        self.setToolTip("Drag to reorder · click to mark done / not done"
                        if enabled else "Click to mark this step done / not done")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self._draggable:
            self._press_pos = event.position().toPoint()
            self._dragged = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if (self._draggable and self._press_pos is not None and not self._dragged
                and (event.position().toPoint() - self._press_pos).manhattanLength()
                >= QApplication.startDragDistance()):
            self._dragged = True
            self._press_pos = None
            drag = QDrag(self)
            mime = QMimeData()
            mime.setData(self.MIME, self._scope.encode("utf-8"))
            drag.setMimeData(mime)
            pix = self.grab()
            drag.setPixmap(pix)
            drag.setHotSpot(QPoint(pix.width() // 2, pix.height() // 2))
            drag.exec(Qt.MoveAction)
            self.setDown(False)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._dragged:
            # Swallow the release after a drag so the chip doesn't toggle.
            self._dragged = False
            self.setDown(False)
            event.accept()
            return
        self._press_pos = None
        super().mouseReleaseEvent(event)

    def _render(self):
        self.setText(esc_plain(("✓ " if self.isChecked() else "") + self._scope))

    def _painter_text_color(self):
        # The :checked text color lives in a pseudo-state rule the palette
        # does not track; mirror QPushButton[role="scopeChip"]:checked in
        # themes.py here.
        if self.isChecked():
            return QColor("#15803d" if saved_theme() == "light"
                          else "#8fdcae")
        return super()._painter_text_color()


class ScopeChipTray(QWidget):
    """Row hosting ScopeChips; accepts chip drops to reorder them.

    Used for the scope-of-work pills in the detail window's edit mode
    only. On drop the chip is moved within the row and order_changed
    fires with the new scope order (scope names, left to right).
    """

    order_changed = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def _chips(self):
        lay = self.layout()
        if lay is None:
            return []
        return [lay.itemAt(i).widget() for i in range(lay.count())
                if isinstance(lay.itemAt(i).widget(), ScopeChip)]

    def chip_order(self):
        """Current scope order, left to right."""
        return [c.scope_name() for c in self._chips()]

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat(ScopeChip.MIME):
            event.acceptProposedAction()

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat(ScopeChip.MIME):
            event.acceptProposedAction()

    def dropEvent(self, event):
        if not event.mimeData().hasFormat(ScopeChip.MIME):
            return
        try:
            scope = bytes(event.mimeData().data(ScopeChip.MIME)).decode("utf-8")
        except (UnicodeDecodeError, ValueError):
            return
        chips = self._chips()
        moving = next((c for c in chips if c.scope_name() == scope), None)
        if moving is None:
            return
        pos = event.position().toPoint()
        others = [c for c in chips if c is not moving]
        idx = len(others)
        for i, c in enumerate(others):
            if pos.x() <= c.geometry().center().x():
                idx = i
                break
        lay = self.layout()
        lay.removeWidget(moving)
        lay.insertWidget(idx, moving)  # idx <= len(others): lands before the stretch
        event.acceptProposedAction()
        self.order_changed.emit(self.chip_order())


# ------------------------------------------------------- tag dropdown popup
class CountLabel(QLabel):
    """Result-count text inside the search field.

    Managed by SearchField (positioned manually as a child widget).
    Hidden while empty, so showing/hiding it never changes the toolbar's
    geometry -- typing in the search field can't shift the row.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("countLabel")
        self.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

    def set_count(self, text):
        self.setText(text or "")
        self.setVisible(bool(text))


class SearchField(QLineEdit):
    """Search input with an embedded result-count label.

    The count lives INSIDE the field as a manually-positioned child
    widget (not a QWidgetAction -- Qt's trailing-action layout clips
    the label). The field reserves right-side text margins for the
    count and the built-in clear button, so neither overlaps the text
    and showing/hiding the count never moves the toolbar.
    """

    # Room for Qt's built-in clear (X) button at the right edge.
    _CLEAR_RESERVE = 24

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setClearButtonEnabled(True)
        self._count = CountLabel(self)
        self._count.hide()
        self.textChanged.connect(lambda _=None: self._layout_count())

    def set_count(self, text):
        """Show (or hide, when empty) the result-count text."""
        self._count.set_count(text)
        self._layout_count()

    def _layout_count(self):
        if self._count.isVisible():
            w = self._count.fontMetrics().horizontalAdvance(
                self._count.text()) + 14
            # Count sits left of the clear button.
            x = self.width() - w - self._CLEAR_RESERVE
            self._count.setGeometry(x, 0, w, self.height())
            self.setTextMargins(0, 0, w + self._CLEAR_RESERVE, 0)
        else:
            # Clear button still needs its room.
            self.setTextMargins(0, 0, self._CLEAR_RESERVE, 0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._layout_count()
class TagPopup(QFrame):
    """Popup shared by the Scope of Work and Rack Type dropdowns.

    Search field with a result count, a scroll-capped option list, and full
    keyboard support: Up/Down moves between options, Enter toggles,
    Esc closes, Tab closes and moves focus on.
    """

    closed = Signal()
    option_added = Signal(str)
    focus_advance = Signal(bool)  # True = backwards (Shift+Tab)

    MAX_LIST_HEIGHT = 300

    def __init__(self, options, selected, kind="scope", parent=None, prefill=""):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint
                         | Qt.NoDropShadowWindowHint)
        self.setObjectName("scopePopup")
        # V1.9.25 glass rewrite (user standing order: dropdowns are
        # GLASS). Translucent window + explicit paintEvent chrome
        # (below) + native blur-behind on show. V1.9.18 relied on the
        # #scopePopup QSS background on a translucent window and
        # Windows never painted it (fully see-through popup);
        # V1.9.24 removed translucency entirely (opaque — the wrong
        # direction, the user never changed direction on glass).
        # The chrome is painted here outright, never via QSS, and the
        # #scopePopup QSS rule is transparent (no double paint).
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        # V1.9.30: rounded window mask (see showEvent) -- re-applied
        # on every resize/show by the filter, applied at placement in
        # TagDropdown._open_popup.
        self._mask_filter = _PopupMaskFilter(self)
        self.installEventFilter(self._mask_filter)
        self._kind = kind
        kind_label = "scope" if kind == "scope" else "rack type"
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)

        # search with its result count stacked above (never squeezed)
        search_box = QVBoxLayout()
        search_box.setContentsMargins(0, 0, 0, 0)
        search_box.setSpacing(3)
        self._count = CountLabel()
        search_box.addWidget(self._count)
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search…")
        self._search.setClearButtonEnabled(True)
        self._search.textChanged.connect(self._on_search)
        self._search.returnPressed.connect(self._on_search_enter)
        self._search.installEventFilter(self)
        search_box.addWidget(self._search)
        layout.addLayout(search_box)

        # scroll-capped option list (stays usable with dozens of options)
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setMaximumHeight(self.MAX_LIST_HEIGHT)
        enable_touch_scroll(self._scroll)
        rows_host = QWidget()
        rows_box = QVBoxLayout(rows_host)
        rows_box.setSpacing(2)
        self._scroll.setWidget(rows_host)
        # App-wide scroll insets: option rows keep clear of the viewport
        # edges and the vertical scrollbar.
        set_scroll_content_margins(self._scroll)
        layout.addWidget(self._scroll)
        self._rows_box = rows_box

        add_btn = QPushButton(f"+ New {kind_label}…")
        add_btn.setObjectName("ghost")
        add_btn.setCursor(Qt.PointingHandCursor)
        add_btn.setToolTip(f"Add a custom {kind_label} to the list")
        add_btn.clicked.connect(self._on_add_clicked)
        add_btn.installEventFilter(self)
        layout.addWidget(add_btn)

        self.set_options(options, selected)
        if prefill:
            self._search.setText(prefill)

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        # Frosted part of the glass: the OS blurs whatever sits
        # behind the popup. No-op off Windows (tint still paints).
        capture_frost(self)
        QTimer.singleShot(0, self._refit_after_settle)
        # V1.9.30 CORRECTION (user screenshots, Sales Rep + Scope
        # popups): the V1.9.29 removal below was WRONG. Its reasoning
        # covered only layers the app paints (shadow, style fill) and
        # missed the OS acrylic/blur layer, which fills the window's
        # RECTANGLE -- that rectangle is the grey sharp corner the
        # user kept photographing behind the rounded paint. The mask
        # is restored: with the window region clipped to the rounded
        # rect, no layer -- paint or compositor -- can show a square
        # corner. (V1.9.29 text claimed the mask unnecessary; the
        # user's machine proved otherwise, twice.)

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        """Paint the glass chrome outright — never via QSS.

        The rounded tint + rim fill the popup's shape; the corners
        outside the rounded rect are never painted, so on the
        translucent window they stay transparent and the popup reads
        round by construction. Deliberately does NOT call super():
        the QFrame style background would double-paint under this
        fill (and on Windows that style fill is exactly what failed
        to paint in V1.9.18). Children (search, rows, button) paint
        themselves independently and are unaffected.
        """
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        fill, rim = glass_colors()
        fill = QColor(fill)
        if paint_frost(self, painter, _GLASS_RADIUS):
            # V1.9.48: same recipe as _GlassComboPopup -- tint
            # 140 over the factor-9 frost; the no-snapshot
            # fallback stays the shipped 150 there too.
            fill.setAlpha(140)
        else:
            fill.setAlpha(150)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()),
                            _GLASS_RADIUS, _GLASS_RADIUS)
        painter.setPen(Qt.NoPen)
        painter.setBrush(fill)
        painter.drawPath(path)
        # V1.9.33: rim stroked on an inset path, inside the
        # silhouette — see _GlassComboPopup.paintEvent for why.
        rim_path = QPainterPath()
        rim_path.addRoundedRect(
            QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
            _GLASS_RADIUS - 0.5, _GLASS_RADIUS - 0.5)
        painter.setPen(QPen(rim, 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(rim_path)
        painter.end()

    def set_options(self, options, selected):
        while self._rows_box.count():
            item = self._rows_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._options = list(options)
        self.rows = []
        for option in self._options:
            row = QPushButton()
            row.setCheckable(True)
            row.setChecked(option in selected)
            row.setProperty("role", "scopeRow")
            chip_font(row)
            row.setCursor(Qt.PointingHandCursor)
            row.clicked.connect(lambda _=False, r=row: self._render_row(r))
            row.installEventFilter(self)
            self.rows.append(row)
            self._rows_box.addWidget(row)
            self._render_row(row)
        self._on_search(self._search.text())

    def _render_row(self, row):
        option = self._options[self.rows.index(row)]
        row.setText(("✓  " if row.isChecked() else "      ") + option)

    def selected(self):
        return [self._options[i] for i, r in enumerate(self.rows) if r.isChecked()]

    def focus_search(self):
        self._search.setFocus(Qt.PopupFocusReason)

    # -- search --
    def _on_search(self, text):
        needle = text.strip().lower()
        visible = 0
        # Rebuild layout membership instead of merely hiding rows: hidden
        # widgets inside a QScrollArea (widgetResizable) keep stale layout
        # slots, which left gaps between the matching rows. Only matching
        # rows live in the layout, so the list always collapses to fit.
        for row in self.rows:
            self._rows_box.removeWidget(row)
        for option, row in zip(self._options, self.rows):
            match = not needle or needle in option.lower()
            row.setVisible(match)
            if match:
                self._rows_box.addWidget(row)
                visible += 1
        total = len(self._options)
        self._count.set_count(f"{visible} of {total}" if total else "")
        # Shrink/grow the list (and the popup) to the visible rows.
        rows_h = self._rows_box.totalSizeHint().height()
        one_row = self.rows[0].sizeHint().height() if self.rows else 27
        self._scroll.setFixedHeight(min(max(rows_h, one_row), self.MAX_LIST_HEIGHT))
        self.adjustSize()

    def _refit_after_settle(self):
        """V1.9.41 (user: a large blank space at the bottom of the
        scopes dropdown): the construction-time sizeHint math runs
        before the popup's rows have their final heights (style
        polish / first layout), so the scroll area could lock in
        taller than its content -- dead glass under the last row.
        Recompute from the rows' REAL heights once shown; when the
        content fits under the cap the list ends exactly at the
        last row."""
        if not self.isVisible():
            return
        visible = [r for r in self.rows if not r.isHidden()]
        if not visible:
            return
        box = self._rows_box
        m = box.contentsMargins()
        rows_h = (sum(r.height() for r in visible)
                  + box.spacing() * (len(visible) - 1)
                  + m.top() + m.bottom())
        one_row = visible[0].height()
        target = min(max(rows_h, one_row), self.MAX_LIST_HEIGHT)
        if self._scroll.height() != target:
            self._scroll.setFixedHeight(target)
            self.adjustSize()

    def _on_search_enter(self):
        """Enter in the search field toggles the first visible option."""
        for row in self.rows:
            if not row.isHidden():
                row.click()
                break

    # -- keyboard --
    def _visible_rows(self):
        return [r for r in self.rows if not r.isHidden()]

    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress:
            key = event.key()
            if key == Qt.Key_Escape:
                self.close()
                return True
            if key in (Qt.Key_Tab, Qt.Key_Backtab):
                self.close()
                self.focus_advance.emit(key == Qt.Key_Backtab)
                return True
            if obj is self._search and key == Qt.Key_Down:
                vis = self._visible_rows()
                if vis:
                    vis[0].setFocus()
                return True
            if obj in self.rows and key in (Qt.Key_Up, Qt.Key_Down):
                vis = self._visible_rows()
                try:
                    i = vis.index(obj)
                except ValueError:
                    return False
                j = max(0, min(len(vis) - 1, i + (-1 if key == Qt.Key_Up else 1)))
                vis[j].setFocus()
                return True
            if obj in self.rows and key in (Qt.Key_Return, Qt.Key_Enter):
                obj.click()
                return True
        return super().eventFilter(obj, event)

    def _on_add_clicked(self):
        kind_label = "scope" if self._kind == "scope" else "rack type"
        text, ok = app_get_text(
            self, f"New {kind_label}", f"{kind_label.capitalize()} name:"
        )
        name = text.strip()
        if ok and name:
            self.option_added.emit(name)

    def closeEvent(self, event):
        self.closed.emit()
        super().closeEvent(event)


class TagDropdown(QFrame):
    """Dropdown field for multi-selecting scope or rack types.

    The arrow is pinned to the right edge. Clicking the field toggles the
    popup; a time guard prevents the click that closes the popup from
    immediately re-opening it.
    """

    selection_changed = Signal(list)

    def __init__(self, selected=None, db=None, kind="scope", parent=None):
        super().__init__(parent)
        self.setObjectName("scopeButton")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.db = db
        self.kind = kind
        self._selected = list(selected or [])
        self._open = False
        self._popup = None
        self._last_close_ms = 0
        self._type_buf = ""
        self._type_ts = 0

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 9, 10, 9)
        layout.setSpacing(8)
        self._layout = layout
        self._text = QLabel()
        self._text.setObjectName("scopeText")
        self._text.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout.addWidget(self._text, 1)
        self._arrow = QLabel("▾")
        self._arrow.setObjectName("scopeArrow")
        self._arrow.setFixedWidth(14)
        self._arrow.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(self._arrow)
        self._render()

    # -- data --
    def _live_options(self):
        if self.db is not None:
            try:
                if self.kind == "rack":
                    return self.db.get_rack_types()
                return self.db.get_scopes()
            except Exception:
                pass
        return list(DEFAULT_RACK_TYPES if self.kind == "rack" else SCOPES)

    def _placeholder(self):
        return "Select rack types…" if self.kind == "rack" else "Select work types…"

    def _display_options(self):
        """Current options plus any selected-but-removed ones (so they can be unchecked)."""
        options = self._live_options()
        extras = [s for s in self._selected if s not in options]
        return extras + options

    # -- interaction --
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.toggle_popup()
            event.accept()
            return
        super().mousePressEvent(event)

    def keyPressEvent(self, event):
        key = event.key()
        mods = event.modifiers()
        if key in (Qt.Key_Space, Qt.Key_Return, Qt.Key_Enter) and not mods:
            self.toggle_popup()
            event.accept()
            return
        if key == Qt.Key_Down and not mods:
            self.toggle_popup()
            event.accept()
            return
        if key == Qt.Key_Backspace and not mods:
            # type-ahead buffer edit
            if self._type_buf:
                self._type_buf = self._type_buf[:-1]
                self._type_ts = QDateTime.currentMSecsSinceEpoch()
                self._apply_type_ahead()
            event.accept()
            return
        if key == Qt.Key_Escape and not mods:
            self._type_buf = ""
            event.accept()
            return
        text = event.text()
        if (text and text.isprintable()
                and not (mods & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier))):
            # inline type-ahead for both kinds: Tab in, type, Tab out.
            # (The popup still opens via Space/Down/Enter/click.)
            self._type_char(text)
            event.accept()
            return
        super().keyPressEvent(event)

    def _type_char(self, char):
        """Inline type-ahead: typing accumulates a prefix and commits only
        when it unambiguously identifies one option (or exactly matches
        one), so typing "s" no longer jumps to Selective when Structural
        also matches — "se" picks Selective, "st" picks Structural."""
        now = QDateTime.currentMSecsSinceEpoch()
        if now - self._type_ts > 1000:
            self._type_buf = ""
        self._type_ts = now
        self._type_buf += char.lower()
        self._apply_type_ahead()

    def _apply_type_ahead(self):
        if not self._type_buf:
            return
        options = self._display_options()
        lowered = [o.lower() for o in options]
        match = None
        if self._type_buf in lowered:
            match = options[lowered.index(self._type_buf)]
        else:
            prefixed = [o for o in options if o.lower().startswith(self._type_buf)]
            if len(prefixed) == 1:
                match = prefixed[0]
        if match is not None:
            if match not in self._selected:
                self._selected.append(match)
                self._render()
                self.selection_changed.emit(list(self._selected))
            # start fresh so the next type-ahead can pick another option
            self._type_buf = ""

    def toggle_popup(self, prefill=""):
        if self._open and self._popup is not None:
            self._popup.close()
            return
        # Guard: the mouse press that auto-closed the Qt.Popup must not re-open it.
        now = QDateTime.currentMSecsSinceEpoch()
        if now - self._last_close_ms < 350:
            return
        self._popup = TagPopup(self._display_options(), self._selected, self.kind,
                               self, prefill=prefill)
        self._popup.option_added.connect(self._on_option_added)
        self._popup.closed.connect(self._on_closed)
        self._popup.focus_advance.connect(self._on_popup_focus_advance)
        pos = self.mapToGlobal(QPoint(0, self.height() + 4))
        self._popup.move(pos)
        self._popup.setFixedWidth(max(280, self.width()))
        self._open = True
        self._render()
        self._popup.show()
        # keyboard users can type to filter immediately; harmless for mouse users
        self._popup.focus_search()

    def _on_popup_focus_advance(self, backwards):
        """Tab/Shift+Tab inside the popup: close it and keep tabbing."""
        self.setFocus(Qt.TabFocusReason)
        self.focusNextPrevChild(backwards)

    def _on_closed(self):
        self._last_close_ms = QDateTime.currentMSecsSinceEpoch()
        new = self._popup.selected() if self._popup is not None else []
        self._open = False
        self._popup = None
        self._render()
        if new != self._selected:
            self._selected = new
            self._render()
            self.selection_changed.emit(list(new))

    def _on_option_added(self, name):
        options = self._live_options()
        existing = next((o for o in options if o.lower() == name.lower()), None)
        if existing is None:
            options.append(name)
            if self.db is not None:
                try:
                    if self.kind == "rack":
                        options = self.db.set_rack_types(options)
                    else:
                        options = self.db.set_scopes(options)
                except Exception:
                    pass
        else:
            # already there (maybe different casing) — say so instead of
            # silently doing nothing, and select the existing spelling
            name = existing
            show_toast(
                self, "info", "Already in the list",
                f"\u201c{name}\u201d is already in the list.",
            )
        if name not in self._selected:
            self._selected.append(name)
        if self._popup is not None:
            self._popup.set_options(self._display_options(), self._selected)
        self._render()
        self.selection_changed.emit(list(self._selected))

    # -- value --
    def _render(self):
        self._arrow.setText("▴" if self._open else "▾")
        if self._selected:
            self._text.setText(", ".join(self._selected))
            self._text.setProperty("empty", False)
        else:
            self._text.setText(self._placeholder())
            self._text.setProperty("empty", True)
        # V1.9.37 (user): exactly ONE selected value centres in the
        # field; two or more go back to left-aligned. Centring is
        # against the whole FIELD, so the left margin grows to match
        # the arrow side (10 margin + 14 arrow + 8 spacing = 32)
        # while a single value is shown.
        single = len(self._selected) == 1
        self._text.setAlignment(
            (Qt.AlignHCenter if single else Qt.AlignLeft) | Qt.AlignVCenter)
        self._layout.setContentsMargins(32 if single else 12, 9, 10, 9)
        self._text.style().unpolish(self._text)
        self._text.style().polish(self._text)

    def selected(self):
        return list(self._selected)

    def set_selected(self, selected):
        self._selected = list(selected)
        self._render()


class ScopeDropdown(TagDropdown):
    """Scope of Work variant of TagDropdown (kept for compatibility)."""

    def __init__(self, selected=None, db=None, parent=None):
        super().__init__(selected=selected, db=db, kind="scope", parent=parent)


# ------------------------------------------------------------- status pill
class _MenuToggleGuard:
    """Toggle guard for click-to-open menu buttons (V1.9.37, user:
    "dropdowns still are not closing when clicked again... ALL
    DROPDOWNS SHOULD BE THE SAME").

    These pills open their menu with menu.exec(), a nested event
    loop: a second press lands while the menu is up, the menu hides
    as an outside click, and the SAME press is then delivered to
    the button -- which promptly opens a fresh menu. It looks
    exactly like the dropdown refused to close. The guard: a press
    while the menu is visible closes it, and a press within 350ms
    of it closing is the closing press -- swallow it. The same
    discipline the glass combo popups got in V1.9.35, now shared
    by every menu button.
    """

    def _menu_toggle_blocked(self):
        menu = getattr(self, "_tg_menu", None)
        if menu is not None and menu.isVisible():
            menu.close()
            return True
        closed = getattr(self, "_tg_closed_ms", 0)
        return QDateTime.currentMSecsSinceEpoch() - closed < 350

    def _track_menu(self, menu):
        self._tg_menu = menu

        def _hidden():
            self._tg_closed_ms = QDateTime.currentMSecsSinceEpoch()
            self._tg_menu = None

        menu.aboutToHide.connect(_hidden)


class StatusPill(PainterTextButton, _MenuToggleGuard):
    status_chosen = Signal(str)

    def __init__(self, status="in_process", parent=None):
        super().__init__(parent)
        self.setObjectName("statusPill")
        self.setCursor(Qt.PointingHandCursor)
        chip_font(self)
        self._status = status
        self._type_buf = ""
        self._type_ts = 0
        self.clicked.connect(self._show_menu)
        self._render()

    def keyPressEvent(self, event):
        # type-ahead: "i" -> In Process, "ca" -> Canceled, etc.
        text = event.text()
        if (text and text.isprintable()
                and not (event.modifiers()
                         & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier))):
            now = QDateTime.currentMSecsSinceEpoch()
            if now - self._type_ts > 1000:
                self._type_buf = ""
            self._type_ts = now
            self._type_buf += text.lower()
            match = next(
                (s for s in STATUSES
                 if STATUS_LABELS[s].lower().startswith(self._type_buf)),
                None,
            )
            if match is not None and match != self._status:
                self.status_chosen.emit(match)
            event.accept()
            return
        super().keyPressEvent(event)

    def _render(self):
        self.setText(STATUS_LABELS.get(self._status, self._status) + "  ▾")
        self.setProperty("statusState", self._status)
        # force QSS re-evaluation of the dynamic property
        self.style().unpolish(self)
        self.style().polish(self)

    def set_status(self, status):
        self._status = status
        self._render()

    def _show_menu(self):
        if self._menu_toggle_blocked():
            return
        menu = themed_menu(self)
        for s in STATUSES:
            action = menu.addAction(STATUS_LABELS[s])
            action.setCheckable(True)
            action.setChecked(s == self._status)
            action.triggered.connect(lambda _=False, st=s: self.status_chosen.emit(st))
        self._track_menu(menu)
        menu.exec(self.mapToGlobal(QPoint(0, self.height() + 4)))

OUTCOME_LABELS = {"unknown": "Unknown", "won": "Won", "lost": "Lost",
                  "dead": "Dead", "on_hold": "On Hold"}


class OutcomePill(PainterTextButton, _MenuToggleGuard):
    """Card-front won/lost/unknown dropdown (V1.9.29, user request).

    Mirrors StatusPill exactly -- same shape, same themed menu, same
    checkmarked current value -- so a quote's outcome can be set from
    the front of the card without opening it. "Unknown" is the
    unmarked default every task starts with. Lives on every TaskCard,
    so it appears in the Task List grid and the Queue alike.
    """

    outcome_chosen = Signal(str)

    def __init__(self, outcome="unknown", parent=None):
        super().__init__(parent)
        self.setObjectName("outcomePill")
        self.setCursor(Qt.PointingHandCursor)
        chip_font(self)
        self._outcome = outcome if outcome in OUTCOME_LABELS else "unknown"
        self.clicked.connect(self._show_menu)
        self._render()

    def _render(self):
        self.setText(OUTCOME_LABELS[self._outcome] + "  \u25be")
        self.setProperty("outcomeState", self._outcome)
        # force QSS re-evaluation of the dynamic property
        self.style().unpolish(self)
        self.style().polish(self)

    def set_outcome(self, outcome):
        self._outcome = outcome if outcome in OUTCOME_LABELS else "unknown"
        self._render()

    def outcome(self):
        return self._outcome

    def _show_menu(self):
        if self._menu_toggle_blocked():
            return
        menu = themed_menu(self)
        for o in ("won", "lost", "dead", "on_hold", "unknown"):
            action = menu.addAction(OUTCOME_LABELS[o])
            action.setCheckable(True)
            action.setChecked(o == self._outcome)
            action.triggered.connect(
                lambda _=False, oc=o: self.outcome_chosen.emit(oc))
        self._track_menu(menu)
        menu.exec(self.mapToGlobal(QPoint(0, self.height() + 4)))



class CancelReasonDialog(QDialog):
    """Ask why a task is being canceled. The reason lands in the task notes."""

    def __init__(self, parent=None, quote_number=""):
        super().__init__(parent)
        self.setModal(True)
        self.setMinimumWidth(400)
        title = f"Cancel {quote_number}" if quote_number else "Cancel Task"
        layout = install_chrome(self, title, show_max=False)

        lab = QLabel("Why is this task being canceled?")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        self._edit = QLineEdit()
        self._edit.setPlaceholderText("Reason for cancellation…")
        layout.addWidget(self._edit)
        hint = QLabel("This will be added to the task notes as *Cancelled:* …")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addStretch(1)

        row = QHBoxLayout()
        row.addStretch(1)
        keep_btn = QPushButton("Keep Task")
        keep_btn.clicked.connect(self.reject)
        cancel_btn = QPushButton("Cancel Task")
        cancel_btn.setObjectName("danger")
        cancel_btn.setDefault(True)
        cancel_btn.clicked.connect(self.accept)
        row.addWidget(keep_btn)
        row.addWidget(cancel_btn)
        _equalize_button_heights([keep_btn, cancel_btn])
        layout.addLayout(row)
        self._edit.setFocus()

    def reason(self):
        return self._edit.text().strip()


def confirm_cancel_with_reason(parent, db, task_id):
    """Prompt for a cancellation reason and apply the cancellation.

    Sets the status to canceled and appends "*Cancelled:* <reason>" to the
    task notes. Returns True when the task was canceled, False when the user
    backed out (caller should revert any optimistic UI change).
    """
    task = db.get_task(task_id)
    dlg = CancelReasonDialog(parent, task["quote_number"] if task else "")
    if dlg.exec() != QDialog.Accepted:
        return False
    reason = dlg.reason()
    db.set_status(task_id, "canceled")
    if reason:
        db.append_note(task_id, f"*Cancelled:* {reason}")
    db.log_activity(task_id, "cancel",
                    f"Canceled: {reason}" if reason else "Canceled")
    return True


# ------------------------------------------------------------------ task card
_chip_row_heights = {}


def chip_row_height(object_name=None, role=None):
    """Height of one chip/tag row, measured once from a polished probe label.

    Used to reserve a fixed-height slot when a card has no badges (or no
    rack-type tags), so the rack-type tag row -- and every row below it --
    starts at the same height on every card and cards scan uniformly
    across a grid row. Both themes use identical chip/tag padding, so the
    cached value is theme-independent.
    """
    key = (object_name, role)
    if key not in _chip_row_heights:
        probe = QLabel("Ag")
        if object_name:
            probe.setObjectName(object_name)
        if role:
            probe.setProperty("role", role)
        chip_font(probe)
        probe.style().unpolish(probe)
        probe.style().polish(probe)
        probe.ensurePolished()
        _chip_row_heights[key] = probe.sizeHint().height()
    return _chip_row_heights[key]


class _HoverIconSwap(QObject):
    """Recolour a button's icon while the pointer hovers it.

    QSS paints the hover background (see the card*Btn rules in themes.py),
    but button icons are pixmaps — the glyph colour has to swap here.
    ``normal_color`` is a callable so stateful buttons (the hot/attention
    button is red when active, gray when not) restore correctly.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._reg = {}

    def arm(self, btn, icon_name, size, normal_color, hover_color):
        self._reg[btn] = (icon_name, size, normal_color, hover_color)
        btn.installEventFilter(self)

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        entry = self._reg.get(obj)
        if entry is None:
            return False
        name, size, normal_color, hover_color = entry
        if event.type() == QEvent.Enter:
            obj.setIcon(svg_icon(name, hover_color, size))
        elif event.type() == QEvent.Leave:
            color = normal_color() if callable(normal_color) else normal_color
            obj.setIcon(svg_icon(name, color, size))
        return False


class _CardDragSession(QObject):
    """One manual queue-card drag (V1.9.48; replaces QDrag).

    A preview overlay (V1.9.51: a child of the queue page, NOT a
    top-level window -- see __init__) carries the card's
    snapshot under the cursor; an application event filter tracks
    the pointer, drives each QueueColumn's placeholder through
    its _manual_drag_* adapters, and on release emits the same
    card_dropped signal the QDrag drop used to -- deferred one
    tick, so every mouse handler completes before the board
    rebuilds. Escape (or any other button) cancels."""

    def __init__(self, card):
        super().__init__(card)
        self._card = card
        self._task_id = card._task["id"]
        self._columns = []
        self._active = None
        self._done = False
        pix, scale = card._drag_preview()
        grab = (card._press_pos if card._press_pos is not None
                else QPoint(0, 0))
        self._hotspot = QPoint(int(grab.x() * scale),
                               int(grab.y() * scale))
        # V1.9.51 (user: "I SHOULD NOT BE SEEING THAT WHITE
        # WINDOW FLASH ON THE SCREEN EVER" when moving a queue
        # card): the preview used to be a brand-new TOP-LEVEL
        # Tool window, and a virgin top-level translucent window
        # presents a frame of plain white backing on Windows
        # before its first real paint lands. The preview is now
        # a CHILD of the queue page: no new window exists during
        # a drag, so there is nothing that can flash. Positions
        # are tracked in page coordinates.
        host = card
        while host is not None and not isinstance(host, QueuePage):
            host = host.parent()
        self._host = host if host is not None else card.window()
        prev = QWidget(self._host)
        prev.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        prev.setAttribute(Qt.WA_TranslucentBackground, True)
        lab = QLabel(prev)
        lab.setPixmap(pix)
        lab.setGeometry(0, 0, pix.width(), pix.height())
        prev.resize(pix.size())
        self._preview = prev

    def _to_host(self, global_pos):
        if self._host is not None:
            return self._host.mapFromGlobal(global_pos)
        return global_pos

    def begin(self):
        win = self._card.window()
        if win is not None:
            self._columns = win.findChildren(QueueColumn)
        # Hide the source card while dragging (its column shows
        # the insertion placeholder instead).
        self._card.setVisible(False)
        self._preview.move(self._to_host(QCursor.pos()) - self._hotspot)
        self._preview.raise_()
        self._preview.show()
        QApplication.instance().installEventFilter(self)
        self._track(QCursor.pos())

    def eventFilter(self, obj, event):  # noqa: N802 (Qt name)
        if self._done:
            return False
        etype = event.type()
        if etype == QEvent.MouseMove:
            if not (event.buttons() & Qt.LeftButton):
                self._finish(None, None)
                return False
            pos = event.globalPosition().toPoint()
            self._preview.move(self._to_host(pos) - self._hotspot)
            self._track(pos)
        elif etype == QEvent.MouseButtonRelease \
                and event.button() == Qt.LeftButton:
            pos = event.globalPosition().toPoint()
            self._finish(self._active, pos)
        elif etype == QEvent.MouseButtonPress \
                and event.button() != Qt.LeftButton:
            self._finish(None, None)
        elif etype == QEvent.KeyPress \
                and event.key() == Qt.Key_Escape:
            self._finish(None, None)
            return True
        return False

    def _track(self, global_pos):
        hit = None
        for col in self._columns:
            try:
                if col.rect().contains(col.mapFromGlobal(global_pos)):
                    hit = col
                    break
            except RuntimeError:
                continue
        if hit is not self._active:
            if self._active is not None:
                self._active._manual_drag_leave()
            self._active = hit
            if hit is not None:
                hit._manual_drag_enter(global_pos)
        elif hit is not None:
            hit._manual_drag_move(global_pos)

    def _finish(self, drop_col, global_pos):
        if self._done:
            return
        self._done = True
        index = None
        if drop_col is not None and global_pos is not None:
            index = drop_col._manual_drop_index(global_pos)
        if self._active is not None:
            self._active._manual_drag_leave()
            self._active = None
        try:
            QApplication.instance().removeEventFilter(self)
        except Exception:
            pass
        # V1.9.50: remember where the card was released -- after
        # the board rebuilds, the dropped card GLIDES from this
        # rect into its slot instead of snapping (user: "cards
        # just snapping where there dropped instead of a clean
        # animation. SLOPPY."). The glide consumes GLOBAL coords;
        # the preview itself lives in page coords now (V1.9.51),
        # so convert on the way out.
        try:
            drop_rect = QRect(
                self._preview.mapToGlobal(QPoint(0, 0)),
                self._preview.size())
        except Exception:
            drop_rect = None
        self._preview.hide()
        self._preview.deleteLater()
        try:
            self._card.setVisible(True)
        except RuntimeError:
            pass
        self._card._drag_session = None
        if drop_col is not None and index is not None:
            if drop_rect is not None:
                drop_col._last_drop_rect = drop_rect
            task_id = self._task_id
            # One tick later: the release finishes dispatching
            # before the board rebuilds itself around the drop.
            QTimer.singleShot(
                0, lambda: drop_col.card_dropped.emit(
                    task_id, drop_col.column_key, index))


class TaskCard(QFrame):
    open_requested = Signal(int)
    edit_requested = Signal(int)
    delete_requested = Signal(int)
    duplicate_requested = Signal(int)
    selection_toggled = Signal(int, bool)  # task_id, now_selected
    nav_requested = Signal(int, int, int)  # task_id, dx, dy (arrow keys)
    scope_toggled = Signal(int, str, bool)
    status_chosen = Signal(int, str)
    hot_toggled = Signal(int)  # V1.9.5: hot/attention flag toggled
    outcome_requested = Signal(int, str)  # task_id, "unknown"|"won"|"lost"
    remove_requested = Signal(int)  # queue: remove from queue (X button)
    # V1.9.50: bulk actions from the right-click menu when this
    # card is part of a multi-selection (the bulk bar's
    # replacement). selection_provider is set by the main window
    # on its cards: a callable returning the live selected-id set.
    bulk_outcome_requested = Signal(str)
    bulk_status_requested = Signal(str)
    bulk_delete_requested = Signal()
    selection_provider = None

    MIME = "application/x-tasklist-task"

    def __init__(self, task, parent=None, db=None, show_remove=False,
                 column_key=None, sdc_contacts=None):
        super().__init__(parent)
        _csp = self.sizePolicy()
        _csp.setHeightForWidth(True)
        self.setSizePolicy(_csp)
        self.setObjectName("card")
        # V1.9.5: hot tasks get a red border via QSS (QFrame#card[hot="true"]).
        # V1.9.16: never on a completed card — completing clears the flag
        # in set_status, and this guard covers rows completed before that
        # (or marked hot while completed) so no completed card can render
        # highlighted.
        self._is_hot = bool(task.get("is_hot"))
        _hot = self._is_hot and task.get("status") != "completed"
        self.setProperty("hot", "true" if _hot else "false")
        self._show_remove = show_remove
        self._column_key = column_key
        self._db = db
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)  # keyboard: arrows/Enter/Delete
        # UNIFORM HEIGHT: every card is exactly 288px tall, identical
        # layout whether data is present or not. Empty fields show as
        # empty space; nothing collapses.
        # V1.9.12: back to 288px. The V1.9.11 freight/lead-time pill row
        # is removed (user correction: he never asked for pills on the
        # card — the details live in the scope-chip hover tooltip and in
        # full in the detail window). With no strip, the 288px budget fits
        # again exactly as it did before V1.9.10.
        self.setFixedHeight(288)
        # NOTE: Do NOT set horizontal Expanding policy here. V1.7.0 tried it
        # to fix Queue overflow, but it breaks the fixed height in QGridLayout
        # (cards revert to natural 289px height instead of fixed 332px).
        # The fixed height is the contract; width is handled by the layouts.
        # Allow the card to shrink below content width so the grid/column
        # layouts can force equal widths (1/3 for 3-col, column width for
        # Queue). The layout controls the width, not the content.
        # Use Ignored (not Expanding) for horizontal: Expanding breaks the
        # fixed height in QGridLayout, but Ignored lets the layout set the
        # width while keeping the fixed 332px height.
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self.setMinimumWidth(0)
        self._task = task
        self._hot_btn = None  # V1.9.7: set when the footer builds; see set_hot
        self._selected = False
        self._press_pos = None  # press point for click-vs-drag disambiguation
        self._dragging = False  # Queue only: a card drag is in progress

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Corner-tab quote pill flush against the card's top-left (shared
        # helper: identical geometry on every task card in every module).
        # The status pill keeps its top-right seat via a padded wrapper so
        # the corner pill stays at (0, 0).
        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(0)
        self._quote_label = make_corner_quote_pill(task["quote_number"],
                                                    CARD_RADIUS)
        self._quote_label.setToolTip("Ctrl+click to copy quote #")
        self._quote_label.installEventFilter(self)
        _place_corner_pill(self, self._quote_label, header)
        # Overdue pill sits immediately right of the quote number tab
        # (v1.6.2): it moved up from the badge row so the rack-type chips
        # can take its old seat and every card loses one vertical row.
        _due_iso = task.get("due_date")
        _overdue_text = ""
        if _due_iso and task.get("status") in OPEN_STATUSES:
            _dt, _urg = due_chip_info(_due_iso)
            if _dt and _urg:
                _overdue_text = _dt
        self._od_wrap = None
        self._od_chip_header = None
        self._od_chip_badge = None
        if _overdue_text:
            _od_wrap = QWidget()
            _od_row = QHBoxLayout(_od_wrap)
            _od_row.setContentsMargins(8, 12, 0, 0)
            _od_row.setSpacing(0)
            _od_chip = QLabel(_overdue_text)
            _od_chip.setObjectName("dueChip")
            _od_chip.setProperty("urgent", True)
            chip_font(_od_chip)
            _od_chip.style().unpolish(_od_chip)
            _od_chip.style().polish(_od_chip)
            _od_row.addWidget(_od_chip)
            header.addWidget(_od_wrap, 0, Qt.AlignTop)
            self._od_wrap = _od_wrap
            self._od_chip_header = _od_chip
            self._overdue_text = _overdue_text
        # V1.9.54 (user, 2026-11-13, image-468): the Est. chip
        # no longer sits in the header. With a Quote Price chip
        # beside it, the header starved the outcome + status
        # pills and the status painted clipped ("Proces:"). Est.
        # and the price now live together at the bottom-left of
        # the card, directly above the date (built with the
        # footer below); only their texts are computed here.
        self._est_chip = None
        self._est_text = format_hours(task.get("estimated_hours"))
        header.addStretch(1)
        self.pill = StatusPill(task["status"])
        self.pill.status_chosen.connect(lambda s: self.status_chosen.emit(task["id"], s))
        # pill consumes the click so the card itself doesn't open
        pill_wrap = QWidget()
        self._pill_wrap = pill_wrap
        pill_row = QHBoxLayout(pill_wrap)
        pill_row.setContentsMargins(0, 12, 8, 0)
        pill_row.setSpacing(8)
        # V1.9.30 (user): the Quote Price sits where Est. used to,
        # immediately left of the pills -- and only when a price is
        # actually entered (blank / 0 shows nothing). Est. moved to
        # the footer, right of the Added date (see below).
        # V1.9.54: the Quote Price chip moved to the bottom row
        # with Est. (see above) -- only its text is computed here.
        self._price_text = format_price(task.get("quote_value"))
        self._card_sdc_badge = None
        self._price_chip = None
        self._price_chip_badge = None
        # V1.9.29 (user request): outcome dropdown on the front of
        # every card, immediately left of the status pill, same look
        # and menu pattern. Wired to the existing outcome_requested
        # signal (app's on_outcome_chosen already handles it).
        self.outcome_pill = OutcomePill(task.get("outcome") or "unknown")
        self.outcome_pill.setToolTip(
            "Quote outcome -- click to set Won / Lost / Unknown")
        self.outcome_pill.outcome_chosen.connect(
            lambda o: self.outcome_requested.emit(task["id"], o))
        pill_row.addWidget(self.outcome_pill, 0, Qt.AlignTop)
        pill_row.addWidget(self.pill)
        header.addWidget(pill_wrap, 0, Qt.AlignTop)
        # Queue X button: the ONLY queue-specific control. When absent, an
        # identical-width spacer keeps the header pixel-identical.
        _rm_wrap = QWidget()
        _rm_row = QHBoxLayout(_rm_wrap)
        _rm_row.setContentsMargins(0, 12, 12, 0)
        _rm_row.setSpacing(0)
        # Always use a QPushButton (same widget class) to ensure identical layout.
        # When not showing remove, it's a disabled invisible placeholder.
        from PySide6.QtWidgets import QSizePolicy as _SP
        rm = QPushButton()
        rm.setObjectName("iconBtn")
        rm.setFixedSize(31, 27)
        rm.setSizePolicy(_SP.Fixed, _SP.Fixed)
        if self._show_remove:
            rm.setIcon(svg_icon("x", "#8a919c", 13))
            rm.setIconSize(QSize(13, 13))
            rm.setCursor(Qt.PointingHandCursor)
            rm.setToolTip("Remove from queue")
            rm.clicked.connect(
                lambda _=False: self.remove_requested.emit(task["id"]))
        else:
            rm.setEnabled(False)
            rm.setAttribute(Qt.WA_TransparentForMouseEvents)
            # No icon = invisible placeholder, same size/layout as the X button
        _rm_row.addWidget(rm, 0, Qt.AlignTop)
        # Only add the remove-button wrapper when actually showing it (Queue).
        # In Task List (_show_remove=False) the invisible placeholder was
        # pushing the Est/Status pills 43px left of the right edge.
        if self._show_remove:
            header.addWidget(_rm_wrap, 0, Qt.AlignTop)
        layout.addLayout(header)

        # Card body keeps the original content padding below the header.
        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(18, 12, 8, 6)
        bl.setSpacing(7)
        layout.addWidget(body)

        # ---- badge / rack-type row (v1.6.2) ----
        # Single row: rack-type chips sit where the overdue pill used to
        # be (overdue moved to the header next to the quote number).
        # Non-overdue due chips and follow-up share this row. The row
        # always reserves exactly one chip-row of height, even when empty,
        # so Distributor/End User below start at the same height on cards
        # that have no types/badges.
        badge_row = QHBoxLayout()
        badge_row.setSpacing(6)
        badges = 0
        rack_types = task.get("rack_types") or []
        for rt in rack_types:
            tag = QLabel(esc_plain(rt))
            tag.setProperty("role", "rackTag")
            chip_font(tag)
            badge_row.addWidget(tag)
            badges += 1
        due = task.get("due_date")
        if due and task.get("status") in OPEN_STATUSES:
            due_text, urgent = due_chip_info(due)
            # Overdue lives in the header now; only non-urgent due chips
            # stay in this row.
            if due_text and not urgent:
                due_chip = QLabel(due_text)
                due_chip.setObjectName("dueChip")
                due_chip.setProperty("urgent", False)
                chip_font(due_chip)
                due_chip.style().unpolish(due_chip)
                due_chip.style().polish(due_chip)
                badge_row.addWidget(due_chip)
                badges += 1
            elif due_text and urgent:
                # V1.9.30: fallback seat for the overdue chip. The
                # header copy shows while the header row fits; when
                # the card is too narrow for quote tab + overdue +
                # price + both pills, resizeEvent swaps visibility
                # to this copy so nothing paints clipped pills.
                _od_badge = QLabel(due_text)
                _od_badge.setObjectName("dueChip")
                _od_badge.setProperty("urgent", True)
                chip_font(_od_badge)
                _od_badge.style().unpolish(_od_badge)
                _od_badge.style().polish(_od_badge)
                _od_badge.setVisible(False)
                badge_row.addWidget(_od_badge)
                self._od_chip_badge = _od_badge
                badges += 1
        # (Est. + price live at the bottom of the card now --
        # V1.9.54; they are not badge-row chips.)
        if follow_up_due(task):
            follow_chip = QLabel("Follow up")
            follow_chip.setObjectName("followChip")
            follow_chip.setToolTip("Follow-up reminder is due")
            chip_font(follow_chip)
            badge_row.addWidget(follow_chip)
            badges += 1
        if badges:
            # Reserve the chip-row height even when every widget in
            # the row is a hidden fallback copy (overdue / price), so
            # the Distributor line starts at the same height on
            # every card.
            _row_h = QWidget()
            _row_h.setFixedSize(0, chip_row_height(object_name="estChip"))
            badge_row.addWidget(_row_h)
            badge_row.addStretch(1)
            bl.addLayout(badge_row)
        else:
            slot = QWidget()
            slot.setFixedHeight(chip_row_height(object_name="estChip"))
            bl.addWidget(slot)

        for key, label in (("distributor", "Distributor"), ("end_user", "End User")):
            value = task.get(key) or "—"
            # V1.9.2: two plain-text labels instead of one RichText
            # label. Rich text paints through a QTextDocument — another
            # text path that can fringe on Windows — and the old
            # hard-coded HTML 'gray' prefix measured 3.95:1 contrast in
            # light mode ("text should be darker"). The prefix is now
            # QLabel#metaPrefix (themed per mode), the value stays
            # QLabel#meta; both plain text with chip_font.
            meta = QWidget()
            meta_lay = QHBoxLayout(meta)
            meta_lay.setContentsMargins(0, 0, 0, 0)
            meta_lay.setSpacing(8)
            prefix_lbl = QLabel(f"{label}:")
            prefix_lbl.setObjectName("metaPrefix")
            chip_font(prefix_lbl)
            meta_lay.addWidget(prefix_lbl)
            value_lbl = QLabel(esc_plain(value))
            value_lbl.setObjectName("meta")
            # V1.9.17: card text slightly thicker (DemiBold values — the
            # prefix stays regular). TEXT weight only: no card sizing,
            # padding, or border change.
            _vf = value_lbl.font()
            _vf.setWeight(QFont.DemiBold)
            value_lbl.setFont(_vf)
            chip_font(value_lbl)
            meta_lay.addWidget(value_lbl, 1)
            meta.setFixedHeight(20)
            if key == "end_user":
                # Seismic indicator: same badge as the queue card, inline
                # right of the end-user line so it adds no vertical space.
                # V1.9.64 (user): the SDC badge sits DOWN in
                # the price/Est row by the date added -- not up
                # here -- and the IBC chip does not belong on
                # cards at all (its specified home is the edit
                # / New Task window's seismic section).
                self._card_sdc_badge = _make_sdc_badge(
                    self._db, task, contacts=sdc_contacts)
            bl.addWidget(meta)

        # Scope row: chips live in a scrollbar-free horizontal strip
        # (V1.9.30, user): with more scopes than fit, hovering the
        # row and rolling the wheel scrolls the chips sideways --
        # no scrollbar, and every chip stays reachable to check off.
        # The "N of M complete" count stays fixed at the right.
        _scopes_list = task.get("scope") or []
        _done_list = task.get("scope_done", [])
        _scope_row = QHBoxLayout()
        _scope_row.setContentsMargins(0, 0, 0, 0)
        _scope_row.setSpacing(6)
        for s in _scopes_list:
            chip = ScopeChip(s, s in _done_list)
            chip.toggled_scope.connect(
                lambda scope, done, tid=task["id"]: self.scope_toggled.emit(tid, scope, done)
            )
            # V1.9.5: freight / lead-time chips show their saved details on hover.
            _tip = scope_info_tooltip(s, task)
            if _tip:
                chip.setToolTip(_tip)
            _scope_row.addWidget(chip)
        _scope_row.addStretch(1)
        _chips_host = QWidget()
        _chips_host.setLayout(_scope_row)
        _scope_scroll = QScrollArea()
        _scope_scroll.setObjectName("chipScroll")
        _scope_scroll.setWidgetResizable(False)
        _scope_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        _scope_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        _scope_scroll.setWidget(_chips_host)
        _scope_scroll.setFixedHeight(28)
        _hwheel = _HWheelScroll(_scope_scroll)
        _scope_scroll.viewport().installEventFilter(_hwheel)
        _scope_scroll._hwheel = _hwheel
        enable_touch_scroll(_scope_scroll)
        self._scope_scroll = _scope_scroll
        total, done = len(_scopes_list), len(_done_list)
        # V1.9.36 (user): compact "5/6" -- the long form ate room
        # the scope pills need.
        prog = QLabel(f"{done}/{total}" if total else "")
        prog.setObjectName("progressLabel")
        chip_font(prog)
        _scope_outer = QHBoxLayout()
        _scope_outer.setContentsMargins(0, 0, 0, 0)
        _scope_outer.setSpacing(8)
        _scope_outer.addWidget(_scope_scroll, 1)
        _scope_outer.addWidget(prog)
        _scope_container = QWidget()
        _scope_container.setLayout(_scope_outer)
        _scope_container.setFixedHeight(28)
        bl.addWidget(_scope_container)

        # V1.9.12: no logistics strip on the card (user correction —
        # he never asked for pills here). The recorded details live in
        # the Freight / Lead-Time scope-chip hover tooltips above
        # (scope_info_tooltip) and in full in the detail window's
        # FREIGHT & LEAD TIME block. Cards without logistics data and
        # cards with it therefore share the exact same layout again.
        notes = task.get("notes", "")
        # UNIFORM HEIGHT: notes area is ALWAYS present with fixed height,
        # even when empty. This guarantees every card is the same height.
        self._notes_full = notes or ""
        self._notes_label = QLabel()
        self._notes_label.setObjectName("notes")
        _nsp = self._notes_label.sizePolicy()
        _nsp.setHeightForWidth(True)
        self._notes_label.setSizePolicy(_nsp)
        self._notes_label.installEventFilter(self)
        chip_font(self._notes_label)
        self._notes_label.setWordWrap(True)
        bl.addWidget(self._notes_label)
        self._render_notes()

        footer = QHBoxLayout()
        if task["status"] == "completed" and task.get("completed_at"):
            date_text = f"Completed {fmt_date_mdy(task['completed_at'])}"
        else:
            date_text = f"Added {fmt_date_mdy(task.get('created_at'))}"
        # V1.9.51: no Est. in this string anymore -- it is the
        # header chip now (see above); the shorter footer text
        # is what stops the date clipping in narrow columns.
        date_label = QLabel(date_text)
        date_label.setObjectName("dateLabel")
        chip_font(date_label)
        footer.addWidget(date_label)
        footer.addStretch(1)
        # V1.9.5: hot/attention toggle — SVG "!" left of the folder button.
        # Red icon + red card border while hot.
        _is_hot = bool(task.get("is_hot"))
        hot_btn = QPushButton()
        hot_btn.setObjectName("cardHotBtn")
        hot_btn.setIcon(svg_icon("alert", "#e5484d" if _is_hot else "#8a919c", 15))
        hot_btn.setIconSize(QSize(15, 15))
        hot_btn.setCursor(Qt.PointingHandCursor)
        hot_btn.setMinimumHeight(28)
        hot_btn.setToolTip("Hot — needs attention (click to clear)"
                           if _is_hot else "Mark as hot — needs attention")
        hot_btn.clicked.connect(lambda: self.hot_toggled.emit(task["id"]))
        self._hot_btn = hot_btn  # V1.9.7: in-place hot updates (set_hot)
        _hsp = hot_btn.sizePolicy()
        _hsp.setHorizontalPolicy(QSizePolicy.Minimum)
        hot_btn.setSizePolicy(_hsp)
        footer.addWidget(hot_btn)
        if task.get("folder_path"):
            folder_btn = QPushButton(" Folder")
            folder_btn.setObjectName("cardFolderBtn")
            folder_btn.setIcon(svg_icon("folder", "#8a919c", 15))
            folder_btn.setIconSize(QSize(15, 15))
            folder_btn.setCursor(Qt.PointingHandCursor)
            folder_btn.setMinimumHeight(28)
            folder_btn.setToolTip(f"Open quote folder:\n{task['folder_path']}")
            folder_btn.clicked.connect(lambda: open_folder(task["folder_path"]))
            _fsp = folder_btn.sizePolicy()
            _fsp.setHorizontalPolicy(QSizePolicy.Minimum)
            folder_btn.setSizePolicy(_fsp)
            footer.addWidget(folder_btn)
        edit = QPushButton(" Edit")
        edit.setObjectName("cardEditBtn")
        edit.setIcon(svg_icon("pencil", "#8a919c", 13))
        edit.setIconSize(QSize(13, 13))
        edit.setCursor(Qt.PointingHandCursor)
        edit.setMinimumHeight(28)
        edit.clicked.connect(lambda: self.edit_requested.emit(task["id"]))
        _esp = edit.sizePolicy()
        _esp.setHorizontalPolicy(QSizePolicy.Minimum)
        edit.setSizePolicy(_esp)
        delete = QPushButton(" Delete")
        delete.setObjectName("cardDeleteBtn")
        delete.setIcon(svg_icon("x", "#8a919c", 13))
        delete.setIconSize(QSize(13, 13))
        delete.setCursor(Qt.PointingHandCursor)
        delete.setMinimumHeight(28)
        delete.clicked.connect(lambda: self.delete_requested.emit(task["id"]))
        _dsp = delete.sizePolicy()
        _dsp.setHorizontalPolicy(QSizePolicy.Minimum)
        delete.setSizePolicy(_dsp)
        footer.addWidget(edit)
        footer.addWidget(delete)
        # Hover feedback: the footer action buttons light up in their
        # relevant colour (attention red, folder amber, edit accent,
        # delete red) — QSS paints the tint, this swaps the glyph colour.
        self._hover_swap = _HoverIconSwap(self)
        self._hover_swap.arm(
            hot_btn, "alert", 15,
            lambda: "#e5484d" if self._is_hot else "#8a919c", "#ff8589")
        if task.get("folder_path"):
            self._hover_swap.arm(folder_btn, "folder", 15,
                                 "#8a919c", "#f0b95a")
        self._hover_swap.arm(edit, "pencil", 13,
                             "#8a919c", shifted_color("#4f8cff"))
        self._hover_swap.arm(delete, "x", 13, "#8a919c", "#ff8589")
        # UNIFORM HEIGHT: footer always 36px, identical on every card.
        # Locked to the bottom via stretch.
        _footer_container = QWidget()
        _footer_container.setLayout(footer)
        _footer_container.setFixedHeight(44)
        # V1.9.54 (user, image-468): Quote Price + Est. row --
        # bottom-left, directly above the Added/Completed date.
        # The row's height is reserved on EVERY card (the same
        # uniform-height rule as the badge slot) so cards align
        # across a column whether or not they carry either chip.
        _pe_wrap = QWidget()
        _pe_wrap.setFixedHeight(chip_row_height(object_name="estChip"))
        _pe_row = QHBoxLayout(_pe_wrap)
        _pe_row.setContentsMargins(0, 0, 0, 0)
        _pe_row.setSpacing(8)
        if self._price_text:
            _pc = QLabel(self._price_text)
            _pc.setObjectName("priceChip")
            _pc.setToolTip("Quote price")
            chip_font(_pc)
            _pe_row.addWidget(_pc)
            self._price_chip = _pc
        if self._est_text:
            _ec = QLabel(f"Est. {self._est_text}")
            _ec.setObjectName("estChip")
            _ec.setToolTip("Estimated hours")
            chip_font(_ec)
            _pe_row.addWidget(_ec)
            self._est_chip = _ec
        if getattr(self, "_card_sdc_badge", None) is not None:
            _pe_row.addWidget(self._card_sdc_badge)
        _pe_row.addStretch(1)
        self._pe_wrap = _pe_wrap
        # V1.9.64: chips + date are ONE bottom block (fixed 6px
        # between them) so nothing can drift apart again.
        _bottom = QWidget()
        _bottom_lay = QVBoxLayout(_bottom)
        _bottom_lay.setContentsMargins(0, 0, 0, 0)
        _bottom_lay.setSpacing(6)
        _bottom_lay.addWidget(_pe_wrap)
        _bottom_lay.addWidget(_footer_container)
        bl.addStretch(1)
        bl.addWidget(_bottom)

        # Queue only: dragging starts from any bare card surface (labels,
        # containers), not just the frame. Route child mouse events
        # through the card's drag/open state machine; real buttons
        # (scope chips, status pill, footer actions) are excluded in
        # eventFilter and keep their own clicks. Restored after the
        # V1.6.3 QueueCard merge dropped it.
        if self._show_remove:
            for child in self.findChildren(QWidget):
                child.installEventFilter(self)

    def heightForWidth(self, w):  # noqa: N802 (Qt virtual)
        # V1.9.61: the card's height must be computed at the
        # width it will actually get (queue columns are narrower
        # than the card's preferred width; without this the
        # wrapped notes were allotted too little height and the
        # Est. row rode over their last line).
        lay = self.layout()
        if lay is not None:
            try:
                return lay.heightForWidth(w)
            except Exception:
                pass
        return super().heightForWidth(w)

    def _render_notes(self):
        # V1.9.4: task notes are plain text and always shown in full — the
        # Show more/less toggle is gone (the user's info-density rule: never
        # hide or clip notes on cards). notes_to_plain is kept as a safety
        # net for any legacy rich notes that predate the plain-text return.
        self._notes_label.setText(notes_to_plain(self._notes_full or ""))

    def set_selected(self, on):
        """Bulk multi-select highlight (Ctrl+click)."""
        self._selected = bool(on)
        self.setProperty("selected", self._selected)
        self.style().unpolish(self)
        self.style().polish(self)

    def _copy_quote(self):
        QApplication.clipboard().setText(self._task.get("quote_number", ""))
        QToolTip.showText(QCursor.pos(), "Quote # copied")

    def eventFilter(self, obj, event):
        if (obj is getattr(self, "_notes_label", None)
                and event.type() == QEvent.Resize):
            # V1.9.61: the label enforces its wrapped height at
            # the width it actually has (see resize analysis in
            # the patch notes) -- converges because a height
            # change never changes the width.
            _need = obj.heightForWidth(obj.width())
            if _need > 0 and obj.minimumHeight() != _need:
                obj.setMinimumHeight(_need)
        if (obj is self._quote_label
                and event.type() == QEvent.MouseButtonPress
                and event.modifiers() & Qt.ControlModifier):
            self._copy_quote()
            return True
        # Queue cards: child widgets (labels, containers) forward their
        # mouse press/move/release to the card's drag/open state machine
        # so a drag can start anywhere on the card. Buttons and sliders
        # (scope chips, status pill, footer actions, notes toggle) keep
        # their own clicks. Task List cards (show_remove=False) are
        # untouched by this.
        if self._show_remove and obj is not self:
            if isinstance(obj, (QAbstractButton, QAbstractSlider)):
                return False
            etype = event.type()
            try:
                pos = obj.mapTo(self, event.position().toPoint())
            except Exception:
                return super().eventFilter(obj, event)
            if etype == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
                self._press_at(pos)
                return True
            if etype == QEvent.MouseButtonDblClick \
                    and event.button() == Qt.LeftButton \
                    and not (event.modifiers() & Qt.ControlModifier):
                self._dbl_at(pos)
                return True
            if etype == QEvent.MouseMove and self._press_pos is not None:
                self._move_at(pos)
                return True
            if etype == QEvent.MouseButtonRelease and event.button() == Qt.LeftButton:
                if self._press_pos is not None or self._dragging:
                    self._release_at(pos)
                    return True
                return False
        return super().eventFilter(obj, event)

    def contextMenuEvent(self, event):
        tid = self._task["id"]
        # V1.9.50 (user): when this card is part of a multi-selection,
        # the menu's modifying actions apply to ALL selected tasks
        # (the removed bulk bar's actions live here now).
        sel_ids = set()
        provider = getattr(self, "selection_provider", None)
        if provider is not None:
            try:
                sel_ids = set(provider() or set())
            except Exception:
                sel_ids = set()
        multi = tid in sel_ids and len(sel_ids) > 1
        suffix = f" ({len(sel_ids)} tasks)" if multi else ""
        menu = themed_menu(self)
        menu.addAction("Duplicate",
                       lambda: self.duplicate_requested.emit(tid))
        menu.addAction("Copy quote number", self._copy_quote)
        menu.addSeparator()
        status_menu = menu.addMenu(f"Set status{suffix}")
        for s in STATUSES:
            if multi:
                status_menu.addAction(
                    STATUS_LABELS[s],
                    lambda _=False, st=s:
                        self.bulk_status_requested.emit(st))
            else:
                status_menu.addAction(
                    STATUS_LABELS[s],
                    lambda _=False, st=s:
                        self.status_chosen.emit(tid, st))
        for label, outcome in (("Mark won", "won"),
                               ("Mark lost", "lost"),
                               ("Mark dead", "dead"),
                               ("Mark on hold", "on_hold")):
            if multi:
                menu.addAction(
                    f"{label}{suffix}",
                    lambda _=False, oc=outcome:
                        self.bulk_outcome_requested.emit(oc))
            else:
                menu.addAction(
                    label,
                    lambda _=False, oc=outcome:
                        self.outcome_requested.emit(tid, oc))
        # V1.9.34 (user): "Clear outcome mark" removed — it was an
        # un-mark to Unknown with a name nobody could decode, and
        # the detail window's P.O Status pill already offers
        # "Unknown" for exactly that.
        menu.addSeparator()
        menu.addAction("Edit",
                       lambda: self.edit_requested.emit(tid))
        if multi:
            menu.addAction(f"Delete{suffix}",
                           lambda: self.bulk_delete_requested.emit())
        else:
            menu.addAction("Delete",
                           lambda: self.delete_requested.emit(tid))
        menu.exec(event.globalPos())

    def keyPressEvent(self, event):
        tid = self._task["id"]
        key = event.key()
        if key in (Qt.Key_Return, Qt.Key_Enter):
            self.open_requested.emit(tid)
            event.accept()
            return
        if key == Qt.Key_Delete:
            self.delete_requested.emit(tid)
            event.accept()
            return
        nav = {Qt.Key_Up: (0, -1), Qt.Key_Down: (0, 1),
               Qt.Key_Left: (-1, 0), Qt.Key_Right: (1, 0)}.get(key)
        if nav is not None:
            self.nav_requested.emit(tid, nav[0], nav[1])
            event.accept()
            return
        super().keyPressEvent(event)

    # ---- click / drag state machine (positions are card-local) ----
    def _press_at(self, pos):
        """Left press: arm a possible click (or, in Queue, a card drag)."""
        self._press_pos = pos
        self._dragging = False

    def _move_at(self, pos):
        """Move: in Queue, start the card drag past the drag threshold."""
        if (self._show_remove and not self._dragging
                and self._press_pos is not None
                and (pos - self._press_pos).manhattanLength()
                >= QApplication.startDragDistance()):
            self._dragging = True
            self._start_drag()
            self._press_pos = None

    def _release_at(self, pos):
        """Left release: ends a click or a drag -- it never opens
        the card. V1.9.47 (user): cards open on DOUBLE click,
        like every standard program; the old release-to-open
        made a plain click (and the first half of every drag)
        fire the detail window open."""
        if self._dragging:
            self._dragging = False
        self._press_pos = None

    def _dbl_at(self, pos):
        """Double click on the card body: open the detail."""
        if not self._dragging:
            self.open_requested.emit(self._task["id"])

    #: V1.9.10 made the queue drag image a scaled-down snapshot
    #: (the full-size grab felt glued to the cursor then).
    #: V1.9.47 (user): the 0.62 preview made the card's pills
    #: read SMALLER for the whole drag and then "glitch" back to
    #: full size on drop, with the little preview window flashing
    #: at drag start. The preview is full-size now -- what you
    #: grab is exactly what you drag.
    _DRAG_PREVIEW_SCALE = 1.0

    def _drag_preview(self):
        """Rounded, slightly translucent snapshot used as the drag image.

        Returns (pixmap, scale). The pixmap is built at plain LOGICAL
        pixels (device pixel ratio 1): on the user's Surface at 200%
        scaling the grabbed pixmap carries physical pixels, and a drag
        image sized from those showed the card hugely oversized while
        dragging by finger (reported on V1.9.3). Logical pixels display
        at exactly ``scale`` × the card in every drag path.
        """
        src = self.grab()
        # V1.9.52 (user, on the Queue: the dragged card "doesnt
        # look right... why is it shrunk"): grab() returns
        # PHYSICAL pixels at the display's device pixel ratio,
        # and QPixmap.scaled() PRESERVES that ratio -- the
        # preview's logical size came out at 1/dpr of the card
        # (half size at 200% scaling). Normalise the ratio off
        # first: the docstring's "plain LOGICAL pixels" is now
        # what the code actually does.
        if src.devicePixelRatio() != 1.0:
            src.setDevicePixelRatio(1.0)
        scale = self._DRAG_PREVIEW_SCALE
        w = max(1, int(self.width() * scale))
        h = max(1, int(self.height() * scale))
        scaled = src.scaled(w, h, Qt.IgnoreAspectRatio,
                            Qt.SmoothTransformation)
        out = QPixmap(scaled.size())
        out.fill(Qt.transparent)
        rect = QRectF(0.5, 0.5, w - 1, h - 1)
        path = QPainterPath()
        path.addRoundedRect(rect, 12, 12)
        painter = QPainter(out)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setClipPath(path)
        painter.setOpacity(0.94)
        painter.drawPixmap(0, 0, scaled)
        painter.setOpacity(1.0)
        painter.setPen(QPen(QColor(shifted_color("#4f8cff")), 1.5))
        painter.drawPath(path)
        painter.end()
        return out, scale

    def _start_drag(self):
        """Begin a drag of this card (Queue column-to-column move).

        V1.9.48 (user: moving cards around the Queue "brings up
        a tiny window and stuff... NOT RIGHT OR LIKE HOW IT HAS
        BEEN WITHOUT PROBLEMS"): the QDrag is GONE. On Windows,
        QDrag's drag image lives in a system-owned window the
        app cannot control -- it flashed as a tiny window at
        drag start and mis-scaled the full-size preview. The
        drag is manual now (_CardDragSession): an app-owned
        preview widget follows the cursor and drives the
        columns' own placeholder machinery directly. Hide the
        source card while dragging; the target column shows a
        same-size insertion placeholder, so the board never
        collapses and the drop position is visible beforehand."""
        self._drag_session = _CardDragSession(self)
        self._drag_session.begin()

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # V1.9.30: keep the card header inside the card. The header
        # holds the quote tab, an overdue chip, a price chip and the
        # outcome + status pills; the pills are interactive and must
        # never paint clipped, so when the card is too narrow the
        # INFO chips yield to their badge-row copies instead (state
        # 1: overdue moves down; state 2: the price moves down too).
        # Widths are summed from the chips' own hints, which do not
        # change with visibility; hysteresis keeps the swap from
        # flickering at a boundary width.
        # V1.9.54: price + Est. no longer take part -- they live
        # at the bottom of the card now, so the header holds only
        # the quote tab, the overdue chip and the two pills. The
        # swap machine below governs the overdue chip alone: when
        # even that does not fit, the chip yields to its badge-row
        # copy so the pills never paint clipped.
        _od_h = getattr(self, "_od_chip_header", None)
        _od_b = getattr(self, "_od_chip_badge", None)
        if _od_h is None:
            return
        _pills = (self.outcome_pill.sizeHint().width() + 8
                  + self.pill.sizeHint().width() + 8)
        _od_w = _od_h.sizeHint().width() + 8
        _base = (self._quote_label.sizeHint().width() + _pills
                 + (43 if self._show_remove else 0))
        _need = _base + _od_w
        _state = getattr(self, "_hdr_state", 0)
        _w = self.width()
        if _state == 0 and _w < _need:
            _state = 1
        if _state == 1 and _w > _need + 24:
            _state = 0
        if _state != getattr(self, "_hdr_state", 0):
            self._hdr_state = _state
            _od_h.setVisible(_state == 0)
            _od_b.setVisible(_state >= 1)

    def set_hot(self, is_hot):
        """V1.9.7: flip the hot/attention visuals in place.

        The old path did a full window refresh() here, which destroyed and
        rebuilt every card — dropping the clicked button's focus and making
        the queue scroll jump ("everything shifts down"). Updating the one
        card avoids all of that: same widgets, same geometry, only the
        border color and icon change.

        V1.9.16: a completed card never shows the hot border (see the
        __init__ guard); the icon still reflects the flag itself.
        """
        self._is_hot = bool(is_hot)
        show_hot = bool(is_hot) and self._task.get("status") != "completed"
        self.setProperty("hot", "true" if show_hot else "false")
        self.style().unpolish(self)
        self.style().polish(self)
        # V1.9.31: the corner pill paints the border arc itself, so it
        # must follow the card's border state.
        if getattr(self, "_quote_label", None) is not None:
            self._quote_label.set_border_state(hot=show_hot)
        if self._hot_btn is not None:
            self._hot_btn.setIcon(svg_icon(
                "alert", "#e5484d" if is_hot else "#8a919c", 15))
            self._hot_btn.setToolTip(
                "Hot — needs attention (click to clear)"
                if is_hot else "Mark as hot — needs attention")
        self.update()

    def enterEvent(self, event):
        # V1.9.31: the corner pill paints the card's border arc, so it
        # tracks the card's hover state (its ring goes hover-colored
        # with the rest of the border).
        if getattr(self, "_quote_label", None) is not None:
            self._quote_label.set_border_state(hover=True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        if getattr(self, "_quote_label", None) is not None:
            self._quote_label.set_border_state(hover=False)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        # Ctrl+click toggles bulk selection; child widgets (chips, pill,
        # buttons) consume their own clicks; a press on the card body
        # arms a drag (Queue) -- opening is DOUBLE click only
        # (V1.9.47), so a press-drag scrolls the list via QScroller
        # instead of opening.
        if event.button() == Qt.LeftButton:
            if event.modifiers() & Qt.ControlModifier:
                self.selection_toggled.emit(self._task["id"], not self._selected)
                event.accept()
                return
            self._press_at(event.position().toPoint())
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.button() == Qt.LeftButton \
                and not (event.modifiers() & Qt.ControlModifier):
            self._dbl_at(event.position().toPoint())
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mouseMoveEvent(self, event):
        self._move_at(event.position().toPoint())
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if (event.button() == Qt.LeftButton
                and not (event.modifiers() & Qt.ControlModifier)):
            self._release_at(event.position().toPoint())
        super().mouseReleaseEvent(event)


# ---------------------------------------------------------------- task table
def _fill_item_wash(painter, option, index):
    """Paint the model's BackgroundRole wash for a cell, if any.

    V1.9.50: the stylesheet style ignores BackgroundRole when a
    stylesheet styles the view -- proven by render probe (the
    V1.9.34 outcome rows carried the correct brush on every item
    yet painted the plain table base, pixel-identical to plain
    rows). The delegates therefore fill the wash themselves,
    under the text they draw; the base paint still draws the
    selection over it, so a selected row reads as selected.
    """
    try:
        brush = index.data(Qt.BackgroundRole)
        if brush is None or brush.style() == Qt.NoBrush:
            return
        color = brush.color()
        if color is not None and color.alpha() > 0:
            painter.save()
            painter.fillRect(option.rect, brush)
            painter.restore()
    except Exception:
        pass


class _DistEndUserDelegate(QStyledItemDelegate):
    """Two-line distributor / end-user cell (attached-1 look).

    Line 1: distributor, DemiBold, normal text color. Line 2:
    "End User: X" (+ " · SDC L" when the seismic letter resolves),
    regular weight, muted color. Selected rows use the highlighted
    text color for both lines so selection stays readable. The data
    arrives as a (distributor, end_user, sdc_letter) tuple in
    Qt.UserRole; the plain text is the same content joined, so the
    cell still reads sensibly without the delegate.
    """

    def paint(self, painter, option, index):
        data = index.data(Qt.UserRole)
        if not isinstance(data, tuple) or len(data) != 3:
            _fill_item_wash(painter, option, index)
            super().paint(painter, option, index)
            return
        dist, end, sdc = data
        selected = bool(option.state & QStyle.State_Selected)
        if not selected:
            _fill_item_wash(painter, option, index)
        # V1.9.19: colors come from the sheet values, NOT the palette —
        # the app themes by stylesheet, so the palette still says
        # black text and painting from it made line 1 invisible on
        # the dark theme. These match dashTable::item exactly.
        dark = saved_theme() != "light"
        if selected:
            c1 = QColor("#ffffff" if dark else "#1c1f24")
            c2 = c1
        else:
            c1 = QColor("#d5d9e0" if dark else "#1c1f24")
            c2 = QColor("#9ba1ab" if dark else "#6b7078")
        rect = option.rect.adjusted(8, 4, -8, -4)
        fm = option.fontMetrics
        line_h = fm.height()
        f1 = font_with_weight(option.font, QFont.DemiBold)
        # V1.9.19: elide, never clip mid-word — the first render cut
        # "Great Lakes Handling" and "End User: ..." mid-word.
        fm1 = QFontMetrics(f1)
        line1 = fm1.elidedText(dist, Qt.ElideRight, rect.width())
        line2 = f"End User: {end}"
        if sdc:
            line2 += f" · SDC {sdc}"
        line2 = fm.elidedText(line2, Qt.ElideRight, rect.width())
        painter.save()
        painter.setFont(f1)
        painter.setPen(c1)
        painter.drawText(rect.x(), rect.y(), rect.width(), line_h,
                         Qt.AlignLeft | Qt.AlignVCenter, line1)
        painter.setFont(option.font)
        painter.setPen(c2)
        painter.drawText(rect.x(), rect.y() + line_h, rect.width(), line_h,
                         Qt.AlignLeft | Qt.AlignVCenter, line2)
        painter.restore()

    def sizeHint(self, option, index):
        base = super().sizeHint(option, index)
        return QSize(base.width(), option.fontMetrics.height() * 2 + 10)


class _NoFocusDelegate(QStyledItemDelegate):
    """TaskTable cells: never paint the current-cell focus frame.

    Mirrors the CRM `_DirectoryRowDelegate` rule (V1.9.17): a clicked
    row must not keep a second inner box inside its selection. The
    row selection itself still paints, so keyboard users still see
    where they are. DIST cells keep their own delegate (which paints
    text manually and never draws a frame); this covers the rest.
    """

    def paint(self, painter, option, index):
        _fill_item_wash(painter, option, index)
        option.state &= ~QStyle.State_HasFocus
        super().paint(painter, option, index)


class DropIndicatorHeader(QHeaderView):
    """QHeaderView with a drop-position indicator for section drags
    (V1.9.33, user: "there needs to be an indicator of where the
    column is going to be placed... as of now I can't really tell
    where it will be placed when I drop it").

    Qt's movable header floats the dragged section but shows no
    insertion marker. This header tracks the drag (the dragged
    section's centre is what decides the drop, as in standard
    programs) and paints the classic marker — a 2px accent line at
    the insertion edge with arrowheads at both ends — live, so the
    landing spot is never a guess. All native behaviour (moving,
    resizing, clicking) is untouched; this only observes and paints.
    """

    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self._press_pos = None
        self._press_logical = None
        self._grab_dx = 0
        self._drop_x = None
        self._drop_visual = None
        self.sectionMoved.connect(lambda *_: self._clear_drop())

    # -- tracking ---------------------------------------------------
    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        super().mousePressEvent(event)
        self._clear_drop()
        if event.button() == Qt.LeftButton:
            # A press on a section boundary is a RESIZE, not a move:
            # the header shows the split cursor there.
            if self.cursor().shape() == Qt.SizeHorCursor:
                return
            logical = self.logicalIndexAt(event.pos())
            if logical >= 0:
                self._press_pos = event.pos()
                self._press_logical = logical
                self._grab_dx = (event.pos().x()
                                 - self.sectionViewportPosition(logical))

    def mouseMoveEvent(self, event):  # noqa: N802 (Qt virtual)
        super().mouseMoveEvent(event)
        if (self._press_logical is None
                or not (event.buttons() & Qt.LeftButton)):
            return
        if ((event.pos() - self._press_pos).manhattanLength()
                < QApplication.startDragDistance()):
            return
        self._update_drop(event.pos().x())

    def mouseReleaseEvent(self, event):  # noqa: N802 (Qt virtual)
        super().mouseReleaseEvent(event)
        self._press_pos = None
        self._press_logical = None
        self._clear_drop()

    def leaveEvent(self, event):  # noqa: N802 (Qt virtual)
        super().leaveEvent(event)
        self._clear_drop()

    # -- drop computation -------------------------------------------
    def _update_drop(self, cursor_x):
        logical = self._press_logical
        size = self.sectionSize(logical)
        center = cursor_x - self._grab_dx + size // 2
        # Walk the sections in visual order (the dragged one still
        # occupies its original slot in the layout); the insertion
        # edge is the first section whose midpoint the dragged
        # centre has NOT passed, else the far right edge.
        order = sorted(range(self.count()),
                       key=lambda l: self.visualIndex(l))
        drop_x = None
        drop_visual = len(order) - 1
        for visual, lgc in enumerate(order):
            if lgc == logical:
                continue
            left = self.sectionViewportPosition(lgc)
            mid = left + self.sectionSize(lgc) // 2
            if center < mid:
                drop_x = left
                drop_visual = visual - (1 if visual > self.visualIndex(logical) else 0)
                break
        if drop_x is None:
            last = order[-1] if order[-1] != logical else order[-2]
            drop_x = (self.sectionViewportPosition(last)
                      + self.sectionSize(last))
            drop_visual = len(order) - 1
        if drop_x != self._drop_x:
            self._drop_x = drop_x
            self._drop_visual = max(0, drop_visual)
            self.viewport().update()

    def _clear_drop(self):
        if self._drop_x is not None:
            self._drop_x = None
            self._drop_visual = None
            self.viewport().update()

    def predicted_visual(self):
        """Visual index the dragged section will occupy on drop."""
        return self._drop_visual

    # -- painting -----------------------------------------------------
    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        super().paintEvent(event)
        if self._drop_x is None:
            return
        painter = QPainter(self.viewport())
        accent = self.palette().color(QPalette.Highlight)
        x = self._drop_x
        h = self.viewport().height()
        painter.setPen(QPen(accent, 2))
        painter.drawLine(x, 0, x, h)
        painter.setBrush(QBrush(accent))
        painter.setPen(Qt.NoPen)
        painter.drawPolygon(QPolygon([
            QPoint(x - 5, 0), QPoint(x + 5, 0), QPoint(x, 6)]))
        painter.drawPolygon(QPolygon([
            QPoint(x - 5, h), QPoint(x + 5, h), QPoint(x, h - 6)]))
        painter.end()


class TaskTable(QTableWidget):
    """List View as a table (V1.9.19, attached-1 look).

    Replaces the full-width cards when View -> List View is active;
    grid views keep cards. Columns carry everything a card shows:
    TASK | DISTRIBUTOR / END USER | SCOPE OF WORK | STATUS | DUE |
    NOTES | RACK TYPES | DATE. Rows open on DOUBLE click (the standing
    row rule); single click selects and the bulk bar follows the
    selection. Sorting stays on the Sort control — headers are labels,
    not sort controls, so the table can never disagree with it.
    Scope done-toggling moves to the detail window in this view
    (grid-view cards keep their chips); every other card action is
    on the row's context menu, identical to the card menu.
    """

    open_requested = Signal(int)
    edit_requested = Signal(int)
    delete_requested = Signal(int)
    duplicate_requested = Signal(int)
    outcome_requested = Signal(int, str)
    # V1.9.50: right-click Set status (single row) + the bulk
    # actions that replace the removed bulk bar (whole selection).
    status_requested = Signal(int, str)
    bulk_outcome_requested = Signal(str)
    bulk_status_requested = Signal(str)
    bulk_delete_requested = Signal()
    selection_changed = Signal(set)

    COLUMNS = ("TASK", "DISTRIBUTOR / END USER", "SCOPE OF WORK",
               "STATUS", "DUE", "NOTES", "RACK TYPES", "DATE ADDED",
               "QUOTE VALUE", "DATE COMPLETED", "OUTCOME", "WAITING ON",
               "SALES REP", "CONTACT NAME", "REVISION",
               "EST. HOURS", "PROGRESS", "FILES")
    (COL_TASK, COL_DIST, COL_SCOPE, COL_STATUS,
     COL_DUE, COL_NOTES, COL_RACK, COL_DATE, COL_VALUE,
     COL_COMPLETED, COL_OUTCOME, COL_WAITING,
     COL_REP, COL_PER, COL_REVISION,
     COL_HOURS, COL_PROGRESS, COL_FILES) = range(18)
    # V1.9.30 (user): the right-click chooser offers every column;
    # the optional ones start hidden (Quote Value starts shown, per
    # spec) and the choice persists in a db setting.
    OPTIONAL_DEFAULT_HIDDEN = (COL_COMPLETED, COL_OUTCOME, COL_WAITING,
                               COL_REP, COL_PER, COL_REVISION,
                               COL_HOURS, COL_PROGRESS, COL_FILES)

    sort_requested = Signal(int)  # V1.9.30: header click -> window sorts

    def __init__(self, parent=None):
        super().__init__(parent)
        # V1.9.61: clip the table (header included) to its
        # rounded frame, the _sync_chrome_mask treatment for
        # windows applied to the table itself -- its header
        # painted a square corner past the frame's arc in the
        # user's Surface photos.
        self.installEventFilter(_PopupMaskFilter(self))
        # Same chrome as the CRM table, exactly: same object names,
        # same sheet, same fonts, same 46px rows (see
        # _style_directory_table). One exception: the shared header
        # font tracks at 110%, which clips "DISTRIBUTOR / END USER"
        # (the longest header here) at narrower widths — this table
        # alone tracks at 100% so its header always fits.
        _style_directory_table(self)
        _hdr = _crm_table_font(10, QFont.DemiBold)
        _hdr.setLetterSpacing(QFont.PercentageSpacing, 100)
        self.horizontalHeader().setFont(_hdr)
        self.setItemDelegate(_NoFocusDelegate(self))
        self.setItemDelegateForColumn(self.COL_DIST, _DistEndUserDelegate(self))
        self.setColumnCount(len(self.COLUMNS))
        self.setHorizontalHeaderLabels(list(self.COLUMNS))
        # V1.9.41 (user): the Progress fraction ("5 of 6") centres
        # in its column -- header and cells alike.
        _prog_hdr = self.horizontalHeaderItem(self.COL_PROGRESS)
        if _prog_hdr is not None:
            _prog_hdr.setTextAlignment(Qt.AlignCenter)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setSortingEnabled(False)
        self.verticalHeader().setVisible(False)
        # V1.9.33: drop-position indicator on column drags.
        # V1.9.34 (user: "PUT THAT RIGHT TF BACK"): swapping the
        # header object discarded the identity _style_directory_
        # table had just given the ORIGINAL header -- the
        # "dashHeader" object name the QSS matches on, and the
        # tracked header font -- so the new header fell back to the
        # native glossy gradient. The replacement header now takes
        # the same name and font; the look is byte-identical to
        # before, the drag indicator is the only addition.
        self.setHorizontalHeader(DropIndicatorHeader(Qt.Horizontal, self))
        self.horizontalHeader().setObjectName("dashHeader")
        self.horizontalHeader().setFont(_hdr)
        self.horizontalHeader().setHighlightSections(False)
        # V1.9.23: columns move (drag headers) and every column
        # resizes by dragging its boundary. Stretch sections ignore
        # drags in Qt, so the old Stretch DIST/SCOPE/NOTES could not
        # be resized at all — all eight are Interactive now and the
        # LAST column absorbs window slack instead (Qt's
        # stretch-last-section). Minimum section size keeps the last
        # column from collapsing at narrow widths.
        self.horizontalHeader().setSectionsMovable(True)
        self.horizontalHeader().setMinimumSectionSize(80)
        # V1.9.30: stretch-last-section OFF -- it made the last column
        # absorb all slack AND ignored drags on its boundary (the
        # user's "DATE is stuck way too wide" report). Slack goes to
        # NOTES via resizeEvent instead.
        self.horizontalHeader().setStretchLastSection(False)
        # V1.9.30 (user): headers are sort controls, like every
        # standard program -- click toggles direction (window sorts).
        self.horizontalHeader().setSortIndicatorShown(True)
        self.horizontalHeader().sectionClicked.connect(
            self.sort_requested.emit)
        # V1.9.30 (user): columns can be dragged into his order, and
        # the whole layout (order, widths, shown set) is remembered.
        self.horizontalHeader().setSectionsMovable(True)
        self.horizontalHeader().sectionResized.connect(
            lambda *_: self._queue_header_save())
        self.horizontalHeader().sectionMoved.connect(
            lambda *_: self._queue_header_save())
        self.horizontalHeader().setSectionResizeMode(
            QHeaderView.Interactive)
        # V1.9.19: widths sized to LIVE widget metrics + 16px item
        # padding + margin so nothing important elides away. Measured
        # on the real table font: "In Process · Est. 4.5h" 177px,
        # "2020-01-01 · Overdue" 188px, "Added 2026-11-02" 159px —
        # the first two width passes elided by a few pixels each
        # (an early estimate from _crm_table_font alone read low).
        # Tooltips carry the full text when columns elide.
        # V1.9.30 (user): widths fitted to what the columns actually
        # hold -- DUE fits "11/04/2026 · Follow up", DATE fits
        # "Added 10/28/2026", QUOTE VALUE fits a seven-figure total.
        # V1.9.33: STATUS fits the status alone ("In Process") now
        # that the estimate lives only in the EST. column. NOTES is
        # the flexible column: it absorbs window slack in resizeEvent
        # (below), so NO column is a stuck stretch column -- every
        # column stays manually resizable, including the last one.
        self.setColumnWidth(self.COL_TASK, 95)
        self.setColumnWidth(self.COL_DIST, 280)
        self.setColumnWidth(self.COL_SCOPE, 200)
        self.setColumnWidth(self.COL_STATUS, 120)
        self.setColumnWidth(self.COL_DUE, 165)
        self.setColumnWidth(self.COL_NOTES, 280)
        self.setColumnWidth(self.COL_RACK, 120)
        self.setColumnWidth(self.COL_DATE, 110)
        self.setColumnWidth(self.COL_VALUE, 130)
        self.setColumnWidth(self.COL_COMPLETED, 110)
        self.setColumnWidth(self.COL_OUTCOME, 110)
        self.setColumnWidth(self.COL_WAITING, 160)
        self.setColumnWidth(self.COL_REP, 120)
        self.setColumnWidth(self.COL_PER, 150)
        self.setColumnWidth(self.COL_REVISION, 90)
        self.setColumnWidth(self.COL_HOURS, 100)
        self.setColumnWidth(self.COL_PROGRESS, 100)
        self.setColumnWidth(self.COL_FILES, 70)
        for _c in self.OPTIONAL_DEFAULT_HIDDEN:
            self.setColumnHidden(_c, True)
        self._db_for_prefs = None
        self._att_counts = {}
        # Coalesced saver for the header state blob (order + widths
        # + shown columns): resize/move fire continuously in a drag.
        self._state_timer = QTimer(self)
        self._state_timer.setSingleShot(True)
        self._state_timer.setInterval(300)
        self._state_timer.timeout.connect(self._save_header_state)
        # V1.9.49: a resize inside the last 300ms before quit
        # (or an update-driven restart) must not be lost with
        # the pending timer -- flush the layout on the way out.
        try:
            QApplication.instance().aboutToQuit.connect(
                self._save_header_state)
        except Exception:
            pass
        # V1.9.23: right-click the header for the column chooser —
        # checkable list of the eight columns plus Show all. Session
        # only (no saved layout); the header bar stays right-clickable
        # even with every column hidden, so Show all always recovers.
        self.horizontalHeader().setContextMenuPolicy(Qt.CustomContextMenu)
        self.horizontalHeader().customContextMenuRequested.connect(
            self._show_header_menu)
        self.itemDoubleClicked.connect(self._on_double_clicked)
        self.itemSelectionChanged.connect(self._on_selection_changed)
        self._rebuilding = False

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        # Drilldown pattern (2026-10-28): the view asserts current
        # (0,0) on show; defer the clear past that so no lone cell
        # highlights before the user clicks. Selection is untouched.
        QTimer.singleShot(0, self._clear_current)

    def _clear_current(self):
        """No current-row box on open: nothing is current until the
        user clicks, so no lone highlighted cell paints on a fresh
        table. Selection (the bulk bar) is untouched — this MUST go
        through the selection model: the view's setCurrentIndex with
        an invalid index wipes the selection in this Qt build
        (measured: restored selection vanished after the view call,
        survives the selection-model call)."""
        try:
            sm = self.selectionModel()
            if sm is not None:
                sm.setCurrentIndex(QModelIndex(),
                                   QItemSelectionModel.NoUpdate)
        except Exception:
            pass

    def _header_menu(self):
        """Column chooser menu (built fresh so check states are live)."""
        menu = themed_menu(self)
        for i, name in enumerate(self.COLUMNS):
            act = menu.addAction(name)
            act.setCheckable(True)
            act.setChecked(not self.isColumnHidden(i))
            act.triggered.connect(
                lambda checked, i=i: self._toggle_column(i, not checked))
        menu.addSeparator()
        menu.addAction("Show all columns", self._show_all_columns)
        menu.addAction("Fit columns to content",
                       self._fit_and_save)
        return menu

    def _show_header_menu(self, pos):
        self._header_menu().exec(
            self.horizontalHeader().mapToGlobal(pos))

    def _show_all_columns(self):
        for i in range(len(self.COLUMNS)):
            self.setColumnHidden(i, False)
        self._save_hidden_cols()
        self._queue_header_save()

    def _fit_and_save(self):
        self._fit_columns_to_content()
        self._queue_header_save()

    def _toggle_column(self, col, hidden):
        self.setColumnHidden(col, hidden)
        self._save_hidden_cols()
        self._queue_header_save()

    # ---- full header layout memory (V1.9.30, user: "it should
    # remember and keep the layouts I have") ----
    def _queue_header_save(self):
        if getattr(self, "_state_timer", None) is not None:
            self._state_timer.start()

    def _save_header_state(self):
        db = self._db_for_prefs
        if db is None:
            return
        try:
            state = self.horizontalHeader().saveState()
            db.set_setting("task_table_header_state",
                           bytes(state.toBase64()).decode("ascii"))
        except Exception:
            pass
        # V1.9.50: a plain-JSON twin of the layout (widths + visual
        # order). QHeaderView.restoreState is all-or-nothing: a
        # state saved against a different column count (a build
        # that added a column) fails WHOLESALE, and the table then
        # silently re-fitted over the user's hand-set layout. The
        # JSON twin survives column additions -- the restore below
        # falls back to it per column instead of discarding
        # everything he set.
        try:
            import json as _json
            header = self.horizontalHeader()
            layout = {
                "widths": {str(c): self.columnWidth(c)
                           for c in range(len(self.COLUMNS))},
                "order": [header.logicalIndex(v)
                          for v in range(header.count())],
            }
            db.set_setting("task_table_layout_json",
                           _json.dumps(layout))
        except Exception:
            pass

    def _restore_header_state(self, db):
        self._layout_restored = False
        try:
            raw = db.get_setting("task_table_header_state", "")
            if raw:
                from PySide6.QtCore import QByteArray
                state = QByteArray.fromBase64(raw.encode("ascii"))
                self._layout_restored = bool(
                    self.horizontalHeader().restoreState(state))
                if self._layout_restored:
                    return
        except Exception:
            pass
        # Blob missing or refused (column set changed since it was
        # saved): apply the JSON twin per column so his widths and
        # order still land exactly as he left them.
        try:
            import json as _json
            raw = db.get_setting("task_table_layout_json", "")
            if not raw:
                return
            layout = _json.loads(raw)
            header = self.horizontalHeader()
            widths = layout.get("widths") or {}
            applied = False
            for key, w in widths.items():
                c = int(key)
                if 0 <= c < len(self.COLUMNS) and int(w) > 0:
                    self.setColumnWidth(c, int(w))
                    applied = True
            order = layout.get("order") or []
            for visual, logical in enumerate(order):
                logical = int(logical)
                if 0 <= logical < len(self.COLUMNS):
                    cur = header.visualIndex(logical)
                    if cur != visual:
                        header.moveSection(cur, visual)
                        applied = True
            self._layout_restored = applied
        except Exception:
            pass

    def _fit_columns_to_content(self):
        """Tight but sufficient (user): every column exactly as
        wide as its widest cell or header needs, plus cell padding
        -- no elided text, no wasted space. Runs on the first data
        load when no saved layout exists, and any time from the
        header menu; the result is saved like any other layout."""
        header = self.horizontalHeader()
        fm = header.fontMetrics()
        # Cells render in the table's (larger) font, not the header
        # font -- measuring them with the header metrics under-sizes
        # every column and elides the text the fit exists to show.
        cfm = QFontMetrics(self.font())
        rows = min(self.rowCount(), 300)
        for c in range(len(self.COLUMNS)):
            if self.isColumnHidden(c):
                continue
            w = fm.horizontalAdvance(self.COLUMNS[c])
            for r in range(rows):
                item = self.item(r, c)
                if item is not None:
                    for line in item.text().split("\n"):
                        w = max(w, cfm.horizontalAdvance(line))
            self.setColumnWidth(c, max(70, min(460, w + 36)))

    def _save_hidden_cols(self):
        db = self._db_for_prefs
        if db is None:
            return
        try:
            import json as _json
            db.set_setting(
                "task_table_hidden_cols",
                _json.dumps([c for c in range(len(self.COLUMNS))
                             if self.isColumnHidden(c)]))
        except Exception:
            pass

    def _load_hidden_cols(self, db):
        try:
            import json as _json
            raw = db.get_setting("task_table_hidden_cols", "")
            if not raw:
                return
            hidden = _json.loads(raw)
            for c in range(len(self.COLUMNS)):
                self.setColumnHidden(c, c in hidden)
        except Exception:
            pass

    # ---- data ----
    def set_tasks(self, tasks, sdc_contacts=None, db=None,
                  selected_ids=None):
        if db is not None and self._db_for_prefs is None:
            self._db_for_prefs = db
            self._load_hidden_cols(db)
            self._restore_header_state(db)
        """Rebuild all rows from list_tasks dicts (no queries here
        except the SDC letter, which resolves from ``sdc_contacts``
        when given — the same batch the cards use)."""
        # Visible-attachment counts for the FILES column: one
        # batched pass (rows minus this revision's soft-detaches),
        # never a query per row.
        self._att_counts = {}
        if db is not None:
            try:
                _hidden = {t["id"]: set(t.get("att_hidden") or [])
                           for t in tasks}
                for _tid, _aid in db.conn.execute(
                        "SELECT task_id, id FROM attachments"):
                    if _aid not in _hidden.get(_tid, set()):
                        self._att_counts[_tid] = \
                            self._att_counts.get(_tid, 0) + 1
            except Exception:
                self._att_counts = {}
        self._rebuilding = True
        try:
            self.setRowCount(0)
            self.setRowCount(len(tasks))
            for row, task in enumerate(tasks):
                self._fill_row(row, task, sdc_contacts, db)
        finally:
            self._rebuilding = False
        if tasks and not getattr(self, "_layout_restored", False) \
                and not getattr(self, "_fitted_once", False):
            self._fitted_once = True
            self._fit_columns_to_content()
        if selected_ids:
            sel_model = self.selectionModel()
            for row, task in enumerate(tasks):
                if task["id"] in selected_ids:
                    sel_model.select(
                        self.model().index(row, 0),
                        QItemSelectionModel.Select | QItemSelectionModel.Rows)
        # No current-row box on a fresh populate either (same reason
        # as showEvent): selection restore above is kept, only the
        # current cell is cleared.
        self._clear_current()

    def _item(self, text, task_id, tooltip=None):
        item = QTableWidgetItem(text)
        item.setData(Qt.UserRole, task_id)
        item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        if tooltip:
            item.setToolTip(tooltip)
        return item

    def _fill_row(self, row, task, sdc_contacts, db):
        tid = task["id"]
        quote = task.get("quote_number") or f"#{tid}"
        task_item = self._item(quote, tid)
        # V1.9.19: the table font, DemiBold. Derive from the table's
        # own (stylesheet-resolved) font via font_with_weight — copying
        # task_item.font() gave Sans Serif 9 (the item carries no font)
        # and copying app_font() can give a different face than the
        # rest of the row when a family override is saved.
        task_item.setFont(font_with_weight(self.font(), QFont.DemiBold))
        if bool(task.get("is_hot")) and task.get("status") != "completed":
            task_item.setIcon(svg_icon("alert", "#e5484d", 13))
            task_item.setToolTip("Hot — needs attention")
        self.setItem(row, self.COL_TASK, task_item)

        dist = task.get("distributor") or "—"
        end = task.get("end_user") or "—"
        letter, _ov = _sdc_letter_for_task(db, task, sdc_contacts)
        dist_tip = f"{dist}\nEnd User: {end}"
        if letter:
            dist_tip += f" · SDC {letter}"
        dist_item = self._item(f"{dist}\nEnd User: {end}", tid,
                               tooltip=dist_tip)
        dist_item.setData(Qt.UserRole, (dist, end, letter))
        self.setItem(row, self.COL_DIST, dist_item)

        scopes = task.get("scope") or []
        done = task.get("scope_done") or []
        if scopes:
            scope_text = ", ".join(scopes)
            if done:
                scope_text += f" ({len(done)}/{len(scopes)})"
        else:
            scope_text = "—"
        self.setItem(row, self.COL_SCOPE,
                     self._item(scope_text, tid, tooltip=scope_text))

        # V1.9.33 (user): STATUS shows only the status. The estimate
        # lives in its own EST. column (below) — never combined here.
        status_text = STATUS_LABELS.get(task.get("status"),
                                        task.get("status") or "")
        self.setItem(row, self.COL_STATUS, self._item(status_text, tid))

        due = (task.get("due_date") or "")[:10]
        due_disp = fmt_date_mdy(due) if due else "—"
        due_item = self._item(due_disp, tid)
        if due and task.get("status") in OPEN_STATUSES:
            _dt, urgent = due_chip_info(due)
            if urgent:
                # V1.9.30 (user): no "· Overdue" crammed in -- an
                # overdue date simply turns red.
                due_item.setForeground(QColor("#e5484d"))
            elif follow_up_due(task):
                due_item.setText(f"{due_disp} · Follow up")
        elif follow_up_due(task):
            due_item.setText("Follow up")
        self.setItem(row, self.COL_DUE, due_item)

        notes = notes_to_plain(task.get("notes") or "")
        first_line = notes.splitlines()[0] if notes.strip() else "—"
        self.setItem(row, self.COL_NOTES,
                     self._item(first_line, tid,
                                tooltip=notes if notes.strip() else None))

        rack = ", ".join(task.get("rack_types") or []) or "—"
        self.setItem(row, self.COL_RACK, self._item(rack, tid))

        # V1.9.30 (user): DATE ADDED holds just the date -- the
        # header carries the meaning, so no "Added"/"Completed"
        # words inside the cells (they only widen the column).
        self.setItem(row, self.COL_DATE,
                     self._item(fmt_date_mdy(task.get('created_at')), tid))

        value = task.get("quote_value")
        value_item = self._item(
            format_price(value) if value else "—", tid)
        value_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.setItem(row, self.COL_VALUE, value_item)

        completed = task.get("completed_at")
        self.setItem(row, self.COL_COMPLETED, self._item(
            fmt_date_mdy(completed) if completed else "—", tid))
        outcome_text = {"won": "Won", "lost": "Lost", "dead": "Dead",
                        "on_hold": "On Hold"}.get(
                            task.get("outcome"), "Unknown")
        self.setItem(row, self.COL_OUTCOME,
                     self._item(outcome_text, tid))
        self.setItem(row, self.COL_WAITING, self._item(
            (task.get("waiting_on") or "").strip() or "—", tid))
        self.setItem(row, self.COL_REP, self._item(
            (task.get("sales_rep") or "").strip() or "—", tid))
        self.setItem(row, self.COL_PER, self._item(
            (task.get("per") or "").strip() or "—", tid))
        self.setItem(row, self.COL_REVISION, self._item(
            (task.get("revision") or "00"), tid))
        hours_item = self._item(
            format_hours(task.get("estimated_hours")) or "—", tid)
        hours_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.setItem(row, self.COL_HOURS, hours_item)
        _scopes = task.get("scope") or []
        _done = [s for s in (task.get("scope_done") or [])
                 if s in _scopes]
        _prog_item = self._item(
            f"{len(_done)} of {len(_scopes)}" if _scopes else "—",
            tid)
        _prog_item.setTextAlignment(Qt.AlignCenter)
        self.setItem(row, self.COL_PROGRESS, _prog_item)
        _att = (self._att_counts or {}).get(tid)
        self.setItem(row, self.COL_FILES, self._item(
            str(_att) if _att else "—", tid))

        # V1.9.34 (user): the WHOLE ROW carries the outcome color --
        # green when won, red when lost, yellow when on hold, gray
        # when dead. A translucent wash tuned per theme, so the text
        # stays crisp and the row still reads as part of this UI in
        # light and dark mode (selection blue still wins on the
        # selected row via the stylesheet).
        _bg = _outcome_row_background(task.get("outcome"),
                                      saved_theme() != "light")
        if _bg is not None:
            for _c in range(self.columnCount()):
                _it = self.item(row, _c)
                if _it is not None:
                    _it.setBackground(_bg)

    # ---- interaction ----
    def _row_task_id(self, row):
        item = self.item(row, self.COL_TASK)
        return item.data(Qt.UserRole) if item is not None else None

    def _current_task_id(self):
        row = self.currentRow()
        return self._row_task_id(row) if row >= 0 else None

    def _on_double_clicked(self, item):
        tid = self._row_task_id(item.row())
        if tid is not None:
            self.open_requested.emit(tid)

    def _on_selection_changed(self):
        if self._rebuilding:
            return
        ids = set()
        for idx in self.selectionModel().selectedRows():
            tid = self._row_task_id(idx.row())
            if tid is not None:
                ids.add(tid)
        self.selection_changed.emit(ids)

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # V1.9.50 (user, 2026-11-12): column widths change ONLY when
        # he drags them -- "GLOBALLY if I change a column width or
        # move columns around that state should be saved until I
        # personally change it again. EVERYWHERE." The V1.9.30 slack
        # absorption that used to live here was a one-way ratchet:
        # it grew NOTES whenever the viewport had slack (a filter
        # with fewer rows drops the vertical scrollbar, the viewport
        # widens, NOTES grew) and NEVER shrank it back, so clicking
        # through the filters steadily widened the table into
        # horizontal scrolling -- and sectionResized then SAVED the
        # damage over his layout. No programmatic width changes
        # remain: unfilled viewport space simply stays empty, like
        # every standard table.

    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        # V1.9.30 (user): clicking empty table space clears the row
        # selection, so the bulk bar goes away -- it used to stick
        # forever because Qt keeps the selection on empty clicks.
        if (event.button() == Qt.LeftButton
                and self.itemAt(event.pos()) is None):
            self.clearSelection()
            self._clear_current()
        super().mousePressEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            tid = self._current_task_id()
            if tid is not None:
                self.open_requested.emit(tid)
                return
        if event.key() == Qt.Key_Delete:
            tid = self._current_task_id()
            if tid is not None:
                self.delete_requested.emit(tid)
                return
        super().keyPressEvent(event)

    def contextMenuEvent(self, event):
        row = self.rowAt(event.pos().y())
        if row < 0:
            return
        tid = self._row_task_id(row)
        if tid is None:
            return
        # V1.9.50 (user): the right-click menu IS the bulk UI now
        # ("you just need to make sure I can select multiple tasks
        # at one time and right click to modify all of them
        # selected"). When the clicked row belongs to a
        # multi-selection, the modifying actions apply to every
        # selected task; a right-click on an unselected row selects
        # that row first, like every standard table.
        sel_ids = []
        for idx in self.selectedIndexes():
            other = self._row_task_id(idx.row())
            if other is not None and other not in sel_ids:
                sel_ids.append(other)
        if tid not in sel_ids:
            self.clearSelection()
            self.selectRow(row)
            sel_ids = [tid]
        self.setCurrentCell(row, 0)
        multi = len(sel_ids) > 1
        suffix = f" ({len(sel_ids)} tasks)" if multi else ""
        menu = themed_menu(self)
        quote = self.item(row, self.COL_TASK).text()
        menu.addAction("Open",
                       lambda: self.open_requested.emit(tid))
        # V1.9.30 (user): no "Duplicate (re-quote)" in the list-view
        # menu -- stacked revisions replace copying a task to track
        # a new version of it.
        menu.addAction("Copy quote number",
                       lambda: self._copy_quote(quote))
        menu.addSeparator()
        status_menu = menu.addMenu(f"Set status{suffix}")
        for s in STATUSES:
            if multi:
                status_menu.addAction(
                    STATUS_LABELS[s],
                    lambda _=False, st=s:
                        self.bulk_status_requested.emit(st))
            else:
                status_menu.addAction(
                    STATUS_LABELS[s],
                    lambda _=False, st=s:
                        self.status_requested.emit(tid, st))
        for label, outcome in (("Mark won", "won"),
                               ("Mark lost", "lost"),
                               ("Mark dead", "dead"),
                               ("Mark on hold", "on_hold")):
            if multi:
                menu.addAction(
                    f"{label}{suffix}",
                    lambda _=False, oc=outcome:
                        self.bulk_outcome_requested.emit(oc))
            else:
                menu.addAction(
                    label,
                    lambda _=False, oc=outcome:
                        self.outcome_requested.emit(tid, oc))
        # V1.9.34: "Clear outcome mark" removed (see the card menu).
        menu.addSeparator()
        menu.addAction("Edit",
                       lambda: self.edit_requested.emit(tid))
        if multi:
            menu.addAction(f"Delete{suffix}",
                           lambda: self.bulk_delete_requested.emit())
        else:
            menu.addAction("Delete",
                           lambda: self.delete_requested.emit(tid))
        menu.exec(event.globalPos())

    def _copy_quote(self, quote):
        QApplication.clipboard().setText(quote)
        QToolTip.showText(QCursor.pos(), "Quote # copied")


# ---------------------------------------------------------- image viewer
class ImageViewerDialog(QDialog):
    """In-app image viewer: wheel-zoom, ←/→ steps through the task's images."""

    def __init__(self, path, title="", parent=None, images=None, index=0):
        super().__init__(parent)
        self._images = [str(p) for p in (images or [path])]
        self._index = max(0, min(index, len(self._images) - 1))
        self._zoom = 1.0
        self._pixmap = QPixmap()
        self.setMinimumSize(480, 380)

        layout = install_chrome(self, title or Path(path).name)

        self._stage = QLabel()
        self._stage.setObjectName("imageStage")
        self._stage.setAlignment(Qt.AlignCenter)
        layout.addWidget(self._stage, 1)

        footer = QHBoxLayout()
        self._status = QLabel()
        self._status.setObjectName("hint")
        footer.addWidget(self._status)
        footer.addStretch(1)
        hint = QLabel("Scroll to zoom · ←/→ for prev/next")
        hint.setObjectName("hint")
        footer.addWidget(hint)
        external = QPushButton("Open externally")
        external.setObjectName("ghost")
        external.clicked.connect(
            lambda: QDesktopServices.openUrl(
                QUrl.fromLocalFile(self._images[self._index])))
        close_btn = QPushButton("Close")
        close_btn.setObjectName("primary")
        close_btn.setDefault(True)
        close_btn.clicked.connect(self.accept)
        footer.addWidget(external)
        footer.addWidget(close_btn)
        _equalize_button_heights([external, close_btn])
        layout.addLayout(footer)
        _chip_font_tree(self)

        self._load(self._index)

    def _load(self, index):
        self._index = max(0, min(index, len(self._images) - 1))
        path = self._images[self._index]
        self._pixmap = QPixmap(path)
        name = Path(path).name
        self.setWindowTitle(name)
        try:
            self._chrome["titlebar"].set_title(name)
        except (AttributeError, KeyError):
            pass
        if self._pixmap.isNull():
            self._stage.setText("Could not load this image.")
        else:
            self._zoom = 1.0
            w = min(max(self._pixmap.width(), 480), 1100)
            h = min(max(self._pixmap.height(), 320), 750)
            self.resize(w + 28, h + 170)
        self._render_status()

    def _step(self, delta):
        if len(self._images) > 1:
            self._load((self._index + delta) % len(self._images))

    def _render_status(self):
        n = len(self._images)
        pos = f"{self._index + 1} of {n} · " if n > 1 else ""
        self._status.setText(f"{pos}{int(self._zoom * 100)}%")

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Left:
            self._step(-1)
            event.accept()
            return
        if event.key() == Qt.Key_Right:
            self._step(1)
            event.accept()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if self._pixmap.isNull():
            return
        factor = 1.2 if event.angleDelta().y() > 0 else 1 / 1.2
        self._zoom = min(max(self._zoom * factor, 0.2), 8.0)
        self._apply()
        self._render_status()
        event.accept()

    def showEvent(self, event):
        super().showEvent(event)
        self._apply()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._apply()

    def _apply(self):
        if self._pixmap.isNull():
            return
        avail = self._stage.size()
        if avail.width() > 10 and avail.height() > 10:
            w = max(1, int(avail.width() * self._zoom))
            h = max(1, int(avail.height() * self._zoom))
            self._stage.setPixmap(
                self._pixmap.scaled(QSize(w, h), Qt.KeepAspectRatio,
                                    Qt.SmoothTransformation))


# ------------------------------------------------------------ pdf viewer
# V1.9.10 (user request): PDF attachments open in a built-in viewer
# instead of an external app (Revu), with markup tools — pen,
# highlighter and text — for the quick markups he does in Revu, right
# on the (touch) screen. Markup is stored as vector data in a sidecar
# file next to the attachment (the PDF itself is never modified), and
# is baked in when printing or saving a copy.
#
# QtPdf is imported LAZILY — only when a PDF is actually opened — so
# it never taxes app startup. If the runtime lacks QtPdf, attachments
# fall back to opening externally, as before.
_PDF_STACK = None  # None = not tried yet; False = unavailable; dict = ok


def _pdf_stack():
    global _PDF_STACK
    if _PDF_STACK is None:
        try:
            from PySide6.QtPdf import QPdfDocument
            from PySide6.QtPrintSupport import QPrintDialog, QPrinter
            from PySide6.QtGui import QPageSize, QPdfWriter
            _PDF_STACK = {"doc": QPdfDocument, "printer": QPrinter,
                          "print_dialog": QPrintDialog,
                          "page_size": QPageSize, "pdf_writer": QPdfWriter}
        except Exception:
            _PDF_STACK = False
    return _PDF_STACK or None


_PDF_VIEW_STACK = None  # None = untried; False = unavailable; dict = ok


def _pdf_view_stack():
    """V1.9.30: viewing/markup needs ONLY QPdfDocument. The old gate
    bundled in QtPrintSupport + QPdfWriter, so one missing print
    component silently bounced EVERY pdf to the external app (the
    user's 'it just opens in Revu' report). Print / Save-a-Copy check
    the full stack separately and degrade on their own."""
    global _PDF_VIEW_STACK
    if _PDF_VIEW_STACK is None:
        try:
            from PySide6.QtPdf import QPdfDocument
            _PDF_VIEW_STACK = {"doc": QPdfDocument}
        except Exception:
            _PDF_VIEW_STACK = False
    return _PDF_VIEW_STACK or None


def pdf_available():
    return _pdf_view_stack() is not None


def is_pdf_file(name):
    return str(name or "").lower().endswith(".pdf")


def _markup_path_for(pdf_path):
    return Path(str(pdf_path) + ".markup.json")


def load_markup(pdf_path):
    """{page_index: [item, ...]} from the sidecar file; {} when none."""
    try:
        raw = json.loads(
            _markup_path_for(pdf_path).read_text(encoding="utf-8"))
        out = {}
        for key, items in raw.get("pages", {}).items():
            out[int(key)] = list(items)
        return out
    except Exception:
        return {}


def save_markup(pdf_path, markup):
    """Persist markup; an all-empty markup removes the sidecar."""
    path = _markup_path_for(pdf_path)
    pages = {str(k): v for k, v in markup.items() if v}
    if not pages:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        return
    path.write_text(json.dumps({"version": 1, "pages": pages}, indent=1),
                    encoding="utf-8")


def _draw_markup_items(painter, items, scale):
    """Paint markup items. The painter's origin must be the page's
    top-left corner; ``scale`` is pixels per PDF point."""
    for item in items:
        kind = item.get("t")
        color = QColor(item.get("c", "#e5484d"))
        if kind == "s":
            pts = item.get("pts") or []
            if len(pts) < 2:
                continue
            if item.get("hl"):
                color.setAlpha(90)
            base_w = float(item.get("w", 2.5))
            if item.get("hl") or not any(len(p) > 2 for p in pts):
                pen = QPen(color, max(1.0, base_w * scale),
                           Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
                painter.setPen(pen)
                path = QPainterPath()
                path.moveTo(pts[0][0] * scale, pts[0][1] * scale)
                for p in pts[1:]:
                    path.lineTo(p[0] * scale, p[1] * scale)
                painter.drawPath(path)
            else:
                # V1.9.30: pen strokes recorded with Surface Pen
                # pressure draw segment by segment, width following
                # the pressure of each segment (light touch = thin).
                for a, b in zip(pts, pts[1:]):
                    pa = a[2] if len(a) > 2 else 0.7
                    pb = b[2] if len(b) > 2 else 0.7
                    w = max(0.6, base_w * (0.3 + 0.95 * (pa + pb) / 2)
                            * scale)
                    painter.setPen(QPen(color, w, Qt.SolidLine,
                                        Qt.RoundCap, Qt.RoundJoin))
                    painter.drawLine(QPointF(a[0] * scale, a[1] * scale),
                                     QPointF(b[0] * scale, b[1] * scale))
        elif kind == "x":
            x, y = item.get("p", [0, 0])
            size = float(item.get("s", 14))
            font = QApplication.instance().font()
            font.setPixelSize(max(6, int(size * scale)))
            painter.setFont(font)
            painter.setPen(QPen(color))
            painter.drawText(QPointF(x * scale, (y + size * 0.92) * scale),
                             item.get("text", ""))


class PdfPageWidget(QWidget):
    """One rendered PDF page plus its markup layer.

    Markup coordinates are PDF points; the widget is exactly
    ``page_points * owner._scale`` pixels, so mapping is a division.
    """

    def __init__(self, owner, page_index, page_pt_size):
        super().__init__(owner._pages_host)
        self._owner = owner
        self.page = page_index
        self._pt = page_pt_size
        self._image = None
        self._active = None  # in-progress stroke
        self._pan = None     # (start_pos, vbar_value, hbar_value)
        self._pen_active = False  # a tablet stroke is in progress;
        # Windows also synthesises mouse events for the pen -- those
        # must not draw a second, pressure-less stroke on top.

    def set_image(self, img):
        self._image = img
        self.update()

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#ffffff"))
        if self._image is not None:
            p.drawImage(self.rect(), self._image)
        else:
            p.setPen(QColor("#8a919c"))
            p.drawText(self.rect(), Qt.AlignCenter, "Loading page…")
        items = list(self._owner._markup.get(self.page, []))
        if self._active is not None:
            items.append(self._active)
        _draw_markup_items(p, items, self._owner._scale)
        p.end()

    def _to_pt(self, pos, pressure=None):
        s = self._owner._scale or 1.0
        pt = [pos.x() / s, pos.y() / s]
        if pressure is not None:
            pt.append(round(float(pressure), 3))
        return pt

    def _begin_stroke(self, pos, pressure=None):
        tool = self._owner._tool
        self._active = {
            "t": "s", "c": self._owner._markup_color,
            "w": 14.0 if tool == "highlight" else 2.5,
            "hl": tool == "highlight",
            "pts": [self._to_pt(pos, pressure)]}
        self.update()

    def _extend_stroke(self, pos, pressure=None):
        pt = self._to_pt(pos, pressure)
        last = self._active["pts"][-1]
        if abs(pt[0] - last[0]) + abs(pt[1] - last[1]) > 0.8:
            self._active["pts"].append(pt)
            self.update()

    def _end_stroke(self):
        item = self._active
        self._active = None
        if len(item["pts"]) == 1:
            x, y = item["pts"][0][:2]
            dot = [x + 0.6, y + 0.6]
            if len(item["pts"][0]) > 2:
                dot.append(item["pts"][0][2])
            item["pts"].append(dot)  # a dot still shows
        self._owner._add_item(self.page, item)
        self.update()

    def mousePressEvent(self, event):  # noqa: N802 (Qt virtual)
        if self._pen_active:
            event.accept()
            return
        tool = self._owner._tool
        if (event.button() == Qt.LeftButton and tool == "scroll"
                and self._owner._scroll is not None):
            # V1.9.30 (user): drag to pan the page, like every real
            # PDF reader -- previously Scroll mode could only wheel.
            sc = self._owner._scroll
            self._pan = (event.globalPosition().toPoint(),
                         sc.verticalScrollBar().value(),
                         sc.horizontalScrollBar().value())
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
            return
        if event.button() == Qt.LeftButton and tool in ("pen", "highlight"):
            self._begin_stroke(event.position())
            event.accept()
            return
        if event.button() == Qt.LeftButton and tool == "text":
            self._owner._place_text(self, event.position())
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: N802 (Qt virtual)
        if self._pen_active:
            event.accept()
            return
        if self._pan is not None and self._owner._scroll is not None:
            sc = self._owner._scroll
            start, v0, h0 = self._pan
            d = event.globalPosition().toPoint() - start
            sc.verticalScrollBar().setValue(v0 - d.y())
            sc.horizontalScrollBar().setValue(h0 - d.x())
            event.accept()
            return
        if self._active is not None:
            self._extend_stroke(event.position())
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: N802 (Qt virtual)
        if self._pen_active:
            event.accept()
            return
        if self._pan is not None:
            self._pan = None
            self.setCursor(
                Qt.OpenHandCursor if self._owner._tool == "scroll"
                else Qt.ArrowCursor)
            event.accept()
            return
        if self._active is not None:
            self._end_stroke()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def tabletEvent(self, event):  # noqa: N802 (Qt virtual)
        """V1.9.30 (user): Surface Pen input with real pressure.
        Pen/highlight strokes record per-point pressure; in Scroll
        mode the pen drags to pan, same as the mouse."""
        tool = self._owner._tool
        etype = event.type()
        if etype == QEvent.TabletPress:
            if tool in ("pen", "highlight"):
                self._pen_active = True
                self._begin_stroke(event.position(), event.pressure())
                event.accept()
                return
            if tool == "text":
                self._owner._place_text(self, event.position())
                event.accept()
                return
            if tool == "scroll" and self._owner._scroll is not None:
                sc = self._owner._scroll
                self._pan = (event.globalPosition().toPoint(),
                             sc.verticalScrollBar().value(),
                             sc.horizontalScrollBar().value())
                event.accept()
                return
        elif etype == QEvent.TabletMove:
            if self._pen_active and self._active is not None:
                self._extend_stroke(event.position(), event.pressure())
                event.accept()
                return
            if self._pan is not None and self._owner._scroll is not None:
                sc = self._owner._scroll
                start, v0, h0 = self._pan
                d = event.globalPosition().toPoint() - start
                sc.verticalScrollBar().setValue(v0 - d.y())
                sc.horizontalScrollBar().setValue(h0 - d.x())
                event.accept()
                return
        elif etype == QEvent.TabletRelease:
            if self._pen_active:
                self._pen_active = False
                if self._active is not None:
                    self._end_stroke()
                event.accept()
                return
            if self._pan is not None:
                self._pan = None
                event.accept()
                return
        super().tabletEvent(event)


class PDFViewerDialog(QDialog):
    """In-app PDF viewer with markup: page navigation, zoom (fit width /
    fit page / percentage), pen + highlighter + text markup saved with
    the attachment, Save a Copy (markup baked in), Print (markup baked
    in), and Open externally — the PDF counterpart of ImageViewerDialog.
    """

    _MARKUP_COLORS = (("Red", "#e5484d"), ("Accent", None),
                      ("Amber", "#e8a13a"), ("Black", "#23252b"),
                      ("White", "#f4f5f7"))

    def __init__(self, path, title="", parent=None):
        super().__init__(parent)
        stack = _pdf_view_stack()
        self._stack = _pdf_stack()  # full stack (print/save); may be None
        self._path = str(path)
        self.setMinimumSize(700, 480)
        self.setWindowTitle(title or Path(path).name)

        layout = install_chrome(self, title or Path(path).name)

        self._doc = stack["doc"](self)
        self._doc.load(self._path)
        ok = (self._doc.status() == stack["doc"].Status.Ready
              and self._doc.pageCount() > 0)
        self._markup = load_markup(self._path) if ok else {}
        self._history = []          # [(page, item)] for Undo
        self._dirty = False
        self._tool = "scroll"
        self._markup_color = "#e5484d"
        self._scale = 1.0           # pixels per PDF point (1.0 = 100%)
        self._current = 0
        self._page_widgets = []
        self._page_tops = []
        self._img_cache = {}

        # ---- navigation / zoom row ----
        controls = QHBoxLayout()
        controls.setSpacing(8)
        self._prev_btn = QPushButton("‹ Prev")
        self._prev_btn.setObjectName("ghost")
        self._prev_btn.clicked.connect(lambda: self._step_page(-1))
        controls.addWidget(self._prev_btn)
        self._page_label = QLabel()
        self._page_label.setObjectName("progressLabel")
        controls.addWidget(self._page_label)
        self._next_btn = QPushButton("Next ›")
        self._next_btn.setObjectName("ghost")
        self._next_btn.clicked.connect(lambda: self._step_page(1))
        controls.addWidget(self._next_btn)
        controls.addStretch(1)
        self._zoom_out_btn = QPushButton("−")
        self._zoom_out_btn.setObjectName("ghost")
        self._zoom_out_btn.setToolTip("Zoom out")
        self._zoom_out_btn.clicked.connect(lambda: self._zoom_by(1 / 1.25))
        controls.addWidget(self._zoom_out_btn)
        self._zoom_label = QLabel("100%")
        self._zoom_label.setObjectName("progressLabel")
        controls.addWidget(self._zoom_label)
        self._zoom_in_btn = QPushButton("+")
        self._zoom_in_btn.setObjectName("ghost")
        self._zoom_in_btn.setToolTip("Zoom in")
        self._zoom_in_btn.clicked.connect(lambda: self._zoom_by(1.25))
        controls.addWidget(self._zoom_in_btn)
        self._fit_w_btn = QPushButton("Fit width")
        self._fit_w_btn.setObjectName("ghost")
        self._fit_w_btn.clicked.connect(self._set_fit_width)
        controls.addWidget(self._fit_w_btn)
        self._fit_p_btn = QPushButton("Fit page")
        self._fit_p_btn.setObjectName("ghost")
        self._fit_p_btn.clicked.connect(self._set_fit_page)
        controls.addWidget(self._fit_p_btn)
        layout.addLayout(controls)

        # ---- markup tools row ----
        tools = QHBoxLayout()
        tools.setSpacing(6)
        self._tool_btns = {}
        for key, label, tip in (
                ("scroll", "Scroll", "Scroll and read (no marking)"),
                ("pen", "Pen", "Draw freehand — pen, touch or mouse"),
                ("highlight", "Highlight", "Translucent marker"),
                ("text", "Text", "Click on the page to place a note")):
            b = QPushButton(label)
            b.setObjectName("ghost")
            b.setCheckable(True)
            b.setToolTip(tip)
            b.clicked.connect(lambda _=False, k=key: self._set_tool(k))
            self._tool_btns[key] = b
            tools.addWidget(b)
        tools.addSpacing(6)
        self._swatches = []
        for name, hexv in self._MARKUP_COLORS:
            color = hexv if hexv else shifted_color("#4f8cff")
            b = QPushButton()
            b.setFixedSize(18, 18)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"{name} markup colour")
            b.clicked.connect(
                lambda _=False, c=color: self._set_markup_color(c))
            self._swatches.append((b, color))
            tools.addWidget(b)
        tools.addSpacing(6)
        self._undo_btn = QPushButton("Undo")
        self._undo_btn.setObjectName("ghost")
        self._undo_btn.clicked.connect(self._undo)
        tools.addWidget(self._undo_btn)
        self._clear_btn = QPushButton("Clear page")
        self._clear_btn.setObjectName("ghost")
        self._clear_btn.clicked.connect(self._clear_page)
        tools.addWidget(self._clear_btn)
        tools.addStretch(1)
        self._save_markup_btn = QPushButton("Save markup")
        self._save_markup_btn.setObjectName("ghost")
        self._save_markup_btn.setToolTip(
            "Save the markup with the attachment (the PDF file itself "
            "is not changed)")
        self._save_markup_btn.clicked.connect(self._save_markup)
        tools.addWidget(self._save_markup_btn)
        layout.addLayout(tools)

        # ---- pages (or an error note) ----
        if ok:
            self._scroll = QScrollArea(self)
            self._scroll.setWidgetResizable(False)
            self._scroll.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
            self._pages_host = QWidget()
            self._pages_layout = QVBoxLayout(self._pages_host)
            self._pages_layout.setContentsMargins(12, 12, 12, 12)
            self._pages_layout.setSpacing(12)
            self._scroll.setWidget(self._pages_host)
            layout.addWidget(self._scroll, 1)
            self._scroll.verticalScrollBar().valueChanged.connect(
                self._on_scrolled)
            for i in range(self._doc.pageCount()):
                w = PdfPageWidget(self, i, self._doc.pagePointSize(i))
                self._page_widgets.append(w)
                self._pages_layout.addWidget(w)
        else:
            self._scroll = None
            err = QLabel(
                "This PDF could not be opened in the built-in viewer "
                "(it may be damaged or password-protected).\n"
                "Use “Open externally” to try your PDF app instead.")
            err.setObjectName("hint")
            err.setWordWrap(True)
            err.setAlignment(Qt.AlignCenter)
            layout.addWidget(err, 1)

        # ---- footer ----
        footer = QHBoxLayout()
        hint = QLabel("Markup saves with the attachment · Ctrl+S saves "
                      "markup · ←/→ change page")
        hint.setObjectName("hint")
        footer.addWidget(hint)
        footer.addStretch(1)
        self._save_copy_btn = QPushButton("Save a Copy…")
        self._save_copy_btn.setObjectName("ghost")
        self._save_copy_btn.setToolTip(
            "Save a copy of this PDF (markup baked in) somewhere else — "
            "the attachment stored with the task is not changed")
        self._save_copy_btn.clicked.connect(self._save_copy)
        footer.addWidget(self._save_copy_btn)
        self._print_btn = QPushButton("Print…")
        self._print_btn.setObjectName("ghost")
        self._print_btn.clicked.connect(self._print)
        footer.addWidget(self._print_btn)
        external = QPushButton("Open externally")
        external.setObjectName("ghost")
        external.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(self._path)))
        footer.addWidget(external)
        close_btn = QPushButton("Close")
        close_btn.setObjectName("primary")
        close_btn.setDefault(True)
        close_btn.clicked.connect(self.accept)
        footer.addWidget(close_btn)
        layout.addLayout(footer)
        _chip_font_tree(self)

        for w in (self._prev_btn, self._next_btn, self._zoom_out_btn,
                  self._zoom_in_btn, self._fit_w_btn, self._fit_p_btn,
                  self._save_copy_btn, self._print_btn):
            w.setEnabled(ok)
        if ok and self._stack is None:
            # Viewing + markup work; only print/save-copy are missing.
            for w in (self._save_copy_btn, self._print_btn):
                w.setEnabled(False)
                w.setToolTip(
                    "Not available in this install (the print "
                    "components are missing) — viewing and markup "
                    "still work.")
        for b in self._tool_btns.values():
            b.setEnabled(ok)
        self._set_tool("scroll")
        self._sync_markup_ui()
        self._render_page_label()

        try:
            avail = QGuiApplication.primaryScreen().availableGeometry()
            self.resize(min(940, avail.width() - 60),
                        min(1020, avail.height() - 60))
        except Exception:
            self.resize(940, 1020)
        if ok:
            QTimer.singleShot(0, self._set_fit_width)

    # ------------------------------------------------------------- pages
    def _layout_pages(self):
        total_h = 24
        max_w = 0
        self._page_tops = []
        for w in self._page_widgets:
            pw = max(1, int(w._pt.width() * self._scale))
            ph = max(1, int(w._pt.height() * self._scale))
            w.setFixedSize(pw, ph)
            self._page_tops.append(total_h)
            total_h += ph + 12
            max_w = max(max_w, pw)
        self._pages_host.setFixedSize(max_w + 24, total_h + 12)
        self._img_cache.clear()
        self._render_visible()
        self._zoom_label.setText(f"{int(round(self._scale * 100))}%")

    def _render_page(self, index):
        if index in self._img_cache:
            return self._img_cache[index]
        pt = self._doc.pagePointSize(index)
        w = max(1, int(pt.width() * self._scale))
        h = max(1, int(pt.height() * self._scale))
        if w > 2400:  # bound memory on extreme zooms
            h = int(h * 2400 / w)
            w = 2400
        img = self._doc.render(index, QSize(w, h))
        if len(self._img_cache) > 10:
            far = max(self._img_cache,
                      key=lambda k: abs(k - self._current))
            self._img_cache.pop(far, None)
            if 0 <= far < len(self._page_widgets):
                self._page_widgets[far].set_image(None)
        self._img_cache[index] = img
        return img

    def _render_visible(self):
        if self._scroll is None:
            return
        bar = self._scroll.verticalScrollBar()
        top = bar.value()
        bottom = top + self._scroll.viewport().height()
        for i, w in enumerate(self._page_widgets):
            y0 = self._page_tops[i] if i < len(self._page_tops) else 0
            y1 = y0 + w.height()
            if y1 >= top - w.height() and y0 <= bottom + w.height():
                if w._image is None:
                    w.set_image(self._render_page(i))

    def _on_scrolled(self, _value):
        self._render_visible()
        # Current page = the one under the viewport centre.
        if not self._page_widgets:
            return
        bar = self._scroll.verticalScrollBar()
        centre = bar.value() + self._scroll.viewport().height() // 2
        current = 0
        for i, w in enumerate(self._page_widgets):
            if self._page_tops[i] <= centre:
                current = i
        if current != self._current:
            self._current = current
            self._render_page_label()

    def _goto_page(self, index):
        index = min(max(index, 0), self._doc.pageCount() - 1)
        self._current = index
        if self._scroll is not None and index < len(self._page_tops):
            self._scroll.verticalScrollBar().setValue(
                max(0, self._page_tops[index] - 12))
        self._render_visible()
        self._render_page_label()

    def _step_page(self, delta):
        self._goto_page(self._current + delta)

    def _render_page_label(self):
        n = self._doc.pageCount()
        self._page_label.setText(
            f"Page {self._current + 1} of {n}" if n else "No pages")
        self._prev_btn.setEnabled(bool(n) and self._current > 0)
        self._next_btn.setEnabled(bool(n) and self._current < n - 1)

    # -------------------------------------------------------------- zoom
    def _set_scale(self, scale):
        self._scale = min(max(scale, 0.3), 4.0)
        self._layout_pages()

    def _zoom_by(self, factor):
        self._set_scale(self._scale * factor)

    def _set_fit_width(self):
        if self._scroll is None or not self._page_widgets:
            return
        pw = max(w._pt.width() for w in self._page_widgets)
        avail = max(200, self._scroll.viewport().width() - 28)
        self._set_scale(avail / pw)
        self._goto_page(self._current)

    def _set_fit_page(self):
        if self._scroll is None or not self._page_widgets:
            return
        w = self._page_widgets[self._current]
        avail_w = max(200, self._scroll.viewport().width() - 28)
        avail_h = max(200, self._scroll.viewport().height() - 28)
        self._set_scale(min(avail_w / w._pt.width(),
                            avail_h / w._pt.height()))
        self._goto_page(self._current)

    # ------------------------------------------------------------ markup
    def _set_tool(self, tool):
        self._tool = tool
        for key, b in self._tool_btns.items():
            b.setChecked(key == tool)
        cursor = {"scroll": Qt.OpenHandCursor, "pen": Qt.CrossCursor,
                  "highlight": Qt.CrossCursor,
                  "text": Qt.IBeamCursor}[tool]
        for w in self._page_widgets:
            w.setCursor(cursor)
        self._sync_markup_ui()

    def _set_markup_color(self, color):
        self._markup_color = color
        self._sync_markup_ui()

    def _sync_markup_ui(self):
        for btn, color in self._swatches:
            ring = ("border: 2px solid #f4f5f7;" if color == self._markup_color
                    else "border: 2px solid rgba(127,127,127,0.35);")
            btn.setStyleSheet(
                f"background: {color}; border-radius: 9px; {ring}")
        self._undo_btn.setEnabled(bool(self._history))
        self._clear_btn.setEnabled(
            bool(self._markup.get(self._current)))
        self._save_markup_btn.setEnabled(self._dirty)

    def _add_item(self, page, item):
        self._markup.setdefault(page, []).append(item)
        self._history.append((page, item))
        self._dirty = True
        self._sync_markup_ui()

    def _undo(self):
        if not self._history:
            return
        page, item = self._history.pop()
        items = self._markup.get(page, [])
        if item in items:
            items.remove(item)
        self._dirty = True
        if 0 <= page < len(self._page_widgets):
            self._page_widgets[page].update()
        self._sync_markup_ui()

    def _clear_page(self):
        if not self._markup.get(self._current):
            return
        self._markup[self._current] = []
        self._history = [h for h in self._history
                         if h[0] != self._current]
        self._dirty = True
        self._page_widgets[self._current].update()
        self._sync_markup_ui()

    def _place_text(self, page_widget, pos_px):
        editor = QLineEdit(page_widget)
        editor.setPlaceholderText("Type, then Enter")
        editor.move(max(0, int(pos_px.x()) - 2), max(0, int(pos_px.y()) - 4))
        editor.resize(260, 26)
        editor.show()
        editor.setFocus()
        done = {"v": False}

        def commit():
            if done["v"]:
                return
            done["v"] = True
            text = editor.text().strip()
            editor.deleteLater()
            if text:
                pt = page_widget._to_pt(pos_px)
                self._add_item(page_widget.page, {
                    "t": "x", "c": self._markup_color, "s": 14.0,
                    "p": pt, "text": text})
                page_widget.update()

        editor.editingFinished.connect(commit)

    def _save_markup(self):
        try:
            save_markup(self._path, self._markup)
        except OSError as exc:
            show_toast(self, "error", "Markup not saved",
                       f"Could not save the markup:\n{exc}")
            return
        self._dirty = False
        self._sync_markup_ui()
        show_toast(self, "success", "Markup saved",
                   "Your markup is saved with this attachment.")

    def done(self, result):  # noqa: N802 (Qt virtual)
        if self._dirty:
            choice = app_choose(
                self, "Unsaved markup",
                "You have markup that has not been saved. Save it "
                "before closing?",
                [("Save", "primary"), ("Discard", "ghost"),
                 ("Cancel", "ghost")])
            if choice in (None, "Cancel"):
                return
            if choice == "Save":
                self._save_markup()
                if self._dirty:
                    return  # save failed — stay open
            self._dirty = False
        super().done(result)

    # -------------------------------------------------------- save/print
    def keyPressEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.key() == Qt.Key_Left:
            self._step_page(-1)
            event.accept()
            return
        if event.key() == Qt.Key_Right:
            self._step_page(1)
            event.accept()
            return
        if event.matches(QKeySequence.Save):
            if self._dirty:
                self._save_markup()
            else:
                self._save_copy()
            event.accept()
            return
        if event.matches(QKeySequence.Print):
            self._print()
            event.accept()
            return
        super().keyPressEvent(event)

    def _save_copy(self):
        if self._doc.pageCount() == 0:
            return
        if self._stack is None:
            show_toast(self, "error", "Save a Copy unavailable",
                       "The PDF-writer components are missing in this "
                       "install — viewing and markup still work.")
            return
        dest, _ = QFileDialog.getSaveFileName(
            self, "Save a copy of this PDF",
            str(Path.home() / Path(self._path).name),
            "PDF files (*.pdf)", "",
            QFileDialog.DontUseNativeDialog)
        if not dest:
            return
        if Path(dest).resolve() != Path(self._path).resolve():
            try:
                self._bake_pdf(dest)
            except Exception as exc:
                show_toast(self, "error", "Save failed",
                           f"Could not save the copy:\n{exc}")
                return
            show_toast(self, "success", "Copy saved",
                       f"Saved to:\n{dest}")

    def _bake_pdf(self, dest):
        """Write a copy with the markup baked in (pages rendered at
        200 DPI, markup drawn over them)."""
        stack = self._stack
        writer = stack["pdf_writer"](dest)
        writer.setResolution(200)
        if self._doc.pageCount():
            writer.setPageSize(stack["page_size"](
                self._doc.pagePointSize(0), stack["page_size"].Unit.Point))
        painter = QPainter(writer)
        try:
            for i in range(self._doc.pageCount()):
                pt = self._doc.pagePointSize(i)
                if i > 0:
                    writer.setPageSize(stack["page_size"](
                        pt, stack["page_size"].Unit.Point))
                    writer.newPage()
                pw = int(pt.width() * 200 / 72)
                ph = int(pt.height() * 200 / 72)
                img = self._doc.render(i, QSize(pw, ph))
                target = painter.viewport()
                painter.drawImage(target, img)
                factor = target.width() / pt.width()
                _draw_markup_items(painter, self._markup.get(i, []), factor)
        finally:
            painter.end()

    def _print(self):
        if self._doc.pageCount() == 0:
            return
        if self._stack is None:
            show_toast(self, "error", "Print unavailable",
                       "The print components are missing in this "
                       "install — viewing and markup still work.")
            return
        printer = self._stack["printer"](self._stack["printer"].HighResolution)
        printer.setDocName(Path(self._path).name)
        dlg = self._stack["print_dialog"](printer, self)
        if dlg.exec():
            self.print_to_printer(printer)

    def print_to_printer(self, printer):
        """Render every selected page (markup included) onto ``printer``.

        Separated from the dialog prompt so the render path is testable
        (a PDF-output printer stands in for paper).
        """
        QPrinter = self._stack["printer"]
        total = self._doc.pageCount()
        first = max(0, (printer.fromPage() or 1) - 1)
        last = min(total - 1, (printer.toPage() or total) - 1)
        page_rect = printer.pageRect(QPrinter.Unit.DevicePixel)
        painter = QPainter(printer)
        try:
            for i in range(first, last + 1):
                if i > first:
                    printer.newPage()
                point_size = self._doc.pagePointSize(i)
                if point_size.isEmpty():
                    continue
                scale = min(page_rect.width() / point_size.width(),
                            page_rect.height() / point_size.height())
                w = max(1, int(point_size.width() * scale))
                h = max(1, int(point_size.height() * scale))
                img = self._doc.render(i, QSize(w, h))
                if img.isNull():
                    continue
                x = page_rect.x() + (page_rect.width() - w) / 2
                y = page_rect.y() + (page_rect.height() - h) / 2
                painter.drawImage(QPointF(x, y), img)
                painter.save()
                painter.translate(x, y)
                _draw_markup_items(painter, self._markup.get(i, []),
                                   w / point_size.width())
                painter.restore()
        finally:
            painter.end()
# --------------------------------------------------------------- attachments
# Outlook drag & drop (V1.9.10): dragging an attachment out of Outlook does
# NOT provide file URLs — Outlook offers "virtual files" through the
# FileGroupDescriptorW clipboard format (the file names) plus a FileContents
# stream (the bytes). Explorer-style drops keep working via URLs; these
# helpers add the Outlook path.
OUTLOOK_DESCRIPTOR_FORMATS = ("FileGroupDescriptorW", "FileGroupDescriptor")
OUTLOOK_CONTENTS_FORMAT = "FileContents"


def _sanitize_drop_filename(name):
    """Reduce a dropped file name to a safe plain file name (or '')."""
    name = (name or "").replace("\\", "/").split("/")[-1].strip()
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name).rstrip(". ")
    return name


def _parse_file_group_descriptor(data, wide):
    """File names from a FileGroupDescriptor(W) blob. Never raises.

    FILEDESCRIPTOR layout (both variants): the variable fields before
    cFileName total 72 bytes; the W variant stores 260 UTF-16 chars
    (descriptor 592 bytes), the A variant 260 ANSI chars (332 bytes).
    """
    names = []
    if not data or len(data) < 4:
        return names
    try:
        count = struct.unpack_from("<I", bytes(data), 0)[0]
    except struct.error:
        return names
    desc_size = 592 if wide else 332
    name_size = 520 if wide else 260
    for i in range(min(count, 64)):
        base = 4 + i * desc_size
        chunk = bytes(data[base + 72: base + 72 + name_size])
        if len(chunk) < 2:
            break
        if wide:
            text = chunk.decode("utf-16-le", errors="ignore")
        else:
            text = chunk.decode("cp1252", errors="ignore")
        name = _sanitize_drop_filename(text.split("\x00")[0])
        if name:
            names.append(name)
    return names


def mime_virtual_file_names(md):
    """File names offered as virtual files (Outlook), or []."""
    if md is None:
        return []
    try:
        formats = md.formats()
    except Exception:
        return []
    for fmt in OUTLOOK_DESCRIPTOR_FORMATS:
        if fmt in formats:
            try:
                names = _parse_file_group_descriptor(
                    md.data(fmt), fmt.endswith("W"))
            except Exception:
                names = []
            if names:
                return names
    return []


def mime_has_virtual_files(md):
    """True when the mime data carries Outlook-style virtual files."""
    return bool(mime_virtual_file_names(md))


def extract_virtual_files(md):
    """Pull (filename, bytes) pairs out of virtual-file mime data.

    Returns (files, skipped_names). Qt exposes one FileContents stream per
    data() call; if a source hands back the identical stream again for a
    different name (a known first-file-only limitation), the repeat is
    reported as skipped instead of being saved under the wrong name.
    """
    files, skipped = [], []
    seen = {}
    for name in mime_virtual_file_names(md):
        try:
            raw = bytes(md.data(OUTLOOK_CONTENTS_FORMAT))
        except Exception:
            raw = b""
        if not raw:
            skipped.append(name)
            continue
        digest = (len(raw), zlib.crc32(raw))
        if digest in seen and seen[digest] != name:
            skipped.append(name)
            continue
        seen[digest] = name
        files.append((name, raw))
    return files, skipped


# Per-row attachment trash button (V1.9.16): size/margin shared by the
# paint delegate and the viewport click intercept below.
_ATTACH_TRASH_SIZE = 16
_ATTACH_TRASH_MARGIN = 8


class _AttachmentTrashDelegate(QStyledItemDelegate):
    """Paints a trash icon on the right edge of every attachment row.

    Rows are plain items (thumbnail + name), so a real button widget
    per row would break selection, preview clicks, drag-out and the
    context menu. Painting the icon here plus intercepting clicks on
    it in AttachmentsWidget.eventFilter gives the same one-click
    delete without touching any row behavior.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._hover_row = -1

    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        rect = option.rect
        x = rect.right() - _ATTACH_TRASH_MARGIN - _ATTACH_TRASH_SIZE
        y = rect.center().y() - _ATTACH_TRASH_SIZE // 2
        # V1.9.17: the trash turns red when the mouse is over it.
        color = "#e5484d" if index.row() == self._hover_row else "#8a919c"
        pix = svg_icon("trash", color,
                       _ATTACH_TRASH_SIZE).pixmap(_ATTACH_TRASH_SIZE,
                                                  _ATTACH_TRASH_SIZE)
        painter.drawPixmap(x, y, pix)


class AttachmentsWidget(QFrame):
    """Attachment list with drag-drop, paste, thumbnails and single-click preview.

    When ``staging=True`` (used by the New Task dialog, where no task id exists
    yet), files are copied into a temp staging dir and held in memory; the
    caller commits them with :meth:`staged_files` after the task is created.
    """

    changed = Signal()

    def __init__(self, db, task_id, parent=None, staging=False):
        super().__init__(parent)
        self.setObjectName("attachPanel")
        self.setAcceptDrops(True)
        self.db = db
        self.task_id = task_id
        self.staging = staging
        self._staged = []  # [{"filename", "stored", "size"}]
        self._staging_dir = None
        if staging:
            self._staging_dir = Path(tempfile.mkdtemp(prefix="tasklist_stage_"))

        # V1.9.30 revisions: id_filter pins the list to one frozen
        # revision's attachment ids; _read_only freezes interactions
        # (a frozen revision can be viewed, never changed).
        self.id_filter = None
        self._read_only = False
        self._top_layout = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(6)

        top = QHBoxLayout()
        self._top_layout = top
        self.title = QLabel("ATTACHMENTS")
        self.title.setObjectName("sectionLabel")
        top.addWidget(self.title)
        top.addStretch(1)
        # V1.9.17: the Remove and Paste buttons are gone — per-row trash
        # replaces Remove outright (V1.9.16 kept both; the user had
        # ordered trash INSTEAD of Remove), and Ctrl+V still pastes via
        # the detail window's shortcut. "Add files…" sits where Remove
        # was: at the right end of the row.
        add_btn = QPushButton("Add files…")
        add_btn.setObjectName("ghost")
        add_btn.clicked.connect(self.browse_files)
        self._add_btn = add_btn
        top.addWidget(add_btn)
        layout.addLayout(top)

        self.list = QListWidget()
        self.list.setObjectName("attachList")
        self.list.setMinimumHeight(64)
        self.list.setMaximumHeight(132)
        # V1.9.10: the list covers most of the panel, so IT must accept
        # drops too — its viewport's drag events are forwarded to this
        # widget's handlers in eventFilter (Explorer files + Outlook).
        self.list.setAcceptDrops(True)
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list.viewport().installEventFilter(self)
        self._drag_start_pos = None
        self._last_drag_out_ms = 0
        self.list.setIconSize(QSize(44, 44))
        self._trash_delegate = _AttachmentTrashDelegate(self.list)
        self.list.setItemDelegate(self._trash_delegate)
        self.list.viewport().setMouseTracking(True)
        self.list.itemClicked.connect(self.open_item)
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._context_menu)
        # Attachments drag OUT with the mouse — touch scrolling only.
        enable_touch_scroll(self.list, mouse_drag=False)
        layout.addWidget(self.list)

        hint = QLabel(
            "Drag files here or paste images (Ctrl+V). Images and PDFs can "
            "be dragged straight from Outlook. Click an image to preview. "
            "Drag files out to Explorer to copy them."
        )
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self.refresh()

    # -- storage abstraction: live db records vs. staged files --
    def _dest_dir(self):
        if self.staging:
            return self._staging_dir
        return task_attachments_dir(self.db, self.task_id)

    def _records(self):
        if self.staging:
            return list(self._staged)
        if self.id_filter is not None:
            # A frozen revision shows exactly its snapshotted set
            # (rows are retained even when later revisions remove
            # them, so this reads the full list, not the current one).
            return [a for a in self.db.list_attachments(self.task_id)
                    if a["id"] in self.id_filter]
        return self.db.visible_attachments(self.task_id)

    def set_read_only(self, read_only):
        """Frozen-revision mode: files can be opened, nothing can be
        added, dropped, pasted or removed."""
        self._read_only = bool(read_only)
        self._add_btn.setVisible(not self._read_only)
        self.setAcceptDrops(not self._read_only)

    def _record(self, filename, stored, size):
        if self.staging:
            self._staged.append(
                {"filename": filename, "stored": stored, "size": size}
            )
        else:
            self.db.add_attachment(self.task_id, filename, stored, size)
            self.db.log_activity(self.task_id, "attachment",
                                 f"Attachment added: {filename}")

    def _get_record(self, item):
        key = item.data(Qt.UserRole)
        if self.staging:
            for rec in self._staged:
                if rec["stored"] == key:
                    return rec
            return None
        return self.db.get_attachment(key)

    def _delete_record(self, rec):
        if self._read_only:
            return
        if not self.staging:
            # V1.9.30: if a frozen revision still holds this file,
            # removing it here must not touch that revision -- the
            # row/file stay and the id is only hidden from the
            # current revision.
            if self.db.detach_attachment(self.task_id, rec["id"]) == "soft":
                self.db.log_activity(
                    self.task_id, "attachment",
                    f"Attachment removed from this revision: "
                    f"{rec.get('filename', '')}")
                self.refresh()
                self.changed.emit()
                return
        path = self._record_path(rec)
        try:
            if path.exists():
                path.unlink()
        except OSError:
            pass
        if self.staging:
            self._staged = [r for r in self._staged if r["stored"] != rec["stored"]]
        else:
            self.db.delete_attachment(rec["id"])
            self.db.log_activity(self.task_id, "attachment",
                                 f"Attachment removed: {rec.get('filename', '')}")

    def _record_path(self, rec):
        return self._dest_dir() / rec["stored"]

    def staged_files(self):
        """Files staged by the New Task dialog: [(filename, Path), ...]."""
        return [(r["filename"], self._staging_dir / r["stored"]) for r in self._staged]

    def cleanup_staging(self):
        if self._staging_dir is not None:
            shutil.rmtree(self._staging_dir, ignore_errors=True)
            self._staging_dir = None

    # -- drag & drop --
    def set_revision_filter(self, ids):
        """Pin (frozen revision) or unpin (None = current revision)."""
        self.id_filter = None if ids is None else set(ids)
        self.refresh()

    def _drag_acceptable(self, md):
        return (md.hasUrls() or md.hasImage()
                or mime_has_virtual_files(md))

    def dragEnterEvent(self, event):
        if self._read_only:
            event.ignore()
            return
        md = event.mimeData()
        if self._drag_acceptable(md):
            event.acceptProposedAction()
            self.setProperty("dragOver", True)
            self.style().unpolish(self)
            self.style().polish(self)

    def dragMoveEvent(self, event):
        if self._drag_acceptable(event.mimeData()):
            event.acceptProposedAction()

    def dragLeaveEvent(self, event):
        self.setProperty("dragOver", False)
        self.style().unpolish(self)
        self.style().polish(self)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        if self._read_only:
            event.ignore()
            return
        self.setProperty("dragOver", False)
        self.style().unpolish(self)
        self.style().polish(self)
        md = event.mimeData()
        if md.hasUrls():
            paths = [u.toLocalFile() for u in md.urls() if u.isLocalFile()]
            self.add_files([p for p in paths if p and Path(p).is_file()])
            event.acceptProposedAction()
        elif mime_has_virtual_files(md):
            # Outlook: no URLs — read the virtual files' bytes directly.
            self.add_virtual_files(md)
            event.acceptProposedAction()
        elif md.hasImage():
            self._save_image(QApplication.clipboard().image())
            event.acceptProposedAction()

    def add_virtual_files(self, md):
        """Save Outlook-style virtual files from mime data as attachments."""
        files, skipped = extract_virtual_files(md)
        for name, raw in files:
            dest = self._unique_dest(name)
            try:
                dest.write_bytes(raw)
            except OSError:
                skipped.append(name)
                continue
            self._record(name, dest.name, len(raw))
        if files:
            self.refresh()
            self.changed.emit()
        if skipped:
            show_toast(self, "warning", "Some files could not be added",
                       "These files were not released by the source app:\n"
                       + "\n".join(skipped[:5]))
        return len(files)

    # -- actions --
    def browse_files(self):
        if self._read_only:
            return
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Add files to task", "",
            options=QFileDialog.DontUseNativeDialog)
        if paths:
            self.add_files(paths)

    def paste_from_clipboard(self):
        if self._read_only:
            return
        clip = QApplication.clipboard()
        md = clip.mimeData()
        if md.hasImage():
            self._save_image(clip.image())
        elif mime_has_virtual_files(md):
            # An attachment copied inside Outlook arrives as virtual files.
            self.add_virtual_files(md)
        elif md.hasUrls():
            paths = [u.toLocalFile() for u in md.urls() if u.isLocalFile()]
            files = [p for p in paths if p and Path(p).is_file()]
            if files:
                self.add_files(files)

    def _save_image(self, image):
        if image.isNull():
            return
        name = f"Pasted image {datetime.now():%Y-%m-%d %H-%M-%S}.png"
        dest = self._unique_dest(name)
        image.save(str(dest), "PNG")
        self._record(name, dest.name, dest.stat().st_size)
        self.refresh()
        self.changed.emit()

    def add_files(self, paths):
        dest_dir = self._dest_dir()
        for src in paths:
            src_p = Path(src)
            dest = dest_dir / src_p.name
            if dest.exists():
                stem, suffix = src_p.stem, src_p.suffix
                i = 1
                while (dest_dir / f"{stem} ({i}){suffix}").exists():
                    i += 1
                dest = dest_dir / f"{stem} ({i}){suffix}"
            try:
                shutil.copy2(src_p, dest)
            except OSError:
                continue
            self._record(src_p.name, dest.name, dest.stat().st_size)
        self.refresh()
        self.changed.emit()

    def _unique_dest(self, name):
        dest_dir = self._dest_dir()
        dest = dest_dir / name
        stem, suffix = Path(name).stem, Path(name).suffix
        i = 1
        while dest.exists():
            dest = dest_dir / f"{stem} ({i}){suffix}"
            i += 1
        return dest

    def _stored_path(self, att):
        # kept for compatibility; prefer _record_path for new code
        return self._record_path(att)

    def open_item(self, item):
        # a click-release ending a drag-out must not ALSO open the file
        if QDateTime.currentMSecsSinceEpoch() - self._last_drag_out_ms < 400:
            return
        att = self._get_record(item)
        if not att:
            return
        path = self._record_path(att)
        if not path.exists():
            show_toast(self, "error", "File missing",
                       f"Could not find:\n{att['filename']}")
            return
        if is_image_file(att["filename"]):
            images = [str(self._record_path(r)) for r in self._records()
                      if is_image_file(r["filename"])
                      and self._record_path(r).exists()]
            index = 0
            sp = str(path)
            if sp in images:
                index = images.index(sp)
            ImageViewerDialog(path, att["filename"], self,
                              images=images, index=index).exec()
        elif is_pdf_file(att["filename"]) and pdf_available():
            # V1.9.10: PDFs open in the built-in viewer (with Save/Print),
            # not an external app; "Open externally" lives in the viewer.
            PDFViewerDialog(path, att["filename"], self).exec()
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _context_menu(self, pos):
        item = self.list.itemAt(pos)
        if not item:
            return
        menu = themed_menu(self)
        att = self._get_record(item)
        previewable = att and (is_image_file(att["filename"])
                               or (is_pdf_file(att["filename"])
                                   and pdf_available()))
        if previewable:
            menu.addAction("Preview", lambda: self.open_item(item))
            menu.addAction("Open externally",
                           lambda: QDesktopServices.openUrl(
                               QUrl.fromLocalFile(str(self._record_path(att)))))
        else:
            menu.addAction("Open", lambda: self.open_item(item))
        menu.addSeparator()
        menu.addAction("Remove", lambda: self.remove_item(item))
        menu.exec(self.list.mapToGlobal(pos))

    def remove_item(self, item):
        self._delete_item(item)
        self.refresh()
        self.changed.emit()

    def _delete_item(self, item):
        att = self._get_record(item)
        if not att:
            return
        self._delete_record(att)

    def eventFilter(self, obj, event):
        if obj is self.list.viewport():
            t = event.type()
            # V1.9.10: forward drops landing on the list to the panel's own
            # drag & drop handlers (Explorer URLs + Outlook virtual files).
            if t == QEvent.DragEnter:
                self.dragEnterEvent(event)
                return event.isAccepted()
            if t == QEvent.DragMove:
                self.dragMoveEvent(event)
                return event.isAccepted()
            if t == QEvent.Drop:
                self.dropEvent(event)
                return True
            if t == QEvent.DragLeave:
                self.dragLeaveEvent(event)
                return False
            if t == QEvent.Leave:
                if self._trash_delegate._hover_row != -1:
                    self._trash_delegate._hover_row = -1
                    self.list.viewport().update()
                return False
            if t == QEvent.MouseMove:
                # V1.9.17: track the trash icon under the cursor so the
                # delegate paints it red on hover (and the cursor turns
                # into a hand). Runs on every move, independent of the
                # drag-out branch below.
                pos = event.position().toPoint()
                hover_row = -1
                item = self.list.itemAt(pos)
                if item is not None:
                    row = self.list.visualItemRect(item)
                    trash = QRect(
                        row.right() - _ATTACH_TRASH_MARGIN - _ATTACH_TRASH_SIZE,
                        row.center().y() - _ATTACH_TRASH_SIZE // 2,
                        _ATTACH_TRASH_SIZE, _ATTACH_TRASH_SIZE)
                    if trash.contains(pos):
                        hover_row = self.list.row(item)
                if hover_row != self._trash_delegate._hover_row:
                    self._trash_delegate._hover_row = hover_row
                    self.list.viewport().update()
                self.list.viewport().setCursor(
                    Qt.PointingHandCursor if hover_row >= 0
                    else Qt.ArrowCursor)
            if t == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
                pos = event.position().toPoint()
                # V1.9.16: a press on a row's trash icon deletes that
                # row directly — no need to open/preview the file first
                # to select it. Consumed here, so the list never sees
                # it: no selection change, no preview opening.
                item = self.list.itemAt(pos)
                if item is not None:
                    row = self.list.visualItemRect(item)
                    trash = QRect(
                        row.right() - _ATTACH_TRASH_MARGIN - _ATTACH_TRASH_SIZE,
                        row.center().y() - _ATTACH_TRASH_SIZE // 2,
                        _ATTACH_TRASH_SIZE, _ATTACH_TRASH_SIZE)
                    if trash.contains(pos):
                        self.remove_item(item)
                        return True
                self._drag_start_pos = pos
            elif t == QEvent.MouseMove and self._drag_start_pos is not None:
                delta = event.position().toPoint() - self._drag_start_pos
                if delta.manhattanLength() >= QApplication.startDragDistance():
                    self._drag_start_pos = None
                    self._start_drag_out()
                    return True
            elif t == QEvent.MouseButtonRelease:
                self._drag_start_pos = None
        return super().eventFilter(obj, event)

    def _start_drag_out(self):
        """Drag attachments OUT to Explorer / the desktop (copy action)."""
        urls = []
        for item in self.list.selectedItems():
            rec = self._get_record(item)
            if rec:
                p = self._record_path(rec)
                if p.exists():
                    urls.append(QUrl.fromLocalFile(str(p)))
        if not urls:
            return
        mime = QMimeData()
        mime.setUrls(urls)
        drag = QDrag(self)
        drag.setMimeData(mime)
        try:
            drag.exec(Qt.CopyAction)
        finally:
            # don't let the button-release at the end of the drag re-open it
            self._last_drag_out_ms = QDateTime.currentMSecsSinceEpoch()

    def _thumbnail(self, path):
        return _cached_thumbnail(path)

    def refresh(self):
        self.list.clear()
        atts = self._records()
        total = sum(int(a.get("size") or 0) for a in atts)
        self.title.setText(f"ATTACHMENTS ({len(atts)}) · {format_size(total)}")
        for att in atts:
            text = f"{att['filename']}  ·  {format_size(att['size'])}"
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, att.get("id", att["stored"]))
            path = self._record_path(att)
            if is_image_file(att["filename"]) and path.exists():
                icon = _cached_thumbnail(path)
                if icon:
                    item.setIcon(icon)
                item.setToolTip("Click to preview · right-click for options")
            elif is_pdf_file(att["filename"]) and pdf_available():
                item.setToolTip("Click to preview · right-click for options")
            else:
                item.setToolTip("Click to open · right-click for options")
            self.list.addItem(item)


# ------------------------------------------------------- quote folder field
class DropLineEdit(QLineEdit):
    """A line edit that accepts a dropped folder."""

    def dragEnterEvent(self, event):
        md = event.mimeData()
        if md.hasUrls():
            for u in md.urls():
                p = u.toLocalFile()
                if p and Path(p).is_dir():
                    event.acceptProposedAction()
                    return
        super().dragEnterEvent(event)

    def dropEvent(self, event):
        for u in event.mimeData().urls():
            p = u.toLocalFile()
            if p and Path(p).is_dir():
                self.setText(p)
                event.acceptProposedAction()
                return
        super().dropEvent(event)


class FolderPathEdit(QFrame):
    """Quote-folder picker: type/paste a path, drop a folder, or browse."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        self.edit = DropLineEdit()
        self.edit.setPlaceholderText("Paste a folder path or drop a folder here…")
        layout.addWidget(self.edit, 1)
        browse = QPushButton("Browse…")
        browse.setObjectName("ghost")
        browse.setCursor(Qt.PointingHandCursor)
        browse.clicked.connect(self._browse)
        layout.addWidget(browse)

    def _browse(self):
        start = self.edit.text().strip() or str(Path.home())
        folder = QFileDialog.getExistingDirectory(
            self, "Select quote folder", start,
            QFileDialog.DontUseNativeDialog)
        if folder:
            self.edit.setText(folder)

    def path(self):
        return self.edit.text().strip()

    def set_path(self, path):
        self.edit.setText(path or "")


# ------------------------------------------------------------ detail window
        return "unknown"


# ---- task notes rich-text helpers ----
NOTES_DEFAULT_COLOR = "#e8eaed"
NOTES_DEFAULT_SIZE = 12
# Standard swatch colors (dark-mode friendly). Displayed as rounded
# swatches, never a generic rectangle color picker.
NOTES_COLORS = [
    ("Default", "#e8eaed"),
    ("Dark Red", "#c00000"),
    ("Red", "#e5484d"),
    ("Orange", "#ed7d31"),
    ("Amber", "#d97706"),
    ("Dark Yellow", "#ca8a04"),
    ("Dark Green", "#166534"),
    ("Green", "#16a34a"),
    ("Teal", "#0f766e"),
    ("Blue", "#2563eb"),
    ("Dark Blue", "#1d4ed8"),
    ("Navy", "#1e40af"),
    ("Purple", "#7c3aed"),
    ("Violet", "#6d28d9"),
    ("Magenta", "#db2777"),
    ("Crimson", "#be123c"),
    ("Brown", "#78350f"),
    ("Slate", "#475569"),
    ("Gray", "#6b7280"),
    ("Light Gray", "#9ca3af"),
]
# Marker/highlighter palette for the Notes module (V1.9.3): soft fills
# that stay readable behind dark or light text in both themes.
NOTES_HIGHLIGHT_COLORS = [
    ("Yellow", "#fff176"),
    ("Bright Green", "#b9f6ca"),
    ("Turquoise", "#a5f3fc"),
    ("Sky Blue", "#bfdbfe"),
    ("Pink", "#fbcfe8"),
    ("Red", "#fecaca"),
    ("Orange", "#fed7aa"),
    ("Amber", "#fde68a"),
    ("Purple", "#e9d5ff"),
    ("Violet", "#ddd6fe"),
    ("Indigo", "#e0e7ff"),
    ("Emerald", "#d1fae5"),
    ("Teal", "#ccfbf1"),
    ("Light Gray", "#f1f5f9"),
    ("Warm Gray", "#e7e5e4"),
]
NOTES_MIN_SIZE = 9
NOTES_MAX_SIZE = 24


def notes_to_html(notes):
    """Convert stored task notes to HTML for QTextEdit.setHtml().

    Legacy notes are plain text: escape and convert newlines to <br>.
    Notes already saved as rich text (contain tags) pass through.
    """
    if not notes:
        return ""
    import re as _re
    if _re.search(r"</?[a-zA-Z][^>]*>", notes):
        return notes
    import html as _html
    return _html.escape(notes).replace("\n", "<br>")


def notes_to_plain(notes):
    """Strip HTML tags from notes for safe plain-text preview/truncation."""
    if not notes:
        return ""
    import re as _re
    import html as _html
    # V1.9.4: rich notes saved via QTextEdit.toHtml() carry a <head> block
    # with a <style> element (p, li { white-space: pre-wrap; } ...). Naive
    # tag stripping removes the tags but leaves the CSS text behind, which
    # then showed up raw on task cards. Remove head/style blocks first.
    text = _re.sub(r"<head[^>]*>.*?</head>", "", notes,
                   flags=_re.S | _re.I)
    text = _re.sub(r"<style[^>]*>.*?</style>", "", text,
                   flags=_re.S | _re.I)
    text = _re.sub(r"<[^>]+>", "", text)
    return _html.unescape(text).strip()


def notes_is_rich(notes):
    """True if stored notes contain HTML tags (were saved as rich text)."""
    if not notes:
        return False
    import re as _re
    return bool(_re.search(r"</?[a-zA-Z][^>]*>", notes))


def notes_editor_save(editor, was_rich=False, format_used=False):
    """Get notes from a QTextEdit for storage.

    V1.9.4: task notes are plain text, full stop. The V1.9.x rich-text
    experiment saved QTextEdit.toHtml() (with <style> blocks) that leaked
    raw CSS onto task cards with no way to repair from the UI, so the
    formatting bar is gone and notes always save as plain text. Rich
    editing lives on in the Notes module, where it belongs. The unused
    flags are kept so old call sites don't break.
    """
    return editor.toPlainText()


class _ColorFaceButton(QPushButton):
    """Notes text-color / highlight button with a PAINTED face
    (V1.9.47). The face used to be the 2x pixmap icon above; on
    125%/150% displays Qt resamples a 2x pixmap to the real
    scaling and the glyph comes out blurry (user report), and the
    buttons read as if their tooltips were gone. Painting the
    glyph in paintEvent is vector-crisp at any scaling. The
    button chrome (hover/pressed background) still comes from
    the #fmtBtn QSS via the normal style pass; only the glyph
    is drawn on top of it. Geometry is the V1.9.38 OneNote-style
    face: "A", a colour bar under it (text) or a band behind it
    (highlight), and a small dropdown chevron.

    V1.9.50 (user: "they are also larger than the icons around
    them. match the size of the buttons around them"): the
    button IS 30x30 now, exactly like every _fmt_btn sibling,
    and the face geometry is redrawn to that box -- glyph,
    band/bar and chevron in one tight, consistent mark."""

    FACE_W, FACE_H = 26, 20

    def __init__(self, kind, tooltip, parent=None):
        super().__init__(parent)
        self._kind = kind            # "text" | "hl"
        self._face_color = None
        self.setObjectName("fmtBtn")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(tooltip)
        self.setFixedSize(30, 30)

    def set_face_color(self, hex_color):
        self._face_color = hex_color
        self.update()

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        super().paintEvent(event)
        from PySide6.QtGui import QPolygonF
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.translate((self.width() - self.FACE_W) / 2.0,
                    (self.height() - self.FACE_H) / 2.0)
        dark = saved_theme() != "light"
        fg = QColor("#e8eaed" if dark else "#1c1f24")
        col = QColor(self._face_color) if self._face_color else None
        has_col = col is not None and col.isValid()
        if self._kind == "hl" and has_col:
            # V1.9.49 (user: "I can BARELY see the A"): the band
            # sits behind the WHOLE glyph. The 1.9.47 band
            # covered only the A's lower half, so the dark A's
            # top half lay on the dark button and vanished --
            # all he could see was a shapeless sliver. The band
            # spans the full glyph box; the dark A reads end to
            # end on the colour.
            p.setBrush(col)
            p.setPen(Qt.NoPen)
            p.drawRoundedRect(QRectF(0.5, 1.0, 16.0, 15.0), 2.0, 2.0)
        # The widget's own font (carries the app font strategy);
        # no bare font constructors outside fonts.py (standing
        # rule, test_v14_light_mode).
        font = self.font()
        font.setBold(True)
        font.setPixelSize(14)
        font.setStyleStrategy(QFont.NoSubpixelAntialias)
        p.setFont(font)
        # OneNote's highlight face: the A is DARK ink over the
        # colour band -- a near-white A dissolves into a light
        # band (the first painted draft did exactly that).
        if self._kind == "hl" and has_col:
            p.setPen(QColor("#17181c"))
        else:
            p.setPen(fg)
        p.drawText(QRectF(1, 0, 15, 16),
                   Qt.AlignHCenter | Qt.AlignVCenter, "A")
        if self._kind == "text" and has_col:
            p.setBrush(col)
            p.setPen(Qt.NoPen)
            p.drawRoundedRect(QRectF(2.0, 16.8, 12.0, 2.6), 1.3, 1.3)
        # Small, muted chevron (OneNote's is a whisper, not a
        # second glyph): 5px wide in the idle-text tone.
        p.setBrush(QColor("#9ba1ab" if dark else "#5c636d"))
        p.setPen(Qt.NoPen)
        p.drawPolygon(QPolygonF([QPointF(19.5, 8.0),
                                 QPointF(24.5, 8.0),
                                 QPointF(22.0, 11.0)]))
        p.end()


def _show_swatch_popup(anchor, colors, on_pick, include_none=False,
                       none_tip="None"):
    """Rounded-swatch color popup — the app-wide notes color standard
    (never the generic OS rectangle color dialog).

    `colors` is a list of (name, hex); clicking a swatch closes the
    popup and calls on_pick(hex). With include_none, a clear-entry
    swatch comes first and calls on_pick(None). Returns the popup.
    """
    popup = QWidget(None, Qt.Popup)
    popup.setObjectName("notesSwatchPopup")
    popup.setAttribute(Qt.WA_DeleteOnClose, True)
    # V1.9.30 (user: glass + fully rounded corners, globally): this
    # popup painted the default opaque square background. It gets
    # the same treatment as every other popup -- translucent window,
    # glass tint, rounded window mask (re-applied on show/resize).
    popup.setAttribute(Qt.WA_TranslucentBackground, True)
    _fill, _rim = glass_colors()
    popup.setStyleSheet(
        "QWidget#notesSwatchPopup { background: rgba(%d, %d, %d, %d);"
        " border: 1px solid rgba(%d, %d, %d, %d); border-radius: 10px; }"
        % (_fill.red(), _fill.green(), _fill.blue(), _fill.alpha(),
           _rim.red(), _rim.green(), _rim.blue(), 160))
    popup.installEventFilter(_PopupMaskFilter(popup))
    grid = QGridLayout(popup)
    grid.setContentsMargins(10, 10, 10, 10)
    grid.setSpacing(8)
    idx = 0
    if include_none:
        none_btn = QPushButton()
        none_btn.setFixedSize(28, 28)
        none_btn.setCursor(Qt.PointingHandCursor)
        none_btn.setToolTip(none_tip)
        none_btn.setIcon(svg_icon("x", "#8a919c", 12))
        none_btn.setStyleSheet(
            "QPushButton { background: transparent;"
            " border: 1px solid #3a3f47; border-radius: 8px; }"
            "QPushButton:hover { border: 2px solid #c8cdd4; }")
        none_btn.clicked.connect(lambda: (popup.close(), on_pick(None)))
        grid.addWidget(none_btn, 0, 0)
        idx = 1
    for name, hex_color in colors:
        sw = QPushButton()
        sw.setFixedSize(28, 28)
        sw.setCursor(Qt.PointingHandCursor)
        sw.setToolTip(name)
        # Rounded swatch, never a generic rectangle.
        sw.setStyleSheet(
            "QPushButton {"
            f"background-color: {hex_color};"
            "border: 1px solid #3a3f47;"
            "border-radius: 8px;"
            "}"
            "QPushButton:hover {"
            "border: 2px solid #c8cdd4;"
            "}"
        )
        sw.clicked.connect(
            lambda _=False, c=hex_color: (popup.close(), on_pick(c)))
        grid.addWidget(sw, idx // 5, idx % 5)
        idx += 1
    # Position below the anchor button.
    pos = anchor.mapToGlobal(anchor.rect().bottomLeft())
    popup.move(pos)
    popup.show()
    return popup


class NotesFindBar(QWidget):
    """In-note search bar: find and highlight text in a QTextEdit.

    Ctrl+F focuses it, Enter/↓ finds next, Shift+Enter/↑ finds previous,
    Esc closes. All matches are highlighted; the current match uses a
    stronger highlight.
    """

    def __init__(self, editor, parent=None):
        super().__init__(parent)
        self._editor = editor
        self._matches = []  # list of (start, end) in document positions
        self._current_idx = -1

        bar = QHBoxLayout(self)
        bar.setContentsMargins(0, 0, 0, 6)
        bar.setSpacing(6)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Find in notes…")
        self._search.setObjectName("notesFindEdit")
        self._search.setClearButtonEnabled(True)
        self._search.textChanged.connect(self._on_text_changed)
        bar.addWidget(self._search, 1)

        self._count = QLabel("")
        self._count.setObjectName("notesFindCount")
        self._count.setFixedWidth(70)
        self._count.setAlignment(Qt.AlignCenter)
        bar.addWidget(self._count)

        self._prev_btn = QPushButton()
        self._prev_btn.setObjectName("notesSizeBtn")
        self._prev_btn.setFixedSize(26, 26)
        self._prev_btn.setCursor(Qt.PointingHandCursor)
        self._prev_btn.setToolTip("Previous match (Shift+Enter)")
        self._prev_btn.setIcon(svg_icon("chevron-up", "#8a919c", 12))
        self._prev_btn.setIconSize(QSize(12, 12))
        self._prev_btn.clicked.connect(self._find_prev)
        bar.addWidget(self._prev_btn)

        self._next_btn = QPushButton()
        self._next_btn.setObjectName("notesSizeBtn")
        self._next_btn.setFixedSize(26, 26)
        self._next_btn.setCursor(Qt.PointingHandCursor)
        self._next_btn.setToolTip("Next match (Enter)")
        self._next_btn.setIcon(svg_icon("chevron-down", "#8a919c", 12))
        self._next_btn.setIconSize(QSize(12, 12))
        self._next_btn.clicked.connect(self._find_next)
        bar.addWidget(self._next_btn)

        self._close_btn = QPushButton()
        self._close_btn.setObjectName("notesSizeBtn")
        self._close_btn.setFixedSize(26, 26)
        self._close_btn.setCursor(Qt.PointingHandCursor)
        self._close_btn.setToolTip("Close find (Esc)")
        self._close_btn.setIcon(svg_icon("x", "#8a919c", 12))
        self._close_btn.clicked.connect(self.hide_bar)
        bar.addWidget(self._close_btn)

        # Esc in the search field closes the bar (not the dialog).
        self._search.installEventFilter(self)

        self.setVisible(False)

    def eventFilter(self, obj, event):
        from PySide6.QtCore import QEvent as _QE, Qt as _Qt
        if obj is self._search and event.type() == _QE.KeyPress:
            if event.key() == _Qt.Key_Escape:
                self.hide_bar()
                return True
            if event.key() in (_Qt.Key_Return, _Qt.Key_Enter):
                # Shift+Enter = previous, Enter = next.
                if event.modifiers() & _Qt.ShiftModifier:
                    self._find_prev()
                else:
                    self._find_next()
                return True
        return super().eventFilter(obj, event)

    def show_bar(self):
        self.setVisible(True)
        self._search.setFocus()
        self._search.selectAll()

    def hide_bar(self):
        self.setVisible(False)
        self._clear_highlights()
        try:
            self._editor.setFocus()
        except Exception:
            pass

    def _on_text_changed(self, text):
        self._find_all(text)

    def _find_all(self, needle):
        from PySide6.QtGui import QTextCursor as _QTC
        editor = self._editor
        self._matches = []
        self._current_idx = -1
        if not needle or editor is None:
            self._clear_highlights()
            self._count.setText("")
            return
        # Collect all match positions.
        doc = editor.document()
        cursor = _QTC(doc)
        cursor.movePosition(_QTC.Start)
        while True:
            found = doc.find(needle, cursor,
                             doc.FindFlag(0))
            if found.isNull():
                break
            self._matches.append((found.selectionStart(),
                                  found.selectionEnd()))
            cursor.setPosition(found.selectionEnd())
            if len(self._matches) > 500:
                break  # sanity cap
        self._apply_highlights()
        if self._matches:
            self._current_idx = 0
            self._goto_match(0)
        self._update_count()

    def _apply_highlights(self):
        from PySide6.QtGui import QTextCursor as _QTC, QColor as _QColor
        from PySide6.QtWidgets import QTextEdit as _QTE
        editor = self._editor
        if editor is None:
            return
        selections = []
        for i, (start, end) in enumerate(self._matches):
            cursor = _QTC(editor.document())
            cursor.setPosition(start)
            cursor.setPosition(end, _QTC.KeepAnchor)
            sel = _QTE.ExtraSelection()
            sel.cursor = cursor
            # Current match: strong orange; others: muted yellow.
            if i == self._current_idx:
                sel.format.setBackground(_QColor("#b7791f"))
                sel.format.setForeground(_QColor("#ffffff"))
            else:
                sel.format.setBackground(_QColor("#5c4d1a"))
            selections.append(sel)
        editor.setExtraSelections(selections)

    def _clear_highlights(self):
        try:
            self._editor.setExtraSelections([])
        except Exception:
            pass
        self._matches = []
        self._current_idx = -1
        self._count.setText("")

    def _goto_match(self, idx):
        from PySide6.QtGui import QTextCursor as _QTC
        editor = self._editor
        if editor is None or not self._matches:
            return
        start, end = self._matches[idx]
        cursor = _QTC(editor.document())
        cursor.setPosition(start)
        cursor.setPosition(end, _QTC.KeepAnchor)
        editor.setTextCursor(cursor)
        # Ensure visible.
        editor.ensureCursorVisible()
        self._apply_highlights()

    def _find_next(self):
        if not self._matches:
            return
        self._current_idx = (self._current_idx + 1) % len(self._matches)
        self._goto_match(self._current_idx)
        self._update_count()

    def _find_prev(self):
        if not self._matches:
            return
        self._current_idx = (self._current_idx - 1) % len(self._matches)
        self._goto_match(self._current_idx)
        self._update_count()

    def _update_count(self):
        if not self._matches:
            self._count.setText("0 of 0")
        else:
            self._count.setText(
                f"{self._current_idx + 1} of {len(self._matches)}")


class TaskDetailWindow(QDialog):
    """Full detail view for one task.

    A single window with two modes: view (opened by clicking a card) and
    edit (via the Edit button). Modes toggle in place — no extra windows.
    """

    task_changed = Signal()
    contact_requested = Signal(str, str)  # kind ("distributor"/"customer"), name
    open_task_requested = Signal(int)  # open another task's detail (version nav)

    # v1.4.0 item 15b: (db, task id) pairs whose B+ SDC popup already fired
    # this app session. Reopening a detail window must not nag again.
    _sdc_popup_tasks = set()
    # V1.9.52: same once-per-task-per-session rule for the IBC
    # lead-time warning popup.
    _ibc_popup_tasks = set()

    def __init__(self, db, task_id, start_editing=False, parent=None):
        super().__init__(parent)
        self.db = db
        self.task_id = task_id
        self.editing = False
        self._opened_editing = start_editing
        self.setWindowTitle("Task Details")
        # Wider default footprint: at 600px the Dates & Value columns and the
        # follow-up row clipped on smaller displays. Still freely resizable.
        self.setMinimumSize(680, 640)
        # v1.4.0 P1a: cap the initial height to the available screen
        # geometry so the dialog fits on 768px laptop screens (same
        # complaint class as item 6's New Task dialog).
        try:
            avail_h = QGuiApplication.primaryScreen().availableGeometry().height()
            init_h = min(840, max(640, avail_h - 80))
        except Exception:
            init_h = 840
        self.resize(740, init_h)

        self.task = db.get_task(task_id)
        if not self.task:
            show_toast(self, "warning", "Task missing",
                       "This task no longer exists.")
            self.close()
            return

        layout = install_chrome(self, "Task Details")
        # V1.9.30 revisions: label of the frozen revision being
        # viewed, or None while the live task is shown.
        self._frozen_label = None
        self._live_task = None
        # The body can exceed the fixed 600x820 footprint (reminder row,
        # version history, attachments). Keep the footprint and scroll the
        # body instead of growing the dialog.
        _body_scroll = QScrollArea()
        _body_scroll.setWidgetResizable(True)
        _body_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        _body_scroll.setFrameShape(QFrame.NoFrame)
        _body = QWidget()
        _body_layout = QVBoxLayout(_body)
        # V1.9.33 (user, correcting the V1.9.32 blanket widening):
        # spacing is a GROUPING signal, not a uniform spread — a
        # section's title and its content are one group and stay
        # TIGHT (8px -- the same gap the field grids use between a
        # caption and its field), while separate groups get clear
        # air between them. Group starters additionally carry a top
        # margin (see the groupStart marking at the end of this
        # constructor and the [groupStart="true"] rule in
        # themes.py), making the between-group gap 8 + 18 = 26px.
        # V1.9.36 (user: sections ran together -- "hard to tell
        # where one thing starts and the other ends"): the old
        # 5 + 14 = 19px read as one more in-group gap, especially
        # under the short Contact Name / Sales Rep row.
        _body_layout.setSpacing(8)
        _body_scroll.setWidget(_body)
        enable_touch_scroll(_body_scroll)
        # App-wide scroll insets (v1.2.4): body content keeps clear of the
        # viewport edges and the vertical scrollbar. This subsumes the
        # earlier right-only inset: the standard 16px right inset applies,
        # plus 16px left / 12px top+bottom. Covers both view and edit modes
        # (shared layout).
        set_scroll_content_margins(_body_scroll)
        layout.addWidget(_body_scroll)
        layout = _body_layout

        # ---- header: clickable title (view) / editable quote # (edit) ----
        header = QHBoxLayout()
        self.title_button = QPushButton()
        self.title_button.setObjectName("titleLink")
        self.title_button.setCursor(Qt.PointingHandCursor)
        self.title_button.clicked.connect(self._on_open_folder)
        self.title_button.installEventFilter(self)  # Ctrl+click copies quote #
        self.quote_edit = QLineEdit()
        self.quote_edit.setPlaceholderText("Quote Number *")
        # V1.9.18 (user report): the field stretched to ~24 characters
        # wide. Quote numbers fit 12 characters — size it for exactly
        # that (font-measured, plus field padding), no stretch.
        _qfm = self.quote_edit.fontMetrics()
        self.quote_edit.setFixedWidth(
            _qfm.horizontalAdvance("M" * 12) + 24)
        # V1.9.33 (user: "the 00 under REVISION should be in line with
        # the task number, and the task number needs to say TASK above
        # it like REVISION does" — asked of Icarus once, never landed):
        # the identity block is ONE grid — TASK and REVISION captions
        # share a row, the two values share the next, and the revision
        # value renders in the task number's display font (see
        # #revValue in themes) at the same fixed height, so the two
        # baselines coincide by construction. The TASK caption shows
        # in BOTH modes (the V1.9.25 "TASK NUMBER" caption hid in view
        # mode, which is exactly the asymmetry reported).
        self.quote_lab = QLabel("TASK")
        self.quote_lab.setObjectName("sectionLabel")
        # V1.9.30 (user): a Revision spot immediately right of the
        # task number. View mode shows the current label; edit mode
        # swaps in the field -- typing a NEW label and saving freezes
        # the task exactly as it is under the old label and carries
        # on under the new one (see _on_save).
        self.rev_lab = QLabel("REVISION")
        self.rev_lab.setObjectName("sectionLabel")
        self.rev_value = QLabel()
        self.rev_value.setObjectName("revValue")
        self.rev_edit = QLineEdit()
        self.rev_edit.setPlaceholderText("00")
        # V1.9.50 (user): a revision is TWO characters ("00".."99")
        # -- the box fits exactly that plus field padding, not the
        # six-M width that made it look like it expected 10000.
        self.rev_edit.setFixedWidth(
            _qfm.horizontalAdvance("00") + 22)
        self.rev_edit.setVisible(False)
        _task_cell = QWidget()
        _task_cell_lay = QVBoxLayout(_task_cell)
        _task_cell_lay.setContentsMargins(0, 0, 0, 0)
        _task_cell_lay.setSpacing(0)
        _task_cell_lay.addWidget(self.title_button)
        _task_cell_lay.addWidget(self.quote_edit)
        _rev_cell = QWidget()
        _rev_cell_lay = QVBoxLayout(_rev_cell)
        _rev_cell_lay.setContentsMargins(0, 0, 0, 0)
        _rev_cell_lay.setSpacing(0)
        _rev_cell_lay.addWidget(self.rev_value)
        _rev_cell_lay.addWidget(self.rev_edit)
        _id_block = QWidget()
        _id_grid = QGridLayout(_id_block)
        _id_grid.setContentsMargins(0, 0, 0, 0)
        _id_grid.setHorizontalSpacing(18)
        _id_grid.setVerticalSpacing(2)
        _id_grid.addWidget(self.quote_lab, 0, 0)
        _id_grid.addWidget(self.rev_lab, 0, 1)
        _id_grid.addWidget(_task_cell, 1, 0)
        _id_grid.addWidget(_rev_cell, 1, 1)
        header.addWidget(_id_block)
        # Matched value heights within each mode: view-mode pair and
        # edit-mode pair each share one height, so the two columns'
        # text sits on the same line in both modes.
        _vh = self.title_button.sizeHint().height()
        self.title_button.setFixedHeight(_vh)
        self.rev_value.setFixedHeight(_vh)
        _eh = self.quote_edit.sizeHint().height()
        self.quote_edit.setFixedHeight(_eh)
        self.rev_edit.setFixedHeight(_eh)
        header.addStretch(1)
        # V1.9.30 (user rework): both header dropdowns are PILLS of
        # the same family, each with its own name stacked ABOVE it --
        # "Status" over the status pill, "P.O Status" over the
        # outcome pill. The outcome used to be a plain combo box
        # beside a floating "Status" caption: neither labelled nor
        # visually matched to the status pill.
        self.pill = StatusPill(self.task["status"])
        self.pill.status_chosen.connect(self._on_status_chosen)
        status_lab = QLabel("Status")
        status_lab.setObjectName("sectionLabel")
        # V1.9.36 (user): centred over the pill, like every other
        # caption-over-field pair in this window.
        status_lab.setAlignment(Qt.AlignCenter)
        _status_wrap = QWidget()
        _status_lay = QVBoxLayout(_status_wrap)
        _status_lay.setContentsMargins(0, 0, 0, 0)
        _status_lay.setSpacing(2)
        _status_lay.addWidget(status_lab)
        _status_lay.addWidget(self.pill)
        header.addWidget(_status_wrap)
        self.outcome_pill = OutcomePill(self.task.get("outcome", "unknown"))
        self.outcome_pill.setToolTip(
            "P.O status -- click to set Won / Lost / Dead / On Hold")
        self.outcome_pill.outcome_chosen.connect(self._on_outcome_chosen)
        po_lab = QLabel("P.O Status")
        po_lab.setObjectName("sectionLabel")
        po_lab.setAlignment(Qt.AlignCenter)
        _po_wrap = QWidget()
        _po_lay = QVBoxLayout(_po_wrap)
        _po_lay.setContentsMargins(0, 0, 0, 0)
        _po_lay.setSpacing(2)
        _po_lay.addWidget(po_lab)
        _po_lay.addWidget(self.outcome_pill)
        header.addWidget(_po_wrap)
        layout.addLayout(header)

        # ---- re-quote link (only when this task is a re-quote) ----
        self.requote_link = QPushButton()
        self.requote_link.setObjectName("requoteLink")
        self.requote_link.setCursor(Qt.PointingHandCursor)
        self.requote_link.clicked.connect(self._on_open_parent)
        layout.addWidget(self.requote_link)

        # ---- rack type (above distributor) ----
        lab = QLabel("RACK TYPE")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        self.rack_wrap = QWidget()
        rack_row = QHBoxLayout(self.rack_wrap)
        rack_row.setContentsMargins(0, 0, 0, 0)
        rack_row.setSpacing(6)
        self.rack_row = rack_row
        layout.addWidget(self.rack_wrap)
        self.rack_dropdown = TagDropdown(
            selected=self.task.get("rack_types", []), db=self.db, kind="rack"
        )
        # V1.9.25 (user report): the dropdown stretched full-width for
        # no reason. It is exactly the task-number field's width
        # (12 characters, same formula as quote_edit above); the popup
        # itself still opens at least 280px wide so options stay
        # readable.
        self.rack_dropdown.setFixedWidth(
            self.quote_edit.fontMetrics().horizontalAdvance("M" * 12) + 24)
        layout.addWidget(self.rack_dropdown, alignment=Qt.AlignLeft)

        # ---- distributor / end user ----
        # Equal-stretch grid with CENTERED labels over UNIFORM fields.
        # One representation at a time: view mode shows the CRM link
        # pills, edit mode SWAPS in the inputs (like every other field
        # in this window — the names are never shown twice). The seismic
        # badge lives in its own full-width row below the grid so it can
        # never steal width from a pill or disturb the column balance.
        # In view mode the pills are links that open the contact in the CRM.
        self.dist_value = QPushButton()
        self.dist_value.setObjectName("contactLink")
        self.dist_value.setCursor(Qt.PointingHandCursor)
        self.user_value = QPushButton()
        self.user_value.setObjectName("contactLink")
        self.user_value.setCursor(Qt.PointingHandCursor)
        # Ignored horizontal policy: a very long name must never push its
        # column wider than the other — the two pills stay exactly uniform
        # and over-long text simply clips (the tooltip carries the full
        # name). The equal-stretch grid then guarantees identical widths.
        for _pill in (self.dist_value, self.user_value):
            _pill.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.dist_value.clicked.connect(
            lambda: self._on_contact_clicked("distributor"))
        self.user_value.clicked.connect(
            lambda: self._on_contact_clicked("customer"))
        # The contact links work on their own: nobody else listens to this
        # signal, so the detail window opens the CRM card itself
        # (QPushButton is focusable and Enter/Space activates it).
        self.contact_requested.connect(self._open_contact_card)
        self.dist_edit = QLineEdit()
        self.dist_edit.setPlaceholderText("Distributor name")
        self.dist_edit.setVisible(False)
        self.user_edit = QLineEdit()
        self.user_edit.setPlaceholderText("End user")
        self.user_edit.setVisible(False)
        attach_contact_completer(self.dist_edit, db, "distributor")
        attach_contact_completer(self.user_edit, db, "customer")

        def _stack(*widgets):
            wrap = QWidget()
            lay = QVBoxLayout(wrap)
            lay.setContentsMargins(0, 0, 0, 0)
            lay.setSpacing(0)
            for w in widgets:
                lay.addWidget(w)
            return wrap

        du_grid = QGridLayout()
        du_grid.setContentsMargins(0, 0, 0, 0)
        du_grid.setHorizontalSpacing(12)
        du_grid.setVerticalSpacing(8)
        du_grid.setColumnStretch(0, 1)
        du_grid.setColumnStretch(1, 1)
        dist_lab = QLabel("DISTRIBUTOR")
        dist_lab.setObjectName("headerNameLabel")
        dist_lab.setAlignment(Qt.AlignCenter)
        user_lab = QLabel("END USER")
        user_lab.setObjectName("headerNameLabel")
        user_lab.setAlignment(Qt.AlignCenter)
        du_grid.addWidget(dist_lab, 0, 0)
        du_grid.addWidget(user_lab, 0, 1)
        du_grid.addWidget(_stack(self.dist_value, self.dist_edit), 1, 0)
        du_grid.addWidget(_stack(self.user_value, self.user_edit), 1, 1)
        layout.addLayout(du_grid)

        # V1.9.29 (user): a "Per" field (the person the quote came
        # from -- typed) and a "Sales Rep" dropdown/entry, so quotes
        # can be tracked per person and per rep for commission. Same
        # two-column shape and view/edit swap as Distributor/End User
        # directly above.
        # V1.9.36 (user: "why are contact name and sales rep not
        # buttons or clickable like distributor and end user?"):
        # they ARE CRM entries now (the directory has contact and
        # sales_rep kinds), so they get the same contactLink links --
        # a click opens that entry's CRM card, exactly like the two
        # above. (The V1.9.29 note that kept them plain labels --
        # "neither is a CRM contact" -- went stale when the CRM
        # grew those kinds.)
        self.per_value = QPushButton()
        self.per_value.setObjectName("contactLink")
        self.per_value.setCursor(Qt.PointingHandCursor)
        self.rep_value = QPushButton()
        self.rep_value.setObjectName("contactLink")
        self.rep_value.setCursor(Qt.PointingHandCursor)
        for _pill in (self.per_value, self.rep_value):
            _pill.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.per_value.clicked.connect(
            lambda: self._on_contact_clicked("contact"))
        self.rep_value.clicked.connect(
            lambda: self._on_contact_clicked("sales_rep"))
        self.per_edit = QLineEdit()
        self.per_edit.setPlaceholderText("Contact name")
        self.per_edit.setAlignment(Qt.AlignCenter)
        self.per_edit.setVisible(False)
        attach_contact_completer(self.per_edit, db, "contact")
        self.rep_edit = SafeComboBox()
        self.rep_edit.setEditable(True)
        if self.rep_edit.lineEdit() is not None:
            self.rep_edit.lineEdit().setAlignment(Qt.AlignCenter)
        # V1.9.48: centre on the whole field, not just the
        # lineEdit (see _ComboTextCenterer).
        optically_center_combo(self.rep_edit)
        self.rep_edit.addItem("")
        for _rep in self.db.get_sales_reps():
            self.rep_edit.addItem(_rep)
        self.rep_edit.setVisible(False)
        pr_grid = QGridLayout()
        pr_grid.setContentsMargins(0, 0, 0, 0)
        pr_grid.setHorizontalSpacing(12)
        pr_grid.setVerticalSpacing(8)
        pr_grid.setColumnStretch(0, 1)
        pr_grid.setColumnStretch(1, 1)
        per_lab = QLabel("CONTACT NAME")
        per_lab.setObjectName("headerNameLabel")
        per_lab.setAlignment(Qt.AlignCenter)
        rep_lab = QLabel("SALES REP")
        rep_lab.setObjectName("headerNameLabel")
        rep_lab.setAlignment(Qt.AlignCenter)
        pr_grid.addWidget(per_lab, 0, 0)
        pr_grid.addWidget(rep_lab, 0, 1)
        pr_grid.addWidget(_stack(self.per_value, self.per_edit), 1, 0)
        pr_grid.addWidget(_stack(self.rep_value, self.rep_edit), 1, 1)
        layout.addLayout(pr_grid)

        # Seismic indicator: its own full-width row under the grid.
        # v1.4.0 item 15: badge hidden when the location is unknown.
        # v1.4.0 item 15a/15c: manual override adjuster, EDIT MODE ONLY.
        # "Auto" follows the estimate; a letter pins the badge for this task.
        self._sdc_badges = {}  # kind -> QLabel (seismic, v1.4.0 item 15)
        self._sdc_bar = QWidget()
        # V1.9.48 (user: the main 4 sat too close to SEISMIC):
        # the seismic section gets the same groupStart air as
        # every other section in this window -- it was the one
        # section with no breathing room above it.
        self._sdc_bar.setProperty("groupStart", True)
        # V1.9.65 (user, 2026-11-13, with photo: "MAKE THESE
        # BADGES PLACED ON THE RIGHT OF 'SEISMIC'. NOT FUCKING
        # UNDER BLOATING UP THE VERTICAL SPACE"): the whole
        # seismic section is ONE row -- the SEISMIC caption,
        # then the IBC chip, the SDC badge and the override
        # adjuster side by side to its right. This supersedes
        # the V1.9.47 caption-over-badge stack and the V1.9.52
        # IBC row of its own.
        sdc_row = QHBoxLayout(self._sdc_bar)
        sdc_row.setContentsMargins(0, 0, 0, 0)
        sdc_row.setSpacing(8)
        sdc_cap = QLabel("SEISMIC")
        sdc_cap.setObjectName("sectionLabel")
        sdc_row.addWidget(sdc_cap, 0, Qt.AlignVCenter)
        self._ibc_chip = IbcChip()
        sdc_row.addWidget(self._ibc_chip, 0, Qt.AlignVCenter)
        _sdc = QLabel()
        _sdc.setObjectName("sdcBadge")
        _sdc.setVisible(False)
        chip_font(_sdc)
        sdc_row.addWidget(_sdc, 0, Qt.AlignVCenter)
        self._sdc_badges["customer"] = _sdc
        self._sdc_adjust = SafeComboBox()
        self._sdc_adjust.setObjectName("sdcAdjust")
        self._sdc_adjust.setToolTip(
            "Override the SDC estimate for this task")
        self._sdc_adjust.addItem("Auto", None)
        for _sdc_letter in ("A", "B", "C", "D", "E"):
            self._sdc_adjust.addItem(_sdc_letter, _sdc_letter)
        self._sdc_adjust.setVisible(False)
        self._sdc_adjust.currentIndexChanged.connect(
            self._on_sdc_adjust)
        sdc_row.addWidget(self._sdc_adjust, 0, Qt.AlignVCenter)
        sdc_row.addStretch(1)
        self._sdc_bar.setVisible(False)
        layout.addWidget(self._sdc_bar)
        # v1.4.0 item 15: resolve SDC when the end-user edit commits
        # (editingFinished = tab/click/focus-out, NOT while typing).
        self.user_edit.editingFinished.connect(self._on_user_edit_finished)
        # v1.4.0 item 15b: B+ popup, at most once per task per APP SESSION
        # (class-level set: reopening the window must not nag again).
        # Pending manual override while editing (None = Auto); the stored
        # value is loaded on edit entry, persisted on Save, discarded on
        # Cancel. Never touches the DB before Save.
        self._sdc_override_value = None

        # ---- quote folder (path field only shown while editing) ----
        # V1.9.18 (user report): the full-width "Open" button was a
        # waste of a row. A folder icon beside the QUOTE FOLDER label
        # opens the folder — same handler, same visibility rules.
        folder_head = QHBoxLayout()
        folder_head.setContentsMargins(0, 0, 0, 0)
        folder_head.setSpacing(6)
        self.folder_label = QLabel("QUOTE FOLDER")
        self.folder_label.setObjectName("sectionLabel")
        # V1.9.47 (user): the folder button belongs to THIS row --
        # centred on the QUOTE FOLDER caption line, not floating
        # between the seismic group above and this one.
        folder_head.addWidget(self.folder_label, 0, Qt.AlignVCenter)
        self.open_folder_btn = QPushButton()
        self.open_folder_btn.setObjectName("ghost")
        self.open_folder_btn.setIcon(svg_icon("folder", "#8a919c", 15))
        self.open_folder_btn.setToolTip("Open quote folder")
        self.open_folder_btn.setCursor(Qt.PointingHandCursor)
        self.open_folder_btn.setFixedSize(28, 28)
        self.open_folder_btn.clicked.connect(self._on_open_folder)
        folder_head.addWidget(self.open_folder_btn, 0, Qt.AlignVCenter)
        folder_head.addStretch(1)
        layout.addLayout(folder_head)
        self.folder_value = QLabel()
        self.folder_value.setObjectName("detailValue")
        self.folder_value.setWordWrap(True)
        self.folder_value.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.folder_value)
        self.folder_edit = FolderPathEdit()
        layout.addWidget(self.folder_edit)
        # Automatic quote folder creation for this task: shown only when the
        # master toggle is on and the task has no folder linked yet.
        self.create_folder_btn = QPushButton("Create folder")
        self.create_folder_btn.setObjectName("ghost")
        self.create_folder_btn.setCursor(Qt.PointingHandCursor)
        self.create_folder_btn.clicked.connect(self._on_create_folder)
        layout.addWidget(self.create_folder_btn)

        # ---- scope ----
        lab = QLabel("SCOPE OF WORK")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        self.scope_dropdown = ScopeDropdown(selected=self.task["scope"], db=self.db)
        self.scope_dropdown.selection_changed.connect(self._on_scope_selection)
        layout.addWidget(self.scope_dropdown)
        chips_row = QHBoxLayout()
        # Zero margins: the tray is a direct child of the same parent layout
        # as the "SCOPE OF WORK" label, so any internal margin shifts the
        # first chip right of the label text (QHBoxLayout defaults to the
        # style's margins, ~9px). Pills align exactly with the label.
        chips_row.setContentsMargins(0, 0, 0, 0)
        chips_row.setSpacing(6)
        self.chips_layout = chips_row
        chips_wrap = ScopeChipTray()
        chips_wrap.setLayout(chips_row)
        chips_wrap.order_changed.connect(self._on_scope_order_changed)
        self.chips_tray = chips_wrap
        self.progress_label = QLabel()
        self.progress_label.setObjectName("progressLabel")
        # V1.9.37 (user): the fraction moves to the LEFT of the
        # chips, on the same row -- under the chips it wasted a
        # whole line. The label's left edge lines up with the
        # dropdown above; the chips shift right to make room.
        # (The CARD fraction stays exactly where it is -- the user
        # called that one perfect.)
        scope_row = QHBoxLayout()
        scope_row.setContentsMargins(0, 0, 0, 0)
        scope_row.setSpacing(8)
        scope_row.addWidget(self.progress_label, 0, Qt.AlignVCenter)
        scope_row.addWidget(chips_wrap, 1)
        layout.addLayout(scope_row)

        # V1.9.11: freight / lead-time details, shown in the window instead
        # of living only in scope-chip hover tooltips — opening a card used
        # to show no freight or lead-time information at all. Hidden when
        # nothing was recorded; _render_logistics (called from _render)
        # fills it from the stored details.
        self.logistics_section_label = QLabel("FREIGHT & LEAD TIME")
        self.logistics_section_label.setObjectName("sectionLabel")
        layout.addWidget(self.logistics_section_label)
        self.detail_freight_label = QLabel()
        self.detail_freight_label.setObjectName("detailValue")
        self.detail_freight_label.setWordWrap(True)
        layout.addWidget(self.detail_freight_label)
        self.detail_lead_label = QLabel()
        self.detail_lead_label.setObjectName("detailValue")
        self.detail_lead_label.setWordWrap(True)
        layout.addWidget(self.detail_lead_label)
        self.detail_ship_label = QLabel()
        self.detail_ship_label.setObjectName("detailValue")
        self.detail_ship_label.setWordWrap(True)
        layout.addWidget(self.detail_ship_label)

        # ---- notes ----
        lab = QLabel("NOTES")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        self.notes_value = QLabel()
        self.notes_value.setObjectName("detailValue")
        self.notes_value.setWordWrap(True)
        self.notes_value.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.notes_edit = _SanitizedTextEdit()
        self.notes_edit.setObjectName("notesEdit")
        # Fixed (not minimum) height: QTextEdit's default sizeHint is ~190px
        # and was inflating the whole window.
        self.notes_edit.setFixedHeight(110)
        self.notes_edit.setPlaceholderText("Notes, details, anything to remember…")
        # V1.9.2: pin the notes base size to NOTES_DEFAULT_SIZE (12). The
        # editor used to open at the platform default 9pt, so the format
        # bar showed 9 and Clear Formatting jumped text UP to 12 instead
        # of restoring the base. Existing saved notes keep their explicit
        # sizes; only unformatted typing uses this default.
        _nf = app_font()
        _nf.setPointSize(NOTES_DEFAULT_SIZE)
        self.notes_edit.document().setDefaultFont(_nf)
        self.notes_edit.setFont(_nf)
        # In-note find bar (Ctrl+F): find + highlight in the notes editor.
        self.notes_find_bar = NotesFindBar(self.notes_edit)
        # Ctrl+F opens the find bar (edit mode only).
        QShortcut(QKeySequence("Ctrl+F"), self,
                  activated=self._open_notes_find)
        layout.addWidget(self.notes_value)
        layout.addWidget(self.notes_find_bar)
        layout.addWidget(self.notes_edit)

        # ---- due date / estimate / quote price ----
        lab = QLabel("DATES & VALUE")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        dhp_row = None  # replaced by the spread grid below
        self.due_value = QLabel()
        self.hours_value = QLabel()
        self.price_value = QLabel()
        for w in (self.due_value, self.hours_value, self.price_value):
            w.setObjectName("detailValue")
        self.due_edit = SafeDateEdit()
        self.due_edit.setCalendarPopup(True)
        self.due_edit.setDisplayFormat("MM/dd/yyyy")
        self.due_edit.setSpecialValueText("No due date")
        self.hours_edit = QLineEdit()
        self.hours_edit.setPlaceholderText("Hours")
        self.hours_edit.setValidator(
            QDoubleValidator(0.0, 100000.0, 2, self.hours_edit))
        self.price_edit = QLineEdit()
        self.price_edit.setPlaceholderText("0.00")
        self.price_edit.setValidator(
            QDoubleValidator(0.0, 1e12, 2, self.price_edit))
        add_currency_prefix(self.price_edit)
        hook_empty_date_popup(self.due_edit)
        # V1.9.48 (user): the date centres in its field, and the
        # field gets the Clear the New Task dialog already had --
        # a set due date could not be removed here at all.
        optically_center_date_edit(self.due_edit)
        # V1.9.51 (user): the clear x now lives INSIDE the field,
        # right of the date and left of the calendar arrow, in
        # its own reserved slot (see _InlineDateClear) -- the
        # V1.9.50 beside-field spot is superseded.
        self.due_clear = _inline_date_clear(
            self.due_edit, "Clear the due date")
        self.due_clear.clicked.connect(
            lambda: self.due_edit.setDate(self.due_edit.minimumDate()))
        _due_row = QWidget()
        _due_row_lay = QHBoxLayout(_due_row)
        _due_row_lay.setContentsMargins(0, 0, 0, 0)
        _due_row_lay.setSpacing(6)
        _due_row_lay.addWidget(self.due_edit)
        # V1.9.25 (user report): the row split three equal ways, so
        # hours and price stretched absurdly wide. Each field is its
        # content width now — hours fits "xxx", price fits
        # "999,999,999,999.99" (18 characters: the 16-char format plus
        # 2 spare) — and a stretch takes the rest instead of the
        # columns splitting it. Due date keeps its natural picker
        # width. V1.9.26: the price is measured on real price
        # characters, not M's — M is the widest letter and oversized
        # the box to ~2x the number in it.
        self.hours_edit.setFixedWidth(_hours_edit_width(self.hours_edit))
        self.price_edit.setFixedWidth(
            self.price_edit.fontMetrics().horizontalAdvance("999,999,999,999.99") + 24)
        # V1.9.26 aligned the numbers right (money-column style);
        # V1.9.36 (user, superseding): inside these centred columns
        # the numbers centre too, matching their captions.
        self.hours_edit.setAlignment(Qt.AlignCenter)
        self.price_edit.setAlignment(Qt.AlignCenter)
        _dhp_cols = []
        self._dhp_fit = []
        for label_text, value_w, edit_w in [
            ("Due Date", self.due_value, _due_row),
            ("Est. Hours", self.hours_value, self.hours_edit),
            ("Quote Price", self.price_value, self.price_edit),
        ]:
            sub = QLabel(label_text.upper())
            sub.setObjectName("fieldLabel")
            # V1.9.30 (user): the title sits CENTERED over its entry
            # box, not left-aligned. V1.9.36: the column is as wide
            # as its widest member (usually the caption), and a
            # fixed-width editor used to hug the column's left edge,
            # so the "centred" caption actually sat off-centre from
            # the box. The editor now centres in the column, which
            # puts the caption's centre exactly over the box's.
            sub.setAlignment(Qt.AlignHCenter)
            value_w.setAlignment(Qt.AlignHCenter)
            # V1.9.36: the column is a fixed-width wrap widget (as
            # wide as its widest member). Inside a plain widget the
            # centred items share one centre line exactly -- inside
            # a bare grid sub-layout the grid stretched the column
            # to its cell and the caption drifted off the box.
            wrap = QWidget()
            col = QVBoxLayout(wrap)
            col.setContentsMargins(0, 0, 0, 0)
            col.setSpacing(8)
            col.addWidget(sub, 0, Qt.AlignHCenter)
            col.addWidget(value_w, 0, Qt.AlignHCenter)
            col.addWidget(edit_w, 0, Qt.AlignHCenter)
            # A fixed-width editor's sizeHint can under-report its
            # real width (the price field: hint 147, actual 150) --
            # trust its minimum width too, or it overflows the wrap
            # and the caption drifts off-centre again.
            wrap.setFixedWidth(max(sub.sizeHint().width(),
                                   edit_w.sizeHint().width(),
                                   edit_w.minimumWidth()))
            _dhp_cols.append(wrap)
            self._dhp_fit.append((sub, value_w, edit_w, wrap))
        # (V1.9.50: the due column's third row is GONE -- the x
        # clear sits inside _due_row beside the picker, so all
        # three columns have the same caption/value/editor
        # structure and share one baseline again.)
        # V1.9.30 (user): the three used to huddle at the left. Now
        # they spread the full width -- Due Date holds left, Est.
        # Hours sits at the window's centre, Quote Price holds right.
        dhp_grid = QGridLayout()
        dhp_grid.setContentsMargins(0, 0, 0, 0)
        dhp_grid.setColumnStretch(0, 1)
        dhp_grid.setColumnStretch(1, 1)
        dhp_grid.setColumnStretch(2, 1)
        # V1.9.50: wraps align to the TOP of the row -- with
        # centre alignment, a column whose editor is a couple of
        # pixels taller (the date picker vs the line edits)
        # pushed its whole stack up and the editors left the
        # shared line ("these dropdowns are no longer inline").
        dhp_grid.addWidget(_dhp_cols[0], 0, 0,
                           Qt.AlignLeft | Qt.AlignTop)
        dhp_grid.addWidget(_dhp_cols[1], 0, 1,
                           Qt.AlignHCenter | Qt.AlignTop)
        dhp_grid.addWidget(_dhp_cols[2], 0, 2,
                           Qt.AlignRight | Qt.AlignTop)
        layout.addLayout(dhp_grid)

        # ---- waiting on (v1.4.0 item 10, opt-in) ----
        # The whole section is hidden unless the Settings toggle is on.
        self.waiting_lab = QLabel("WAITING ON")
        self.waiting_lab.setObjectName("sectionLabel")
        # V1.9.50 (user): the caption CENTRES over its dropdown --
        # it and the combo share a column the combo's width wide
        # (built below, once the combo exists).
        self.waiting_lab.setAlignment(Qt.AlignCenter)
        self.waiting_value = QLabel()
        self.waiting_value.setObjectName("detailValue")
        self.waiting_value.setWordWrap(True)
        self.waiting_edit = SafeComboBox()
        self.waiting_edit.setEditable(True)
        # V1.9.18 (user report): the blank first item rendered as an
        # empty row at the top of the dropdown "for no reason". It
        # existed only as a "no value" slot; the field is editable,
        # so clearing is deleting the text, and an empty value shows
        # the placeholder — no blank row needed in the list.
        for preset in ("Internal pricing", "Outside supplier", "Freight"):
            self.waiting_edit.addItem(preset)
        self.waiting_edit.setPlaceholderText("Who are you waiting on?")
        _fit_combo_to_contents(self.waiting_edit)
        _waiting_wrap = QWidget()
        _waiting_col = QVBoxLayout(_waiting_wrap)
        _waiting_col.setContentsMargins(0, 0, 0, 0)
        _waiting_col.setSpacing(8)
        _waiting_col.addWidget(self.waiting_lab)
        _waiting_col.addWidget(self.waiting_edit)
        layout.addWidget(_waiting_wrap, 0, Qt.AlignLeft)
        layout.addWidget(self.waiting_value)

        # ---- follow-up reminder (in-app only) ----
        lab = QLabel("FOLLOW-UP REMINDER")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        remind_row = QHBoxLayout()
        remind_row.setContentsMargins(0, 0, 0, 0)
        remind_row.setSpacing(8)
        self.remind_status = QLabel()
        self.remind_status.setObjectName("detailValue")
        remind_row.addWidget(self.remind_status)
        remind_row.addStretch(1)
        quick_btns = []
        for qlabel, qdays in (("Tomorrow", 1), ("In 3 days", 3), ("In a week", 7)):
            qb = QPushButton(qlabel)
            qb.setObjectName("ghost")
            qb.setCursor(Qt.PointingHandCursor)
            qb.clicked.connect(
                lambda _c=False, d=qdays: self._on_remind_quick(d))
            remind_row.addWidget(qb)
            quick_btns.append(qb)
        self.remind_edit = SafeDateEdit()
        self.remind_edit.setCalendarPopup(True)
        self.remind_edit.setDisplayFormat("MMM d, yyyy")
        self.remind_edit.setSpecialValueText("No reminder")
        self.remind_edit.dateChanged.connect(self._on_remind_picked)
        hook_empty_date_popup(self.remind_edit)
        optically_center_date_edit(self.remind_edit)
        remind_row.addWidget(self.remind_edit)
        # V1.9.51: the clear x lives INSIDE the field (see
        # _InlineDateClear) -- no longer a row widget, so it no
        # longer drives the row's uniform height either.
        self.remind_clear = _inline_date_clear(
            self.remind_edit, "Clear the reminder")
        self.remind_clear.clicked.connect(self._on_remind_clear)
        # Uniform row height: the tallest of the ghost buttons and the
        # date edit. The date edit needs more room than the buttons (QSS
        # padding 8px top/bottom + 13px font vs the buttons' 5px/12px);
        # forcing it to the button height clipped the date text at the
        # bottom ("No reminder" cut off).
        row_h = max([b.sizeHint().height() for b in quick_btns]
                    + [self.remind_edit.sizeHint().height()])
        for w in quick_btns + [self.remind_edit]:
            w.setFixedHeight(row_h)
        # Keep the date field wide enough for the longest possible date
        # text ("MMM d, yyyy") or the "No reminder" special value, plus
        # the QSS padding and the drop-down button chrome.
        _fm = self.remind_edit.fontMetrics()
        _samples = ["No reminder"] + [
            f"{m} 30, 2026" for m in
            ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
             "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")]
        _text_w = max(_fm.horizontalAdvance(s) for s in _samples)
        # + the inline clear's slot (V1.9.51).
        self.remind_edit.setMinimumWidth(
            _text_w + 22 + 24 + 16 + _InlineDateClear.SLOT)
        layout.addLayout(remind_row)
        self._rendering_reminder = False

        # ---- attachments ----
        self.attachments = AttachmentsWidget(db, task_id)
        layout.addWidget(self.attachments)
        # V1.9.30 (user): the revision dropdown sits in the
        # attachments header row, right of the "ATTACHMENTS (N)"
        # count -- visible in view mode only, and only once a frozen
        # revision exists. It switches the whole window between the
        # live task and any frozen revision (view-only there).
        self.rev_combo = SafeComboBox()
        self.rev_combo.setToolTip(
            "Choose which revision of this task to view")
        self.rev_combo.currentIndexChanged.connect(
            self._on_revision_combo_changed)
        self.rev_combo.setVisible(False)
        _att_top = self.attachments._top_layout
        if _att_top is not None:
            _att_top.insertWidget(1, self.rev_combo)

        # ---- dates ----
        self.dates_label = QLabel()
        self.dates_label.setObjectName("dateLabel")
        layout.addWidget(self.dates_label)

        # ---- activity timeline ----
        lab = QLabel("ACTIVITY")
        lab.setObjectName("sectionLabel")
        layout.addWidget(lab)
        self.activity_scroll = QScrollArea()
        self.activity_scroll.setObjectName("activityScroll")
        self.activity_scroll.setWidgetResizable(True)
        self.activity_scroll.setFixedHeight(132)
        activity_host = QWidget()
        self.activity_layout = QVBoxLayout(activity_host)
        self.activity_layout.setSpacing(4)
        self.activity_layout.setAlignment(Qt.AlignTop)
        enable_touch_scroll(self.activity_scroll)
        self.activity_scroll.setWidget(activity_host)
        # App-wide scroll insets (was 4px: timeline rows sat near the edges).
        set_scroll_content_margins(self.activity_scroll)
        layout.addWidget(self.activity_scroll)

        # ---- version history (re-quote chains; hidden when a lone task) ----
        self.version_label = QLabel("VERSION HISTORY")
        self.version_label.setObjectName("sectionLabel")
        layout.addWidget(self.version_label)
        self.version_host = QWidget()
        self.version_rows = QVBoxLayout(self.version_host)
        self.version_rows.setContentsMargins(0, 0, 0, 0)
        self.version_rows.setSpacing(2)
        layout.addWidget(self.version_host)

        layout.addStretch(1)

        # ---- footer ----
        # V1.9.36 parked Delete midway (a stretch above AND below);
        # V1.9.47 (user: "you never moved this delete button down")
        # -- the stretch below is gone, so the stretch above pushes
        # the footer to the BOTTOM edge of the window.
        footer = QHBoxLayout()
        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setObjectName("danger")
        self.delete_btn.clicked.connect(self._on_delete)
        footer.addWidget(self.delete_btn)
        footer.addStretch(1)
        # V1.9.30 (user): the Edit button leaves the footer -- it is
        # a pencil icon in the title bar now, left of Minimize. The
        # footer's Close button is removed too (the window's own X
        # in the title bar closes, as everywhere else).
        # V1.9.35 (user): Save / Cancel leave the footer too -- they
        # are ICONS in the title bar, appearing in the pencil's spot
        # while editing (check = save, x = cancel editing). The
        # footer keeps only Delete.
        layout.addLayout(footer)
        _titlebar = self._chrome["titlebar"]
        self.edit_pencil_btn = _titlebar.make_chrome_button(
            "pencil", "Edit task")
        self.edit_pencil_btn.clicked.connect(
            lambda: self.set_editing(True))
        _titlebar.add_before_min(self.edit_pencil_btn)
        self.save_btn = _titlebar.make_chrome_button("check", "Save task")
        self.save_btn.setDefault(True)
        self.save_btn.clicked.connect(self._on_save)
        _titlebar.add_before_min(self.save_btn)
        self.cancel_btn = _titlebar.make_chrome_button("x", "Cancel editing")
        self.cancel_btn.clicked.connect(self._on_cancel)
        _titlebar.add_before_min(self.cancel_btn)
        self.save_btn.setVisible(False)
        self.cancel_btn.setVisible(False)

        QShortcut(QKeySequence("Ctrl+V"), self, activated=self.attachments.paste_from_clipboard)

        # V1.9.33: mark the body's GROUP STARTERS with the groupStart
        # property (QSS top margin in themes.py) so the clear air
        # lands BETWEEN sections while titles stay tight to their
        # content. Direct section labels mark themselves; sub-layouts
        # (the distributor / contact grids, the folder header row)
        # mark their first-row section labels; the attachments panel
        # marks itself. In-group pairs and the dates grid's
        # sub-captions are never marked.
        def _mark_group_starts(lay):
            for i in range(lay.count()):
                item = lay.itemAt(i)
                w = item.widget()
                targets = []
                if w is not None:
                    if (isinstance(w, QLabel)
                            and w.objectName() == "sectionLabel"):
                        targets = [w]
                    elif w.objectName() == "attachPanel":
                        targets = [w]
                elif item.layout() is not None:
                    sub = item.layout()
                    cells = []
                    for j in range(sub.count()):
                        sw = sub.itemAt(j).widget()
                        if sw is None:
                            continue
                        row = 0
                        if isinstance(sub, QGridLayout):
                            row = sub.getItemPosition(j)[0]
                        cells.append((row, sw))
                    if cells:
                        top_row = min(r for r, _sw in cells)
                        targets = [sw for r, sw in cells
                                   if r == top_row
                                   and isinstance(sw, QLabel)
                                   and sw.objectName() == "sectionLabel"]
                for t in targets:
                    t.setProperty("groupStart", True)
                    t.style().unpolish(t)
                    t.style().polish(t)
        _mark_group_starts(_body_layout)
        _pin_caption_labels(self)
        self._group_spacers = []
        _apply_group_air(_body_layout, registry=self._group_spacers)
        # V1.9.48 (user, image-394): the four-name block must sit
        # CENTRED between the rack pills and the quote-folder
        # row, not hugging the pills with a chasm under it. It
        # gets the standard group air above it; the matching air
        # below comes from the folder group (and, in edit mode,
        # the seismic group) -- and _sync_group_air collapses
        # the seismic air whenever the bar itself is hidden, so
        # the balance holds in view mode too.
        for _gi in range(_body_layout.count()):
            _sub = _body_layout.itemAt(_gi).layout()
            if isinstance(_sub, QGridLayout) and any(
                    isinstance(_sub.itemAt(_gj).widget(), QLabel)
                    and _sub.itemAt(_gj).widget().objectName()
                    == "headerNameLabel"
                    for _gj in range(_sub.count())):
                _body_layout.insertSpacing(_gi, 30)
                break

        self._render()
        self.set_editing(start_editing)
        _chip_font_tree(self)

    # -- rendering / modes --
    # ---- revisions (V1.9.30) ----
    def _revision_combo_has_items(self):
        try:
            return len(self.db.list_revisions(self.task_id)) > 0
        except Exception:
            return False

    def _refresh_revision_combo(self):
        """Rebuild the revision dropdown: current revision first,
        then every frozen revision (newest first)."""
        if not hasattr(self, "rev_combo"):
            return
        frozen = self.db.list_revisions(self.task_id)
        cur = (self._live_task or self.task).get("revision") or "00"
        self.rev_combo.blockSignals(True)
        try:
            self.rev_combo.clear()
            self.rev_combo.addItem(f"Rev {cur} — Current", None)
            for entry in reversed(frozen):
                self.rev_combo.addItem(
                    f"Rev {entry['revision']} — Frozen", entry["revision"])
            idx = 0
            if self._frozen_label:
                for i in range(self.rev_combo.count()):
                    if self.rev_combo.itemData(i) == self._frozen_label:
                        idx = i
                        break
            self.rev_combo.setCurrentIndex(idx)
        finally:
            self.rev_combo.blockSignals(False)
        self.rev_combo.setVisible(
            not self.editing and len(frozen) > 0)

    def _on_revision_combo_changed(self, idx):
        if idx < 0 or not hasattr(self, "rev_combo"):
            return
        self._view_revision(self.rev_combo.itemData(idx))

    def _view_revision(self, label):
        """Show a frozen revision (label) or the live task (None)."""
        if label is None:
            if self._frozen_label is None:
                return
            self._frozen_label = None
            self.task = self._live_task or self.db.get_task(self.task_id)
            self._live_task = None
            self.attachments.set_revision_filter(None)
            self.attachments.set_read_only(False)
        else:
            snap = self.db.get_revision(self.task_id, label)
            if snap is None:
                return
            if self._frozen_label is None:
                self._live_task = self.task
            self._frozen_label = label
            view = dict(snap)
            view.pop("attachments", None)
            view["id"] = self.task_id
            self.task = view
            self.attachments.set_revision_filter(
                [a.get("id") for a in snap.get("attachments", [])])
            self.attachments.set_read_only(True)
        frozen = self._frozen_label is not None
        self.pill.setEnabled(not frozen)
        self.outcome_pill.setEnabled(not frozen)
        self.title_button.setEnabled(
            bool(self.task.get("folder_path")) and not frozen)
        self.edit_pencil_btn.setVisible(not frozen and not self.editing)
        # V1.9.47 (user): Delete shows ONLY in edit mode -- the old
        # rule had it exactly backwards (visible while viewing,
        # gone while editing).
        self.delete_btn.setVisible(not frozen and self.editing)
        self._render()

    def _render(self):
        t = self.task
        self.setWindowTitle(f"Task {t['quote_number']}")
        self.title_button.setText(esc_plain(t["quote_number"]))
        folder = t.get("folder_path") or ""
        self.title_button.setEnabled(bool(folder))
        self.title_button.setToolTip(
            (f"Open quote folder:\n{folder}\nCtrl+click copies the quote #"
             if folder
             else "No quote folder linked — click Edit to add one\n"
                  "Ctrl+click copies the quote #")
        )
        self.rev_value.setText(esc_plain(t.get("revision") or "00"))
        self.dist_value.setText(esc_plain(t["distributor"] or "—"))
        self.dist_value.setEnabled(bool(t["distributor"]))
        self.dist_value.setToolTip(
            f"Open in CRM: {t['distributor']}" if t["distributor"] else "")
        self.user_value.setText(esc_plain(t["end_user"] or "—"))
        self.user_value.setEnabled(bool(t["end_user"]))
        self.per_value.setText(esc_plain(t.get("per") or "—"))
        # V1.9.37 (user): a blank entry must NOT be clickable --
        # dist/user already disabled on blank; per/rep were missed
        # when they became links in V1.9.36.
        self.per_value.setEnabled(bool(t.get("per")))
        self.per_value.setToolTip(
            f"Open in CRM: {t['per']}" if t.get("per") else "")
        self.rep_value.setText(esc_plain(t.get("sales_rep") or "—"))
        self.rep_value.setEnabled(bool(t.get("sales_rep")))
        self.rep_value.setToolTip(
            f"Open in CRM: {t['sales_rep']}" if t.get("sales_rep") else "")
        self.user_value.setToolTip(
            f"Open in CRM: {t['end_user']}" if t["end_user"] else "")
        # v1.4.0 item 15: SDC badge near the end-user row (view mode).
        self._update_sdc_badge(t.get("end_user") or "")
        # V1.9.52: IBC chip above it + the lead-time warning popup
        # on open (once per task per session, Settings-toggleable).
        self._update_ibc_chip(t.get("end_user") or "")
        if getattr(self, "_ibc_assess", None) and \
                self._ibc_assess.get("flag"):
            QTimer.singleShot(400, self._maybe_ibc_popup)
        self.folder_value.setText(esc_plain(folder or "—"))
        _nv = t["notes"] or ""
        if notes_is_rich(_nv):
            # Rich-text notes: QLabel auto-detects HTML and renders it.
            self.notes_value.setText(_nv)
        else:
            self.notes_value.setText(esc_plain(_nv or "—"))
        self._render_rack_tags()
        self._render_chips()
        self._render_logistics()
        self._refresh_folder_row()
        # due / estimate / price
        due = t.get("due_date") or ""
        if due:
            chip, _urgent = due_chip_info(due)
            extra = (f" · {chip}"
                     if chip and t.get("status") in OPEN_STATUSES else "")
            self.due_value.setText(f"{fmt_date_mdy(due)}{extra}")
        else:
            self.due_value.setText("—")
        self.hours_value.setText(format_hours(t.get("estimated_hours")) or "—")
        self.price_value.setText(format_price(t.get("quote_value")) or "—")
        # The values just changed: re-fit the column wraps so a
        # wide value can never clip (see _refit_dhp).
        self._refit_dhp()
        self._refresh_waiting_section()
        created = fmt_date_mdy(t.get("created_at"))
        if t["status"] == "completed" and t.get("completed_at"):
            dates = f"Added {created}   ·   Completed {fmt_date_mdy(t['completed_at'])}"
        else:
            dates = f"Added {created}"
        self.dates_label.setText(dates)
        self._set_outcome_combo(t.get("outcome", "unknown"))
        self.pill.set_status(t["status"])
        self._refresh_revision_combo()
        self._render_requote()
        self._render_versions()
        self._render_reminder()
        self._render_activity()
        self.attachments.refresh()
        self._sync_group_air()

    def _render_activity(self):
        while self.activity_layout.count():
            item = self.activity_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        try:
            entries = self.db.list_activity(self.task_id)
        except Exception:
            entries = []
        if not entries:
            none = QLabel("No activity yet.")
            none.setObjectName("hint")
            self.activity_layout.addWidget(none)
            return
        for e in reversed(entries):  # newest first
            detail = e.get("detail") or e.get("kind", "")
            row = QLabel(f"{format_activity_time(e.get('at'))} — {detail}")
            row.setObjectName("activityRow")
            row.setWordWrap(True)
            self.activity_layout.addWidget(row)

    def _on_contact_clicked(self, kind):
        # All four name fields are CRM link pills (V1.9.36 added
        # contact + sales_rep to the original distributor/customer).
        _fields = {"distributor": "distributor", "customer": "end_user",
                   "contact": "per", "sales_rep": "sales_rep"}
        if self.editing:
            # Edit mode: open whatever is currently typed, not the last
            # saved value.
            if kind == "sales_rep":
                name = self.rep_edit.currentText().strip()
            else:
                edit = {"distributor": self.dist_edit,
                        "customer": self.user_edit,
                        "contact": self.per_edit}[kind]
                name = edit.text().strip()
        else:
            name = (self.task.get(_fields[kind]) or "").strip()
        if name:
            self.contact_requested.emit(kind, name)

    # -- seismic SDC (v1.4.0 item 15) --
    def _resolve_sdc(self, name):
        """(letter, is_override) for an end-user name, or (None, False).

        Resolution order (item 15a): the per-task manual override wins
        (pending edit value while editing, else the stored column);
        otherwise the linked CRM contact's city/state; otherwise the
        parsed field text. Never raises; user-typed text is escaped by
        callers (B1).
        """
        try:
            from .seismic import resolve_sdc as _resolve
        except Exception:
            return (None, False)
        name = (name or "").strip()
        if self.editing:
            override = self._sdc_override_value
        else:
            override = (self.task.get("seismic_override")
                        if isinstance(self.task, dict) else None)
        city = state = None
        if name:
            try:
                contact = self.db.directory_get_by_name("customer", name)
            except Exception:
                contact = None
            if contact:
                city = (contact.get("city") or "").strip() or None
                state = (contact.get("state") or "").strip() or None
        return _resolve(override, city, state, name or None)

    def _update_sdc_badge(self, name):
        """Refresh the inline SDC badge for an end-user name."""
        badge = self._sdc_badges.get("customer")
        if badge is None:
            return None
        try:
            from .seismic import sdc_severity, sdc_badge_text, sdc_tooltip
        except Exception:
            return None
        letter, is_override = self._resolve_sdc(name)
        if not letter:
            badge.setVisible(False)
            self._refresh_sdc_bar()
            return None
        # B1: the badge text is built from the estimate letter only —
        # no raw user text enters it.
        badge.setText(sdc_badge_text(letter, is_override))
        badge.setProperty("sdcSeverity", sdc_severity(letter))
        badge.setToolTip(sdc_tooltip(is_override))
        badge.style().unpolish(badge)
        badge.style().polish(badge)
        badge.setVisible(True)
        self._refresh_sdc_bar()
        return letter

    def _sync_group_air(self):
        """Collapse the group air above a section that is
        currently hidden (V1.9.48). A spacer does not hide with
        its widget: with the seismic bar collapsed in view mode
        its 30px stayed behind as dead air and threw the header
        block's centring off by exactly that much. Registered
        spacers (see _apply_group_air) shrink to 0 while the
        item they precede is hidden, and come back with it."""
        try:
            spacers = getattr(self, "_group_spacers", None)
            if not spacers:
                return
            lay = self._sdc_bar.parentWidget().layout()
            if lay is None:
                return
            for i in range(lay.count() - 1):
                sp = lay.itemAt(i).spacerItem()
                if sp is None or not any(sp is s for s in spacers):
                    continue
                nxt = lay.itemAt(i + 1)
                w = nxt.widget() if nxt is not None else None
                hidden = w is not None and w.isHidden()
                sp.changeSize(40, 0 if hidden else 30)
            lay.invalidate()
        except Exception:
            pass

    def _refresh_sdc_bar(self):
        """Show/hide the full-width seismic row.

        The bar is visible in edit mode (the override adjuster lives
        there) or whenever a badge resolved. In view mode with an
        unknown location the whole row collapses — no empty gap.
        """
        badge = self._sdc_badges.get("customer")
        # isHidden() (not isVisible()): the bar itself may still be hidden
        # at this point, which makes isVisible() lie about the badge.
        has_badge = badge is not None and not badge.isHidden()
        ibc = getattr(self, "_ibc_chip", None)
        has_ibc = ibc is not None and not ibc.isHidden()
        editing = getattr(self, "editing", False)
        self._sdc_adjust.setVisible(editing)
        self._sdc_bar.setVisible(has_badge or has_ibc or editing)
        self._sync_group_air()

    def _on_sdc_adjust(self, _idx):
        """Manual override picked (edit mode only): preview the badge now,
        persist on Save. A B+ pick also triggers the popup (once)."""
        if not self.editing:
            return
        self._sdc_override_value = self._sdc_adjust.currentData()
        letter = self._update_sdc_badge(self.user_edit.text().strip())
        if letter:
            self._maybe_sdc_popup(letter)

    def _seismic_popup_enabled(self):
        """v1.4.0 item 15b: the Settings toggle. Default ON. Never raises."""
        try:
            return self.db.get_setting("seismic_popup", "1") == "1"
        except Exception:
            return True

    def _maybe_sdc_popup(self, letter):
        """Themed B+ popup: at most once per task per app session (the
        class-level set survives window reopen), and only when the
        Settings toggle is on. Never raises."""
        if not letter or letter == "A":
            return
        popup_key = (self.db, self.task_id)
        if popup_key in TaskDetailWindow._sdc_popup_tasks:
            return
        if not self._seismic_popup_enabled():
            return
        TaskDetailWindow._sdc_popup_tasks.add(popup_key)
        try:
            from .seismic import sdc_severity, sdc_tooltip
            _letter, is_override = self._resolve_sdc(
                self.user_edit.text().strip())
            show_toast(
                self,
                "warning" if sdc_severity(letter) == "high" else "info",
                f"Seismic Design Category: {letter}",
                sdc_tooltip(is_override),
            )
        except Exception:
            pass

    def _update_ibc_chip(self, name):
        """Refresh the IBC chip for an end-user name (V1.9.52).
        Never raises; an unresolvable location hides the chip."""
        chip = getattr(self, "_ibc_chip", None)
        if chip is None:
            return
        res, assess = resolve_ibc_for_name(self.db, name)
        self._ibc_res = res
        self._ibc_assess = assess
        chip.set_ibc(res, assess)
        self._refresh_sdc_bar()

    def _ibc_popup_enabled(self):
        """Settings toggle for the IBC warning popup. Default ON."""
        try:
            return self.db.get_setting("ibc_popup", "1") == "1"
        except Exception:
            return True

    def _maybe_ibc_popup(self):
        """Auto-popup (toast) when this task's code switch lands
        inside the lead-time horizon: once per task per session,
        only when the Settings toggle is on. Never raises."""
        assess = getattr(self, "_ibc_assess", None)
        if not assess or not assess.get("flag"):
            return
        popup_key = (self.db, self.task_id)
        if popup_key in TaskDetailWindow._ibc_popup_tasks:
            return
        if not self._ibc_popup_enabled():
            return
        TaskDetailWindow._ibc_popup_tasks.add(popup_key)
        try:
            title, text = ibc_warning_toast_text(self._ibc_res, assess)
            show_toast(self, "warning", title, text)
        except Exception:
            pass

    def _on_user_edit_finished(self):
        """v1.4.0 item 15: end-user field committed (tab/click/focus-out).

        Updates the inline SDC badge; one popup when the estimate is B
        or worse (never repeated for the same task in a session).
        """
        if not self.editing:
            return
        name = self.user_edit.text().strip()
        letter = self._update_sdc_badge(name)
        if letter:
            self._maybe_sdc_popup(letter)
        self._update_ibc_chip(name)
        self._maybe_ibc_popup()

    def _open_contact_card(self, kind, name):
        """Open the CRM info card for a distributor / end-user name.

        Reuses the exact ContactDetailWindow the dashboard distributor rows
        and the CRM module open — no second detail view. When the name has
        no directory entry yet (e.g. just typed in edit mode), fall back
        to the new-contact card with the name prefilled, the same
        affordance as the CRM's own "Add" buttons.
        """
        name = (name or "").strip()
        entry_id = self.db.directory_entry_id(kind, name) if name else None
        if entry_id is not None:
            win = ContactDetailWindow(self.db, entry_id, self)
        else:
            win = ContactDetailWindow(self.db, None, self, kind=kind,
                                      start_editing=True)
            win.name_edit.setText(name)
        # V1.9.51 (user: renamed a distributor from a card opened
        # here and the task did not update -- "glitchy and not
        # instant... randomly updated"): the card's saves were
        # never wired back into this window, so a rename landed in
        # the database but the task on screen kept the old name
        # until an unrelated refresh. Now: reload the task and
        # re-render the moment the card reports a change, and let
        # the main window know too.
        win.contact_changed.connect(self._on_linked_contact_changed)
        win.show()
        win.raise_()
        win.activateWindow()

    def _on_linked_contact_changed(self):
        try:
            fresh = self.db.get_task(self.task_id)
        except Exception:
            fresh = None
        if fresh is not None:
            self.task = fresh
        self._render()
        self.task_changed.emit()

    # -- outcome (won/lost, optional tri-state) --
    def _set_outcome_combo(self, outcome):
        """Reflect an outcome on the header control without firing
        its handler. V1.9.30: the control is an OutcomePill (the name
        stays for this setter's callers)."""
        if hasattr(self, "outcome_pill"):
            self.outcome_pill.set_outcome(outcome or "unknown")

    def _on_outcome_chosen(self, outcome):
        if getattr(self, "_frozen_label", None):
            return  # frozen revisions never change
        # db.set_outcome validates and raises ValueError on junk; the UI
        # only ever offers the three valid values.
        self.db.set_outcome(self.task_id, outcome)
        detail = (f"Marked {outcome}" if outcome in ("won", "lost")
                  else "Outcome mark cleared")
        self.db.log_activity(self.task_id, "outcome", detail)
        self.task = self.db.get_task(self.task_id)
        self._set_outcome_combo(self.task.get("outcome", "unknown"))
        self.task_changed.emit()

    # -- re-quote link + version history --
    def _render_requote(self):
        parent_id = self.task.get("parent_task_id")
        if not parent_id:
            self.requote_link.setVisible(False)
            return
        parent = None
        try:
            parent = self.db.get_task(parent_id)
        except Exception:
            parent = None
        label = (f"#{parent['quote_number']}"
                 if parent and parent.get("quote_number")
                 else f"task #{parent_id}")
        self.requote_link.setText(f"Re-quote of {label}")
        self.requote_link.setVisible(True)

    def _on_open_parent(self):
        parent_id = self.task.get("parent_task_id")
        if parent_id:
            self.open_task_requested.emit(parent_id)

    def _render_versions(self):
        while self.version_rows.count():
            item = self.version_rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        try:
            chain = self.db.get_version_chain(self.task_id)
        except Exception:
            chain = []
        try:
            frozen = self.db.list_revisions(self.task_id)
        except Exception:
            frozen = []
        # V1.9.30 (user): revisions ARE re-quotes -- the version
        # history pulls in this task's frozen revisions too, so the
        # section also shows for a task whose only "versions" are
        # its revisions (no re-quote chain yet).
        show = len(chain) > 1 or bool(frozen)
        self.version_label.setVisible(show)
        self.version_host.setVisible(show)
        if not show:
            return
        # The LIVE task drives the current row's revision label
        # (while a frozen revision is on screen, self.task is the
        # snapshot and the live dict is parked in _live_task).
        live = self._live_task or self.task
        cur_label = live.get("revision") or "00"
        quote_number = (live.get("quote_number")
                        or self.task.get("quote_number") or "—")
        current_seen = False
        for t in chain:
            is_current = t["id"] == self.task_id
            status = STATUS_LABELS.get(t.get("status"), t.get("status") or "")
            row = QPushButton(
                f"{t.get('quote_number') or '—'} — "
                f"{short_date((t.get('created_at') or '')[:10])} — {status}")
            row.setObjectName("versionRow")
            row.setProperty("current", is_current)
            row.setCursor(Qt.PointingHandCursor)
            if is_current:
                row.setText(row.text() + f" · Rev {cur_label}"
                            + "  ·  current")
                row.setEnabled(False)  # highlighted, not clickable
            else:
                row.clicked.connect(
                    lambda _c=False, tid=t["id"]:
                    self.open_task_requested.emit(tid))
            self.version_rows.addWidget(row)
            if is_current:
                current_seen = True
                self._render_frozen_revision_rows(frozen, quote_number)
        if frozen and not current_seen:
            # Degenerate fallback (chain lookup failed): the frozen
            # revisions still get their rows.
            self._render_frozen_revision_rows(frozen, quote_number)

    def _render_frozen_revision_rows(self, frozen, quote_number):
        """One row per frozen revision of THIS task (oldest first,
        as list_revisions returns them), inserted right after the
        current task's row. Clicking opens the frozen snapshot in
        this window (view-only); the revision already on screen is
        marked current and disabled, like the current task's row."""
        viewing = getattr(self, "_frozen_label", None)
        for entry in frozen:
            label = entry.get("revision") or ""
            row = QPushButton(
                f"{quote_number} — Rev {label} — Frozen "
                f"{fmt_date_mdy(entry.get('created_at') or '')}")
            row.setObjectName("versionRow")
            row.setProperty("revision", label)
            row.setProperty("current", viewing == label)
            row.setCursor(Qt.PointingHandCursor)
            if viewing == label:
                row.setText(row.text() + "  ·  current")
                row.setEnabled(False)  # already on screen
            else:
                row.clicked.connect(
                    lambda _c=False, lab=label:
                    self._view_revision(lab))
            self.version_rows.addWidget(row)

    # -- follow-up reminder --
    def _render_reminder(self):
        ra = self.task.get("remind_at") or ""
        self._rendering_reminder = True
        try:
            if ra:
                try:
                    d = date.fromisoformat(ra[:10])
                    self.remind_edit.setDate(QDate(d.year, d.month, d.day))
                    self.remind_status.setText(
                        f"Reminder: {short_date(d.isoformat())}")
                except ValueError:
                    self.remind_status.setText(f"Reminder: {ra}")
            else:
                self.remind_edit.setDate(self.remind_edit.minimumDate())
                self.remind_status.setText("No reminder set")
        finally:
            self._rendering_reminder = False

    def _on_remind_quick(self, days):
        self._set_reminder((date.today() + timedelta(days=days)).isoformat())

    def _on_remind_picked(self, qdate):
        if self._rendering_reminder:
            return
        if qdate == self.remind_edit.minimumDate():
            self._set_reminder(None)  # "No reminder" == clear
            return
        self._set_reminder(qdate.toString("yyyy-MM-dd"))

    def _on_remind_clear(self):
        self._set_reminder(None)

    def _set_reminder(self, iso_or_none):
        self.db.set_remind_at(self.task_id, iso_or_none)
        self.db.log_activity(
            self.task_id, "reminder",
            f"Follow-up reminder set: {iso_or_none}" if iso_or_none
            else "Follow-up reminder cleared")
        self.task = self.db.get_task(self.task_id)
        self._render_reminder()
        self.task_changed.emit()

    def eventFilter(self, obj, event):
        if (obj is self.title_button
                and event.type() == QEvent.MouseButtonPress
                and event.modifiers() & Qt.ControlModifier):
            QApplication.clipboard().setText(
                self.task.get("quote_number", ""))
            QToolTip.showText(QCursor.pos(), "Quote # copied")
            return True
        return super().eventFilter(obj, event)

    def _render_rack_tags(self):
        while self.rack_row.count():
            item = self.rack_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for rt in self.task.get("rack_types", []):
            tag = QLabel(esc_plain(rt))
            tag.setProperty("role", "rackTag")
            chip_font(tag)
            self.rack_row.addWidget(tag)
        self.rack_row.addStretch(1)

    def _render_chips(self):
        while self.chips_layout.count():
            item = self.chips_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        t = self.task
        for s in t["scope"]:
            # Drag-reorder is an edit-mode affordance only; view mode chips
            # stay fixed (click still toggles done there).
            chip = ScopeChip(s, s in t.get("scope_done", []),
                             draggable=self.editing)
            chip.toggled_scope.connect(self._on_chip_toggled)
            # V1.9.5: freight / lead-time chips show their saved details on hover.
            _tip = scope_info_tooltip(s, t)
            if _tip:
                chip.setToolTip(_tip)
            self.chips_layout.addWidget(chip)
        self.chips_layout.addStretch(1)
        total, done = len(t["scope"]), len(t.get("scope_done", []))
        self.progress_label.setText(
            f"{done}/{total}" if total else "No scope selected"
        )

    def _render_logistics(self):
        """V1.9.11: fill the visible Freight & Lead Time block from the
        stored details (same text as the card strip). The whole block
        hides when nothing was recorded.

        V1.9.16: three separate lines, never an equation — freight cost,
        lead time, and (on the opened quote only) the shipping duration
        on its own line.
        """
        t = self.task
        freight = freight_card_text(t)
        lead = leadtime_card_text(t)
        ship = leadtime_ship_text(t)
        self.detail_freight_label.setText(freight or "")
        self.detail_lead_label.setText(lead or "")
        self.detail_ship_label.setText(ship or "")
        self.detail_freight_label.setVisible(bool(freight))
        self.detail_lead_label.setVisible(bool(lead))
        self.detail_ship_label.setVisible(bool(ship))
        self.logistics_section_label.setVisible(
            bool(freight or lead or ship))

    def _open_notes_find(self):
        """Open the in-note find bar (Ctrl+F). Edit mode only."""
        if not getattr(self, "editing", False):
            return
        bar = getattr(self, "notes_find_bar", None)
        if bar is not None:
            bar.show_bar()

    def set_editing(self, editing):
        # A frozen revision is view-only, forever -- no edit mode.
        if editing and getattr(self, "_frozen_label", None):
            return
        # V1.9.49 (user, on 1.9.48: "STILL JUMPING AROUND AND
        # MOVING WHEN I CLICK THE PENCIL TO EDIT"): the 1.9.48
        # anchor held the DUE column still, which scrolled the
        # page to do it -- the window itself moved under his
        # eye. The invariant he actually wants: the toggle does
        # not scroll the page AT ALL. Remember the scrollbar's
        # value and the window size, and put both back once the
        # new mode has laid out. Rows below may change height
        # (editors are taller than labels), but the page is
        # never scrolled by the toggle.
        if self.isVisible():
            try:
                _w = self.due_edit
                _sa = None
                while _w is not None:
                    if isinstance(_w, QScrollArea):
                        _sa = _w
                        break
                    _w = _w.parentWidget()
                if _sa is not None:
                    _bar = _sa.verticalScrollBar()
                    _saved = (_bar, _bar.value(), self.size())

                    def _restore(_s=_saved):
                        _b, _val, _size = _s
                        try:
                            if self.size() != _size:
                                self.resize(_size)
                        except Exception:
                            pass

                        def _pin():
                            try:
                                _b.setValue(_val)
                            except Exception:
                                pass

                        QTimer.singleShot(0, _pin)

                    QTimer.singleShot(0, _restore)
            except Exception:
                pass
        was_editing = self.editing
        self.editing = editing
        if editing and not was_editing:
            # reload fresh in case it changed elsewhere
            fresh = self.db.get_task(self.task_id)
            if fresh:
                self.task = fresh
            self.quote_edit.setText(self.task["quote_number"])
            self.rev_edit.setText(self.task.get("revision") or "00")
            self.dist_edit.setText(self.task["distributor"])
            self.user_edit.setText(self.task["end_user"])
            self.per_edit.setText(self.task.get("per") or "")
            # V1.9.32 (user): an unassigned rep defaults to House
            # Account in the editor, matching new-task creation.
            _rep = self.task.get("sales_rep") or default_sales_rep(self.db)
            _ri = self.rep_edit.findText(_rep)
            if _ri >= 0:
                self.rep_edit.setCurrentIndex(_ri)
            else:
                self.rep_edit.setCurrentText(_rep)
            self.folder_edit.set_path(self.task.get("folder_path") or "")
            self.notes_edit.setHtml(notes_to_html(self.task["notes"]))
            self.scope_dropdown.set_selected(self.task["scope"])
            self.rack_dropdown.set_selected(self.task.get("rack_types", []))
            self._set_due_edit(self.task.get("due_date") or "")
            self.hours_edit.setText(self._num_text(self.task.get("estimated_hours")))
            self.price_edit.setText(self._num_text(self.task.get("quote_value")))
            # v1.4.0 item 15a/15c: load the stored override into the
            # EDIT-MODE-ONLY adjuster (never shown in view mode).
            self._sdc_override_value = self.task.get("seismic_override")
            self._sdc_adjust.blockSignals(True)
            _sdc_idx = self._sdc_adjust.findData(self._sdc_override_value)
            self._sdc_adjust.setCurrentIndex(max(0, _sdc_idx))
            self._sdc_adjust.blockSignals(False)
            # snapshot for change detection when saving
            self._edit_baseline = {
                "quote_number": self.task["quote_number"],
                "distributor": self.task["distributor"],
                "end_user": self.task["end_user"],
                "folder_path": self.task.get("folder_path") or "",
                "notes": self.task["notes"],
                "scope": list(self.task.get("scope", [])),
                "scope_done": list(self.task.get("scope_done", [])),
                "rack_types": list(self.task.get("rack_types", [])),
                "due_date": self.task.get("due_date") or "",
                "estimated_hours": self.task.get("estimated_hours"),
                "quote_value": self.task.get("quote_value"),
            }
            self._render_chips()
        elif was_editing and not editing:
            # Leaving edit mode: chips lose their drag handles again so
            # view mode is unchanged (no dragging there).
            self._render_chips()
        for value_w, edit_w in [
            (self.dist_value, self.dist_edit),
            (self.user_value, self.user_edit),
            (self.per_value, self.per_edit),
            (self.rep_value, self.rep_edit),
            (self.rev_value, self.rev_edit),
            (self.notes_value, self.notes_edit),
            (self.due_value, self.due_edit),
            (self.hours_value, self.hours_edit),
            (self.price_value, self.price_edit),
        ]:
            # View mode shows the value widgets, edit mode swaps in the
            # inputs — one representation at a time, never stacked.
            value_w.setVisible(not editing)
            edit_w.setVisible(editing)
        self.due_clear.setVisible(editing)
        # Find bar starts hidden even in edit mode; Ctrl+F opens it.
        if not editing:
            self.notes_find_bar.hide_bar()
        # QUOTE FOLDER section: view mode shows label + path + Open only
        # when a folder is linked; edit mode shows the path editor.
        self._refresh_folder_row()
        self.rack_wrap.setVisible(not editing)
        self.rack_dropdown.setVisible(editing)
        self.title_button.setVisible(not editing)
        self.quote_edit.setVisible(editing)
        # V1.9.33: the TASK caption is permanent (both modes), paired
        # with the REVISION caption beside it.
        self.quote_lab.setVisible(True)
        self.scope_dropdown.setVisible(editing)
        # V1.9.30: Edit is the title-bar pencil now; it hides while
        # editing (Save/Cancel take over) and while a frozen revision
        # is on screen. V1.9.47 (user): Delete is the opposite --
        # EDIT MODE ONLY, never in view mode, never on a frozen
        # revision.
        self.edit_pencil_btn.setVisible(
            not editing and not getattr(self, "_frozen_label", None))
        self.delete_btn.setVisible(
            editing and not getattr(self, "_frozen_label", None))
        if hasattr(self, "rev_combo"):
            self.rev_combo.setVisible(
                not editing and self._revision_combo_has_items())
        self.save_btn.setVisible(editing)
        self.cancel_btn.setVisible(editing)
        # v1.4.0 item 15c: the SDC override adjuster is EDIT-MODE ONLY; the
        # full-width seismic row shows in edit mode or when a badge
        # resolved (never an empty gap in view mode).
        self._refresh_sdc_bar()
        self._refresh_waiting_section()
        if editing:
            self.quote_edit.setFocus()
            self.quote_edit.selectAll()

    def _waiting_enabled(self):
        """v1.4.0 item 10: the opt-in Settings toggle. Never raises."""
        try:
            return self.db.get_setting("waiting_on_enabled", "0") == "1"
        except Exception:
            return False

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        # V1.9.18: the quote field's 12-character width is font-measured,
        # but the font at construction is pre-polish — the theme's
        # QLineEdit font lands on first paint and the field came out
        # sized for the wrong font. Re-measure once, deferred past the
        # first paint, when the polished font is in effect.
        # V1.9.25: the same re-measure covers the other narrow fields
        # (rack, hours, price) — see _fix_quote_width.
        if not getattr(self, "_quote_width_fixed", False):
            self._quote_width_fixed = True
            QTimer.singleShot(0, self._fix_quote_width)

    def _fix_quote_width(self):
        try:
            fm = self.quote_edit.fontMetrics()
            self.quote_edit.setFixedWidth(
                fm.horizontalAdvance("M" * 12) + 24)
            # V1.9.25: the narrow fields share the same pre-polish
            # trap — re-measure them here too, from the polished font.
            # Rack matches the task-number box (quote's metrics, not
            # its own smaller chip font); hours fits "xxx", price
            # fits "999,999,999,999.99" (18 characters, see above).
            self.rack_dropdown.setFixedWidth(
                fm.horizontalAdvance("M" * 12) + 24)
            self.hours_edit.setFixedWidth(
                _hours_edit_width(self.hours_edit))
            self.price_edit.setFixedWidth(
                self.price_edit.fontMetrics().horizontalAdvance(
                    "999,999,999,999.99") + 24)
            # V1.9.36: the centred DATES & VALUE columns are
            # fixed-width wraps sized at construction from the
            # UNpolished metrics -- re-fit them to the widths just
            # set, or the editors outgrow their wraps and the
            # captions drift off-centre again.
            self._refit_dhp()
        except Exception:
            pass

    def _refit_dhp(self):
        """Size each DATES & VALUE column wrap to its widest
        member -- caption, VALUE, or editor. V1.9.47 (user
        screenshot: "'11/2026 · Overdue", the month clipped off):
        the wraps were sized from the caption and the editor
        only, so the view-mode due value -- wider than both --
        overflowed its fixed column and clipped at the edge.
        V1.9.50: first make sure the centred date texts FIT
        their fields (the centring margin eats narrow fields),
        then size the wraps to the grown editors."""
        _ensure_date_text_fits(self.due_edit)
        _ensure_date_text_fits(self.remind_edit)
        for sub, value_w, edit_w, wrap in getattr(
                self, "_dhp_fit", []):
            wrap.setFixedWidth(max(
                sub.sizeHint().width(), value_w.sizeHint().width(),
                edit_w.sizeHint().width(), edit_w.minimumWidth()))

    def _refresh_waiting_section(self):
        """Show/hide the WAITING ON section and populate its widgets."""
        enabled = self._waiting_enabled()
        value = (self.task.get("waiting_on") or "").strip()
        self.waiting_lab.setVisible(enabled)
        self.waiting_value.setVisible(enabled and not self.editing)
        self.waiting_edit.setVisible(enabled and self.editing)
        if enabled:
            self.waiting_value.setText(esc_plain(value or "—"))
            # Select the preset, or show custom text in the edit line.
            # V1.9.18: no blank item anymore — an empty/custom value
            # shows via the edit line with no current index.
            idx = self.waiting_edit.findText(value)
            if idx >= 0:
                self.waiting_edit.setCurrentIndex(idx)
            else:
                self.waiting_edit.setCurrentIndex(-1)
                self.waiting_edit.setEditText(value)

    @staticmethod
    def _num_text(value):
        return "" if value is None else str(value)

    def _set_due_edit(self, due_iso):
        try:
            d = date.fromisoformat((due_iso or "")[:10])
            self.due_edit.setDate(QDate(d.year, d.month, d.day))
        except ValueError:
            self.due_edit.setDate(self.due_edit.minimumDate())

    # -- events --
    def _on_open_folder(self):
        folder = (self.task.get("folder_path") or "").strip()
        if folder and not open_folder(folder):
            show_toast(self, "error", "Folder not found",
                       f"This folder could not be opened:\n{folder}")

    # -- automatic quote folder creation --
    def _refresh_create_folder_btn(self):
        show = (
            not self.editing
            and folder_creation_enabled(self.db)
            and not (self.task.get("folder_path") or "").strip()
        )
        self.create_folder_btn.setVisible(show)

    def _refresh_folder_row(self):
        """Show the QUOTE FOLDER section according to mode and link state.

        View mode: label + path text + Open button appear once a folder is
        actually linked (after linking the button/row shows without a
        restart — _after_folder_linked re-renders). With no folder linked
        the section stays hidden and only "Create folder" may show.
        Edit mode: the path editor shows; the path value and Open button
        stay hidden.
        """
        self._refresh_create_folder_btn()
        has_folder = bool((self.task.get("folder_path") or "").strip())
        if self.editing:
            self.folder_label.setVisible(True)
            self.folder_value.setVisible(False)
            self.open_folder_btn.setVisible(False)
            self.folder_edit.setVisible(True)
        else:
            self.folder_label.setVisible(has_folder)
            self.folder_value.setVisible(has_folder)
            self.open_folder_btn.setVisible(has_folder)
            self.folder_edit.setVisible(False)

    def _on_create_folder(self):
        task = self.db.get_task(self.task_id) or self.task
        self.create_folder_btn.setEnabled(False)
        begin_quote_folder_flow(
            self.db, task, interactive=True, parent=self,
            on_done=self._after_folder_linked)

    def _after_folder_linked(self, _path):
        self.create_folder_btn.setEnabled(True)
        # Refresh the folder row (title button, folder value) without a
        # restart; the emitted signal refreshes the queue/list card too.
        self.task = self.db.get_task(self.task_id) or self.task
        self._render()
        self.task_changed.emit()

    def _on_chip_toggled(self, scope, done):
        if getattr(self, "_frozen_label", None):
            return  # frozen revisions never change
        done_list = list(self.task.get("scope_done", []))
        if done and scope not in done_list:
            done_list.append(scope)
        elif not done and scope in done_list:
            done_list.remove(scope)
        self.task["scope_done"] = self.db.set_scope_done(self.task_id, done_list)
        self.db.log_activity(self.task_id, "scope",
                             f"Scope step {'done' if done else 'reopened'}: {scope}")
        # V1.9.5: checking off Freight / Lead-Time prompts for its details.
        if done:
            maybe_prompt_scope_info(self, self.db, self.task_id, scope)
            self.task = self.db.get_task(self.task_id) or self.task
        self._maybe_auto_complete()
        self._render_chips()
        self._render_logistics()
        self._render_activity()
        self.task_changed.emit()

    def _maybe_auto_complete(self):
        """If every selected scope step is checked, mark the task completed."""
        scopes = self.task.get("scope", [])
        done = set(self.task.get("scope_done", []))
        status = self.task.get("status")
        if scopes and all(s in done for s in scopes):
            if status not in ("completed", "canceled"):
                self.db.set_status(self.task_id, "completed")
                self.db.log_activity(self.task_id, "status",
                                     "Status → Completed (all scope done)")
                maybe_ask_price(self, self.db, self.task_id)
                self.task["status"] = "completed"
                self.pill.set_status("completed")
        elif status == "completed" and any(s not in done for s in scopes):
            self.db.set_status(self.task_id, "in_process")
            self.db.log_activity(self.task_id, "status",
                                 "Status → In Process (scope reopened)")
            self.task["status"] = "in_process"
            self.pill.set_status("in_process")

    def _on_scope_selection(self, selected):
        self.task["scope"] = selected
        self.task["scope_done"] = [s for s in self.task["scope_done"] if s in selected]
        self._maybe_auto_complete()
        self._render_chips()

    def _on_scope_order_changed(self, order):
        """Scope pills were drag-reordered in edit mode.

        Keeps the in-memory task and the scope dropdown in sync so the
        new order is what _on_save persists to the DB. (set_selected
        deliberately does not re-emit selection_changed.)
        """
        self.task["scope"] = list(order)
        self.scope_dropdown.set_selected(order)

    def _on_status_chosen(self, status):
        if getattr(self, "_frozen_label", None):
            return  # frozen revisions never change
        if status == "canceled" and self.task.get("status") != "canceled":
            if not confirm_cancel_with_reason(self, self.db, self.task_id):
                self.pill.set_status(self.task["status"])  # user backed out
                return
            self.task = self.db.get_task(self.task_id)
            self.pill.set_status("canceled")
            self._render()
            self.task_changed.emit()
            return
        if status == "on_hold" and self.task.get("status") != "on_hold":
            if not confirm_hold_with_reason(self, self.db, self.task_id):
                self.pill.set_status(self.task["status"])  # user backed out
                return
            self.task = self.db.get_task(self.task_id)
            self.pill.set_status("on_hold")
            self._render()
            self.task_changed.emit()
            return
        if status == self.task.get("status"):
            return
        self.db.set_status(self.task_id, status)
        self.db.log_activity(
            self.task_id, "status",
            f"Status → {STATUS_LABELS.get(status, status)}")
        if status == "completed":
            maybe_ask_price(self, self.db, self.task_id)
        self.task = self.db.get_task(self.task_id)
        self.pill.set_status(status)
        self._render()
        self.task_changed.emit()

    def _on_save(self):
        quote = self.quote_edit.text().strip()
        if not quote:
            show_toast(self, "warning", "Missing info",
                       "Please enter a Quote Number.")
            self.quote_edit.setFocus()
            return
        if self.db.task_id_for_quote(quote, ignore_id=self.task_id) is not None:
            show_toast(
                self, "warning", "Duplicate quote number",
                f"Another task already uses quote # {quote}.\n"
                "Please use a different quote number.",
            )
            self.quote_edit.setFocus()
            self.quote_edit.selectAll()
            return

        def parse_number(edit, label):
            text = edit.text().strip().replace(",", "")
            if not text:
                return None, True
            try:
                return float(text), True
            except ValueError:
                show_toast(
                    self, "warning", "Invalid number",
                    f"{label} must be a number (e.g. 2.5).")
                edit.setFocus()
                return None, False

        # V1.9.30 revisions: a NEW revision label freezes the task
        # exactly as it stands (last saved state) under the old
        # label BEFORE any of this save's edits land -- the edits
        # belong to the new revision, which starts as a full copy.
        _new_rev = self.rev_edit.text().strip()
        _cur_rev = self.task.get("revision") or "00"
        if _new_rev and _new_rev != _cur_rev:
            _frozen_labels = [r["revision"] for r in
                              self.db.list_revisions(self.task_id)]
            if _new_rev in _frozen_labels:
                show_toast(
                    self, "warning", "Revision already exists",
                    f"Revision {_new_rev} is already frozen for this "
                    f"task.\nPick a new revision number, or view "
                    f"{_new_rev} from the revision dropdown.")
                self.rev_edit.setFocus()
                self.rev_edit.selectAll()
                return
            self.db.freeze_revision(self.task_id)
        elif not _new_rev:
            _new_rev = _cur_rev

        hours, ok = parse_number(self.hours_edit, "Est. hours")
        if not ok:
            return
        price, ok = parse_number(self.price_edit, "Quote price")
        if not ok:
            return
        due_qdate = self.due_edit.date()
        due_iso = (""
                   if due_qdate <= self.due_edit.minimumDate()
                   else due_qdate.toString("yyyy-MM-dd"))

        old = getattr(self, "_edit_baseline", {}) or {}
        # V1.9.4: task notes are plain text again — notes_editor_save
        # always returns toPlainText(), which also repairs any legacy
        # rich notes the moment the task is saved.
        new_notes = notes_editor_save(self.notes_edit)
        new_scope = self.scope_dropdown.selected()
        new_rack = self.rack_dropdown.selected()
        self.db.update_task(
            self.task_id,
            quote,
            self.dist_edit.text().strip(),
            self.user_edit.text().strip(),
            new_notes,
            new_scope,
            self.task.get("scope_done", []),
            folder_path=self.folder_edit.path(),
            rack_types=new_rack,
            due_date=due_iso,
            estimated_hours=hours,
            quote_value=price,
            # v1.4.0 item 10: when the toggle is off the field is hidden,
            # so preserve the stored value untouched.
            waiting_on=(self.waiting_edit.currentText().strip()
                        if self._waiting_enabled()
                        else (self.task.get("waiting_on") or "")),
            # v1.4.0 item 15a: manual SDC override (None = Auto).
            seismic_override=self._sdc_override_value,
            # V1.9.29: Per / Sales Rep (commission tracking).
            per=self.per_edit.text().strip(),
            sales_rep=self.rep_edit.currentText().strip(),
            # V1.9.30: the (possibly new) revision label.
            revision=_new_rev,
        )
        # ---- activity log for what actually changed ----
        if new_notes != (old.get("notes") or ""):
            self.db.log_activity(self.task_id, "note", "Notes updated")
        if list(new_scope) != list(old.get("scope") or []):
            self.db.log_activity(
                self.task_id, "scope",
                f"Scope updated: {', '.join(new_scope) or 'none'}")
        if (old.get("quote_value") is None) != (price is None) or \
                (price is not None and float(old.get("quote_value") or 0) != price):
            self.db.log_activity(
                self.task_id, "price",
                f"Quote price: {format_price(old.get('quote_value')) or '—'} → "
                f"{format_price(price)}")
        changes = []
        for key, label in (("quote_number", "Quote #"),
                           ("distributor", "Distributor"),
                           ("end_user", "End User"),
                           ("folder_path", "Folder")):
            new_val = {"quote_number": quote,
                       "distributor": self.dist_edit.text().strip(),
                       "end_user": self.user_edit.text().strip(),
                       "folder_path": self.folder_edit.path()}[key]
            if (old.get(key) or "") != (new_val or ""):
                changes.append(f"{label}: {old.get(key) or '—'} → {new_val or '—'}")
        if set(new_rack) != set(old.get("rack_types") or []):
            changes.append("Rack types updated")
        if (old.get("due_date") or "") != (due_iso or ""):
            changes.append(f"Due: {old.get('due_date') or '—'} → {due_iso or '—'}")
        if (old.get("estimated_hours") is None) != (hours is None) or \
                (hours is not None
                 and float(old.get("estimated_hours") or 0) != hours):
            changes.append(f"Est.: {format_hours(old.get('estimated_hours')) or '—'} → "
                           f"{format_hours(hours) or '—'}")
        if changes:
            self.db.log_activity(self.task_id, "edit", "; ".join(changes))
        self.task = self.db.get_task(self.task_id)
        self.task_changed.emit()
        if self._opened_editing:
            self.close()
        else:
            self._render()
            self.set_editing(False)

    def _on_cancel(self):
        if self._opened_editing:
            self.close()
        else:
            self.set_editing(False)

    def _on_delete(self):
        if app_confirm(
            self, "Delete task",
            f"Delete task {self.task['quote_number']} and all its attachments? "
            "This cannot be undone.",
            confirm_label="Delete", danger=True):
            self.db.delete_task(self.task_id)
            shutil.rmtree(task_attachments_dir(self.db, self.task_id), ignore_errors=True)
            self.task_changed.emit()
            self.close()


# ------------------------------------------------------------ new task dialog
class NewTaskDialog(QDialog):
    """New Task window — mirrors the detail window's edit mode field for field.

    Attachments are staged in a temp dir while the dialog is open; after the
    task is created the caller commits them via :meth:`staged_files`.

    When ``queue_columns`` is given (a [(key, label), ...] list, read at
    dialog-open time so Settings renames are respected), a queue-column
    picker is shown and the caller can read the choice via
    :meth:`queue_column_key`. The Task List module passes nothing: no picker,
    no column assignment, behavior unchanged.
    """

    def __init__(self, db, parent=None, queue_columns=None):
        super().__init__(parent)
        self._db = db
        self.setWindowTitle("New Task")
        self.setModal(True)
        # V1.9.10: minimum width raised with the default width below — the
        # window can no longer be shrunk back into the cramped state where
        # fields crowded the scrollbar.
        self.setMinimumSize(580, 560)

        # No in-dialog title: the chrome title bar already says "New Task",
        # and the extra heading cost ~35px of vertical space.
        layout = install_chrome(self, "New Task")

        # The body is taller than any sane dialog (attachments staging
        # alone needs ~150px), so it lives in a scroll area: the dialog
        # keeps a compact fixed size and the fields can NEVER be squeezed
        # into strips, on any screen or scale. The Cancel/Create buttons
        # stay outside the scroll, always visible.
        _body = QWidget()
        body = QVBoxLayout(_body)
        body.setContentsMargins(0, 0, 0, 0)
        # The detail window's rhythm -- 8px within a group,
        # the groupStart margin (18px) between groups (V1.9.36).
        body.setSpacing(8)
        _scroll = QScrollArea()
        _scroll.setWidgetResizable(True)
        _scroll.setFrameShape(QFrame.NoFrame)
        _scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        _scroll.setWidget(_body)
        layout.addWidget(_scroll, 1)
        enable_touch_scroll(_scroll)
        # V1.9.10 (user screenshot): the fields ran right up against the
        # scrollbar — this dialog was the one form window missing the
        # shared scroll insets. Fields now keep the standard 16px clear of
        # the bar, like Task Details.
        set_scroll_content_margins(_scroll)

        self.quote_edit = QLineEdit()
        self.quote_edit.setPlaceholderText("e.g. XX-XXXX")
        self.rack_dropdown = TagDropdown(db=db, kind="rack")
        # V1.9.26 (user report): the quote box stretched full-width
        # for no reason. 12 characters, like the detail window's
        # task-number box; rack matches it (same relationship as the
        # detail window). Re-measured post-polish in
        # _fix_narrow_widths below.
        self.quote_edit.setFixedWidth(
            self.quote_edit.fontMetrics().horizontalAdvance("M" * 12) + 24)
        self.rack_dropdown.setFixedWidth(
            self.quote_edit.fontMetrics().horizontalAdvance("M" * 12) + 24)
        self.dist_edit = QLineEdit()
        self.dist_edit.setPlaceholderText("Distributor name")
        self.user_edit = QLineEdit()
        self.user_edit.setPlaceholderText("End user")
        attach_contact_completer(self.dist_edit, db, "distributor")
        attach_contact_completer(self.user_edit, db, "customer")
        self.folder_edit = FolderPathEdit()
        self.folder_hint = QLabel()
        self.folder_hint.setObjectName("folderHint")
        self.folder_hint.setWordWrap(True)
        self.folder_hint.setVisible(False)
        self.folder_edit.edit.textChanged.connect(self._update_folder_hint)
        self.due_edit = SafeDateEdit()
        self.due_edit.setCalendarPopup(True)
        self.due_edit.setDisplayFormat("MMM d, yyyy")
        # clearable: the minimum date shows a "No due date" placeholder
        self.due_edit.setSpecialValueText("No due date")
        # New tasks start with NO due date; the calendar popup still opens
        # on the current month/year (never the 1752 minimum date) via
        # hook_empty_date_popup. The Clear button restores the empty state.
        self.due_edit.setDate(self.due_edit.minimumDate())
        hook_empty_date_popup(self.due_edit)
        optically_center_date_edit(self.due_edit)
        # V1.9.51: the clear x lives INSIDE the field (see
        # _InlineDateClear), same as the detail window's.
        self.due_clear = _inline_date_clear(
            self.due_edit, "Clear the due date")
        self.due_clear.clicked.connect(
            lambda: self.due_edit.setDate(self.due_edit.minimumDate()))
        self.hours_edit = QLineEdit()
        # V1.9.35: placeholders match the detail window's editors.
        self.hours_edit.setPlaceholderText("Hours")
        self.hours_edit.setValidator(
            QDoubleValidator(0.0, 100000.0, 2, self.hours_edit))
        self.price_edit = QLineEdit()
        self.price_edit.setPlaceholderText("0.00")
        self.price_edit.setValidator(
            QDoubleValidator(0.0, 1e12, 2, self.price_edit))
        add_currency_prefix(self.price_edit)
        self.scope_dropdown = ScopeDropdown(db=db)
        # Subtle distributor scope preset: one suggestion chip, only when the
        # distributor's history is consistent (>=60% of >=3 quotes share the
        # exact scope set). Never auto-applies; vanishes on manual touch.
        self._scope_touched = False
        self._suggested_scopes = None
        self.scope_suggest = QPushButton()
        self.scope_suggest.setObjectName("scopeSuggest")
        self.scope_suggest.setCursor(Qt.PointingHandCursor)
        self.scope_suggest.setVisible(False)
        self.scope_suggest.clicked.connect(self._on_apply_scope_suggest)
        self.scope_dropdown.selection_changed.connect(self._on_scope_user_changed)
        self.dist_edit.editingFinished.connect(self._maybe_suggest_scope)
        _comp = self.dist_edit.completer()
        if _comp is not None:
            try:
                _comp.activated[str].connect(
                    lambda _t: self._maybe_suggest_scope())
            except Exception:
                pass
        self.notes_edit = _SanitizedTextEdit()
        self.notes_edit.setObjectName("notesEdit")
        self.notes_edit.setPlaceholderText("Notes, details, anything to remember…")
        # Fixed (not minimum) height: QTextEdit's default sizeHint is ~190px
        # and was inflating the whole dialog.
        self.notes_edit.setFixedHeight(76)
        # V1.9.2: same NOTES_DEFAULT_SIZE (12) base as the detail window —
        # the editor used to open at the platform default 9pt.
        _nf = app_font()
        _nf.setPointSize(NOTES_DEFAULT_SIZE)
        self.notes_edit.document().setDefaultFont(_nf)
        self.notes_edit.setFont(_nf)

        # V1.9.35: captions in the detail window's language --
        # sectionLabel, uppercase, same words (the detail's TASK
        # header is this window's QUOTE NUMBER; the * stays, it is
        # the one required field).
        # V1.9.51 (user: New Task had NO Revision spot): REVISION
        # sits immediately right of the quote number, exactly as
        # in the detail window -- a two-character box, "00" by
        # default, carried into the created task.
        self.rev_edit = QLineEdit()
        self.rev_edit.setPlaceholderText("00")
        self.rev_edit.setText("00")
        self.rev_edit.setFixedWidth(
            self.quote_edit.fontMetrics().horizontalAdvance("00") + 22)
        _id_block = QWidget()
        _id_grid = QGridLayout(_id_block)
        _id_grid.setContentsMargins(0, 0, 0, 0)
        _id_grid.setHorizontalSpacing(18)
        _id_grid.setVerticalSpacing(2)
        _q_lab = QLabel("QUOTE NUMBER *")
        _q_lab.setObjectName("sectionLabel")
        _r_lab = QLabel("REVISION")
        _r_lab.setObjectName("sectionLabel")
        _id_grid.addWidget(_q_lab, 0, 0)
        _id_grid.addWidget(_r_lab, 0, 1)
        _id_grid.addWidget(self.quote_edit, 1, 0)
        _id_grid.addWidget(self.rev_edit, 1, 1)
        _id_grid.setColumnStretch(2, 1)
        body.addWidget(_id_block)
        for label_text, widget, group_start in [
            ("RACK TYPE", self.rack_dropdown, True),
        ]:
            lab = QLabel(label_text)
            lab.setObjectName("sectionLabel")
            if group_start:
                lab.setProperty("groupStart", True)
            body.addWidget(lab)
            body.addWidget(widget, alignment=Qt.AlignLeft)

        # Distributor + End User side by side to keep the window short.
        # Equal-stretch grid with CENTERED labels over UNIFORM inputs.
        # The seismic badge and override adjuster live in their own
        # full-width row below the grid (same as the detail window), so
        # they can never squeeze the inputs or disturb the columns.
        # v1.4.0 item 15/15a: badge + override adjuster. The whole dialog
        # is an edit context, so the adjuster lives here (15c: never in
        # view mode).
        self._sdc_badge = QLabel()
        self._sdc_badge.setObjectName("sdcBadge")
        self._sdc_badge.setVisible(False)
        chip_font(self._sdc_badge)
        self._sdc_adjust = SafeComboBox()
        self._sdc_adjust.setObjectName("sdcAdjust")
        self._sdc_adjust.setToolTip(
            "Override the SDC estimate for this task")
        self._sdc_adjust.addItem("Auto", None)
        for _sdc_letter in ("A", "B", "C", "D", "E"):
            self._sdc_adjust.addItem(_sdc_letter, _sdc_letter)
        self._sdc_adjust.currentIndexChanged.connect(
            self._on_sdc_adjust)

        du_grid = QGridLayout()
        du_grid.setContentsMargins(0, 0, 0, 0)
        du_grid.setHorizontalSpacing(12)
        du_grid.setVerticalSpacing(8)
        du_grid.setColumnStretch(0, 1)
        du_grid.setColumnStretch(1, 1)
        dist_lab = QLabel("DISTRIBUTOR")
        dist_lab.setObjectName("headerNameLabel")
        dist_lab.setAlignment(Qt.AlignCenter)
        dist_lab.setProperty("groupStart", True)
        user_lab = QLabel("END USER")
        user_lab.setObjectName("headerNameLabel")
        user_lab.setAlignment(Qt.AlignCenter)
        user_lab.setProperty("groupStart", True)
        du_grid.addWidget(dist_lab, 0, 0)
        du_grid.addWidget(user_lab, 0, 1)
        du_grid.addWidget(self.dist_edit, 1, 0)
        du_grid.addWidget(self.user_edit, 1, 1)
        body.addLayout(du_grid)

        # V1.9.34 (user: "You didn't add the new fields here -- this
        # should be identical almost to the edit task window"):
        # CONTACT NAME + SALES REP, the fields the detail window's
        # edit mode has had since V1.9.29/30, mirrored in the same
        # two-column grid directly under Distributor / End User.
        self.per_edit = QLineEdit()
        self.per_edit.setPlaceholderText("Contact name")
        self.per_edit.setAlignment(Qt.AlignCenter)
        attach_contact_completer(self.per_edit, db, "contact")
        self.rep_edit = SafeComboBox()
        self.rep_edit.setEditable(True)
        if self.rep_edit.lineEdit() is not None:
            self.rep_edit.lineEdit().setAlignment(Qt.AlignCenter)
        # V1.9.48: centre on the whole field (see detail window).
        optically_center_combo(self.rep_edit)
        for _rep in db.get_sales_reps():
            self.rep_edit.addItem(_rep)
        # New tasks start on the default rep (House Account rule).
        self.rep_edit.setCurrentText(default_sales_rep(db))
        pr_grid = QGridLayout()
        pr_grid.setContentsMargins(0, 0, 0, 0)
        pr_grid.setHorizontalSpacing(12)
        pr_grid.setVerticalSpacing(8)
        pr_grid.setColumnStretch(0, 1)
        pr_grid.setColumnStretch(1, 1)
        per_lab = QLabel("CONTACT NAME")
        per_lab.setObjectName("headerNameLabel")
        per_lab.setAlignment(Qt.AlignCenter)
        per_lab.setProperty("groupStart", True)
        rep_lab = QLabel("SALES REP")
        rep_lab.setObjectName("headerNameLabel")
        rep_lab.setAlignment(Qt.AlignCenter)
        rep_lab.setProperty("groupStart", True)
        pr_grid.addWidget(per_lab, 0, 0)
        pr_grid.addWidget(rep_lab, 0, 1)
        pr_grid.addWidget(self.per_edit, 1, 0)
        pr_grid.addWidget(self.rep_edit, 1, 1)
        body.addLayout(pr_grid)

        self._sdc_bar = QWidget()
        self._sdc_bar.setProperty("groupStart", True)
        sdc_bar = QHBoxLayout(self._sdc_bar)
        sdc_bar.setContentsMargins(0, 0, 0, 0)
        sdc_bar.setSpacing(8)
        sdc_cap = QLabel("SEISMIC")
        sdc_cap.setObjectName("sectionLabel")
        sdc_bar.addWidget(sdc_cap)
        sdc_bar.addWidget(self._sdc_badge)
        sdc_bar.addWidget(self._sdc_adjust)
        # V1.9.52 (user): the IBC chip sits to the RIGHT of the
        # seismic option in the New Task window.
        self._ibc_chip = IbcChip()
        sdc_bar.addWidget(self._ibc_chip)
        sdc_bar.addStretch(1)
        body.addWidget(self._sdc_bar)
        # v1.4.0 item 15: resolve SDC when the end-user edit commits
        # (editingFinished = tab/click/focus-out, NOT while typing).
        self.user_edit.editingFinished.connect(self._on_user_edit_finished)
        # Pending manual override (None = Auto); B+ popup fires at most
        # once per dialog session (item 15b).
        self._sdc_override_value = None
        self._sdc_popup_done = False
        self._ibc_popup_done = False
        self._ibc_res = None
        self._ibc_assess = None
        self._update_ibc_chip(self.user_edit.text().strip())

        # V1.9.35 (user: New Task must match the detail window's
        # layout): QUOTE FOLDER sits where the detail window puts
        # it -- after Seismic, before Scope of Work.
        lab = QLabel("QUOTE FOLDER")
        lab.setObjectName("sectionLabel")
        lab.setProperty("groupStart", True)
        body.addWidget(lab)
        body.addWidget(self.folder_edit)
        body.addWidget(self.folder_hint)
        # Automatic quote folder creation: only offered when the master
        # toggle is on; default checked. The caller reads
        # self.create_folder_box after accept().
        self.create_folder_box = QCheckBox("Create Folder")
        self.create_folder_box.setObjectName("primaryCheck")
        self.create_folder_box.setChecked(True)
        self.create_folder_box.setVisible(folder_creation_enabled(self._db))
        body.addWidget(self.create_folder_box)
        # Setup guard: when the master toggle is on but setup is
        # incomplete, a prominent inline warning + an "Open Settings"
        # shortcut explain the outcome BEFORE save — never a silent
        # no-op. Hidden when the toggle is off or setup is complete.
        self.folder_setup_warning = QLabel()
        self.folder_setup_warning.setObjectName("folderSetupWarning")
        self.folder_setup_warning.setWordWrap(True)
        self.folder_setup_warning.setVisible(False)
        body.addWidget(self.folder_setup_warning)
        self.folder_setup_button = QPushButton("Open Settings")
        self.folder_setup_button.setObjectName("folderSetupButton")
        self.folder_setup_button.setCursor(Qt.PointingHandCursor)
        self.folder_setup_button.setVisible(False)
        self.folder_setup_button.clicked.connect(self._on_open_folder_settings)
        body.addWidget(self.folder_setup_button)
        self._folder_settings_dialog = None

        # V1.9.10 (user order): Scope of Work sits ABOVE the queue-column
        # picker — at the bottom of the form it was being overlooked.
        for label_text, widget in [
            ("Scope of Work (select all that apply)", self.scope_dropdown),
        ]:
            lab = QLabel("SCOPE OF WORK")
            lab.setObjectName("sectionLabel")
            lab.setProperty("groupStart", True)
            # V1.9.51 (user screenshot): this caption sits
            # CENTRED over its dropdown, like the detail
            # window's centred field captions.
            lab.setAlignment(Qt.AlignCenter)
            body.addWidget(lab)
            body.addWidget(widget)
        body.addWidget(self.scope_suggest)

        for label_text, widget in [
            ("Notes", self.notes_edit),
        ]:
            lab = QLabel("NOTES")
            lab.setObjectName("sectionLabel")
            lab.setProperty("groupStart", True)
            body.addWidget(lab)
            body.addWidget(widget)

        # V1.9.35: DATES & VALUE -- the detail window's section,
        # in the detail window's place (after Notes) and shape:
        # section caption, then Due / Est. Hours / Quote Price
        # spread left / centre / right with CENTRED field captions
        # over content-width editors.
        dv_lab = QLabel("DATES & VALUE")
        dv_lab.setObjectName("sectionLabel")
        dv_lab.setProperty("groupStart", True)
        body.addWidget(dv_lab)
        # Due date gets its Clear button beside the picker (same "ghost"
        # pattern as the follow-up reminder's Clear button) so "no due
        # date" stays reachable now that the field defaults to today.
        due_wrap = QWidget()
        self._due_wrap = due_wrap
        due_box = QHBoxLayout(due_wrap)
        due_box.setContentsMargins(0, 0, 0, 0)
        due_box.setSpacing(6)
        due_box.addWidget(self.due_edit, 1)
        # V1.9.51: no beside-field clear anymore -- the x is
        # inside the field (see _InlineDateClear).
        # V1.9.25: same content widths as the detail window — hours
        # fits "xxx", price fits "x,xxx,xxx,xxx.xx" — no three-way
        # split (see the detail-window note above).
        self.hours_edit.setFixedWidth(_hours_edit_width(self.hours_edit))
        self.price_edit.setFixedWidth(
            self.price_edit.fontMetrics().horizontalAdvance("999,999,999,999.99") + 24)
        # V1.9.36: numbers centre like the detail window's (the
        # V1.9.26 right-alignment is superseded there too), and the
        # editor centres in its column so the centred caption sits
        # exactly over the box.
        self.hours_edit.setAlignment(Qt.AlignCenter)
        self.price_edit.setAlignment(Qt.AlignCenter)
        _dhp_cols = []
        self._dhp_fit = []
        for label_text, widget in [
            ("DUE DATE", due_wrap),
            ("EST. HOURS", self.hours_edit),
            ("QUOTE PRICE", self.price_edit),
        ]:
            lab = QLabel(label_text)
            lab.setObjectName("fieldLabel")
            lab.setAlignment(Qt.AlignHCenter)
            # Fixed-width wrap, same as the detail window: caption
            # and field share one centre line exactly.
            wrap = QWidget()
            col = QVBoxLayout(wrap)
            col.setContentsMargins(0, 0, 0, 0)
            col.setSpacing(8)
            # V1.9.48 (user: "why is due date not centered OVER
            # ITS DAMN DROPDOWN"): the DUE caption anchors to the
            # picker alone (see _fit_due_caption), so it is added
            # left-aligned with a picker-width box instead of
            # centring over picker+Clear.
            if label_text == "DUE DATE":
                col.addWidget(lab, 0, Qt.AlignLeft)
                self._due_lab = lab
            else:
                col.addWidget(lab, 0, Qt.AlignHCenter)
            col.addWidget(widget, 0, Qt.AlignHCenter)
            wrap.setFixedWidth(max(lab.sizeHint().width(),
                                   widget.sizeHint().width(),
                                   widget.minimumWidth()))
            _dhp_cols.append(wrap)
            self._dhp_fit.append((lab, widget, wrap))
        dhp_grid = QGridLayout()
        dhp_grid.setContentsMargins(0, 0, 0, 0)
        dhp_grid.setColumnStretch(0, 1)
        dhp_grid.setColumnStretch(1, 1)
        dhp_grid.setColumnStretch(2, 1)
        dhp_grid.addWidget(_dhp_cols[0], 0, 0,
                           Qt.AlignLeft | Qt.AlignTop)
        dhp_grid.addWidget(_dhp_cols[1], 0, 1,
                           Qt.AlignHCenter | Qt.AlignTop)
        dhp_grid.addWidget(_dhp_cols[2], 0, 2,
                           Qt.AlignRight | Qt.AlignTop)
        body.addLayout(dhp_grid)

        # V1.9.34 (same parity pass): WAITING ON + FOLLOW-UP
        # REMINDER from the detail window's edit mode. Waiting On
        # follows the same Settings toggle that gates it there.
        self._waiting_wrap = QWidget()
        waiting_box = QVBoxLayout(self._waiting_wrap)
        waiting_box.setContentsMargins(0, 0, 0, 0)
        waiting_box.setSpacing(8)
        waiting_lab = QLabel("WAITING ON")
        waiting_lab.setObjectName("sectionLabel")
        # V1.9.50 (user): centred over its dropdown, like the
        # detail window's (the wrap is the combo's width wide).
        waiting_lab.setAlignment(Qt.AlignCenter)
        waiting_box.addWidget(waiting_lab)
        self.waiting_edit = SafeComboBox()
        self.waiting_edit.setEditable(True)
        for _preset in ("Internal pricing", "Outside supplier",
                        "Freight"):
            self.waiting_edit.addItem(_preset)
        self.waiting_edit.setPlaceholderText(
            "Who are you waiting on?")
        self.waiting_edit.setCurrentIndex(-1)
        _fit_combo_to_contents(self.waiting_edit)
        waiting_box.addWidget(self.waiting_edit, 0, Qt.AlignLeft)
        self._waiting_wrap.setVisible(
            db.get_setting("waiting_on_enabled", "0") == "1")

        remind_lab = QLabel("FOLLOW-UP REMINDER")
        remind_lab.setObjectName("sectionLabel")
        remind_col = QWidget()
        remind_box = QVBoxLayout(remind_col)
        remind_box.setContentsMargins(0, 0, 0, 0)
        remind_box.setSpacing(8)
        remind_box.addWidget(remind_lab)
        remind_row = QHBoxLayout()
        remind_row.setContentsMargins(0, 0, 0, 0)
        remind_row.setSpacing(6)
        self.remind_edit = SafeDateEdit()
        self.remind_edit.setCalendarPopup(True)
        self.remind_edit.setDisplayFormat("MMM d, yyyy")
        self.remind_edit.setSpecialValueText("No reminder")
        self.remind_edit.setDate(self.remind_edit.minimumDate())
        hook_empty_date_popup(self.remind_edit)
        # V1.9.48 (user: "WHY DID YOU MAKE THIS DROPDOWN SO WIDE
        # WHEN IT JUST OPENS A CALENDAR"): the picker was added
        # with stretch and ate the whole row. It takes the same
        # content width as the detail window's reminder field --
        # longest date text plus chrome -- and Clear sits beside
        # it; the rest of the row stays empty.
        _rfm = self.remind_edit.fontMetrics()
        _rsamples = ["No reminder"] + [
            f"{m} 30, 2026" for m in
            ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
             "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")]
        self.remind_edit.setMinimumWidth(
            max(_rfm.horizontalAdvance(s) for s in _rsamples)
            + 22 + 24 + 16 + _InlineDateClear.SLOT)
        self.remind_edit.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        remind_row.addWidget(self.remind_edit)
        # V1.9.51: the clear x lives INSIDE the field (see
        # _InlineDateClear) -- not a row widget anymore.
        remind_clear = _inline_date_clear(
            self.remind_edit, "Clear the reminder")
        remind_clear.clicked.connect(
            lambda: self.remind_edit.setDate(
                self.remind_edit.minimumDate()))
        remind_box.addLayout(remind_row)

        # Queue-column picker: only when opened from the Queue module
        # (the caller passes the current column names). A creation-
        # only extra, so it sits after the mirrored field flow,
        # before Attachments. Defaults to the first column.
        self._queue_column_keys = []
        self.queue_column_combo = None
        if queue_columns:
            qlab = QLabel("QUEUE COLUMN")
            qlab.setObjectName("sectionLabel")
            queue_col = QWidget()
            queue_box = QVBoxLayout(queue_col)
            queue_box.setContentsMargins(0, 0, 0, 0)
            queue_box.setSpacing(8)
            queue_box.addWidget(qlab)
            self.queue_column_combo = SafeComboBox()
            self.queue_column_combo.setCursor(Qt.PointingHandCursor)
            for key, label in queue_columns:
                self._queue_column_keys.append(str(key))
                self.queue_column_combo.addItem(str(label))
            self.queue_column_combo.setCurrentIndex(0)
            _fit_combo_to_contents(self.queue_column_combo)
            queue_box.addWidget(self.queue_column_combo,
                                0, Qt.AlignLeft)

        # V1.9.48 (user: "all 3 can fit in the same row"):
        # WAITING ON, FOLLOW-UP REMINDER and QUEUE COLUMN share
        # ONE row of content-sized columns instead of three
        # full-width stacked fields. The row carries the
        # groupStart air; a hidden column (Waiting off, or no
        # queue context) collapses and the rest slide over.
        trio = QWidget()
        trio.setProperty("groupStart", True)
        trio_row = QHBoxLayout(trio)
        trio_row.setContentsMargins(0, 0, 0, 0)
        trio_row.setSpacing(24)
        # AlignTop: the date picker's natural height is 2px
        # taller than the combos', and a centred column parked
        # its field 2px high (measured) -- tops must coincide.
        trio_row.addWidget(self._waiting_wrap, 0, Qt.AlignTop)
        trio_row.addWidget(remind_col, 0, Qt.AlignTop)
        if queue_columns:
            trio_row.addWidget(queue_col, 0, Qt.AlignTop)
        trio_row.addStretch(1)
        body.addWidget(trio)

        self.attachments = AttachmentsWidget(db, None, staging=True)
        # v1.4.0 item 6: the attachment list's 132px default pushed the
        # Create Task button off laptop screens. The New Task instance
        # starts compact (scrolls when files are added); the detail
        # window keeps the roomier default.
        self.attachments.list.setMaximumHeight(84)
        self.attachments.setProperty("groupStart", True)
        body.addWidget(self.attachments)

        body.addSpacing(6)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self._on_reject)
        save = QPushButton("Create Task")
        save.setObjectName("primary")
        save.setDefault(True)
        save.clicked.connect(self._on_accept)
        row.addWidget(cancel)
        row.addWidget(save)
        layout.addLayout(row)

        QShortcut(QKeySequence("Ctrl+V"), self,
                  activated=self.attachments.paste_from_clipboard)

        # Evaluate the folder-setup guard after everything exists.
        self._refresh_folder_guard()

        # Compact but roomy: the body scrolls, so this height only sets
        # the initial viewport — fields can never be squeezed.
        # V1.9.10 (user request): a little wider than the old 560 so the
        # new scroll insets pad the fields from the scrollbar without
        # narrowing the form.
        self.resize(624, 720)
        _pin_caption_labels(self)
        _apply_group_air(body)
        _chip_font_tree(self)
        # V1.9.48: the dialog must open at the body's real
        # width. Its own sizeHint comes from the scroll area and
        # understates the content -- the shipped dialog clipped
        # its widest rows (the quote-folder Browse button ran
        # off the right edge). The width is applied on first
        # show (see showEvent): resizing here would also freeze
        # the height at its pre-polish hint and shrink the
        # dialog vertically.
        self._body_hint_w = max(640, min(1000,
                                         body.sizeHint().width()
                                         + 44))

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        # V1.9.48: widen to the body's real width on first show
        # (see _body_hint_w in __init__) -- height untouched.
        if not getattr(self, "_width_fit_done", False):
            self._width_fit_done = True
            _need = getattr(self, "_body_hint_w", 0)
            if _need and self.width() < _need:
                self.resize(_need, self.height())
        # V1.9.25: hours/price widths are font-measured, but the font
        # at construction is pre-polish (same trap as the detail
        # window's _fix_quote_width). Re-measure once, deferred past
        # the first paint, when the polished font is in effect.
        if not getattr(self, "_narrow_widths_fixed", False):
            self._narrow_widths_fixed = True
            QTimer.singleShot(0, self._fix_narrow_widths)

    def _fit_due_caption(self):
        """V1.9.48: size the DUE DATE caption's box to the
        picker's own width, so its centre sits exactly over the
        picker. V1.9.51: the wrap now holds the picker ALONE (the
        clear x moved inside the field), so the wrap's hint IS
        the picker's width -- no subtraction."""
        lab = getattr(self, "_due_lab", None)
        if lab is None:
            return
        w = self._due_wrap.sizeHint().width()
        if w > 0:
            lab.setFixedWidth(w)

    def _fix_narrow_widths(self):
        try:
            _qfm = self.quote_edit.fontMetrics()
            self.quote_edit.setFixedWidth(
                _qfm.horizontalAdvance("M" * 12) + 24)
            self.rack_dropdown.setFixedWidth(
                _qfm.horizontalAdvance("M" * 12) + 24)
            self.hours_edit.setFixedWidth(
                _hours_edit_width(self.hours_edit))
            self.price_edit.setFixedWidth(
                self.price_edit.fontMetrics().horizontalAdvance(
                    "999,999,999,999.99") + 24)
            # V1.9.50: the centred due text must actually FIT --
            # grow the picker before the wraps are re-fitted to it
            # (the "o due date" clip).
            _ensure_date_text_fits(self.due_edit)
            # V1.9.36: re-fit the centred column wraps, same as the
            # detail window's _fix_quote_width.
            for lab, widget, wrap in getattr(self, "_dhp_fit", []):
                wrap.setFixedWidth(max(
                    lab.sizeHint().width(), widget.sizeHint().width(),
                    widget.minimumWidth()))
            self._fit_due_caption()
        except Exception:
            pass

    def _on_reject(self):
        self.attachments.cleanup_staging()
        self.reject()

    def _on_accept(self):
        if not self.quote_edit.text().strip():
            show_toast(self, "warning", "Missing info",
                       "Please enter a Quote Number.")
            self.quote_edit.setFocus()
            return
        self.accept()

    def _update_folder_hint(self):
        """Non-blocking hint when the quote folder isn't reachable (VPN).

        Local paths are checked synchronously (cheap); UNC paths are
        probed off the UI thread after a short debounce — typing must
        never wait on the network (v1.2.9).
        """
        path = self.folder_edit.path().strip()
        old_timer = getattr(self, "_folder_hint_timer", None)
        if old_timer is not None:
            try:
                old_timer.stop()
            except RuntimeError:
                pass
            self._folder_hint_timer = None
        if not path or not _looks_like_unc(path):
            if path and not Path(path).is_dir():
                self.folder_hint.setText(
                    "Folder not reachable — will work on VPN")
                self.folder_hint.setVisible(True)
            else:
                self.folder_hint.setVisible(False)
            return
        self._folder_hint_gen = getattr(self, "_folder_hint_gen", 0) + 1
        gen = self._folder_hint_gen
        self.folder_hint.setText("Checking folder…")
        self.folder_hint.setVisible(True)

        def _done(payload):
            try:
                if gen != self._folder_hint_gen:
                    return  # stale keystroke
                ok = bool(payload.get("ok") and payload.get("value"))
                if ok:
                    self.folder_hint.setVisible(False)
                else:
                    self.folder_hint.setText(
                        "Folder not reachable — will work on VPN")
                    self.folder_hint.setVisible(True)
            except RuntimeError:
                pass  # dialog closed meanwhile

        def _fire():
            try:
                if gen != self._folder_hint_gen:
                    return
                run_folder_background(_probe_dir_exists, _done, path)
            except RuntimeError:
                pass

        timer = QTimer(self)
        timer.setSingleShot(True)
        timer.timeout.connect(_fire)
        timer.start(400)
        self._folder_hint_timer = timer

    # -- folder setup guard (never a silent no-op) --
    def folder_setup_issues(self):
        """Return issue strings describing incomplete folder-creation setup.

        Mirrors begin_quote_folder_flow's guards: nothing is reported when
        the master toggle is off, since nothing is attempted in that case.
        Local template paths are checked synchronously (cheap); UNC paths
        are never stat'ed on the UI thread — their verdict arrives via the
        background probe kicked off by _refresh_folder_guard (v1.2.9).
        Returns [] when setup is complete.
        """
        if not folder_creation_enabled(self._db):
            return []
        issues = []
        template = (self._db.get_setting("folder_template_dir", "") or "").strip()
        if not template:
            issues.append(
                "Template folder isn't set or can't be reached — "
                "no folder can be created yet.")
        elif not _looks_like_unc(template):
            if not os.path.isdir(template):
                issues.append(
                    "Template folder isn't set or can't be reached — "
                    "no folder can be created yet.")
        elif self._unc_template_unreachable():
            issues.append(
                "Template folder isn't set or can't be reached — "
                "no folder can be created yet.")
        dest = (self._db.get_setting("folder_dest_dir", "") or "").strip()
        if not dest:
            issues.append(
                "Destination folder isn't set — "
                "no folder can be created yet.")
        return issues

    def _unc_template_unreachable(self):
        """Cached verdict of the background UNC-template probe (v1.2.9).

        False while unknown or reachable; True once a probe has reported
        the template unreachable. Only the latest probe's verdict is ever
        applied (generation counter in _kick_unc_template_probe).
        """
        return bool(getattr(self, "_unc_template_bad", False))

    def _kick_unc_template_probe(self):
        """Start the background reachability probe for a UNC template path.

        Returns True while the verdict for the current template is still
        unknown (probe in flight or just started). Local paths and empty
        templates never probe — they are handled synchronously.
        """
        template = (self._db.get_setting("folder_template_dir", "") or "").strip()
        if not _looks_like_unc(template):
            return False
        if getattr(self, "_unc_probe_for", None) == template:
            return bool(getattr(self, "_unc_probe_pending", False))
        gen = getattr(self, "_unc_probe_gen", 0) + 1
        self._unc_probe_gen = gen
        self._unc_probe_for = template
        self._unc_probe_pending = True
        self._unc_template_bad = False

        def _done(payload):
            try:
                if gen != self._unc_probe_gen:
                    return  # stale: settings changed again
                self._unc_probe_pending = False
                self._unc_template_bad = not (
                    payload.get("ok") and payload.get("value"))
                self._refresh_folder_guard()
            except RuntimeError:
                pass  # dialog closed meanwhile

        run_folder_background(_probe_dir_exists, _done, template)
        return True

    def _refresh_folder_guard(self):
        """Show the inline setup warning + \"Open Settings\" button only when
        the master toggle is on and setup is incomplete. Also re-syncs the
        \"Create Folder\" checkbox visibility with the toggle (the guard
        button may have changed it from Settings)."""
        master = folder_creation_enabled(self._db)
        self.create_folder_box.setVisible(master)
        probing = master and self._kick_unc_template_probe()
        issues = self.folder_setup_issues()
        if probing and not issues:
            # UNC template reachability still being probed off-thread:
            # show the checking state, never block the UI thread.
            issues = ["Checking template folder…"]
        show = bool(master and issues)
        self.folder_setup_warning.setText("\n".join(issues))
        self.folder_setup_warning.setVisible(show)
        self.folder_setup_button.setVisible(show)

    def _on_open_folder_settings(self):
        """Open Settings as a modal dialog (this dialog is modal, so a
        modeless child would be dead), scrolled to Folder Creation first.
        Re-evaluates the guard after it closes."""
        dlg = SettingsDialog(self._db, self)
        self._folder_settings_dialog = dlg
        dlg.ensure_folder_section_visible()
        dlg.exec()
        self._refresh_folder_guard()

    # -- distributor scope preset (suggestion only, never auto-applies) --
    def _on_scope_user_changed(self, _selected):
        self._scope_touched = True
        self.scope_suggest.setVisible(False)

    def _maybe_suggest_scope(self):
        name = self.dist_edit.text().strip()
        pattern = None
        if (name and not self._scope_touched
                and not self.scope_dropdown.selected()):
            try:
                pattern = self._db.distributor_scope_pattern(name)
            except Exception:
                pattern = None
        self._suggested_scopes = pattern
        if pattern:
            self.scope_suggest.setText(
                f"Usual for {name}: {', '.join(pattern)} — Apply")
            self.scope_suggest.setVisible(True)
        else:
            self.scope_suggest.setVisible(False)

    def _on_apply_scope_suggest(self):
        if self._suggested_scopes:
            self.scope_dropdown.set_selected(list(self._suggested_scopes))
        self.scope_suggest.setVisible(False)

    def _due_iso(self):
        d = self.due_edit.date()
        if d <= self.due_edit.minimumDate():
            return ""
        return d.toString("yyyy-MM-dd")

    @staticmethod
    def _float_or_none(edit):
        text = edit.text().strip().replace(",", "")
        if not text:
            return None
        try:
            return float(text)
        except ValueError:
            return None

    def staged_files(self):
        """[(filename, Path), ...] staged attachments to commit after creation."""
        return self.attachments.staged_files()

    def queue_column_key(self):
        """Selected queue column key, or None when no picker was shown.

        Defaults to the first column (the combo always has index 0
        selected unless the user picks another).
        """
        if not self._queue_column_keys:
            return None
        idx = self.queue_column_combo.currentIndex()
        if 0 <= idx < len(self._queue_column_keys):
            return self._queue_column_keys[idx]
        return self._queue_column_keys[0]

    # -- seismic SDC (v1.4.0 item 15) --
    def _resolve_sdc(self, name):
        """(letter, is_override) for an end-user name, or (None, False).

        Resolution order (item 15a): the pending manual override wins;
        otherwise the linked CRM contact's city/state; otherwise the
        parsed field text. Never raises.
        """
        try:
            from .seismic import resolve_sdc as _resolve
        except Exception:
            return (None, False)
        name = (name or "").strip()
        city = state = None
        if name:
            try:
                contact = self._db.directory_get_by_name("customer", name)
            except Exception:
                contact = None
            if contact:
                city = (contact.get("city") or "").strip() or None
                state = (contact.get("state") or "").strip() or None
        return _resolve(self._sdc_override_value, city, state, name or None)

    def _update_sdc_badge(self, name):
        """Refresh the inline SDC badge for an end-user name."""
        badge = getattr(self, "_sdc_badge", None)
        if badge is None:
            return None
        try:
            from .seismic import sdc_severity, sdc_badge_text, sdc_tooltip
        except Exception:
            return None
        letter, is_override = self._resolve_sdc(name)
        if not letter:
            badge.setVisible(False)
            return None
        badge.setText(sdc_badge_text(letter, is_override))
        badge.setProperty("sdcSeverity", sdc_severity(letter))
        badge.setToolTip(sdc_tooltip(is_override))
        badge.style().unpolish(badge)
        badge.style().polish(badge)
        badge.setVisible(True)
        return letter

    def _on_sdc_adjust(self, _idx):
        """Manual override picked: preview the badge now, persist on
        Create. A B+ pick also triggers the popup (once)."""
        self._sdc_override_value = self._sdc_adjust.currentData()
        letter = self._update_sdc_badge(self.user_edit.text().strip())
        if letter:
            self._maybe_sdc_popup(letter)

    def _maybe_sdc_popup(self, letter):
        """Themed B+ popup: at most once per dialog session, and only
        when the Settings toggle is on. Never raises."""
        if not letter or letter == "A" or self._sdc_popup_done:
            return
        try:
            popup_on = self._db.get_setting("seismic_popup", "1") == "1"
        except Exception:
            popup_on = True
        if not popup_on:
            return
        self._sdc_popup_done = True
        try:
            from .seismic import sdc_severity, sdc_tooltip
            _letter, is_override = self._resolve_sdc(
                self.user_edit.text().strip())
            show_toast(
                self,
                "warning" if sdc_severity(letter) == "high" else "info",
                f"Seismic Design Category: {letter}",
                sdc_tooltip(is_override),
            )
        except Exception:
            pass

    def _update_ibc_chip(self, name):
        """Refresh the IBC chip for an end-user name (V1.9.52)."""
        chip = getattr(self, "_ibc_chip", None)
        if chip is None:
            return
        res, assess = resolve_ibc_for_name(self._db, name)
        self._ibc_res = res
        self._ibc_assess = assess
        chip.set_ibc(res, assess)

    def _maybe_ibc_popup(self):
        """IBC lead-time warning toast: once per dialog, only
        when the Settings toggle is on. Never raises."""
        if getattr(self, "_ibc_popup_done", False):
            return
        assess = getattr(self, "_ibc_assess", None)
        if not assess or not assess.get("flag"):
            return
        try:
            if self._db.get_setting("ibc_popup", "1") != "1":
                return
        except Exception:
            pass
        self._ibc_popup_done = True
        try:
            title, text = ibc_warning_toast_text(self._ibc_res, assess)
            show_toast(self, "warning", title, text)
        except Exception:
            pass

    def _on_user_edit_finished(self):
        """End-user field committed: refresh the badge, popup once on B+."""
        letter = self._update_sdc_badge(self.user_edit.text().strip())
        if letter:
            self._maybe_sdc_popup(letter)
        self._update_ibc_chip(self.user_edit.text().strip())
        self._maybe_ibc_popup()

    def values(self):
        return {
            "quote_number": self.quote_edit.text().strip(),
            "distributor": self.dist_edit.text().strip(),
            "end_user": self.user_edit.text().strip(),
            "folder_path": self.folder_edit.path(),
            "notes": notes_editor_save(self.notes_edit),
            "scope": self.scope_dropdown.selected(),
            "rack_types": self.rack_dropdown.selected(),
            "due_date": self._due_iso(),
            "estimated_hours": self._float_or_none(self.hours_edit),
            "quote_value": self._float_or_none(self.price_edit),
            # v1.4.0 item 15a: manual SDC override (None = Auto).
            "seismic_override": self._sdc_override_value,
            # V1.9.34: detail-window parity fields.
            "per": self.per_edit.text().strip(),
            # V1.9.51: the Revision box (defaults to "00").
            "revision": self.rev_edit.text().strip() or "00",
            "sales_rep": self.rep_edit.currentText().strip(),
            "waiting_on": (self.waiting_edit.currentText().strip()
                           if self._waiting_wrap.isVisibleTo(self)
                           else ""),
            "remind_at": self._remind_iso(),
        }

    def _remind_iso(self):
        d = self.remind_edit.date()
        if d <= self.remind_edit.minimumDate():
            return ""
        return d.toString("yyyy-MM-dd")


def _commit_staged_attachments(db, task_id, dialog):
    """Copy files staged in a New Task dialog onto the new task."""
    staged = dialog.staged_files()
    try:
        if not staged:
            return
        dest_dir = task_attachments_dir(db, task_id)
        for filename, src in staged:
            if not src.exists():
                continue
            dest = dest_dir / filename
            if dest.exists():
                stem, suffix = Path(filename).stem, Path(filename).suffix
                i = 1
                while (dest_dir / f"{stem} ({i}){suffix}").exists():
                    i += 1
                dest = dest_dir / f"{stem} ({i}){suffix}"
            try:
                shutil.copy2(src, dest)
            except OSError:
                continue
            db.add_attachment(
                task_id, filename, dest.name, dest.stat().st_size
            )
    finally:
        dialog.attachments.cleanup_staging()


def run_new_task_dialog(db, parent, queue_columns=None, on_created=None,
                        open_existing=None, on_settled=None):
    """Shared New-Task create flow for the Task List and Queue modules.

    Opens the same NewTaskDialog both modules use. ``queue_columns`` (a
    [(key, label), ...] list) adds the queue-column picker; pass None for
    the plain Task List behavior.

    - ``on_created(task_id, values, dialog)`` runs right after the task is
      saved (e.g. the Queue module files it into the picked column here).
    - ``open_existing(task_id)`` handles the duplicate-quote branch's
      "Open existing task" choice.
    - ``on_settled()`` runs when the (async) quote-folder flow finishes.

    Returns the new task id, or None if the dialog was cancelled or the
    duplicate-quote branch deferred. The caller refreshes its own views.
    """
    dialog = NewTaskDialog(db, parent, queue_columns=queue_columns)
    while dialog.exec():
        v = dialog.values()
        existing = db.task_id_for_quote(v["quote_number"])
        if existing is None:
            task_id = db.add_task(
                v["quote_number"], v["distributor"], v["end_user"], v["notes"],
                v["scope"], folder_path=v.get("folder_path", ""),
                rack_types=v.get("rack_types", []),
                due_date=v.get("due_date") or None,
                estimated_hours=v.get("estimated_hours"),
                quote_value=v.get("quote_value"),
                # v1.4.0 item 15a: manual SDC override (None = Auto).
                seismic_override=v.get("seismic_override"),
                # V1.9.34: the dialog's own Contact Name / Sales Rep
                # / Waiting On fields (detail-window parity). The rep
                # falls back to the default (House Account rule) only
                # when the field was left blank.
                per=v.get("per", ""),
                sales_rep=v.get("sales_rep") or default_sales_rep(db),
                waiting_on=v.get("waiting_on", ""),
                revision=v.get("revision") or "00",
            )
            if v.get("remind_at"):
                db.set_remind_at(task_id, v["remind_at"])
            db.log_activity(task_id, "create",
                            f"Task created (quote # {v['quote_number'] or '—'})")
            _commit_staged_attachments(db, task_id, dialog)
            if on_created is not None:
                on_created(task_id, v, dialog)
            # Automatic quote folder creation (never blocks): the flow runs
            # off the UI thread and on_settled fires when it settles.
            # NOTE: this runs after dialog.exec() returned, so the dialog
            # itself is already hidden — isVisible() would ALWAYS be False
            # here. isVisibleTo(dialog) checks only the widget's own
            # explicit-visible flag (set at construction from the master
            # toggle), which is the correct gate.
            folder_box = getattr(dialog, "create_folder_box", None)
            if (folder_box is not None and folder_box.isVisibleTo(dialog)
                    and folder_box.isChecked()):
                task = db.get_task(task_id)
                if task:
                    begin_quote_folder_flow(
                        db, task, interactive=True, parent=parent,
                        on_done=lambda _path: on_settled() if on_settled else None)
            # The new card appears in the list; the detail window opens only
            # when the user clicks the card.
            return task_id
        # Duplicate quote number: prompt instead of silently doubling up.
        choice = app_choose(
            parent, "Duplicate quote number",
            f"A task with quote # {v['quote_number']} already exists.\n"
            "Rename this one, or open the existing task instead?",
            [("Rename", "primary"), ("Open existing task", "ghost"),
             ("Cancel", "ghost")])
        if choice == "Open existing task":
            if open_existing is not None:
                open_existing(existing)
            return None
        if choice == "Rename":
            dialog.quote_edit.setFocus()
            dialog.quote_edit.selectAll()
            continue
        return None
    return None


# ------------------------------------------------------------ settings dialog
class _BareIconButton(QPushButton):
    """Icon button with NO box (V1.9.40, user): the glyph alone at
    rest, brightening on hover. `hover_outline` adds the faint
    rectangle silhouette on hover only (the "+" add button). The
    colors are baked into the SVG icons, so hover swaps the icon.
    """

    def __init__(self, icon_name, rest_color, hover_color, size=16,
                 hover_outline=False, parent=None):
        super().__init__(parent)
        self._icon_name = icon_name
        self._rest_color = rest_color
        self._hover_color = hover_color
        self._icon_size = size
        self._hover_outline = hover_outline
        self.setCursor(Qt.PointingHandCursor)
        self._paint(False)

    def _paint(self, hovered):
        self.setIcon(svg_icon(
            self._icon_name,
            self._hover_color if hovered else self._rest_color,
            self._icon_size))
        if self._hover_outline:
            dark = saved_theme() != "light"
            line = ("rgba(255, 255, 255, 0.35)" if dark
                    else "rgba(0, 0, 0, 0.30)")
            fill = ("rgba(255, 255, 255, 0.07)" if dark
                    else "rgba(0, 0, 0, 0.05)")
            self.setStyleSheet(
                "QPushButton { background: " + (
                    fill if hovered else "transparent")
                + "; border: 1px solid " + (
                    line if hovered else "transparent")
                + "; border-radius: 6px; }")
        else:
            self.setStyleSheet(
                "QPushButton { background: transparent;"
                " border: 1px solid transparent; }")

    def enterEvent(self, event):
        self._paint(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._paint(False)
        super().leaveEvent(event)


class _OptionListEditor(QFrame):
    """Editable option list (Scope of Work or Rack Types) used by Settings."""

    changed = Signal()

    def __init__(self, title, hint, get_options, set_options, parent=None,
                 on_rename=None):
        super().__init__(parent)
        self._get = get_options
        self._set = set_options
        # V1.9.51: optional cascade for renames -- Settings passes
        # a callback that rewrites the old name on every task.
        self._on_rename = on_rename

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # V1.9.18 (user order): no "Rename selected"/"Remove selected"
        # buttons and no "New ..." bar + Add button. Each row carries
        # its own pencil (rename) and trash (remove) icons at the right
        # end, and a "+" button at the right end of the title row opens
        # an inline editor row inside the list for adding. The list
        # itself never scrolls — it grows to its content and the
        # settings page scrolls as one longer page, so there is no
        # second scrollbar touching the selections and nothing crammed.
        head_row = QHBoxLayout()
        # V1.9.40: right margin 4 matches the row layout's, so the
        # "+" sits directly above the trash column (it was shifted
        # right by those 4px before). The button itself is bare now
        # (gray plus, no blue box) and only gains its outline +
        # white plus on hover.
        head_row.setContentsMargins(0, 0, 4, 0)
        head_row.setSpacing(6)
        lab = QLabel(title)
        lab.setObjectName("sectionLabel")
        head_row.addWidget(lab)
        head_row.addStretch(1)
        _dark = saved_theme() != "light"
        add_btn = _BareIconButton(
            "plus", "#a6a6a6" if _dark else "#6e6e73",
            "#ffffff" if _dark else "#111318", 15, hover_outline=True)
        add_btn.setToolTip(f"Add {title.lower()}")
        add_btn.setFixedSize(28, 28)
        add_btn.clicked.connect(self._start_add)
        head_row.addWidget(add_btn)
        layout.addLayout(head_row)
        hint_lab = QLabel(hint)
        hint_lab.setObjectName("hint")
        hint_lab.setWordWrap(True)
        layout.addWidget(hint_lab)

        self._title = title
        self._row_h = 30
        self._editor_item = None
        self._editor_edit = None
        self._editor_mode = None
        self._editor_old = None
        self.list = QListWidget()
        self.list.setObjectName("optionList")
        self.list.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        layout.addWidget(self.list)

        self._refresh_list()

    def _refresh_list(self):
        self._editor_item = None
        self._editor_edit = None
        self._editor_mode = None
        self._editor_old = None
        self.list.clear()
        for option in self._get():
            item = QListWidgetItem()
            item.setSizeHint(QSize(0, self._row_h))
            self.list.addItem(item)
            self.list.setItemWidget(item, self._make_row_widget(option))
        self._sync_list_height()

    def _sync_list_height(self):
        # Sum the real item heights: the open editor row is taller
        # than a display row (see _make_editor_widget).
        total = sum(self.list.item(i).sizeHint().height()
                    for i in range(self.list.count()))
        self.list.setFixedHeight(total + 2)

    def _make_row_widget(self, name):
        w = QWidget()
        # V1.9.20: the row label needs a stylesheet address. It used to
        # be a plain QLabel, which paints palette black — invisible on
        # the dark theme (the list's own color never reaches item
        # widgets). The optionRow rule in themes.py carries the color
        # per theme, so it follows live theme switches.
        w.setObjectName("optionRow")
        w.setProperty("option_name", name)
        lay = QHBoxLayout(w)
        lay.setContentsMargins(8, 0, 4, 0)
        # V1.9.21: same look (ghost buttons, gray pencil, red trash),
        # made legible — 13px glyphs in 26px buttons with a 4px gap
        # read as faint and cramped, and at chat-display scale looked
        # overlapping. 16px glyphs, 28px buttons, 8px gap; pencil gray
        # is now true neutral, not blue-toned.
        # V1.9.22: the widget MUST be fixed-height. QListWidget assigns
        # item widgets a 16px height (its own layout pass ignores the
        # 28px sizeHint; only adjustSize() restores it), and Qt clips
        # the 28px buttons to their 16px parent — pencil tips and
        # trash bases never drew, in every version. Fixed height is
        # the lever the view cannot override; 28 fits the 30px item
        # with 1px top/bottom.
        w.setFixedHeight(30)
        lay.setSpacing(8)
        lab = QLabel(name)
        lay.addWidget(lab, 1)
        _dark = saved_theme() != "light"
        pencil = _BareIconButton(
            "pencil", "#a6a6a6" if _dark else "#6e6e73",
            "#ffffff" if _dark else "#111318", 16)
        pencil.setToolTip("Rename")
        pencil.setFixedSize(28, 28)
        pencil.clicked.connect(lambda: self._start_rename(name))
        lay.addWidget(pencil)
        trash = _BareIconButton("trash", "#c25055", "#ff2d37", 16)
        trash.setToolTip("Remove")
        trash.setFixedSize(28, 28)
        trash.clicked.connect(lambda: self._on_remove_item(name))
        lay.addWidget(trash)
        return w

    def _make_editor_widget(self, initial, placeholder):
        w = QWidget()
        # V1.9.29 (user screenshot): the editor wrapper needs the same
        # fixed height as the display rows (V1.9.22) -- QListWidget
        # otherwise assigns it ~16px and the QLineEdit inside is
        # clipped to a thin unreadable sliver. The edit fills the
        # full 30px item height so its text sits at full size.
        # The editor row is TALLER than a display row (42px item):
        # the app QSS gives QLineEdit 8px vertical padding, so a
        # readable field needs ~38px -- a 30px row clips it no matter
        # what (that was the sliver in the screenshot).
        w.setFixedHeight(42)
        lay = QHBoxLayout(w)
        lay.setContentsMargins(8, 0, 4, 0)
        lay.setSpacing(0)
        edit = QLineEdit()
        edit.setFixedHeight(38)
        edit.setText(initial)
        edit.setPlaceholderText(placeholder)
        edit.returnPressed.connect(self._commit_editor)
        edit.editingFinished.connect(self._editor_finished)
        edit.installEventFilter(self)
        lay.addWidget(edit, 1)
        return w, edit

    def eventFilter(self, obj, event):
        if (obj is self._editor_edit
                and event.type() == QEvent.KeyPress
                and event.key() == Qt.Key_Escape):
            self._cancel_editor()
            return True
        return super().eventFilter(obj, event)

    def _start_add(self):
        if self._editor_item is not None:
            if self._editor_edit is not None:
                self._editor_edit.setFocus()
            return
        item = QListWidgetItem()
        item.setSizeHint(QSize(0, 42))  # editor row height
        self.list.addItem(item)
        widget, edit = self._make_editor_widget(
            "", f"New {self._title.lower()}...")
        self.list.setItemWidget(item, widget)
        self._editor_item = item
        self._editor_edit = edit
        self._editor_mode = "add"
        self._editor_old = None
        self._sync_list_height()
        edit.setFocus()

    def _start_rename(self, name):
        if self._editor_item is not None:
            self._cancel_editor()
        for row in range(self.list.count()):
            item = self.list.item(row)
            widget = self.list.itemWidget(item)
            if widget is not None and widget.property("option_name") == name:
                item.setSizeHint(QSize(0, 42))  # editor row height
                editor, edit = self._make_editor_widget(name, "")
                self.list.setItemWidget(item, editor)
                self._editor_item = item
                self._editor_edit = edit
                self._editor_mode = "rename"
                self._editor_old = name
                self._sync_list_height()
                edit.selectAll()
                edit.setFocus()
                return

    def _cancel_editor(self):
        # Refresh rebuilds rows from the stored list; an uncommitted
        # editor row simply disappears.
        self._refresh_list()

    def _editor_finished(self):
        # Enter already committed (and cleared the editor refs) before
        # editingFinished fires, so this only runs on focus loss.
        # V1.9.29 (user report: the editor "got stuck and didn't go
        # away after clicking off or clicking enter"): the old rule
        # kept any non-empty abandoned row open indefinitely. Focus
        # loss now SETTLES the editor like every standard inline
        # editor: a changed, non-duplicate name commits; an empty,
        # unchanged, or duplicate name closes silently (the toast
        # for a duplicate belongs to an explicit Enter, not to a
        # click-away that would trap the row open).
        edit = self._editor_edit
        if edit is None:
            return
        name = edit.text().strip()
        if (not name or name == (self._editor_old or "")
                or self._duplicate(name, ignore=self._editor_old)):
            self._cancel_editor()
            return
        self._commit_editor()

    def _commit_editor(self):
        edit = self._editor_edit
        if edit is None:
            return
        name = edit.text().strip()
        if self._editor_mode == "rename":
            old = self._editor_old
            if not name or name == old:
                self._cancel_editor()
                return
            if self._duplicate(name, ignore=old):
                show_toast(self, "warning", "Duplicate entry",
                           f"'{name}' is already in the list.")
                return
            self._set([name if o == old else o for o in self._get()])
            if self._on_rename is not None:
                try:
                    self._on_rename(old, name)
                except Exception:
                    pass
        else:
            if not name:
                self._cancel_editor()
                return
            if self._duplicate(name):
                show_toast(self, "warning", "Duplicate entry",
                           f"'{name}' is already in the list.")
                return
            self._set(self._get() + [name])
        self._refresh_list()
        self.changed.emit()

    def _duplicate(self, name, ignore=None):
        return any(o.lower() == name.lower() and o != ignore for o in self._get())

    def _on_remove_item(self, name):
        if not app_confirm(
            self, "Remove entry",
            f"Remove '{name}' from the list?\n\n"
            "Existing tasks that use it will keep it.",
            confirm_label="Remove", danger=True):
            return
        self._set([o for o in self._get() if o != name])
        self._refresh_list()
        self.changed.emit()


class ThemedStepper(QWidget):
    """Themed - / + stepper: a QSpinBox API without the native arrows.

    The generic native up/down arrows clash with the dark UI, so numeric
    settings (queue-column WIP limits, stale-quote days) use two small
    themed buttons around a value readout instead. value()/setValue()/
    setRange()/setSuffix() mirror QSpinBox so call sites are unchanged.
    """

    valueChanged = Signal(int)

    def __init__(self, minimum=0, maximum=999, value=0, suffix="",
                 parent=None):
        super().__init__(parent)
        self._min = minimum
        self._max = maximum
        self._value = value
        self._suffix = suffix

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self._minus = QPushButton("\u2212")
        self._minus.setObjectName("stepperBtn")
        self._minus.setCursor(Qt.PointingHandCursor)
        self._minus.setFocusPolicy(Qt.NoFocus)
        self._minus.setFixedSize(30, 30)
        self._minus.clicked.connect(lambda: self._step(-1))
        layout.addWidget(self._minus)

        self._label = QLabel()
        self._label.setObjectName("stepperValue")
        self._label.setAlignment(Qt.AlignCenter)
        # V1.9.18 (user report): the value box was 70px wide — room for
        # ~5 characters. WIP limits fit 2, so size it for exactly that
        # (font-measured, plus the QSS padding/border). A minimum, not
        # a fixed width: a 3-digit value still grows instead of
        # clipping.
        self._label.setMinimumWidth(
            self._label.fontMetrics().horizontalAdvance("MM") + 22)
        layout.addWidget(self._label)

        self._plus = QPushButton("+")
        self._plus.setObjectName("stepperBtn")
        self._plus.setCursor(Qt.PointingHandCursor)
        self._plus.setFocusPolicy(Qt.NoFocus)
        self._plus.setFixedSize(30, 30)
        self._plus.clicked.connect(lambda: self._step(1))
        layout.addWidget(self._plus)

        self._render()

    def _step(self, delta):
        self.setValue(self._value + delta)

    def _render(self):
        self._label.setText(f"{self._value}{self._suffix}")
        self._minus.setEnabled(self._value > self._min)
        self._plus.setEnabled(self._value < self._max)

    def value(self):
        return self._value

    def setValue(self, value):
        try:
            value = int(value)
        except (TypeError, ValueError):
            return
        value = max(self._min, min(self._max, value))
        if value != self._value:
            self._value = value
            self._render()
            self.valueChanged.emit(value)

    def setRange(self, minimum, maximum):
        self._min, self._max = minimum, maximum
        self.setValue(self._value)
        self._render()

    def setSuffix(self, suffix):
        self._suffix = suffix
        self._render()


# V1.9.51 TRIAL (user: "let me try the settings glassed up like
# this dropdown... make sure you remember how the settings looks
# now before glass though, as I might want to change it back"):
# the pre-glass look is recorded in MEMORY.md (his image-440
# screenshot; the shipped opaque dialog), and reverting is
# flipping this ONE flag to False -- the opaque frame stylesheet
# and layout are untouched.
SETTINGS_GLASS_TRIAL = False


class _SettingsFrostFilter(QObject):
    """Paints the approved frost recipe behind the Settings
    window's chrome frame (the same construction as the combo
    dropdowns the user defined as THE frosted glass standard:
    app-painted blurred snapshot + tint alpha 140 + rim on an
    inset path + the frame's own 12px radius). Runs as a filter
    so the frame paints its (now transparent) QSS background and
    its children over the frost."""

    def __init__(self, frame):
        super().__init__(frame)
        self._frame = frame
        # V1.9.52 (user, on the 1.9.51 trial: the glass "snaps a
        # blurred image of whats behind it... when i move the
        # window around it does not look like glass and more
        # looks like something frozen behind the window"):
        # capture() runs once at show; MOVES are tracked live
        # via capture_live() (the dialog's host window re-render,
        # throttled), so the frost follows the window instead of
        # freezing the spot where it opened.
        self._dialog = None
        self._last_live = 0.0
        self._trail = QTimer(self)
        self._trail.setSingleShot(True)
        self._trail.setInterval(70)
        self._trail.timeout.connect(self.capture_live)

    def watch_dialog(self, dlg):
        """Track a dialog's moves/resizes for live frost."""
        self._dialog = dlg
        dlg.installEventFilter(self)

    def _on_moved(self):
        now = time.monotonic()
        if now - self._last_live >= 0.12:
            self.capture_live()
        elif not self._trail.isActive():
            self._trail.start()

    def capture_live(self):
        """Rebuild the frost from the host window's CURRENT
        rendering (a widget grab -- never includes this dialog,
        so no self-feedback), composited over the previous
        frost for any part of the dialog hanging off the host.
        Skips when the dialog barely overlaps its host (the
        show-time snapshot stays the honest fallback)."""
        dlg = self._dialog
        frame = self._frame
        if dlg is None:
            return
        self._last_live = time.monotonic()
        try:
            host = dlg.parent()
            hostw = (host.window()
                     if isinstance(host, QWidget) else None)
            if hostw is None or hostw is dlg or not hostw.isVisible():
                return
            grect = QRect(frame.mapToGlobal(QPoint(0, 0)),
                          frame.size())
            hrect = QRect(hostw.mapToGlobal(QPoint(0, 0)),
                          hostw.size())
            overlap = grect.intersected(hrect)
            if (overlap.width() * overlap.height()
                    < 0.45 * grect.width() * grect.height()):
                return
            shot = hostw.grab()
            if shot.isNull():
                return
            dpr = shot.devicePixelRatio() or 1.0
            src = QRect(
                QPoint(int((overlap.x() - hrect.x()) * dpr),
                       int((overlap.y() - hrect.y()) * dpr)),
                QSize(int(overlap.width() * dpr),
                      int(overlap.height() * dpr)))
            img = QImage(grect.size(),
                         QImage.Format_ARGB32_Premultiplied)
            img.fill(QColor("#101114"))
            painter = QPainter(img)
            old = getattr(frame, "_frost_pixmap", None)
            if old is not None:
                painter.drawPixmap(img.rect(), old)
            painter.drawPixmap(
                QRect(overlap.topLeft() - grect.topLeft(),
                      overlap.size()), shot, src)
            painter.end()
            frame._frost_pixmap = QPixmap.fromImage(
                _blur_image(img))
            frame.update()
        except Exception:
            pass

    def capture(self):
        frame = self._frame
        try:
            rect = QRect(frame.mapToGlobal(QPoint(0, 0)), frame.size())
            screen = frame.screen() or QApplication.primaryScreen()
            if screen is None or rect.width() < 2:
                return
            shot = _grab_screen(screen, rect)
            if shot is None or shot.isNull():
                return
            raw = shot.toImage()
            peak = 0
            for gx in range(8):
                for gy in range(8):
                    c = raw.pixelColor(int(raw.width() * (gx + 0.5) / 8),
                                       int(raw.height() * (gy + 0.5) / 8))
                    peak = max(peak, c.red(), c.green(), c.blue())
            if peak <= 2:
                frame._frost_pixmap = None
                return
            pm = QPixmap.fromImage(_blur_image(raw))
            pm.setDevicePixelRatio(shot.devicePixelRatio())
            frame._frost_pixmap = pm
        except Exception:
            pass

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        if (obj is self._dialog
                and event.type() in (QEvent.Move, QEvent.Resize)):
            self._on_moved()
            return False
        if obj is self._frame and event.type() == QEvent.Paint:
            try:
                # The combo dropdown's recipe, verbatim, at the
                # window frame's 12px radius (see _GlassComboPopup).
                frame = self._frame
                p = QPainter(frame)
                p.setRenderHint(QPainter.Antialiasing, True)
                fill, rim = glass_colors()
                fill = QColor(fill)
                if paint_frost(frame, p, 12):
                    fill.setAlpha(140)
                else:
                    fill.setAlpha(150)
                path = QPainterPath()
                path.addRoundedRect(QRectF(frame.rect()), 12, 12)
                p.setPen(Qt.NoPen)
                p.setBrush(fill)
                p.drawPath(path)
                rim_path = QPainterPath()
                rim_path.addRoundedRect(
                    QRectF(frame.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
                    11.5, 11.5)
                p.setPen(QPen(rim, 1))
                p.setBrush(Qt.NoBrush)
                p.drawPath(rim_path)
                p.end()
            except Exception:
                pass
        return False


class SettingsDialog(QDialog):
    """File > Settings - manages the Scope of Work and Rack Type option lists."""

    scopes_changed = Signal()
    rack_types_changed = Signal()
    sales_reps_changed = Signal()
    # V1.9.29: emitted the moment the theme/accent changes INSIDE
    # Settings, so the main window re-themes its painted surfaces
    # live -- the old flow only synced after the dialog closed, so
    # switching to Light left the dashboard and task table black
    # behind the still-open dialog (user screenshot).
    theme_changed = Signal()
    queue_changed = Signal()
    # V1.9.30: emitted when an update has been downloaded and
    # staged; the main window offers the restart that applies it.
    update_ready = Signal(str)
    _upd_status = Signal(str)
    # V1.9.52: the folder-cache size total, computed off-thread.
    _cache_size_ready = Signal(str)
    _sync_done = Signal()
    _upd_done = Signal()

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Settings")
        self.setModal(True)
        # v1.4.0 item 16: sidebar-navigated sections. One topic per page
        # keeps every section compact and the dialog laptop-safe no matter
        # how many options accumulate; each page scrolls internally.
        self.setMinimumSize(900, 600)

        layout = install_chrome(self, "Settings")

        # V1.9.51 frosted glass TRIAL (see SETTINGS_GLASS_TRIAL):
        # the chrome frame's fill goes transparent and the frost
        # filter paints the glass behind everything. The frame
        # keeps its border via the instance sheet.
        self._settings_frost = None
        if SETTINGS_GLASS_TRIAL:
            try:
                _frame = self._chrome["frame"]
                _border = ("#d9dbde" if saved_theme() == "light"
                           else "#26282f")
                _frame.setStyleSheet(
                    "QFrame#windowFrame { background: transparent; "
                    f"border: 1px solid {_border}; "
                    "border-radius: 12px; }")
                self._settings_frost = _SettingsFrostFilter(_frame)
                _frame.installEventFilter(self._settings_frost)
                self._settings_frost.watch_dialog(self)
            except Exception:
                self._settings_frost = None

        # Set by ensure_folder_section_visible(): switches to the Folders
        # page and scrolls it to the Folder Creation section on show.
        self._pending_folder_scroll = False

        title = QLabel("Settings")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)

        def section_container():
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(12, 12, 12, 12)
            l.setSpacing(8)
            return w, l

        def _page(content):
            """Wrap a section's content widget in a scrolling page."""
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            scroll.setFrameShape(QFrame.NoFrame)
            scroll.setWidget(content)
            enable_touch_scroll(scroll)
            return scroll

        # ---------------- Scopes & Racks page ----------------
        scopes_w, scopes_l = section_container()
        scopes_head = QLabel("OPTION LISTS")
        scopes_head.setObjectName("sectionLabel")
        scopes_l.addWidget(scopes_head)
        scope_editor = _OptionListEditor(
            "SCOPE OF WORK",
            "These options populate the Scope of Work dropdown on every task. "
            "Add your own, or remove any you don't need - existing tasks keep "
            "whatever they already have.",
            self.db.get_scopes,
            self.db.set_scopes,
            on_rename=lambda old, new: self.db.rename_task_option(
                "scope", old, new),
        )
        scope_editor.changed.connect(self.scopes_changed.emit)
        scopes_l.addWidget(scope_editor)

        # V1.9.29 (user screenshot): the two option-list sections ran
        # together -- real breathing room between the last scope row
        # and the RACK TYPES title.
        scopes_l.addSpacing(26)

        rack_editor = _OptionListEditor(
            "RACK TYPES",
            "These options populate the Rack Type dropdown on every task, shown "
            "above the Distributor field. Add your own, or remove any you don't "
            "need - existing tasks keep whatever they already have.",
            self.db.get_rack_types,
            self.db.set_rack_types,
            on_rename=lambda old, new: self.db.rename_task_option(
                "rack_types", old, new),
        )
        rack_editor.changed.connect(self.rack_types_changed.emit)
        scopes_l.addWidget(rack_editor)

        # V1.9.39 (user): no SALES REPS editor here — reps are the
        # CRM's Sales Rep directory entries and are added/adjusted
        # in the CRM module; a second editing surface for the same
        # list only invites drift.
        scopes_l.addStretch(1)

        # ---------------- General page ----------------
        general_w, small_l = section_container()
        # V1.9.47 (user: the whole page can shift up slightly --
        # it missed fitting by ~36px and grew a scrollbar for
        # nothing): the page shifts UP as a whole (container
        # margins 12 -> 2 top/bottom) and the row rhythm tightens
        # (spacing 8 -> 6); the sub-section gaps keep the full
        # V1.9.38 air (16 -- GENERAL must never sit on APPEARANCE
        # again). Same look, no scroll.
        small_l.setContentsMargins(12, 2, 12, 2)
        small_l.setSpacing(6)
        general_head = QLabel("GENERAL")
        general_head.setObjectName("sectionLabel")
        small_l.addWidget(general_head)

        # V1.9.38 (user): GENERAL sat directly on top of APPEARANCE
        # -- two headers 8px apart, nothing between, read as one
        # crammed block. Sub-section headers on this page now all
        # breathe with the same gap.
        small_l.addSpacing(16)

        # ---- appearance: font family + size ----
        appear_lab = QLabel("APPEARANCE")
        appear_lab.setObjectName("sectionLabel")
        small_l.addWidget(appear_lab)
        frow = QHBoxLayout()
        frow.setContentsMargins(0, 0, 0, 0)
        frow.setSpacing(8)
        flab = QLabel("Font")
        flab.setMinimumWidth(110)
        frow.addWidget(flab)
        self._font_combo = SafeFontComboBox()
        self._font_combo.setObjectName("sortBox")
        self._font_combo.insertItem(0, "Inter (Default)")
        cur_family = saved_font_family()
        if cur_family:
            idx = self._font_combo.findText(cur_family)
            self._font_combo.setCurrentIndex(idx if idx >= 0 else 0)
        else:
            self._font_combo.setCurrentIndex(0)
        self._font_combo.setToolTip(
            "Interface font. Inter (Default) is the bundled font.")
        self._font_combo.currentIndexChanged.connect(
            self._apply_font_prefs)
        frow.addWidget(self._font_combo, 1)
        small_l.addLayout(frow)
        srow = QHBoxLayout()
        srow.setContentsMargins(0, 0, 0, 0)
        srow.setSpacing(8)
        slab = QLabel("Text size")
        slab.setMinimumWidth(110)
        srow.addWidget(slab)
        self._font_size_combo = SafeComboBox()
        self._font_size_combo.setObjectName("sortBox")
        for label, scale in (("Smaller (90%)", 0.9),
                             ("Default (100%)", 1.0),
                             ("Larger (110%)", 1.1),
                             ("Extra large (125%)", 1.25)):
            self._font_size_combo.addItem(label, scale)
        cur_scale = saved_font_scale()
        best = min(range(self._font_size_combo.count()),
                   key=lambda i: abs(self._font_size_combo.itemData(i)
                                     - cur_scale))
        self._font_size_combo.setCurrentIndex(best)
        self._font_size_combo.setToolTip(
            "Scales all interface text. Applies immediately.")
        self._font_size_combo.currentIndexChanged.connect(
            self._apply_font_prefs)
        srow.addWidget(self._font_size_combo, 1)
        small_l.addLayout(srow)

        # ---- appearance: theme (dark/light) + accent colour ----
        trow = QHBoxLayout()
        trow.setContentsMargins(0, 0, 0, 0)
        trow.setSpacing(8)
        tlab = QLabel("Theme")
        tlab.setMinimumWidth(110)
        trow.addWidget(tlab)
        # V1.9.29 (user: "this was and should be a toggle switch with
        # motion/animation -- don't know why it was changed"): the
        # Dark/Light button pair is replaced by the app's animated
        # ToggleSwitch (sliding knob, same widget as the toolbar's
        # Has-attachments switch). On = Dark; the state label beside
        # it names the current theme so the switch is never ambiguous.
        self._theme_switch = ToggleSwitch()
        self._theme_switch.setToolTip("Toggle dark / light theme")
        self._theme_switch.toggled.connect(
            lambda on: self._apply_theme_choice(
                "dark" if on else "light"))
        trow.addWidget(self._theme_switch)
        self._theme_state = QLabel("Dark")
        trow.addWidget(self._theme_state)
        trow.addStretch(1)
        small_l.addLayout(trow)

        # V1.9.25: glass dropdowns are the standard look now (user
        # standing order — the V1.9.17 toggle is retired, no switch).
        arow = QHBoxLayout()
        arow.setContentsMargins(0, 0, 0, 0)
        arow.setSpacing(8)
        alab = QLabel("Accent color")
        alab.setMinimumWidth(110)
        arow.addWidget(alab)
        self._accent_swatches = []
        for name, hexv in (("Blue", "#2f6fed"), ("Sky", "#0ea5e9"),
                           ("Teal", "#14b8a6"), ("Green", "#22c55e"),
                           ("Amber", "#f59e0b"), ("Orange", "#f97316"),
                           ("Red", "#ef4444"), ("Violet", "#8b5cf6"),
                           ("Pink", "#ec4899")):
            b = AccentSwatch(hexv)
            b.setToolTip(f"{name} ({hexv})")
            b.clicked.connect(
                lambda _=False, h=hexv: self._apply_accent_choice(h))
            self._accent_swatches.append((b, hexv))
            arow.addWidget(b)
        custom_btn = QPushButton("Custom…")
        custom_btn.setObjectName("ghost")
        custom_btn.setCursor(Qt.PointingHandCursor)
        custom_btn.clicked.connect(self._pick_custom_accent)
        arow.addWidget(custom_btn)
        arow.addStretch(1)
        small_l.addLayout(arow)
        self._sync_appearance_controls()

        small_l.addSpacing(16)

        # ---- quote price prompt ----
        price_lab = QLabel("COMPLETION")
        price_lab.setObjectName("sectionLabel")
        small_l.addWidget(price_lab)
        self._price_box = QCheckBox(
            "Ask for quote price when completing a task")
        self._price_box.setObjectName("settingsCheck")
        self._price_box.setChecked(
            self.db.get_setting("ask_price_on_complete", "1") == "1")
        small_l.addWidget(self._price_box)

        small_l.addSpacing(16)

        # ---- stale quotes ----
        stale_lab = QLabel("STALE QUOTES")
        stale_lab.setObjectName("sectionLabel")
        small_l.addWidget(stale_lab)
        stale_row = QHBoxLayout()
        stale_row.setContentsMargins(0, 0, 0, 0)
        stale_lead = QLabel("Flag quotes untouched for")
        stale_row.addWidget(stale_lead)
        try:
            stale_val = int(self.db.get_setting("stale_days", "30"))
        except (TypeError, ValueError):
            stale_val = 30
        self._stale_spin = ThemedStepper(
            minimum=1, maximum=365, value=stale_val, suffix=" days")
        stale_row.addWidget(self._stale_spin)
        stale_row.addStretch(1)
        small_l.addLayout(stale_row)

        small_l.addSpacing(16)

        # ---- updates (V1.9.30, user: the Drawing Finder template) --
        upd_lab = QLabel("UPDATES")
        upd_lab.setObjectName("sectionLabel")
        small_l.addWidget(upd_lab)
        self._upd_check_box = QCheckBox(
            "Check for updates on startup")
        self._upd_check_box.setObjectName("settingsCheck")
        self._upd_check_box.setChecked(updater.check_updates_enabled())
        self._upd_check_box.toggled.connect(
            updater.set_check_updates_enabled)
        small_l.addWidget(self._upd_check_box)
        upd_row = QHBoxLayout()
        upd_row.setContentsMargins(0, 0, 0, 0)
        upd_row.setSpacing(8)
        self._upd_btn = QPushButton("Check for updates")
        self._upd_btn.setObjectName("ghost")
        self._upd_btn.setCursor(Qt.PointingHandCursor)
        self._upd_btn.clicked.connect(self._on_check_updates_clicked)
        upd_row.addWidget(self._upd_btn)
        self._upd_status_label = QLabel(
            f"Version {updater.current_version()}")
        self._upd_status_label.setObjectName("hint")
        self._upd_status_label.setWordWrap(True)
        upd_row.addWidget(self._upd_status_label, 1)
        small_l.addLayout(upd_row)
        self._upd_status.connect(self._upd_status_label.setText)
        self._upd_done.connect(
            lambda: self._upd_btn.setEnabled(True))
        small_l.addStretch(1)

        # ---------------- right column: folders + queue ----------------
        folder_w, folder_l = section_container()

        # ---- folder creation ----
        folder_lab = QLabel("FOLDER CREATION")
        folder_lab.setObjectName("sectionLabel")
        folder_l.addWidget(folder_lab)
        self._folder_master = QCheckBox(
            "Enable automatic quote folder creation")
        self._folder_master.setObjectName("settingsCheck")
        self._folder_master.setChecked(folder_creation_enabled(self.db))
        self._folder_master.toggled.connect(self._refresh_folder_section)
        folder_l.addWidget(self._folder_master)

        self._folder_rows = []  # widgets enabled only when the master is on
        for key, label_text in (
            ("folder_template_dir", "Template folder"),
            ("folder_dest_dir", "Destination folder"),
        ):
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(8)
            lab = QLabel(label_text)
            lab.setMinimumWidth(110)
            row.addWidget(lab)
            edit = QLineEdit()
            edit.setText(self.db.get_setting(key, ""))
            edit.textChanged.connect(self._refresh_folder_section)
            row.addWidget(edit, 1)
            browse = QPushButton("Browse…")
            browse.setCursor(Qt.PointingHandCursor)
            browse.clicked.connect(
                lambda _=False, e=edit: self._browse_folder_dir(e))
            row.addWidget(browse)
            folder_l.addLayout(row)
            self._folder_rows.append((lab, edit, browse))
            if key == "folder_template_dir":
                self._folder_template_edit = edit
            else:
                self._folder_dest_edit = edit

        irow = QHBoxLayout()
        irow.setContentsMargins(0, 0, 0, 0)
        irow.setSpacing(8)
        ilab = QLabel("Your initials")
        ilab.setMinimumWidth(110)
        irow.addWidget(ilab)
        self._folder_initials_edit = QLineEdit()
        self._folder_initials_edit.setText(
            self.db.get_setting("folder_initials", ""))
        self._folder_initials_edit.setPlaceholderText("e.g. ABC")
        self._folder_initials_edit.setMaximumWidth(110)
        irow.addWidget(self._folder_initials_edit)
        irow.addStretch(1)
        folder_l.addLayout(irow)
        self._folder_rows.append((ilab, self._folder_initials_edit, None))

        self._folder_hint = QLabel()
        self._folder_hint.setObjectName("folderHint")
        self._folder_hint.setWordWrap(True)
        self._folder_hint.setVisible(False)
        folder_l.addWidget(self._folder_hint)

        # ---- verify setup: read-only diagnostic (v1.2.4) ----
        vrow = QHBoxLayout()
        vrow.setContentsMargins(0, 0, 0, 0)
        vrow.setSpacing(8)
        self._folder_verify_btn = QPushButton("Verify setup")
        self._folder_verify_btn.setCursor(Qt.PointingHandCursor)
        self._folder_verify_btn.clicked.connect(self._on_verify_setup)
        vrow.addWidget(self._folder_verify_btn)
        vrow.addStretch(1)
        folder_l.addLayout(vrow)
        # Per-item pass/fail checklist, rendered inline (never a popup).
        # Re-running replaces the previous results.
        self._verify_box = QWidget()
        _verify_lay = QVBoxLayout(self._verify_box)
        _verify_lay.setContentsMargins(0, 2, 0, 0)
        _verify_lay.setSpacing(2)
        self._verify_box.setVisible(False)
        folder_l.addWidget(self._verify_box)

        qrow = QHBoxLayout()
        qrow.setContentsMargins(0, 0, 0, 0)
        qrow.setSpacing(8)
        self._folder_pending_label = QLabel()
        self._folder_pending_label.setObjectName("hint")
        self._folder_pending_label.setWordWrap(True)
        qrow.addWidget(self._folder_pending_label, 1)
        self._folder_retry_btn = QPushButton("Retry now")
        self._folder_retry_btn.setCursor(Qt.PointingHandCursor)
        self._folder_retry_btn.clicked.connect(self._on_retry_folders)
        qrow.addWidget(self._folder_retry_btn)
        folder_l.addLayout(qrow)
        self._refresh_folder_section()
        folder_l.addStretch(1)

        # ---- queue columns ----
        queue_w, queue_l = section_container()
        queue_lab = QLabel("QUEUE COLUMNS")
        queue_lab.setObjectName("sectionLabel")
        queue_l.addWidget(queue_lab)
        queue_hint = QLabel(
            "Rename the queue board columns and set WIP limits (0 = no limit).")
        queue_hint.setObjectName("hint")
        queue_hint.setWordWrap(True)
        queue_l.addWidget(queue_hint)
        try:
            wip = self.db.get_queue_wip()
        except Exception:
            wip = {}
        self._queue_rows = []  # (key, QLineEdit, ThemedStepper)
        for key, label in queue_columns_normalized(self.db):
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(8)
            name_edit = QLineEdit(label)
            name_edit.setPlaceholderText("Column name")
            row.addWidget(name_edit, 1)
            wip_lab = QLabel("WIP")
            wip_lab.setObjectName("hint")
            row.addWidget(wip_lab)
            try:
                wip_val = int(wip.get(key, 0))
            except (TypeError, ValueError):
                wip_val = 0
            wip_stepper = ThemedStepper(minimum=0, maximum=999,
                                        value=wip_val)
            row.addWidget(wip_stepper)
            queue_l.addLayout(row)
            self._queue_rows.append((key, name_edit, wip_stepper))
        # V1.9.17: the "Waiting-state column" row is gone (user order).
        # Its queue-card chip was never implemented — only the tooltip
        # mentioned it — so the row did nothing visible. The detail
        # window's WAITING ON field itself stays (he said it can stay);
        # its stored enabled/column settings are left as-is, so the
        # field keeps showing when editing exactly as before.
        queue_l.addStretch(1)

        # ---- notifications page (v1.4.0 item 15b) ----
        notif_w, notif_l = section_container()
        notif_lab = QLabel("NOTIFICATIONS")
        notif_lab.setObjectName("sectionLabel")
        notif_l.addWidget(notif_lab)
        self._seismic_popup_check = QCheckBox("Seismic popup alerts")
        self._seismic_popup_check.setObjectName("settingsCheck")
        self._seismic_popup_check.setToolTip(
            "Show a popup when an end-user location estimates to "
            "Seismic Design Category B or worse")
        try:
            popup_on = self.db.get_setting("seismic_popup", "1") == "1"
        except Exception:
            popup_on = True
        self._seismic_popup_check.setChecked(popup_on)
        notif_l.addWidget(self._seismic_popup_check)
        popup_hint = QLabel(
            "When the end-user field commits with an estimated SDC of B or "
            "worse, the app shows a popup in addition to the inline badge "
            "(at most once per task).")
        popup_hint.setObjectName("hint")
        popup_hint.setWordWrap(True)
        notif_l.addWidget(popup_hint)
        # V1.9.52 (user): the building-code settings live in ONE
        # group with the seismic alerts above -- the IBC popup
        # toggle, the lead times the warning horizon uses, and
        # the code data's status. Nothing scattered.
        codes_lab = QLabel("BUILDING CODES")
        codes_lab.setObjectName("sectionLabel")
        codes_lab.setProperty("groupStart", True)
        notif_l.addWidget(codes_lab)
        self._ibc_popup_check = QCheckBox(
            "Building code popup alerts")
        self._ibc_popup_check.setObjectName("settingsCheck")
        self._ibc_popup_check.setToolTip(
            "Show a popup when a task opens whose building code "
            "changes during its lead time")
        try:
            ibc_on = self.db.get_setting("ibc_popup", "1") == "1"
        except Exception:
            ibc_on = True
        self._ibc_popup_check.setChecked(ibc_on)
        notif_l.addWidget(self._ibc_popup_check)
        ibc_hint = QLabel(
            "When a task's location has a verified building-code "
            "edition change inside the lead-time window below, a "
            "warning pops up on open (at most once per task) and "
            "the IBC chip in the SEISMIC section shows a warning "
            "marker.")
        ibc_hint.setObjectName("hint")
        ibc_hint.setWordWrap(True)
        notif_l.addWidget(ibc_hint)
        lead_row = QHBoxLayout()
        lead_row.setSpacing(8)
        lead_lab = QLabel("Typical lead time")
        lead_lab.setObjectName("hint")
        lead_row.addWidget(lead_lab)
        _lo, _hi = lead_time_settings(self.db)
        self._lead_min_stepper = ThemedStepper(
            minimum=1, maximum=104, value=_lo)
        self._lead_max_stepper = ThemedStepper(
            minimum=1, maximum=104, value=_hi)
        lead_row.addWidget(self._lead_min_stepper)
        lead_to = QLabel("to")
        lead_to.setObjectName("hint")
        lead_row.addWidget(lead_to)
        lead_row.addWidget(self._lead_max_stepper)
        lead_unit = QLabel("weeks")
        lead_unit.setObjectName("hint")
        lead_row.addWidget(lead_unit)
        lead_row.addStretch(1)
        notif_l.addLayout(lead_row)
        self._ibc_data_label = QLabel("")
        self._ibc_data_label.setObjectName("hint")
        self._ibc_data_label.setWordWrap(True)
        notif_l.addWidget(self._ibc_data_label)
        _ibc_btn_row = QHBoxLayout()
        self._ibc_check_btn = QPushButton(
            "Check for code updates")
        self._ibc_check_btn.setObjectName("ghost")
        self._ibc_check_btn.setCursor(Qt.PointingHandCursor)
        self._ibc_check_btn.clicked.connect(
            self._on_ibc_check_now)
        _ibc_btn_row.addWidget(self._ibc_check_btn)
        _ibc_btn_row.addStretch(1)
        notif_l.addLayout(_ibc_btn_row)
        self._refresh_ibc_data_label()
        notif_l.addStretch(1)

        # ---------------- Offline page (V1.9.50) ----------------
        offline_w, off_l = section_container()
        off_head = QLabel("DATA LOCATION")
        off_head.setObjectName("sectionLabel")
        off_l.addWidget(off_head)
        self._off_location = QLabel("")
        self._off_location.setObjectName("hint")
        self._off_location.setWordWrap(True)
        off_l.addWidget(self._off_location)
        _move_row = QHBoxLayout()
        self._off_move_btn = QPushButton("Move data folder…")
        self._off_move_btn.setObjectName("ghost")
        self._off_move_btn.setCursor(Qt.PointingHandCursor)
        self._off_move_btn.clicked.connect(self._move_data_folder)
        _move_row.addWidget(self._off_move_btn)
        _move_row.addStretch(1)
        off_l.addLayout(_move_row)
        off_l.addSpacing(18)
        seed_head = QLabel("LOCAL COPY (WORKS OFFLINE)")
        seed_head.setObjectName("sectionLabel")
        off_l.addWidget(seed_head)
        self._off_seed_status = QLabel("")
        self._off_seed_status.setObjectName("hint")
        self._off_seed_status.setWordWrap(True)
        off_l.addWidget(self._off_seed_status)
        _seed_row = QHBoxLayout()
        self._off_seed_btn = QPushButton("Sync now")
        self._off_seed_btn.setObjectName("ghost")
        self._off_seed_btn.setCursor(Qt.PointingHandCursor)
        self._off_seed_btn.clicked.connect(self._refresh_seed_now)
        _seed_row.addWidget(self._off_seed_btn)
        self._off_review_btn = QPushButton("Review merge conflicts…")
        self._off_review_btn.setObjectName("ghost")
        self._off_review_btn.setCursor(Qt.PointingHandCursor)
        self._off_review_btn.clicked.connect(self._review_conflicts)
        _seed_row.addWidget(self._off_review_btn)
        _seed_row.addStretch(1)
        off_l.addLayout(_seed_row)
        off_l.addSpacing(18)
        cache_head = QLabel("QUOTE FOLDER CACHE")
        cache_head.setObjectName("sectionLabel")
        off_l.addWidget(cache_head)
        cache_hint = QLabel(
            "Folders under these roots are copied to this PC "
            "automatically (open quotes first, then newest), so "
            "they open with no network. Set the roots once — "
            "folders are never picked by hand.")
        cache_hint.setObjectName("hint")
        cache_hint.setWordWrap(True)
        off_l.addWidget(cache_hint)
        _cache_trow = QHBoxLayout()
        _cache_trow.setSpacing(8)
        _clab = QLabel("Cache enabled")
        _clab.setMinimumWidth(110)
        _cache_trow.addWidget(_clab)
        self._cache_switch = ToggleSwitch()
        self._cache_switch.toggled.connect(
            lambda _on: self._save_cache_config())
        _cache_trow.addWidget(self._cache_switch)
        _cache_trow.addStretch(1)
        off_l.addLayout(_cache_trow)
        self._cache_roots = QListWidget()
        self._cache_roots.setObjectName("optionList")
        self._cache_roots.setFixedHeight(30)
        off_l.addWidget(self._cache_roots)
        _roots_row = QHBoxLayout()
        _add_root = QPushButton("Add folder root…")
        _add_root.setObjectName("ghost")
        _add_root.setCursor(Qt.PointingHandCursor)
        _add_root.clicked.connect(self._add_cache_root)
        _roots_row.addWidget(_add_root)
        _rm_root = QPushButton("Remove selected")
        _rm_root.setObjectName("ghost")
        _rm_root.setCursor(Qt.PointingHandCursor)
        _rm_root.clicked.connect(self._remove_cache_root)
        _roots_row.addWidget(_rm_root)
        _roots_row.addStretch(1)
        off_l.addLayout(_roots_row)
        _budget_row = QHBoxLayout()
        _budget_row.setSpacing(8)
        _blab = QLabel("Cache size limit")
        _blab.setMinimumWidth(110)
        _budget_row.addWidget(_blab)
        self._cache_budget = ThemedStepper(1, 50, 5, " GB")
        self._cache_budget.valueChanged.connect(
            lambda _v: self._save_cache_config())
        _budget_row.addWidget(self._cache_budget)
        _budget_row.addStretch(1)
        off_l.addLayout(_budget_row)
        _csize_row = QHBoxLayout()
        self._cache_size_label = QLabel("")
        self._cache_size_label.setObjectName("hint")
        _csize_row.addWidget(self._cache_size_label)
        _clear_cache = QPushButton("Clear cache")
        _clear_cache.setObjectName("ghost")
        _clear_cache.setCursor(Qt.PointingHandCursor)
        _clear_cache.clicked.connect(self._clear_folder_cache)
        _csize_row.addWidget(_clear_cache)
        _csize_row.addStretch(1)
        off_l.addLayout(_csize_row)
        off_l.addStretch(1)
        # V1.9.68 (user: "I have no idea how any of it works"):
        # every control on this page explains itself in plain
        # language via its tooltip.
        self._off_location.setToolTip(
            "The network folder both of your PCs sync with. "
            "The copy you actually work on lives on this PC -- "
            "that's why the app opens fast and never gets "
            "stuck waiting on the network.")
        self._off_seed_status.setToolTip(
            "Task List works on the copy of your data stored "
            "on this PC. It syncs with the database in the "
            "network folder in the background, both ways -- a "
            "change made on either PC lands on the other.")
        self._off_seed_btn.setToolTip(
            "Sync this PC with the network database right now: "
            "pull down anything new, send up anything you "
            "changed. This normally happens on its own -- when "
            "the app opens, about once a minute while it runs, "
            "and when it closes.")
        self._off_review_btn.setToolTip(
            "When the same task was changed on both PCs, one "
            "version has to win. The network version stays in "
            "place, and the other version is kept here so you "
            "can look at it and switch if it's the one you "
            "want.")
        self._off_move_btn.setToolTip(
            "Move the network data folder -- the database and "
            "attachments both PCs sync with -- to a different "
            "folder.")
        _clab.setToolTip(
            "Keep copies of your quote folders on this PC, so "
            "drawings and files open even with no network.")
        self._cache_switch.setToolTip(
            "Keep copies of your quote folders on this PC, so "
            "drawings and files open even with no network.")
        self._cache_roots.setToolTip(
            "Folders that get copied to this PC automatically "
            "-- open quotes first, then newest. You set the "
            "folders once; files are never picked by hand.")
        _add_root.setToolTip(
            "Add a folder to keep copied to this PC.")
        _rm_root.setToolTip(
            "Stop copying the selected folder. Copies already "
            "on this PC are cleaned up automatically.")
        _blab.setToolTip(
            "The most space the copied folders may use on this "
            "PC. When it's full, the least-needed copies are "
            "dropped first.")
        self._cache_budget.setToolTip(
            "The most space the copied folders may use on this "
            "PC. When it's full, the least-needed copies are "
            "dropped first.")
        _clear_cache.setToolTip(
            "Delete every copied folder from this PC. The "
            "originals on the network are not touched.")
        # V1.9.52 (user: opening Settings made the app go
        # unresponsive): _refresh_offline_page() totals the
        # folder cache by WALKING it -- on his machine that tree
        # sits on the flaky redirected/network paths, and the
        # walk ran on the UI thread at every Settings open. The
        # page now refreshes LAZILY, the first time it is shown
        # (see _show_settings_page), and the size itself is
        # totalled in a worker (see _refresh_offline_page).
        self._offline_page_ready = False
        self._cache_size_ready.connect(
            self._cache_size_label.setText)
        self._sync_done.connect(self._refresh_offline_page)
        self._sync_done.connect(self._on_sync_done_extra)
        try:
            self._off_location.setText(
                f"Data folder: {self.db.path.parent}")
        except Exception:
            pass

        # ---- sidebar + stacked pages ----
        pages = [
            ("General", general_w),
            ("Option Lists", scopes_w),
            ("Queue", queue_w),
            ("Folders", folder_w),
            ("Notifications", notif_w),
            ("Offline", offline_w),
        ]
        self._settings_page_index = {n: i for i, (n, _) in enumerate(pages)}
        self._settings_scrolls = {}

        mid = QHBoxLayout()
        mid.setContentsMargins(0, 0, 0, 0)
        mid.setSpacing(16)

        sidebar = QWidget()
        sidebar.setFixedWidth(184)
        sidel = QVBoxLayout(sidebar)
        sidel.setContentsMargins(0, 4, 0, 4)
        sidel.setSpacing(4)
        self._nav_group = QButtonGroup(self)
        self._nav_group.setExclusive(True)
        self._nav_stack = QStackedWidget()
        for i, (name, content) in enumerate(pages):
            btn = QPushButton(name)
            btn.setObjectName("settingsNav")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.clicked.connect(
                lambda _=False, idx=i: self._show_settings_page(idx))
            self._nav_group.addButton(btn, i)
            sidel.addWidget(btn)
            sc = _page(content)
            self._nav_stack.addWidget(sc)
            self._settings_scrolls[name] = sc
            if i == 0:
                btn.setChecked(True)
        # V1.9.18: settings nav never got the sliding animation (user
        # report) — the pill slides behind General / Option Lists /
        # Queue / Folders / Notifications.
        self._nav_pill = _SlidingButtonPill(
            sidebar,
            [self._nav_group.button(i) for i in range(len(pages))],
            "#26292f", "#e4e4e7", radius=10, object_name="settingsNav")
        sidel.addStretch(1)
        mid.addWidget(sidebar)
        mid.addWidget(self._nav_stack, 1)
        layout.addLayout(mid, 1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        close_btn = QPushButton("Close")
        close_btn.setDefault(True)
        close_btn.clicked.connect(self.accept)
        footer.addWidget(close_btn)
        layout.addLayout(footer)
        _chip_font_tree(self)

    def _show_settings_page(self, idx):
        """Switch the stacked widget (sidebar navigation). Never raises.

        V1.9.21: the switch is INSTANT. V1.9.18 slid the page content
        with the nav pill, but sliding two full-page pictures past
        each other for 250ms reads as a blurry overlapping mess on a
        real machine (Travis report 2026-11-02) — the pill highlight
        still slides, it carries no text, so it cannot blur. Other
        slides in the app are untouched; only settings nav changed.
        """
        try:
            self._nav_stack.setCurrentIndex(idx)
            if (idx == self._settings_page_index.get("Offline")
                    and not getattr(self, "_offline_page_ready",
                                    False)):
                self._offline_page_ready = True
                self._refresh_offline_page()
            btn = self._nav_group.button(idx)
            if btn is not None and not btn.isChecked():
                btn.setChecked(True)
        except Exception:
            pass

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        if getattr(self, "_settings_frost", None) is not None:
            self._settings_frost.capture()
        # Deferred navigation requested via ensure_folder_section_visible.
        if self._pending_folder_scroll:
            self._pending_folder_scroll = False
            try:
                self._show_settings_page(
                    self._settings_page_index["Folders"])
                _fscroll = self._settings_scrolls.get("Folders")
                if _fscroll is not None:
                    _fscroll.ensureWidgetVisible(self._folder_master, 50, 50)
            except Exception:
                pass

    def ensure_folder_section_visible(self):
        """Open Settings on the Folders page, scrolled to the Folder
        Creation section (a no-op when it is already visible).

        Used by the new-task setup guard's "Open Settings" button so the
        user lands exactly where the missing setup lives. Safe to call
        before show(): navigation is applied when the dialog appears.
        """
        self._pending_folder_scroll = True
        try:
            self._show_settings_page(self._settings_page_index["Folders"])
            _fscroll = self._settings_scrolls.get("Folders")
            if _fscroll is not None:
                _fscroll.ensureWidgetVisible(self._folder_master, 50, 50)
        except Exception:
            pass

    def accept(self):
        self._save_extra_settings()
        super().accept()

    # ---- offline (V1.9.50) ----
    def _offline_session_active(self):
        # V1.9.68: there are no offline sessions any more --
        # every session runs on the local working copy and
        # syncs in the background. Kept (always False) for the
        # page-state call sites below.
        return False

    def _refresh_offline_page(self):
        from tasklist import datahome as _dh
        from tasklist import offline as _off
        from tasklist import foldercache as _fc
        try:
            ptr = _dh.read_pointer()
            suffix = "  (location set on this PC)" if ptr else ""
            try:
                from tasklist.app import default_db_path as _ddp
                _live_parent = _ddp().parent
            except Exception:
                _live_parent = self.db.path.parent
            self._off_location.setText(
                f"Data folder: {_live_parent}{suffix}")
            meta = _dh.read_seed_meta()
            when = (meta.get("last_sync_at")
                    or meta.get("refreshed_at") or "never")
            try:
                size = _dh.seed_db_path().stat().st_size / 1e6
            except Exception:
                size = 0.0
            conflicts = len(_off.load_conflicts(self.db))
            text = (f"Last synced with the network data: {when}"
                    f"  ·  local copy {size:.1f} MB")
            if meta.get("last_sync_ok") is False:
                text += ("  ·  the network copy couldn't be "
                         "reached last try -- your work is "
                         "saved on this PC and syncs on its "
                         "own when it can")
            if conflicts:
                text += f"  ·  {conflicts} merge conflict(s) to review"
            self._off_seed_status.setText(text)
            self._off_review_btn.setEnabled(conflicts > 0)
            offline_now = self._offline_session_active()
            self._off_seed_btn.setEnabled(not offline_now)
            self._off_move_btn.setEnabled(not offline_now)
            cfg = _dh.read_cache_config()
            self._cache_switch.blockSignals(True)
            self._cache_switch.setChecked(bool(cfg.get("enabled", True)))
            self._cache_switch.blockSignals(False)
            self._cache_budget.blockSignals(True)
            self._cache_budget.setValue(int(cfg.get("budget_gb", 5)))
            self._cache_budget.blockSignals(False)
            self._cache_roots.clear()
            for r in cfg.get("roots") or []:
                self._cache_roots.addItem(str(r))
            self._size_roots_list()
            # V1.9.52: the total is a tree walk -- it runs in a
            # worker and lands via _cache_size_ready; the label
            # carries the budget half in the meantime.
            budget = int(cfg.get("budget_gb", 5))
            self._cache_size_label.setText(
                f"Cache budget: {budget} GB (totalling…)")
            self._start_cache_size_worker(budget)
        except Exception:
            pass

    def _save_cache_config(self):
        from tasklist import datahome as _dh
        from tasklist import foldercache as _fc
        try:
            cfg = _dh.read_cache_config()
            cfg["enabled"] = self._cache_switch.isChecked()
            cfg["budget_gb"] = self._cache_budget.value()
            cfg["roots"] = [
                self._cache_roots.item(i).text()
                for i in range(self._cache_roots.count())]
            _dh.write_cache_config(cfg)
            _fc.evict_to_budget()
            self._cache_size_label.setText(
                f"Cache is using {_fc.total_size() / 1e9:.2f} GB of "
                f"{cfg['budget_gb']} GB.")
        except Exception:
            pass

    def _size_roots_list(self):
        # V1.9.68 (user: "a huge gap between these options"):
        # the roots list reserved a tall fixed block even when
        # it was EMPTY -- an invisible void in the middle of
        # the page. It now takes exactly the room its rows
        # need (one slim strip when empty).
        try:
            n = self._cache_roots.count()
            self._cache_roots.setFixedHeight(
                30 if n == 0 else min(110, n * 24 + 8))
        except Exception:
            pass

    def _add_cache_root(self):
        picked = QFileDialog.getExistingDirectory(
            self, "Choose a quote-folder root", "",
            QFileDialog.DontUseNativeDialog)
        if picked:
            self._cache_roots.addItem(picked)
            self._size_roots_list()
            self._save_cache_config()

    def _remove_cache_root(self):
        row = self._cache_roots.currentRow()
        if row >= 0:
            self._cache_roots.takeItem(row)
            self._size_roots_list()
            self._save_cache_config()

    def _clear_folder_cache(self):
        from tasklist import foldercache as _fc
        _fc.clear_cache()
        self._refresh_offline_page()

    def _refresh_seed_now(self):
        # V1.9.68: "Sync now" -- a full pull+push cycle. It
        # runs on a worker with its OWN connection to the
        # working file (sqlite connections are not shared
        # across threads; the file's WAL serializes writers),
        # and the page refreshes through _sync_done.
        from tasklist import datahome as _dh
        if Path(self.db.path) != _dh.seed_db_path():
            from tasklist import offline as _off
            _off.refresh_seed(self.db)
            self._refresh_offline_page()
            return
        self._off_seed_btn.setEnabled(False)
        self._off_seed_btn.setText("Syncing…")
        _path = str(self.db.path)

        def _work():
            try:
                from tasklist.app import default_db_path as _ddp
                from tasklist.db import TaskDatabase as _TDB
                from tasklist import offline as _off
                _w = _TDB(_path)
                try:
                    _off.sync_once(_w, _ddp())
                finally:
                    _w.conn.close()
            except Exception:
                pass
            self._sync_done.emit()

        import threading
        threading.Thread(target=_work, daemon=True).start()

    def _on_sync_done_extra(self):
        try:
            self._off_seed_btn.setEnabled(True)
            self._off_seed_btn.setText("Sync now")
        except Exception:
            pass

    def _move_data_folder(self):
        from tasklist import datahome as _dh
        from tasklist.db import TaskDatabase as _TDB
        picked = QFileDialog.getExistingDirectory(
            self, "Choose the new data folder",
            str(self.db.path.parent), QFileDialog.DontUseNativeDialog)
        if not picked:
            return
        dest = Path(picked)
        if dest == self.db.path.parent:
            app_message(self, "Move data folder",
                        "That's the current data folder.")
            return
        if (dest / "tasks.db").exists() and not app_confirm(
                self, "Move data folder",
                "A tasks.db already exists in that folder. Replace "
                "it with your current data?",
                confirm_label="Replace", cancel_label="Cancel"):
            return
        try:
            dest.mkdir(parents=True, exist_ok=True)
            tmp = dest / "tasks.db.tmp"
            dest_db = _TDB(tmp)
            try:
                self.db.conn.backup(dest_db.conn)
            finally:
                dest_db.conn.close()
            tmp.replace(dest / "tasks.db")
            src_att = self.db.path.parent / "attachments"
            if src_att.is_dir():
                shutil.copytree(src_att, dest / "attachments",
                                dirs_exist_ok=True)
        except Exception as exc:  # noqa: BLE001
            app_message(self, "Move data folder",
                        f"The move failed: {exc}")
            return
        if not _dh.write_pointer(dest):
            app_message(
                self, "Move data folder",
                "The data was copied, but the new location could "
                "not be saved for this PC.")
            return
        choice = app_choose(
            self, "Data folder moved",
            "Your data now lives in the new folder. Restart Task "
            "List to start using it.",
            [("Restart now", "primary"), ("Later", "ghost")])
        if choice == "Restart now":
            _relaunch_app()

    def _review_conflicts(self):
        from tasklist import offline as _off
        dlg = QDialog(self)
        dlg.setWindowTitle("Merge conflicts")
        dlg.setModal(True)
        dlg.setMinimumSize(660, 430)
        layout = install_chrome(dlg, "Merge conflicts")
        intro = QLabel(
            "These were changed on both PCs. The network "
            "version is in place now — switch to this PC's "
            "version only if it's the one you want.")
        intro.setObjectName("hint")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        host = QWidget()
        host_l = QVBoxLayout(host)
        host_l.setContentsMargins(0, 0, 0, 0)
        host_l.setSpacing(8)
        layout.addWidget(host, 1)

        def _describe(entry):
            row = entry.get("live") or entry.get("seed") or {}
            for field in ("quote_number", "title", "name"):
                if row.get(field):
                    return f"{entry['table']} — {row[field]}"
            return f"{entry['table']} — row {entry['id']}"

        def _rebuild():
            while host_l.count():
                item = host_l.takeAt(0)
                w = item.widget()
                if w is not None:
                    w.hide()  # V1.9.50: hide before detach (flash)
                    w.setParent(None)
                    w.deleteLater()
            conflicts = _off.load_conflicts(self.db)
            if not conflicts:
                lab = QLabel("No conflicts left.")
                lab.setObjectName("hint")
                host_l.addWidget(lab)
                return
            for i, entry in enumerate(conflicts):
                row_w = QFrame()
                row_w.setObjectName("followRow")
                rl = QHBoxLayout(row_w)
                rl.setContentsMargins(10, 8, 10, 8)
                rl.setSpacing(8)
                lab = QLabel(_describe(entry))
                rl.addWidget(lab, 1)
                keep = QPushButton("Keep live")
                keep.setObjectName("ghost")
                keep.setCursor(Qt.PointingHandCursor)
                keep.clicked.connect(
                    lambda _c=False, idx=i: (
                        _off.resolve_conflict(self.db, idx, False),
                        _rebuild(), self._refresh_offline_page()))
                rl.addWidget(keep)
                use = QPushButton("Use offline")
                use.setObjectName("ghost")
                use.setCursor(Qt.PointingHandCursor)
                use.clicked.connect(
                    lambda _c=False, idx=i: (
                        _off.resolve_conflict(self.db, idx, True),
                        _rebuild(), self._refresh_offline_page()))
                rl.addWidget(use)
                host_l.addWidget(row_w)
            host_l.addStretch(1)

        _rebuild()
        footer = QHBoxLayout()
        footer.addStretch(1)
        close_btn = QPushButton("Close")
        close_btn.setDefault(True)
        close_btn.clicked.connect(dlg.accept)
        footer.addWidget(close_btn)
        layout.addLayout(footer)
        dlg.exec()

    # ---- automatic quote folder creation ----
    def _browse_folder_dir(self, edit):
        picked = QFileDialog.getExistingDirectory(
            self, "Choose folder", edit.text().strip() or "",
            QFileDialog.DontUseNativeDialog)
        if picked:
            # Pasted UNC text (\\server\share\…) is accepted verbatim —
            # never normalize away the leading backslashes.
            edit.setText(picked)

    # ---- updates (V1.9.30): the Drawing Finder flow, in-app ----
    def _on_check_updates_clicked(self):
        self._upd_btn.setEnabled(False)
        self._upd_status.emit("Checking for updates…")
        threading.Thread(target=self._check_update_worker,
                         daemon=True).start()

    def _check_update_worker(self):
        """Manual check: compare, download + stage when newer,
        then let the window offer the restart. DF's status lines,
        Task List's name."""
        import threading as _t  # noqa: F401 (keeps linters honest)
        version = updater.current_version()
        data_dir = self.db.path.parent
        try:
            release = updater.fetch_latest_release()
        except Exception:
            self._upd_status.emit(
                "The update check could not be completed.")
            self._upd_done.emit()
            return
        tag = str(release.get("tag_name", "")).lstrip("v")
        if not tag or updater.version_tuple(tag) \
                <= updater.version_tuple(version):
            self._upd_status.emit(
                f"You're up to date — version {version} is the "
                "latest release.")
            self._upd_done.emit()
            return
        url = updater.pick_zip_asset(release)
        if not url:
            self._upd_status.emit(
                f"Version {tag} is available, but its download is "
                "missing — try again later.")
            self._upd_done.emit()
            return
        if updater.pending_offer(data_dir, version) == ("offer", tag):
            self._upd_status.emit(
                f"Update {tag} is downloaded and ready to apply.")
            self.update_ready.emit(tag)
            self._upd_done.emit()
            return
        self._upd_status.emit(f"Downloading Task List {tag}…")
        try:
            updater.stage_update(url, data_dir, tag)
        except Exception:
            self._upd_status.emit(
                "The update download could not be completed.")
            self._upd_done.emit()
            return
        self._upd_status.emit(
            f"Update {tag} downloaded — restart Task List to "
            "apply it.")
        self.update_ready.emit(tag)
        self._upd_done.emit()

    def _apply_font_prefs(self):
        """Save font family/size and apply immediately, no restart."""
        idx = self._font_combo.currentIndex()
        family = "" if idx <= 0 else self._font_combo.currentText()
        save_font_family(family)
        save_font_scale(self._font_size_combo.currentData())
        app = QApplication.instance()
        if app is not None:
            app.setFont(app_font())
            apply_theme(app, saved_theme())

    # ---- appearance: theme + accent (apply immediately) ----
    def _sync_appearance_controls(self):
        dark = saved_theme() != "light"
        self._theme_switch.blockSignals(True)
        self._theme_switch.setChecked(dark)
        self._theme_switch.blockSignals(False)
        self._theme_state.setText("Dark" if dark else "Light")
        current = saved_accent()
        for btn, hexv in self._accent_swatches:
            btn.blockSignals(True)
            btn.setChecked(hexv == current)
            btn.blockSignals(False)

    def _apply_theme_choice(self, name):
        save_theme(name)
        app = QApplication.instance()
        if app is not None:
            apply_theme(app, name)
        try:
            from .dashboard import set_dash_theme
            set_dash_theme(name)
        except Exception:
            pass
        self._sync_appearance_controls()
        self.theme_changed.emit()

    def _apply_accent_choice(self, hexv):
        save_accent(hexv)
        app = QApplication.instance()
        if app is not None:
            apply_theme(app, saved_theme())
        try:
            from .dashboard import set_dash_theme
            set_dash_theme(saved_theme())
        except Exception:
            pass
        self._sync_appearance_controls()
        self.theme_changed.emit()

    def _pick_custom_accent(self):
        color = app_get_color(
            self, QColor(saved_accent()), "Choose an accent color")
        if color.isValid():
            self._apply_accent_choice(color.name())

    def _refresh_folder_section(self):
        """Enable/disable the folder rows and refresh the soft hint + the
        pending-queue readout. Informational only — never blocks saving.

        Local template paths are checked synchronously (cheap); UNC paths
        are probed off the UI thread — the hint shows "checking" until the
        verdict resolves (v1.2.9). The network is never stat'ed here.
        """
        master = self._folder_master.isChecked()
        for lab, edit, browse in self._folder_rows:
            lab.setEnabled(master)
            edit.setEnabled(master)
            if browse is not None:
                browse.setEnabled(master)
        hint = ""
        template_bad = False
        dest_bad = False
        if master:
            template = self._folder_template_edit.text().strip()
            dest = self._folder_dest_edit.text().strip()
            if not template:
                hint = ("Template folder isn't set or can't be reached — "
                        "quote folders won't be created until it's fixed.")
                template_bad = True
            elif _looks_like_unc(template):
                verdict = self._unc_template_verdict(template)
                if verdict is False:
                    hint = ("Template folder isn't set or can't be reached — "
                            "quote folders won't be created until it's fixed.")
                    template_bad = True
                elif verdict is None:
                    hint = "Checking template folder…"
            elif not os.path.isdir(template):
                hint = ("Template folder isn't set or can't be reached — "
                        "quote folders won't be created until it's fixed.")
                template_bad = True
            elif not dest:
                hint = ("Destination folder isn't set — new quote folders "
                        "will be queued until it's set.")
                dest_bad = True
            elif template.casefold() == dest.casefold():
                hint = ("Template and destination are the same folder — "
                        "pick a different destination.")
                dest_bad = True
        self._folder_hint.setText(hint)
        self._folder_hint.setVisible(bool(hint))
        # Upgrade the plain hint to warning styling + highlight the field(s)
        # at fault. Informational only — saving is never blocked.
        self._folder_hint.setProperty("warn", master and bool(hint))
        self._folder_template_edit.setProperty("missing", template_bad)
        self._folder_dest_edit.setProperty("missing", dest_bad)
        for widget in (self._folder_hint, self._folder_template_edit,
                       self._folder_dest_edit):
            widget.style().unpolish(widget)
            widget.style().polish(widget)
        self._refresh_folder_pending()

    def _unc_template_verdict(self, template):
        """Cached reachability verdict for a UNC template path (v1.2.9).

        Returns True (reachable), False (unreachable), or None (probe in
        flight / not started). Kicks off a background probe when the path
        changed since the last probe. Never blocks the UI thread; stale
        probe results are discarded via a generation counter.
        """
        if getattr(self, "_unc_probe_for", None) != template:
            self._unc_probe_for = template
            self._unc_probe_verdict = None
            gen = getattr(self, "_unc_probe_gen", 0) + 1
            self._unc_probe_gen = gen

            def _done(payload):
                try:
                    if gen != self._unc_probe_gen:
                        return  # stale: field edited again
                    self._unc_probe_verdict = bool(
                        payload.get("ok") and payload.get("value"))
                    self._refresh_folder_section()
                except RuntimeError:
                    pass  # dialog closed meanwhile

            run_folder_background(_probe_dir_exists, _done, template)
            return None
        return self._unc_probe_verdict

    def _pending_folder_summary(self):
        rows = _pending_rows(self.db)
        n = len(rows)
        if not n:
            return "No folders waiting."
        names = [str(r.get("folder_name") or "—") for r in rows[:4]]
        text = ", ".join(names)
        if n > 4:
            text += f", +{n - 4} more"
        if len(text) > 120:
            text = text[:117] + "…"
        return f"{n} folder{'s' if n != 1 else ''} waiting: {text}"

    def _refresh_folder_pending(self):
        has_master = self._folder_master.isChecked()
        self._folder_pending_label.setText(self._pending_folder_summary())
        self._folder_pending_label.setEnabled(has_master)
        self._folder_retry_btn.setEnabled(
            has_master and bool(_pending_rows(self.db)))

    def _save_folder_settings(self):
        self.db.set_setting(
            "folder_creation_enabled",
            "1" if self._folder_master.isChecked() else "0")
        # UNC paths are stored verbatim (leading \\ preserved).
        self.db.set_setting(
            "folder_template_dir", self._folder_template_edit.text().strip())
        self.db.set_setting(
            "folder_dest_dir", self._folder_dest_edit.text().strip())
        self.db.set_setting(
            "folder_initials", self._folder_initials_edit.text().strip())

    def _on_retry_folders(self):
        # Persist first so the retry uses what the user just typed.
        self._save_folder_settings()
        self._folder_retry_btn.setEnabled(False)
        self._folder_retry_btn.setText("Retrying…")
        retry_pending_folders(self.db, parent=self,
                              on_done=self._after_retry_folders)

    def _after_retry_folders(self, summary):
        self._folder_retry_btn.setText("Retry now")
        self._refresh_folder_section()
        # The single manual-retry confirmation (per-folder successes stay
        # quiet during a retry). Always reports exactly once per retry.
        if summary:
            created = summary.get("created") or 0
            waiting = summary.get("waiting") or 0
            if created:
                text = f"{created} quote folder(s) created and linked."
                if waiting:
                    text += f" {waiting} still waiting."
                show_toast(self, "success", "Quote folders created", text)
            elif waiting:
                show_toast(
                    self, "info", "Quote folders",
                    f"{waiting} quote folder(s) still waiting — will be "
                    "created when you're connected to the work network.")

    def _on_verify_setup(self):
        """Run the read-only folder-setup diagnostic.

        Snapshots the field values, then probes off the UI thread via
        run_folder_background (destination reachability can touch the
        network and must never block the dialog). Purely diagnostic:
        never creates folders, writes files, or changes settings.
        """
        self._folder_verify_btn.setEnabled(False)
        self._folder_verify_btn.setText("Checking…")
        run_folder_background(
            verify_folder_setup,
            self._on_verify_done,
            self._folder_master.isChecked(),
            self._folder_template_edit.text(),
            self._folder_dest_edit.text(),
            self._folder_initials_edit.text(),
        )

    def _on_verify_done(self, payload):
        """Render the diagnostic's per-item pass/fail checklist inline."""
        self._folder_verify_btn.setEnabled(True)
        self._folder_verify_btn.setText("Verify setup")
        lay = self._verify_box.layout()
        # Re-running replaces the previous results: detach the old rows
        # immediately (deleteLater() alone would leave them discoverable
        # via findChildren until the event loop runs).
        while lay.count():
            w = lay.takeAt(0).widget()
            if w is not None:
                w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
                w.setParent(None)
                w.deleteLater()
        if payload.get("ok"):
            rows = payload.get("value") or []
        else:
            rows = [("error", "Verification could not run", False,
                     str(payload.get("error") or "unknown error"))]
        for _key, label, ok, detail in rows:
            text = ("✓ " if ok else "✗ ") + label
            if detail:
                text += " — " + detail
            item = QLabel(text)
            item.setObjectName("verifyItem")
            item.setProperty("ok", bool(ok))
            item.setWordWrap(True)
            lay.addWidget(item)
        # Polish after the dynamic property is set so the QSS [ok=…]
        # rules apply (same pattern as the folder hint warn state).
        for i in range(lay.count()):
            w = lay.itemAt(i).widget()
            if w is not None:
                w.style().unpolish(w)
                w.style().polish(w)
        self._verify_box.setVisible(True)

    def _refresh_ibc_data_label(self, note=None):
        """Code-data status line on the Notifications page."""
        try:
            from . import building_codes as _bc
            data_dir = None
            try:
                data_dir = str(self.db.path.parent)
            except Exception:
                data_dir = None
            _compiled, verified, origin = _bc.dataset_status(
                data_dir)
            where = ("updated automatically"
                     if origin == "remote cache"
                     else "as bundled with the app")
            text = (f"Code data verified through "
                    f"{_fmt_iso_long(verified)} ({where}). It "
                    f"refreshes on its own at launch; a check "
                    f"here does the same thing now.")
            if note:
                text = f"{note} {text}"
            self._ibc_data_label.setText(text)
        except Exception:
            pass

    def _on_ibc_check_now(self):
        """Manual code-data check (same fetch the launch runs)."""
        self._ibc_check_btn.setEnabled(False)
        self._ibc_data_label.setText("Checking for code updates…")
        result = {}

        def _work():
            try:
                from . import building_codes as _bc
                data_dir = str(self.db.path.parent)
                result["status"] = _bc.fetch_remote_sync(data_dir)
            except Exception:
                result["status"] = "failed"

        import threading as _threading
        _threading.Thread(target=_work, daemon=True).start()
        self._ibc_poll = result
        self._ibc_poll_timer = QTimer(self)
        self._ibc_poll_timer.setInterval(300)
        self._ibc_poll_timer.timeout.connect(
            self._ibc_check_poll)
        self._ibc_poll_timer.start()

    def _ibc_check_poll(self):
        result = getattr(self, "_ibc_poll", None)
        if result is None or "status" not in result:
            return
        self._ibc_poll_timer.stop()
        self._ibc_check_btn.setEnabled(True)
        note = {"updated": "Code data updated.",
                "current": "Code data is already current.",
                "failed": "Check failed (offline?)."}.get(
                    result["status"], "")
        self._refresh_ibc_data_label(note)

    def _start_cache_size_worker(self, budget):
        """Total the folder cache in a daemon thread; the label
        updates through _cache_size_ready. Never blocks."""
        def _work():
            try:
                from tasklist import foldercache as _fc
                text = (f"Cache is using "
                        f"{_fc.total_size() / 1e9:.2f} GB of "
                        f"{budget} GB.")
            except Exception:
                text = f"Cache budget: {budget} GB."
            try:
                self._cache_size_ready.emit(text)
            except Exception:
                pass

        import threading as _threading
        _threading.Thread(target=_work, daemon=True).start()

    def _save_extra_settings(self):
        self.db.set_setting("ask_price_on_complete",
                             "1" if self._price_box.isChecked() else "0")
        # v1.4.0 item 15b: seismic B+ popup alerts (default ON).
        if hasattr(self, "_seismic_popup_check"):
            self.db.set_setting(
                "seismic_popup",
                "1" if self._seismic_popup_check.isChecked() else "0")
        # V1.9.52: IBC popup toggle + lead times.
        if hasattr(self, "_ibc_popup_check"):
            self.db.set_setting(
                "ibc_popup",
                "1" if self._ibc_popup_check.isChecked() else "0")
        if hasattr(self, "_lead_min_stepper"):
            lo = self._lead_min_stepper.value()
            hi = self._lead_max_stepper.value()
            if hi < lo:
                lo, hi = hi, lo
            self.db.set_setting("lead_min_weeks", str(lo))
            self.db.set_setting("lead_max_weeks", str(hi))
        self._save_folder_settings()
        self.db.set_setting("stale_days", str(self._stale_spin.value()))
        cols = []
        wip = {}
        for key, name_edit, wip_spin in self._queue_rows:
            cols.append([key, name_edit.text().strip() or key])
            if wip_spin.value() > 0:
                wip[key] = wip_spin.value()
        self.db.set_queue_columns(cols)
        self.db.set_queue_wip(wip)
        # v1.4.0 item 10: persist the waiting-state toggle + column KEY.
        # The picker's labels also refresh here so a same-session rename
        # is visible without reopening Settings.
        if hasattr(self, "_waiting_check"):
            self.db.set_setting(
                "waiting_on_enabled",
                "1" if self._waiting_check.isChecked() else "0")
            wait_key = self._waiting_combo.currentData()
            if wait_key:
                self.db.set_setting("waiting_on_column", str(wait_key))
            cur = self._waiting_combo.currentData()
            self._waiting_combo.blockSignals(True)
            self._waiting_combo.clear()
            for key, label in cols:
                self._waiting_combo.addItem(label, key)
            idx = self._waiting_combo.findData(cur)
            self._waiting_combo.setCurrentIndex(max(0, idx))
            self._waiting_combo.blockSignals(False)
        self.queue_changed.emit()


# ------------------------------------------------------- contact autocomplete
class PinnedCompleter(QCompleter):
    """QCompleter whose disabled rows are no-ops when activated.

    The '— Frequent —' separator row is part of the model for display, but
    activating it must not insert junk into the field — so pathFromIndex
    returns the field's current text for any disabled index.
    """

    def pathFromIndex(self, index):
        if not index.isValid() or not (index.flags() & Qt.ItemIsEnabled):
            w = self.widget()
            return w.text() if w is not None else ""
        return super().pathFromIndex(index)


def frequent_distributors(db, limit=5, days=180):
    """[(name, quote_count)] — most-quoted distributors, last `days` days.

    Read-only query straight on the db connection; db.py is untouched.
    Blank distributor names are excluded.
    """
    try:
        rows = db.conn.execute(
            """SELECT distributor, COUNT(*) AS n FROM tasks
               WHERE created_at >= date('now', ?)
                 AND TRIM(COALESCE(distributor, '')) <> ''
               GROUP BY distributor
               ORDER BY n DESC, distributor COLLATE NOCASE
               LIMIT ?""",
            (f"-{days} days", limit),
        ).fetchall()
    except Exception:
        return []
    return [(r[0], r[1]) for r in rows]


def _distributor_completion_model(db, edit):
    """Pinned frequent distributors, a muted separator, then the rest A–Z."""
    names = db.directory_names("distributor")
    seen = set()
    pinned = []
    for name, _count in frequent_distributors(db):
        key = (name or "").casefold()
        if key and key not in seen:
            seen.add(key)
            pinned.append(name)
    rest = [n for n in names if n.casefold() not in seen]
    model = QStandardItemModel(edit)
    for name in pinned:
        item = QStandardItem(name)
        item.setEditable(False)
        model.appendRow(item)
    if pinned:
        sep = QStandardItem("— Frequent —")
        sep.setFlags(Qt.NoItemFlags)
        sep.setEditable(False)
        sep.setEnabled(False)
        font = app_font()
        font.setItalic(True)
        sep.setFont(font)
        sep.setForeground(QColor("#8a919c"))
        model.appendRow(sep)
    for name in rest:
        item = QStandardItem(name)
        item.setEditable(False)
        model.appendRow(item)
    return model


def default_sales_rep(db):
    """V1.9.32 (user): new tasks default to the House Account rep."""
    try:
        reps = db.get_sales_reps()
    except Exception:
        reps = []
    return "House Account" if "House Account" in reps else ""


def _crm_tabs_qss():
    """Styling for _AttachedTabs (CRM detail window).

    V1.9.46 (user, Chrome screenshot in hand: the tabs must look
    IDENTICAL to Chrome's): the strip and the tabs are now
    CUSTOM-PAINTED (_ChromeTabStrip / _ChromeTabButton) with the
    real Chrome silhouette -- base flares, no outline, a darker
    strip recess, separators between inactive tabs. QSS is left
    with only what paint does not do: the pane frame and the tab
    buttons' size/font (their padding carries the silhouette's
    flare zones, 20px of body padding + 11px of flare per side).
    """
    if saved_theme() == "light":
        pane = "#f7f7f8"
        line = "rgba(0, 0, 0, 0.14)"
        idle_text = "#5c636d"
    else:
        pane = "#0c0d10"
        line = "rgba(255, 255, 255, 0.10)"
        idle_text = "#8a919c"
    return f"""
QWidget#crmStrip {{
    background: transparent;
}}
QFrame#crmPane {{
    background: {pane};
    border: 1px solid {line};
    border-top: none;
    /* V1.9.49 (user: "WHY IS THE BOTTOM CORNERS ROUNDED BUT
       THE TOP ARE SHARP LEADING INTO THE TABS???"): all four
       corners carry the same radius -- uniform. */
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
}}
QFrame#crmPanePlain {{
    background: transparent;
    border: none;
}}
QPushButton#crmTab {{
    background: transparent;
    color: {idle_text};
    border: none;
    padding: 8px 31px;
    font-weight: 600;
}}
"""


def _dash_tab_palette():
    """Dashboard tab colours (V1.9.49): the dashboard page
    surface (#0b0c0e / #f5f5f6) is both strip and pane, so the
    active tab is outline-only over its own page -- the values
    the retired AnimatedTabBar painted with."""
    if saved_theme() == "light":
        return {"pane": QColor("#f5f5f6"), "line": QColor("#d3d4d8"),
                "hover": QColor(0, 0, 0, 13), "idle": QColor("#474c54"),
                "text": QColor("#1c1f24"), "strip": QColor("#f5f5f6"),
                "sep": QColor(0, 0, 0, 30)}
    return {"pane": QColor("#0b0c0e"), "line": QColor("#23252b"),
            "hover": QColor(255, 255, 255, 18),
            "idle": QColor("#9ba1ab"), "text": QColor("#f4f5f7"),
            "strip": QColor("#0b0c0e"),
            "sep": QColor(255, 255, 255, 30)}


def _page_tab_palette():
    """Tabs that merge into the window page itself (the main
    window's status filter, V1.9.49): strip and pane are the
    app surface (#101114 / #f5f5f6); line, separators and text
    come from the shared CRM tab palette so every tab in the
    app reads identically."""
    pal = _crm_tab_palette()
    if saved_theme() == "light":
        pal["strip"] = QColor("#f5f5f6")
        pal["pane"] = QColor("#f5f5f6")
    else:
        pal["strip"] = QColor("#101114")
        pal["pane"] = QColor("#101114")
    return pal


class _ChromeTabBar(QWidget):
    """THE app's one tab strip (V1.9.49, user: "CRM should
    have the tabs just like dashboard... IT NEEDS TO BE ALL
    UNIFORM"). Every tab strip in the app is this widget: the
    CRM pages and contact window (via _AttachedTabs), the
    dashboard (via _AttachedTabs), and the main window's
    status filter row (standalone).

    One implementation, so there is one behaviour to get
    right: the Chrome silhouette with base flares, an OUTLINE
    around the active tab (its interior is exactly the surface
    it merges into -- no gray fill anywhere, the user's
    standing rule), one baseline hairline, thin separators
    between inactive neighbours, and the dashboard's slide
    animation (180ms) on every switch. No QTabBar and no
    native style anywhere near it: on Windows the native
    style kept painting its own #1c1d1f selected-tab slab
    under the custom-painted QTabBar no matter what the paint
    code did (the user's "black box on the tabs", 1.9.46-48);
    a plain QWidget strip leaves nothing for it to paint.

    V1.9.46/47 heritage: the strip fill is the surface around
    the tabs, never a black recess (that read as a stray box).
    """

    currentChanged = Signal(int)
    # V1.9.52: emitted when the slide animation settles, so a
    # heavy content rebuild can wait for a clean strip instead
    # of eating the slide's frames (the main filter row's
    # choppiness the user reported on 1.9.51).
    slideFinished = Signal()

    def __init__(self, parent=None, palette_fn=None):
        super().__init__(parent)
        self.setObjectName("crmStrip")
        self._palette_fn = palette_fn
        self._buttons = []
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self._group.buttonClicked.connect(self._on_button)
        self._current = -1
        self._filters = []
        self._sliding = False
        self._slide_from = QRectF()
        self._slide_to = QRectF()
        self._slide_t = 1.0
        self._lay = QHBoxLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setSpacing(0)
        self._lay.addStretch(1)
        self.setStyleSheet(_crm_tabs_qss())
        self._anim = QPropertyAnimation(self, b"slide_t", self)
        self._anim.setDuration(180)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.finished.connect(self._slide_done)

    # -- palette --
    def _resolve_palette(self):
        if self._palette_fn is not None:
            try:
                return self._palette_fn()
            except Exception:
                pass
        return _crm_tab_palette()

    def refresh_theme(self):
        self.setStyleSheet(_crm_tabs_qss())
        for b in self._buttons:
            b.update()
        self.update()

    # -- slide animation --
    def _get_slide_t(self):
        return self._slide_t

    def _set_slide_t(self, value):
        self._slide_t = float(value)
        self.update()

    slide_t = Property(float, _get_slide_t, _set_slide_t)

    def _body_rect(self, btn):
        g = btn.geometry()
        return QRectF(g.left() + 11.0, 2.0, g.width() - 22.0,
                      self.height() - 2.0)

    def _slide_rect_now(self):
        """The silhouette's rect at the animation's current
        position (the paintEvent interpolation, shared so a
        retarget starts from exactly what is on screen)."""
        t = self._slide_t
        f, g = self._slide_from, self._slide_to
        return QRectF(f.x() + (g.x() - f.x()) * t, f.y(),
                      f.width() + (g.width() - f.width()) * t,
                      f.height())

    def _slide_done(self):
        self._sliding = False
        self.slideFinished.emit()
        for b in self._buttons:
            b.update()
        self.update()

    # -- event filters (the dashboard's page-slide capture
    # installs itself here so presses on the strip or any tab
    # button are seen before the switch) --
    def install_event_filter(self, obj):
        if obj not in self._filters:
            self._filters.append(obj)
        self.installEventFilter(obj)
        for b in self._buttons:
            b.installEventFilter(obj)

    # -- QTabWidget-shaped API --
    def add_tab(self, text):
        btn = _ChromeTabButton(text)
        btn.setObjectName("crmTab")
        btn.setCheckable(True)
        btn.setCursor(Qt.PointingHandCursor)
        btn._bar = self
        btn._palette_fn = self._palette_fn
        chip_font(btn)
        self._lay.insertWidget(len(self._buttons), btn)
        self._group.addButton(btn, len(self._buttons))
        self._buttons.append(btn)
        for f in self._filters:
            btn.installEventFilter(f)
        if self._current < 0:
            self.setCurrentIndex(0)
        return btn

    def count(self):
        return len(self._buttons)

    def tabRect(self, index):  # noqa: N802 (Qt name)
        """QTabBar-shaped accessor: the tab's rect is its
        button's geometry."""
        return self._buttons[index].geometry()

    def tabText(self, index):  # noqa: N802 (Qt name)
        return self._buttons[index].text()

    def setTabText(self, index, text):  # noqa: N802 (Qt name)
        self._buttons[index].setText(text)

    def setTabEnabled(self, index, enabled):  # noqa: N802 (Qt name)
        self._buttons[index].setEnabled(enabled)

    def isTabEnabled(self, index):  # noqa: N802 (Qt name)
        return self._buttons[index].isEnabled()

    def currentIndex(self):  # noqa: N802 (Qt name)
        return self._current

    def setCurrentIndex(self, index):  # noqa: N802 (Qt name)
        if index < 0 or index >= len(self._buttons):
            return
        if index == self._current:
            self._buttons[index].setChecked(True)
            return
        old = self._current
        self._buttons[index].setChecked(True)
        self._current = index
        if old >= 0 and self.isVisible() and self.width() > 0:
            # V1.9.51 (user: the switch "bounces between the tabs
            # back and forth before moving to the tab that has
            # been clicked. not smooth at all and visually
            # glitchy"): the old code REFUSED to start a slide
            # while one was running -- but it still flipped the
            # checked tab instantly, so the running slide landed
            # on the OLD target and the silhouette then TELEPORTED
            # to the newly checked tab: slide, snap back, slide
            # again. Now a switch mid-slide RETARGETS: the new
            # slide starts from the silhouette's current on-screen
            # rect (the paint interpolation), so the motion is one
            # continuous glide to the clicked tab, always.
            if self._sliding:
                _from = self._slide_rect_now()
            else:
                _from = self._body_rect(self._buttons[old])
            _to = self._body_rect(self._buttons[index])
            if (not _from.isEmpty() and not _to.isEmpty()
                    and _from != _to):
                self._slide_from = _from
                self._slide_to = _to
                self._sliding = True
                self._anim.stop()
                self._slide_t = 0.0
                self._anim.start()
            else:
                self._sliding = False
                self._slide_t = 1.0
        self.update()
        self.currentChanged.emit(index)

    def _on_button(self, btn):
        idx = self._group.id(btn)
        if idx >= 0:
            self.setCurrentIndex(idx)

    # -- painting: surface, baseline, separators, and the
    # sliding silhouette while a switch animates (the checked
    # button suppresses its own silhouette until the slide
    # lands, so exactly one silhouette exists at any moment) --
    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        pal = self._resolve_palette()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), pal["strip"])
        base = self.height() - 1
        p.setPen(QPen(pal["line"], 1))
        # V1.9.65 (user, with photo: a line runs UNDER the
        # active CRM tab): the baseline is drawn in two segments
        # that stop at the active silhouette's body span, so the
        # line can never cross under the active tab whatever
        # the paint/compositing order on the machine. (Sandbox
        # renders at DPR 1/1.5/2 probed clean already; this makes
        # the exclusion structural instead of relying on the
        # button's fill painting over the line.)
        _span = None
        if 0 <= self._current < len(self._buttons):
            if self._sliding:
                _r = self._slide_rect_now()
            else:
                _g = self._buttons[self._current].geometry()
                _r = QRectF(_g.left() + 11.0, 2.0,
                            _g.width() - 22.0, _g.height() - 2.0)
            _span = (int(_r.left()), int(_r.right()))
        if _span is None:
            p.drawLine(0, base, self.width(), base)
        else:
            if _span[0] > 0:
                p.drawLine(0, base, _span[0], base)
            if _span[1] < self.width():
                p.drawLine(_span[1], base, self.width(), base)
        if self._buttons:
            p.setPen(QPen(pal["sep"], 1))
            y0 = int(self.height() * 0.34)
            y1 = int(self.height() * 0.66)
            for i in range(len(self._buttons) - 1):
                if i == self._current or i + 1 == self._current:
                    continue
                x = self._buttons[i].geometry().right()
                p.drawLine(x, y0, x, y1)
        if self._sliding:
            body = self._slide_rect_now()
            p.setPen(Qt.NoPen)
            p.setBrush(pal["pane"])
            p.drawPath(chrome_tab_path(body))
            p.setPen(QPen(pal["line"], 1))
            p.setBrush(Qt.NoBrush)
            p.drawPath(chrome_tab_outline_path(body))
        p.end()


class _ChromeTabStrip(_ChromeTabBar):
    """The strip's V1.9.46 name; the strip IS the tab bar
    since V1.9.49 (see _ChromeTabBar)."""


class _ChromeTabButton(QPushButton):
    """One CRM tab, painted as a Chrome tab (V1.9.46).

    The button's rect includes the silhouette's flare zones
    (QSS padding carries them), so the text centres on the tab
    BODY when centred in the rect. Active: the Chrome silhouette
    in the pane colour, no outline. Hover (inactive): Chrome's
    inset rounded slab. Inactive: bare text on the strip."""

    def _palette(self):
        fn = getattr(self, "_palette_fn", None)
        if fn is not None:
            try:
                return fn()
            except Exception:
                pass
        return _crm_tab_palette()

    def _bar_sliding(self):
        bar = getattr(self, "_bar", None)
        return bool(bar is not None
                    and getattr(bar, "_sliding", False))

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        pal = self._palette()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = QRectF(self.rect())
        fillet = 11.0
        if self.isChecked() and not self._bar_sliding():
            body = QRectF(r.left() + fillet, 2.0,
                          r.width() - 2 * fillet, r.height())
            p.setPen(Qt.NoPen)
            p.setBrush(pal["pane"])
            p.drawPath(chrome_tab_path(body))
            # V1.9.48 (user): the pane's outline follows AROUND
            # the tab -- the silhouette is stroked with the same
            # line colour (open at the bottom, where the tab
            # merges into the pane), so the active tab reads
            # against the strip instead of floating on it.
            p.setPen(QPen(pal["line"], 1))
            p.setBrush(Qt.NoBrush)
            p.drawPath(chrome_tab_outline_path(body))
        elif self.isEnabled() and self.underMouse():
            # V1.9.51 (user, with screenshot): hover is an OUTLINE
            # ONLY -- "I am certain I asked for just rectangle
            # outlines and not the gray color filled rectangles".
            # The filled hover slab is gone everywhere; an inactive
            # tab never carries a fill in any state.
            hr = QRectF(r.left() + fillet + 3.0, 4.0,
                        r.width() - 2 * fillet - 6.0, r.height() - 8.0)
            p.setPen(QPen(pal["line"], 1))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(hr, 8.0, 8.0)
        col = pal["text"] if self.isChecked() else pal["idle"]
        if self.property("attention"):
            # The filter row's Needs attention tab keeps its red
            # read (the old seg chip's attention colours).
            if saved_theme() == "light":
                col = QColor("#912018" if self.isChecked()
                             else "#b42318")
            else:
                col = QColor("#ffc9c9" if self.isChecked()
                             else "#ef9a9a")
        if not self.isEnabled():
            col = QColor(col)
            col.setAlpha(140)
        p.setPen(col)
        p.setFont(self.font())
        # V1.9.51 (user screenshot: the dashboard tab read
        # "Freight && Lead-Time"): tab labels carry Qt's mnemonic
        # escaping ("&&" displays as "&" under the native style),
        # but this button paints its text RAW, so the escape showed
        # literally. Render the display form: collapse "&&" to "&"
        # and drop a lone mnemonic marker, exactly as the native
        # text engine would draw it.
        _disp = (self.text().replace("&&", "\x00")
                 .replace("&", "").replace("\x00", "&"))
        p.drawText(r, Qt.AlignCenter, _disp)
        p.end()

    def enterEvent(self, event):  # noqa: N802 (Qt virtual)
        super().enterEvent(event)
        self.update()

    def leaveEvent(self, event):  # noqa: N802 (Qt virtual)
        super().leaveEvent(event)
        self.update()


class _PaneFrame(QFrame):
    """The framed pane under an _AttachedTabs strip (V1.9.51).

    The pane's QSS carries ``border-top: none`` (the strip's
    baseline is the top line) with 10px top corner radii -- and
    with no top border, the stylesheet renderer leaves the top
    corner arcs effectively undrawn: the side border just fades
    in below where the arc should be. That was the user's
    contact-window screenshot: the active tab's flare "goes off
    into nothing" at the strip's left end because the corner it
    should round down into was never painted. The frame paints
    the two top arcs itself, after the QSS pass, at the border's
    own colour: one continuous line from the tab's flare, along
    the baseline, around the corner, and down the side."""

    RADIUS = 10

    def paintEvent(self, event):  # noqa: N802 (Qt virtual)
        super().paintEvent(event)
        try:
            if saved_theme() == "light":
                line = QColor(0, 0, 0, 36)      # rgba(0,0,0,0.14)
            else:
                line = QColor(255, 255, 255, 26)  # rgba(255,..,0.10)
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing, True)
            p.setPen(QPen(line, 1))
            p.setBrush(Qt.NoBrush)
            r = self.RADIUS - 0.5
            w = self.width()
            # Each arc starts at its TOP point (on the baseline
            # row) and sweeps to its SIDE point (on the side
            # border): +90 lands at 9 o'clock (left corner),
            # -90 at 3 o'clock (right corner).
            for cx, sweep in ((r + 0.5, 90), (w - r - 0.5, -90)):
                box = QRectF(cx - r, 0.5, 2 * r, 2 * r)
                path = QPainterPath()
                path.arcMoveTo(box, 90)
                path.arcTo(box, 90, sweep)
                p.drawPath(path)
            p.end()
        except Exception:
            pass


class _AttachedTabs(QWidget):
    """Real attached tabs with a guaranteed merge (V1.9.32).

    QTabWidget's QSS-styled pane would not hold the tab geometry:
    with documentMode its frame vanished entirely and the tabs read
    as floating chips; without it, the pane's top border kept a seam
    under the active tab. This widget builds the pattern from plain
    parts instead — a strip of checkable buttons overlapping a
    framed pane by exactly one row, so the active button paints the
    pane's surface over the pane's top border beneath it: the merge
    is painted, not negotiated with the style engine.

    V1.9.49: the strip is the shared _ChromeTabBar — the same
    component the dashboard and the main window's status filter
    use — so every tab in the app is one implementation with one
    look and the same slide animation. `framed=False` drops the
    pane's border/background (the dashboard's pages paint their
    own surface); `palette_fn` recolours strip + pane.

    API mirrors the slice of QTabWidget the CRM detail window uses:
    addTab / count / tabText / widget / setCurrentIndex /
    currentIndex / setTabEnabled / isTabEnabled / currentChanged.
    """

    currentChanged = Signal(int)

    def __init__(self, parent=None, palette_fn=None, framed=True):
        super().__init__(parent)
        self._bar = _ChromeTabBar(self, palette_fn=palette_fn)
        self._bar.currentChanged.connect(self._on_bar_changed)
        # Compat aliases: the strip and its button list used to
        # be this widget's own members.
        self._strip = self._bar
        self._buttons = self._bar._buttons
        self._pane = _PaneFrame(self) if framed else QFrame(self)
        self._pane.setObjectName("crmPane" if framed else "crmPanePlain")
        if not framed:
            self._paint_plain_pane()
        pane_lay = QVBoxLayout(self._pane)
        pane_lay.setContentsMargins(1, 1, 1, 1)
        self._stack = QStackedWidget()
        pane_lay.addWidget(self._stack)
        self._current = -1
        self.setStyleSheet(_crm_tabs_qss())
        self._bar.raise_()

    # -- geometry: strip on top; the pane's TOP EDGE IS the
    # strip's baseline row. The bar paints its baseline at its own
    # last row (strip_h - 1); the pane therefore starts at
    # strip_h - 1, so its top border and corner arcs share that
    # exact row. V1.9.51 (user, contact-window screenshot: "see
    # the left side? there is a disconnect... should round right
    # down into the rest not go off into nothing"): with the pane
    # at strip_h, its corner arc began one row BELOW the baseline
    # and the active tab's left flare landed on a line that never
    # joined the pane -- a visible step and a floating hook at the
    # strip's left end. One shared row: baseline, tab base, pane
    # top and pane corner arcs all meet.
    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        w, h = self.width(), self.height()
        strip_h = max(1, self._bar.sizeHint().height())
        self._bar.setGeometry(0, 0, w, strip_h)
        self._pane.setGeometry(0, strip_h - 1, w,
                               max(0, h - strip_h + 1))
        self._bar.raise_()

    def sizeHint(self):  # noqa: N802 (Qt virtual)
        hint = self._stack.currentWidget()
        base = hint.sizeHint() if hint is not None else QSize(320, 240)
        return QSize(base.width(),
                     base.height() + self._bar.sizeHint().height())

    def minimumSizeHint(self):  # noqa: N802 (Qt virtual)
        return QSize(240, 160)

    # -- accessors for hosts that need the strip itself (the
    # dashboard's page-slide capture installs an event filter) --
    def strip_widget(self):
        return self._bar

    def tabBar(self):  # noqa: N802 (Qt name)
        """QTabWidget-shaped accessor: the 'tab bar' is the
        shared _ChromeTabBar."""
        return self._bar

    def tab_buttons(self):
        return list(self._bar._buttons)

    def install_event_filter(self, obj):
        self._bar.install_event_filter(obj)

    def refresh_theme(self):
        self.setStyleSheet(_crm_tabs_qss())
        self._bar.refresh_theme()
        if self._pane.objectName() == "crmPanePlain":
            self._paint_plain_pane()

    def _paint_plain_pane(self):
        """The plain (unframed) pane PAINTS its surface colour
        itself: its shared QSS is transparent, and the 1px ring
        between the pane's edge and the stack would otherwise
        show whatever -- or nothing -- is behind it. The colour
        goes in the pane's OWN stylesheet (an ID selector, so
        it can touch nothing else): the shared sheet's
        transparent background would override a palette fill."""
        fn = self._bar._palette_fn
        try:
            pal = fn() if fn is not None else _crm_tab_palette()
        except Exception:
            pal = _crm_tab_palette()
        self._pane.setStyleSheet(
            "QFrame#crmPanePlain { background: "
            + pal["pane"].name() + "; border: none; }")

    # -- QTabWidget-shaped API --
    def addTab(self, page, text):  # noqa: N802 (Qt name)
        self._bar.add_tab(text)
        self._stack.addWidget(page)
        return len(self._bar._buttons) - 1

    def count(self):
        return self._bar.count()

    def tabText(self, index):  # noqa: N802 (Qt name)
        return self._bar.tabText(index)

    def setTabText(self, index, text):  # noqa: N802 (Qt name)
        self._bar.setTabText(index, text)

    def widget(self, index):
        return self._stack.widget(index)

    def currentWidget(self):  # noqa: N802 (Qt name)
        return self._stack.currentWidget()

    def currentIndex(self):  # noqa: N802 (Qt name)
        return self._bar.currentIndex()

    def setCurrentIndex(self, index):  # noqa: N802 (Qt name)
        self._bar.setCurrentIndex(index)

    def setTabEnabled(self, index, enabled):  # noqa: N802 (Qt name)
        self._bar.setTabEnabled(index, enabled)

    def isTabEnabled(self, index):  # noqa: N802 (Qt name)
        return self._bar.isTabEnabled(index)

    def _on_bar_changed(self, index):
        self._current = index
        self._stack.setCurrentIndex(index)
        self.currentChanged.emit(index)


def _fit_combo_to_contents(combo, min_w=170, max_w=360):
    """Size a bounded-content combo to its longest entry
    (V1.9.48). WAITING ON and QUEUE COLUMN stretched the full
    window width to offer three short choices -- the user
    flagged them one screenshot after another ("sAME FOR THIS
    ONE... AND THIS ONE"). Width = longest item text + the
    combo's padding and drop-down zone, clamped to a sane
    band. Free-text fields and name fields are NOT this: they
    keep the width their content deserves."""
    fm = combo.fontMetrics()
    texts = [combo.itemText(i) for i in range(combo.count())]
    if combo.isEditable() and combo.lineEdit() is not None:
        texts.append(combo.lineEdit().placeholderText())
        texts.append(combo.currentText())
    w = max((fm.horizontalAdvance(t) for t in texts if t),
            default=0)
    combo.setFixedWidth(max(min_w, min(max_w, w + 72)))
    return combo


def _layout_has_group_start(lay):
    """True when any widget in a layout subtree carries the
    groupStart marker (set by _mark_group_starts in the detail
    window, or by hand in New Task)."""
    for i in range(lay.count()):
        item = lay.itemAt(i)
        w = item.widget()
        if w is not None:
            if w.property("groupStart"):
                return True
            for sub in w.findChildren(QWidget):
                if sub.property("groupStart"):
                    return True
        elif item.layout() is not None:
            if _layout_has_group_start(item.layout()):
                return True
    return False


def _apply_group_air(top_layout, air=30, registry=None):
    """Group-start air as REAL layout spacing (V1.9.48).

    The air used to be a QSS margin-top on the marked widget
    (QWidget[groupStart="true"] in themes.py). QSS margins feed
    the widget's size hint, so every group-start caption became
    a 44px box with its text sunk to the bottom of the box --
    the root cause of a whole family of reports at once: the
    main-4 block riding high with a chasm under it, captions
    drifting between sections ("huge gap above, barely any
    below"), and the quote-folder button centring on a box
    whose text sat 15px lower (the "floating" folder icon).
    The QSS rule is gone; the same 30px now lives in the layout
    as spacing BEFORE the item that holds the marked widget,
    so caption boxes are their true text height again and
    anything centred on a caption line centres on the TEXT.
    Total air is unchanged (layout spacing + this spacer), so
    section positions do not move -- only the boxes shrink to
    honesty."""
    hits = []
    for i in range(1, top_layout.count()):
        item = top_layout.itemAt(i)
        w = item.widget()
        if w is not None:
            if w.property("groupStart") or any(
                    s.property("groupStart")
                    for s in w.findChildren(QWidget)):
                hits.append(i)
        elif item.layout() is not None:
            if _layout_has_group_start(item.layout()):
                hits.append(i)
    for i in reversed(hits):
        top_layout.insertSpacing(i, air)
        if registry is not None:
            sp = top_layout.itemAt(i).spacerItem()
            if sp is not None:
                registry.append(sp)


def _hours_edit_width(edit):
    """Content width for the Est. Hours field (V1.9.48): the
    widest of a 3-M value and the "Hours" placeholder, plus
    the field padding. The old "M"*3-only measure left the
    placeholder a hair too wide, so it rendered elided
    ("Ho...") in the window that asks for the number."""
    fm = edit.fontMetrics()
    # V1.9.48: the allowance is 40, not 24 -- the old sum left
    # the rendered text area a couple of pixels narrower than
    # the "Hours" placeholder, so it painted elided ("Ho...")
    # in the shipped build even though the width arithmetic
    # said it fit. Padding + frame + a real safety margin.
    return (max(fm.horizontalAdvance("M" * 3),
                fm.horizontalAdvance(edit.placeholderText())) + 40)


def _pin_caption_labels(root):
    """Captions never absorb layout surplus (V1.9.48).

    The detail / New Task body layouts hand their extra height
    to any widget whose vertical policy allows growth; the
    caption labels were Preferred, so on a tall window every
    caption floated in a ~44px band (text centred, air pooled
    above and below it) and the header groups drifted apart --
    the "huge gap above, barely any below" the user flagged.
    Pinned to Fixed, a caption is exactly its text height and
    the layout's one spacing (8px) plus the groupStart margin
    are the only air in the rhythm, on every machine."""
    for lab in root.findChildren(QLabel):
        if lab.objectName() in ("sectionLabel", "headerNameLabel",
                                "fieldLabel"):
            pol = lab.sizePolicy()
            lab.setSizePolicy(pol.horizontalPolicy(),
                              QSizePolicy.Fixed)


class _ComboTextCenterer(QObject):
    """Optical centring for editable combos (V1.9.48).

    QComboBox centres its text inside the lineEdit, which
    EXCLUDES the drop-down zone (~46px) -- so "centred" combo
    text actually sits ~23px left of the field's centre (the
    user's "why is House Account not centered in its
    dropdown???"). A left text margin equal to the arrow zone
    moves the text's centre onto the field's centre. Synced on
    resize/show. For a hint-sized combo (the Notes font-size
    box) the width is pinned at first show BEFORE the margin
    can inflate its sizeHint (margins feed sizeHint in Qt6);
    grid-stretched combos (the Sales Rep fields) are never
    pinned, only margined."""

    def __init__(self, combo):
        super().__init__(combo)
        self._combo = combo
        self._pinned = False
        combo.installEventFilter(self)
        # V1.9.50: also watch the line edit itself. The margin
        # formula reads le.width(), but a spinbox/combo lays its
        # line edit out a beat AFTER the outer widget resizes --
        # a _sync that runs on the outer Resize can read the
        # line edit at its pre-layout width and pin a huge stale
        # margin (the detail due date sat shoved right, clipped,
        # margin 94 for a 24px button zone). The line edit's own
        # Resize fires when its geometry settles, and margins do
        # not feed that geometry, so re-syncing there is a safe
        # self-correction with no feedback loop.
        try:
            le = combo.lineEdit()
            if le is not None:
                le.installEventFilter(self)
        except Exception:
            pass

    def eventFilter(self, obj, event):  # noqa: N802 (Qt name)
        if event.type() == QEvent.Show:
            if obj is self._combo:
                self._pin()
            self._sync()
        elif event.type() == QEvent.Resize:
            self._sync()
        return False

    def _pin(self):
        if self._pinned:
            return
        self._pinned = True
        combo = self._combo
        if combo.sizePolicy().horizontalPolicy() not in (
                QSizePolicy.Ignored, QSizePolicy.Expanding,
                QSizePolicy.MinimumExpanding):
            combo.setFixedWidth(combo.width())

    def _sync(self):
        combo = self._combo
        le = combo.lineEdit()
        if le is None or combo.width() <= 0 or le.width() <= 0:
            return
        zone = (combo.width() - le.width()
                - 2 * le.geometry().x())
        le.setTextMargins(max(0, zone), 0, 0, 0)


def optically_center_combo(combo):
    """Centre an editable combo's text on the WHOLE field."""
    if combo.lineEdit() is not None:
        combo.lineEdit().setAlignment(Qt.AlignCenter)
    combo._text_centerer = _ComboTextCenterer(combo)
    return combo


def _date_clear_button(tooltip="Clear the date"):
    """V1.9.50 (user): the clear beside a date field is a small
    x icon button -- "should be x icon rather than the ugly
    clear" -- the same drawn x as the rest of the app's icon
    set, sized to sit beside a date field. Never a text button.
    """
    btn = QPushButton()
    btn.setObjectName("iconBtn")
    btn.setIcon(svg_icon("x", "#8a919c", 13))
    btn.setIconSize(QSize(13, 13))
    btn.setFixedSize(28, 28)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setToolTip(tooltip)
    return btn


class _InlineDateClear(QObject):
    """V1.9.51 (user, pointing at the clear beside a date field:
    "this X here to clear it out, move it INSIDE so its inside
    the box over here to the right, before the drop down arrow,
    but ensure that it has the room it needs to be clicked in
    there without issue and not overlapping anything"): the
    clear button is a CHILD of the date edit, parked in a
    reserved slot immediately left of the edit's native button
    zone. The slot is real layout space, not an overlap: the
    text centerer adds the same slot to the text margins (see
    _DateTextCenterer._sync), and _pin widens the field by it,
    so text, x and arrow each own their space and all stay
    clickable. The helper owns the button's visibility: shown
    exactly when the field holds a value and is editable."""

    SLOT = 24
    SIZE = 20

    def __init__(self, edit, btn):
        super().__init__(edit)
        self._edit = edit
        self._btn = btn
        edit._inline_clear = self
        edit.installEventFilter(self)
        btn.installEventFilter(self)
        try:
            edit.dateChanged.connect(self._sync)
        except Exception:
            pass
        QTimer.singleShot(0, self._sync)

    def _has_value(self):
        try:
            return self._edit.date() > self._edit.minimumDate()
        except Exception:
            return False

    def _sync(self):
        edit, btn = self._edit, self._btn
        if edit.width() <= 0:
            return
        le = edit.lineEdit()
        if le is not None:
            zone = edit.width() - le.geometry().right() - 1
        else:
            zone = 24
        zone = max(0, zone)
        x = edit.width() - zone - self.SLOT + (self.SLOT - self.SIZE) // 2
        y = max(0, (edit.height() - self.SIZE) // 2)
        btn.setGeometry(x, y, self.SIZE, self.SIZE)
        btn.setVisible(self._has_value() and edit.isEnabled()
                       and not edit.isReadOnly())

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        if event.type() in (QEvent.Resize, QEvent.Show,
                            QEvent.EnabledChange, QEvent.ReadOnlyChange):
            QTimer.singleShot(0, self._sync)
        return False


def _inline_date_clear(edit, tooltip="Clear the date"):
    """Build the inline clear x for a date edit (see
    _InlineDateClear). Returns the button; callers connect its
    clicked signal exactly as they did the old beside-field
    button, and may keep a reference under the old attribute
    names (due_clear / remind_clear)."""
    btn = QPushButton(edit)
    btn.setObjectName("iconBtn")
    btn.setIcon(svg_icon("x", "#8a919c", 12))
    btn.setIconSize(QSize(12, 12))
    btn.setFixedSize(_InlineDateClear.SIZE, _InlineDateClear.SIZE)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setFocusPolicy(Qt.NoFocus)
    btn.setToolTip(tooltip)
    btn.setVisible(False)
    _InlineDateClear(edit, btn)
    return btn


def _ensure_date_text_fits(edit):
    """Grow a centred date field until its longest possible text
    fits beside the centring margin. The margin that centres the
    text is exactly what clips it when the field is sized to the
    bare text (V1.9.50: the New Task due field showed "o due
    date" -- the No was eaten by the margin). Measures the
    special-value text plus the longest date the field's own
    format can produce; only ever grows the field."""
    try:
        le = edit.lineEdit()
        if le is None:
            return
        fm = edit.fontMetrics()
        samples = []
        try:
            sv = edit.specialValueText()
            if sv:
                samples.append(sv)
        except Exception:
            pass
        fmt = edit.displayFormat()
        for month in range(1, 13):
            samples.append(QDate(2026, month, 28).toString(fmt))
            samples.append(QDate(2026, month, 9).toString(fmt))
        text_w = max(fm.horizontalAdvance(s) for s in samples if s)
        # Measure against the GEOMETRIC button zone, not the
        # current margin: the margin can be transiently stale
        # (see _ComboTextCenterer), and sizing from a stale
        # margin ratchets the field wider for no reason.
        # V1.9.51: the inline clear's slot eats text room on
        # BOTH sides of the centred text -- the left margin
        # grows by the slot and the right margin IS the slot --
        # so the deduction is the zone plus TWICE the slot.
        # (First cut counted it once: the date overflowed its
        # box, slid right off centre, and touched the x.)
        margin = (edit.width() - le.width()
                  - 2 * le.geometry().x()
                  + (2 * _InlineDateClear.SLOT
                     if getattr(edit, "_inline_clear", None) is not None
                     else 0))
        avail = le.width() - max(0, margin)
        if avail < text_w + 6:
            edit.setFixedWidth(edit.width() + (text_w + 6 - avail))
    except Exception:
        pass


def optically_center_date_edit(edit):
    """Centre a QDateEdit's text on the WHOLE field (V1.9.48).

    The user's screenshot: "11/11/2026" sat hard against the
    left of its field with the calendar button on the right --
    the spinbox centres (at best) inside its line edit, which
    excludes the button zone, so the date reads shifted left.
    Same cure as the combos: a left text margin equal to the
    button zone puts the date's centre on the field's centre.
    The margin machinery is _ComboTextCenterer (duck-typed on
    lineEdit()/width())."""
    le = edit.lineEdit()
    if le is not None:
        le.setAlignment(Qt.AlignCenter)
    edit._text_centerer = _DateTextCenterer(edit)
    return edit


class _DateTextCenterer(_ComboTextCenterer):
    """Date-edit centerer (V1.9.49). The plain centerer CLIPPED
    the reminder date on the user's machine ("Nov 16, 202" --
    his screenshot): a spinbox's width is sized to just fit
    its format text, so the centring margin had nowhere to
    come from and ate the text itself. This variant WIDENS
    the field by the button zone once, before the margin is
    applied, so the full date always fits AND sits centred;
    a host window exposing _refit_dhp is re-fitted a tick
    later so a fitted column grows with its editor.

    V1.9.51: when the edit carries the inline clear x, the
    field also widens by the x's slot and the text margins
    grow symmetrically (left += slot, right = slot), so the
    date keeps its proven centre and never slides under the
    x -- the slot is reserved space on both sides of the text."""

    def _slot(self):
        return (_InlineDateClear.SLOT
                if getattr(self._combo, "_inline_clear", None) is not None
                else 0)

    def _sync(self):
        super()._sync()
        slot = self._slot()
        if slot:
            edit = self._combo
            le = edit.lineEdit()
            if le is None or edit.width() <= 0 or le.width() <= 0:
                return
            zone = (edit.width() - le.width()
                    - 2 * le.geometry().x())
            le.setTextMargins(max(0, zone) + slot, 0, slot, 0)

    def _pin(self):
        if self._pinned:
            return
        self._pinned = True
        edit = self._combo
        le = edit.lineEdit()
        if le is None or edit.width() <= 0 or le.width() <= 0:
            return
        zone = (edit.width() - le.width()
                - 2 * le.geometry().x())
        grow = zone + self._slot()
        if grow > 0:
            edit.setFixedWidth(edit.width() + grow)
            win = edit.window()

            def _refit(_w=win):
                try:
                    fn = getattr(_w, "_refit_dhp", None)
                    if fn is not None:
                        fn()
                except Exception:
                    pass

            QTimer.singleShot(0, _refit)


class _PopupExactFit(QObject):
    """The global popup exact-fit (V1.9.48, user: "THAT ISSUE
    AGAIN NEEDS TO BE FIXED GLOBALLY AND FOREVER").

    Qt sizes the QCompleter popup from row-height estimates
    that never match the real delegate heights: with TWO
    suggestions the popup came out 4px short in the viewport
    (a scrollbar for a 1px overflow) while the window was
    simultaneously too tall (a dead blank band under the last
    row). This filter applies the same measured snap the combo
    popup proved in V1.9.40/41 -- after the popup shows or is
    resized, the window height is corrected by the MEASURED
    gap between the viewport and the last row's bottom, and
    the scrollbar is switched off entirely whenever every row
    fits. A popup whose rows all fit can then never show a
    scrollbar or dead space, by construction."""

    def __init__(self, view, max_rows, parent=None):
        super().__init__(parent)
        self._view = view
        self._max_rows = max_rows
        self._pending = False
        self._snapped = None  # (rows, window height) of last snap
        view.installEventFilter(self)

    def eventFilter(self, obj, event):  # noqa: N802 (Qt name)
        if event.type() in (QEvent.Show, QEvent.Resize):
            self._schedule()
        return False

    def _schedule(self):
        if not self._pending:
            self._pending = True
            QTimer.singleShot(0, self._refit)

    def _refit(self):
        self._pending = False
        view = self._view
        if view is None or not view.isVisible():
            return
        model = view.model()
        if model is None:
            return
        rows = model.rowCount()
        if rows == 0:
            return
        if rows > self._max_rows:
            view.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            self._snapped = None
            return
        view.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        view.doItemsLayout()
        last = view.visualRect(model.index(rows - 1, 0))
        if not last.isValid():
            return
        leftover = view.viewport().height() - (last.bottom() + 1)
        if leftover == 0:
            return
        win = view.window()
        new_h = win.height() - leftover
        # V1.9.54 (image-442 root cause): the memo may only skip
        # when the window is ALREADY at the snapped height.
        # QCompleter re-sizes the popup back to its own estimate
        # between keystrokes; the old memo compared only against
        # its own history, so the corrective resize was skipped
        # and the popup stayed a few px short forever (last row
        # clipped, scrollbar forbidden -- unrecoverable).
        if self._snapped == (rows, new_h) and win.height() == new_h:
            return
        self._snapped = (rows, new_h)
        win.resize(win.width(), new_h)


class _GlassCompleterView(QListView):
    """The contact completer's popup, as the app's own glass
    (V1.9.54, image-442).

    The stock completer popup was the last non-glass popup in
    the app: an opaque square-cornered window whose selection
    painted as a filled gray slab -- it never received the
    _GlassComboPopup treatment because it is not a combo.
    QCompleter accepts an owned view via setPopup(); this one
    follows the combo popup's recipe exactly: translucent
    window, the rounded window MASK (the corner guarantee that
    does not depend on compositing), frost + tint + rim painted
    by the view itself, and _ComboPopupDelegate so the current
    row is an outline, never a fill. Height still comes from
    _PopupExactFit (the global exact-fit rule)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("completerPopup")
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFrameShape(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setStyleSheet(
            "QListView { background: transparent; border: none; }")
        self.viewport().setAutoFillBackground(False)
        self.setItemDelegate(_ComboPopupDelegate(self))
        self.setMouseTracking(True)
        self._mask_filter = _PopupMaskFilter(self)
        self.installEventFilter(self._mask_filter)
        # The glass is painted on the VIEWPORT (see eventFilter):
        # a scroll area's own paintEvent has no usable painter
        # ("Paint device returned engine == 0") -- that is why
        # _GlassComboPopup paints on its frame instead. Here the
        # view IS the window, so the viewport is the surface.
        self.viewport().installEventFilter(self)

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        # QCompleter.setPopup replaces the view's delegate with
        # a stock QStyledItemDelegate; re-assert the outline
        # delegate at show time so the selection can never fall
        # back to a filled slab.
        if not isinstance(self.itemDelegate(), _ComboPopupDelegate):
            self.setItemDelegate(_ComboPopupDelegate(self))
        capture_frost(self)
        super().showEvent(event)

    def eventFilter(self, watched, event):  # noqa: N802
        if watched is self.viewport() \
                and event.type() == QEvent.Paint:
            # The same glass recipe as _GlassComboPopup: ONLY
            # the rounded glass shape, painted first; the event
            # then continues and the items draw over it.
            painter = QPainter(self.viewport())
            painter.setRenderHint(QPainter.Antialiasing, True)
            fill, rim = glass_colors()
            fill = QColor(fill)
            if paint_frost(self, painter, _GLASS_RADIUS):
                fill.setAlpha(140)
            else:
                fill.setAlpha(150)
            path = QPainterPath()
            path.addRoundedRect(QRectF(self.rect()),
                                _GLASS_RADIUS, _GLASS_RADIUS)
            painter.setPen(Qt.NoPen)
            painter.setBrush(fill)
            painter.drawPath(path)
            rim_path = QPainterPath()
            rim_path.addRoundedRect(
                QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
                _GLASS_RADIUS - 0.5, _GLASS_RADIUS - 0.5)
            painter.setPen(QPen(rim, 1))
            painter.setBrush(Qt.NoBrush)
            painter.drawPath(rim_path)
            painter.end()
        return super().eventFilter(watched, event)


def attach_contact_completer(edit, db, kind):
    """Suggest saved distributor/end-user names as the user types.

    Matches anywhere in the name (not just the start), case-insensitively,
    so existing spellings stay consistent without re-typing. Distributor
    suggestions pin the most-quoted distributors (last 180 days) above a
    muted separator, then list the rest alphabetically.
    """
    if kind == "distributor":
        model = _distributor_completion_model(db, edit)
        completer = PinnedCompleter(model, edit)
    else:
        model = QStringListModel(db.directory_names(kind), edit)
        completer = QCompleter(model, edit)
    completer.setCaseSensitivity(Qt.CaseInsensitive)
    completer.setFilterMode(Qt.MatchContains)
    completer.setCompletionMode(QCompleter.PopupCompletion)
    completer.setMaxVisibleItems(10)
    # V1.9.54 (image-442): the completer shows the app's own
    # glass view instead of Qt's opaque stock popup.
    completer.setPopup(_GlassCompleterView(edit))
    completer.popup().setObjectName("completerPopup")
    # V1.9.48: the global exact-fit (see _PopupExactFit) -- the
    # completer popup can never show a scrollbar or a dead band
    # under the last row when every match fits.
    completer._exact_fit = _PopupExactFit(
        completer.popup(), completer.maxVisibleItems(),
        completer.popup())
    edit.setCompleter(completer)
    return completer


# ---------------------------------------------------------------- merge dialog
class MergeContactsDialog(QDialog):
    """Merge one CRM entry into another (for duplicate names)."""

    def __init__(self, db, kind, loser_id, loser_name, parent=None):
        super().__init__(parent)
        self.db = db
        self._kind = kind
        self._loser_id = loser_id
        self.setModal(True)
        self.setMinimumWidth(430)
        layout = install_chrome(self, "Merge Contact")

        lab = QLabel(f"Merge “{loser_name}” into:")
        lab.setObjectName("sectionLabel")
        lab.setWordWrap(True)
        layout.addWidget(lab)
        hint = QLabel(
            "Every task pointing at the merged contact is re-pointed at the "
            "survivor, then the merged contact is removed. "
            "This cannot be undone.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self._combo = SafeComboBox()
        others = [e for e in db.directory_list(kind) if e["id"] != loser_id]
        for e in others:
            self._combo.addItem(f"{e['name']} ({e['task_count']} tasks)",
                                e["id"])
        layout.addWidget(self._combo)

        layout.addStretch(1)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        merge_btn = QPushButton("Merge")
        merge_btn.setObjectName("primary")
        merge_btn.setEnabled(bool(others))
        merge_btn.clicked.connect(self._on_merge)
        row.addWidget(cancel)
        row.addWidget(merge_btn)
        layout.addLayout(row)

    def _on_merge(self):
        survivor_id = self._combo.currentData()
        name = self._combo.currentText()
        if not app_confirm(
            self, "Merge contacts",
            f"Merge into “{name}”?\nAll of its tasks will be re-pointed.",
            confirm_label="Merge"):
            return
        if self.db.directory_merge(self._kind, self._loser_id, survivor_id):
            self.accept()
        else:
            show_toast(self, "error", "Merge failed",
                       "Could not merge these contacts.")


# ------------------------------------------------------------------ CRM page
# The CRM listing is a table with the same typographic treatment as the
# dashboard Distributor Performance table: 13pt Inter body, demi-bold
# names, tracked-out uppercase 10pt headers. No monogram tiles, no
# pills — secondary facts live in their own columns.


class _DirSortItem(QTableWidgetItem):
    """Table cell whose sort order comes from a numeric key, not its text.

    Used for the TASKS count and LAST QUOTED columns so they sort by
    value (ISO datestamps order chronologically as strings) instead of
    alphabetically.
    """

    def __init__(self, text, sort_key):
        super().__init__(text)
        self._sort_key = sort_key

    def __lt__(self, other):
        if isinstance(other, _DirSortItem):
            return self._sort_key < other._sort_key
        return super().__lt__(other)


def _crm_table_font(point_size=13, weight=QFont.Normal):
    f = app_font()
    f.setPointSize(point_size)
    f.setWeight(weight)
    return f


# Same table chrome as the dashboard Distributor Performance table
# (mirrors the table rules in dashboard.py's _DASH_QSS; duplicated here
# so the CRM page doesn't import the dashboard module).
_DATA_TABLE_QSS = """
QTableWidget#dashTable {
    background: #0e0f12; border: 1px solid #23252b;
    border-radius: 12px; gridline-color: #1d1f24;
}
QTableWidget#dashTable::item { padding: 10px 8px; color: #d5d9e0; border: none; }
QTableWidget#dashTable::item:selected { background: #1a2c4e; color: #ffffff; }
QTableWidget#dashTable::item:hover:!selected { background: #1b1e24; }
QTableWidget#dashTable QTableCornerButton::section {
    background: #141518; border: none;
}
QHeaderView#dashHeader::section {
    background: #141518; color: #9ba1ab; border: none;
    border-right: 1px solid #1d1f24; padding: 12px 10px;
    font-size: 12px; font-weight: 700;
}
QHeaderView#dashHeader::section:first {
    border-top-left-radius: 12px;
}
QHeaderView#dashHeader::section:last {
    border-top-right-radius: 12px;
}
QHeaderView#dashHeader {
    background: #141518;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}
QTableWidget#dashTable QTableCornerButton::section {
    border-top-left-radius: 12px;
}
"""

_DATA_TABLE_QSS_LIGHT = """
QTableWidget#dashTable {
    background: #ffffff; border: 1px solid #e3e4e6;
    border-radius: 12px; gridline-color: #e3e4e6;
}
QTableWidget#dashTable::item { padding: 10px 8px; color: #1c1f24; border: none; }
QTableWidget#dashTable::item:selected { background: #e3e9f2; color: #1c1f24; }
QTableWidget#dashTable::item:hover:!selected { background: #ececee; }
QTableWidget#dashTable QTableCornerButton::section {
    background: #ffffff; border: none;
}
QHeaderView#dashHeader::section {
    background: #f7f7f8; color: #474c54; border: none;
    border-right: 1px solid #e3e4e6; padding: 12px 10px;
    font-size: 12px; font-weight: 700;
}
QHeaderView#dashHeader::section:first {
    border-top-left-radius: 12px;
}
QHeaderView#dashHeader::section:last {
    border-top-right-radius: 12px;
}
QHeaderView#dashHeader {
    background: #f7f7f8;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}
QTableWidget#dashTable QTableCornerButton::section {
    border-top-left-radius: 12px;
}
"""


def data_table_qss():
    """Directory table chrome for the active theme (mirrors dashboard).

    V1.9.16: the sheet is accent-shifted like dash_qss() — before this
    the selection stayed hardcoded blue (#1a2c4e/#8fb4ff) no matter what
    accent the user picked, because this string never passed through
    the shift that the dashboard sheet gets.
    """
    from .themes import apply_accent_shift
    if saved_theme() == "light":
        return apply_accent_shift(_DATA_TABLE_QSS_LIGHT)
    return apply_accent_shift(_DATA_TABLE_QSS)


def _track_label(lbl):
    """112% letter-spacing, matching the dashboard's dashSection labels."""
    f = lbl.font()
    f.setLetterSpacing(QFont.PercentageSpacing, 112)
    lbl.setFont(f)


def _style_directory_table(table):
    """Mirror the dashboard Distributor Performance table's styling onto a
    CRM table: 13pt Inter body rows, demi-bold names set per-cell, and
    tracked uppercase 10pt headers. Same object names as the dashboard
    table so the chrome matches exactly."""
    table.setObjectName("dashTable")
    table.horizontalHeader().setObjectName("dashHeader")
    table.setStyleSheet(data_table_qss())
    table.setFont(_crm_table_font(13))
    table.verticalHeader().setDefaultSectionSize(46)
    hdr_font = _crm_table_font(10, QFont.DemiBold)
    hdr_font.setLetterSpacing(QFont.PercentageSpacing, 110)
    table.horizontalHeader().setFont(hdr_font)


# V1.9.16: CRM name-column floor — the name column gets at least
# this much room, taken from the notes column's stretch share.
_CRM_NAME_MIN_WIDTH = 380


class _DirectoryRowDelegate(QStyledItemDelegate):
    """CRM rows: full-row hover + no inner focus box.

    V1.9.17 (user screenshots): hovering a directory row lit only the
    hovered CELL, while a click lit the whole row; and a clicked row
    kept a second inner box (the current-cell focus rect) inside the
    selection. Qt stylesheets cannot paint row hover, so the delegate
    fills the whole row rect with the hover tone when the mouse is
    over any cell of that row, and strips State_HasFocus before the
    base paint so no inner box ever draws.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._hover_row = -1

    @staticmethod
    def _without_focus(state):
        return state & ~QStyle.State_HasFocus

    def paint(self, painter, option, index):
        if index.row() == self._hover_row and not (
                option.state & QStyle.State_Selected):
            dark = saved_theme() != "light"
            painter.save()
            painter.fillRect(option.rect,
                             QColor("#1b1e24" if dark else "#ececee"))
            painter.restore()
        opt = QStyleOptionViewItem(option)
        opt.state = self._without_focus(opt.state)
        super().paint(painter, opt, index)


class DirectoryPage(QWidget):
    """CRM: saved end users & distributors with a kind toggle."""

    # V1.9.51: re-emitted whenever any contact card opened from
    # here reports a change, so the main window (task list, cards,
    # dashboard) refreshes immediately -- a rename used to reach
    # the task views only when some unrelated action refreshed
    # them (the user's "it updated eventually, glitchy, random").
    directory_changed = Signal()

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.kind = "distributor"
        self._filter = ""
        self._detail_windows = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 16, 24, 18)
        layout.setSpacing(10)
        # Dashboard language: no big title — a quiet letter-spaced section
        # label sits directly above the table (like "DISTRIBUTOR
        # PERFORMANCE"), with the controls row above that.
        self.setStyleSheet(
            "QLabel#dirSection { color: #6b7078; font-size: 11px; "
            "font-weight: 700; }")

        controls = QHBoxLayout()
        controls.setSpacing(10)
        # V1.9.52 (user): the kind switcher is TABS like every
        # other module — the shared Chrome tab strip (same build,
        # same slide), not another pill control with its own look.
        # _kind_buttons stays as the kind -> tab-button map the
        # rest of the page (and the test gates) read.
        self._kind_tabs = _ChromeTabBar()
        self._kind_buttons = {}
        for k in DIRECTORY_KINDS:
            self._kind_buttons[k] = self._kind_tabs.add_tab(
                DIRECTORY_LABELS[k])
        self._kind_tabs.currentChanged.connect(self._on_kind_tab)
        self._kind_tabs.slideFinished.connect(self._apply_pending_kind)
        controls.addWidget(self._kind_tabs)

        search_box = QVBoxLayout()
        search_box.setContentsMargins(0, 0, 0, 0)
        search_box.setSpacing(3)
        self.search_count = CountLabel()
        search_box.addWidget(self.search_count)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter names…")
        self.search.setClearButtonEnabled(True)
        # V1.9.47 (user): about twice as wide as it was -- a cap
        # alone changed nothing (the layout only ever gave the
        # field its ~150px hint), so it gets a real floor too.
        self.search.setMinimumWidth(340)
        self.search.setMaximumWidth(520)
        self.search.textChanged.connect(self._on_filter)
        search_box.addWidget(self.search)
        controls.addLayout(search_box)
        controls.addStretch(1)

        self.add_btn = QPushButton("+ Add Distributor")
        self.add_btn.setObjectName("ghost")
        self.add_btn.setCursor(Qt.PointingHandCursor)
        self.add_btn.clicked.connect(self._on_add)
        controls.addWidget(self.add_btn)
        layout.addLayout(controls)

        # Section label row, dashboard-style: quiet caps label on the left,
        # the totals/open-work counts on the right in the same treatment.
        label_row = QHBoxLayout()
        label_row.setSpacing(10)
        self._kind_label = QLabel()
        self._kind_label.setObjectName("dirSection")
        _track_label(self._kind_label)
        self._kind_label.setText(DIRECTORY_LABELS[self.kind].upper())
        label_row.addWidget(self._kind_label)
        label_row.addStretch(1)
        self.kpi_label = QLabel()
        self.kpi_label.setObjectName("dirSection")
        label_row.addWidget(self.kpi_label)
        layout.addLayout(label_row)

        # CRM listing: a table with the dashboard Distributor Performance
        # look. The notes column stretches; the rest size to content. An
        # outer horizontal scroller takes over on narrow windows (a lone
        # Stretch column swallows Qt's own horizontal scrollbar).
        self._table = QTableWidget()
        _style_directory_table(self._table)
        # V1.9.34 (user: CRM column headers VANISHED in 1.9.33 --
        # "you fucked up all of the columns everywhere"): the drop-
        # indicator header is installed ONCE here, for the table's
        # whole life, carrying the dashHeader name + tracked font.
        # V1.9.33 installed a NEW header object inside
        # _setup_columns -- i.e. on every tab switch -- and repeated
        # header swaps collapse the header (height 0, headers gone)
        # and dropped its styled identity. _setup_columns now only
        # relabels/resizes the permanent header, like it did before
        # 1.9.33.
        self._table.setHorizontalHeader(
            DropIndicatorHeader(Qt.Horizontal, self._table))
        _dhdr = self._table.horizontalHeader()
        _dhdr.setObjectName("dashHeader")
        _dhfont = _crm_table_font(10, QFont.DemiBold)
        _dhfont.setLetterSpacing(QFont.PercentageSpacing, 110)
        _dhdr.setFont(_dhfont)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._table.setSortingEnabled(True)
        self._table.setShowGrid(False)
        self._table.verticalHeader().setVisible(False)
        self._table.setAlternatingRowColors(False)
        # V1.9.17: rows open on DOUBLE-click only. Single click selects.
        # (V1.9.16 fixed this for drilldowns but left the CRM tables on
        # single click.) Keyboard Enter/Space still opens via eventFilter.
        self._table.cellDoubleClicked.connect(self._on_row_activated)
        self._dir_delegate = _DirectoryRowDelegate(self._table)
        self._table.setItemDelegate(self._dir_delegate)
        self._table.setMouseTracking(True)
        self._table.viewport().setMouseTracking(True)
        self._table.installEventFilter(self)
        self._table.setContextMenuPolicy(Qt.CustomContextMenu)
        self._table.customContextMenuRequested.connect(self._on_row_menu)
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }")
        self._scroll.setWidget(self._table)
        # Table scrolls itself vertically; the outer area scrolls it
        # horizontally (wheel/scrollbar). V1.9.65: the outer area
        # no longer grabs the kinetic gesture -- nested scrollers
        # competed for the same drag and the barely-scrollable
        # outer area won, which is why pen scrolling did nothing
        # in the CRM. The table's scroller owns the drag.
        enable_touch_scroll(self._table)
        layout.addWidget(self._scroll, 1)

        self._empty = QLabel()
        self._empty.setObjectName("emptyState")
        self._empty.setAlignment(Qt.AlignCenter)
        self._empty.setVisible(False)
        layout.addWidget(self._empty, 1)

        # V1.9.16: user-sized columns survive refresh (see
        # _on_section_resized). _programmatic_resize guards the flag
        # while refresh() itself sizes columns, so only real drags
        # count as user sizing.
        self._user_sized = set()
        self._programmatic_resize = False
        # V1.9.49: column widths PERSIST (db setting, per kind).
        # Before this they lived only in _user_sized's memory --
        # every restart quietly reset the table to the auto-fit
        # (the user's "it is not saving my column sizing and
        # setups through updates and restarts").
        self._width_timer = QTimer(self)
        self._width_timer.setSingleShot(True)
        self._width_timer.setInterval(300)
        self._width_timer.timeout.connect(self._save_dir_widths)
        self._table.horizontalHeader().sectionResized.connect(
            self._on_section_resized)
        self._table.horizontalHeader().sectionMoved.connect(
            self._on_section_moved)
        self._setup_columns()
        self.refresh()
        _chip_font_tree(self)

    def _on_section_resized(self, logical, _old, _new):
        """A user drag-resized a column: remember it so refresh() stops
        auto-fitting that column. Programmatic resizes (refresh's own
        fitting) are guarded by _programmatic_resize and ignored."""
        if not self._programmatic_resize:
            self._user_sized.add(logical)
            self._width_timer.start()

    def _on_section_moved(self, *_):
        """V1.9.50: a user drag-moved a column -- column ORDER is
        part of the layout he owns (his global rule), so it
        persists per kind alongside the widths."""
        if not getattr(self, "_programmatic_resize", False):
            self._width_timer.start()

    def _save_dir_widths(self):
        """Persist this kind's user-sized widths (V1.9.49). The
        notes column is excluded: it stretches to whatever room
        is left, by design."""
        try:
            raw = self.db.get_setting("directory_widths_v1", "")
            all_w = json.loads(raw) if raw else {}
            t = self._table
            notes_col = t.columnCount() - 1
            all_w[self.kind] = {
                str(c): t.columnWidth(c)
                for c in sorted(self._user_sized)
                if 0 <= c < notes_col}
            self.db.set_setting("directory_widths_v1",
                                json.dumps(all_w))
        except Exception:
            pass
        try:
            raw_o = self.db.get_setting("directory_order_v1", "")
            all_o = json.loads(raw_o) if raw_o else {}
            hdr = self._table.horizontalHeader()
            all_o[self.kind] = [hdr.logicalIndex(v)
                                for v in range(hdr.count())]
            self.db.set_setting("directory_order_v1",
                                json.dumps(all_o))
        except Exception:
            pass

    def _restore_dir_widths(self):
        """Apply this kind's saved widths at the end of
        _setup_columns; restored columns count as user-sized so
        the auto-fit in refresh() leaves them alone."""
        self._user_sized = set()
        try:
            raw = self.db.get_setting("directory_widths_v1", "")
            saved = (json.loads(raw) if raw else {}).get(
                self.kind, {})
        except Exception:
            saved = {}
        if not saved:
            return
        t = self._table
        notes_col = t.columnCount() - 1
        self._programmatic_resize = True
        try:
            for key, w in saved.items():
                c = int(key)
                if 0 <= c < notes_col and int(w) > 20:
                    t.setColumnWidth(c, int(w))
                    self._user_sized.add(c)
        finally:
            self._programmatic_resize = False

    def _on_kind_tab(self, index):
        """Tab strip switched kinds (V1.9.52)."""
        if 0 <= index < len(DIRECTORY_KINDS):
            kind = DIRECTORY_KINDS[index]
            # V1.9.65 (user: the CRM tab animation is "STILL
            # FUCKING GLITCHING AND JUMPING AROUND RATHER THAN A
            # SMOOTH ANIMATION LIKE THE OTHER MODULES"): the
            # V1.9.61 one-tick deferral still landed the
            # synchronous set_kind rebuild INSIDE the 180ms
            # glide on his Surface and froze it mid-slide. The
            # content swap now waits for the bar's slideFinished
            # signal -- the glide runs to completion on a free
            # loop, THEN the table rebuilds. The pending kind is
            # always recorded, so clicking back to the current
            # kind mid-glide cancels the swap.
            self._pending_kind = kind
            if kind == self.kind:
                return
            if not getattr(self._kind_tabs, "_sliding", False):
                QTimer.singleShot(0, self._apply_pending_kind)

    def _apply_pending_kind(self):
        kind = getattr(self, "_pending_kind", None)
        self._pending_kind = None
        if kind is not None and kind != self.kind:
            self.set_kind(kind)

    def set_kind(self, kind):
        if kind not in DIRECTORY_KINDS:
            return
        # V1.9.51: no CONTENT slide on a kind switch anymore --
        # tab switches everywhere are the silhouette slide plus an
        # instant content swap (the contact window's pattern, which
        # the user held up as the correct one). The V1.9.18
        # slide-the-table layer underneath read as glitch.
        # V1.9.49: flush any pending width save under the OLD
        # kind before the switch rebuilds the table.
        try:
            if self._width_timer.isActive():
                self._width_timer.stop()
                self._save_dir_widths()
        except Exception:
            pass
        self.kind = kind
        self._kind_tabs.setCurrentIndex(DIRECTORY_KINDS.index(kind))
        self.add_btn.setText(f"+ Add {DIRECTORY_SINGULAR[kind]}")
        self._kind_label.setText(DIRECTORY_LABELS[kind].upper())
        self._setup_columns()
        self.refresh()

    def refresh_theme(self):
        """Re-apply directory table chrome for the active theme."""
        self._table.setStyleSheet(data_table_qss())

    def _on_filter(self, text):
        self._filter = text.strip().lower()
        self.refresh()

    def _setup_columns(self):
        """Column headers per kind; the notes column stretches, the name
        column is Interactive with a 380px floor enforced in refresh()
        (V1.9.16), and every column is user-resizable and re-orderable
        (V1.9.16): sections are Interactive + movable, and refresh()
        only auto-fits columns the user has never dragged."""
        t = self._table
        t.setSortingEnabled(False)
        t.clear()
        t.setRowCount(0)
        if self.kind == "distributor":
            headers = ["DISTRIBUTOR", "LOCATION", "TASKS", "TOTAL VALUE",
                       "LAST QUOTED", "STATUS", "NOTES"]
        elif self.kind == "contact":
            # V1.9.30: same columns as Distributors. V1.9.34 (user):
            # plus COMPANY right after the name — a bare contact name
            # ("who the hell is Seth?") is useless without the company
            # the contact is linked to.
            headers = ["CONTACT NAME", "COMPANY", "LOCATION", "TASKS",
                       "TOTAL VALUE", "LAST QUOTED", "STATUS", "NOTES"]
        elif self.kind == "sales_rep":
            # V1.9.30 (user): the new CRM tabs carry the SAME columns
            # as Distributors -- name, location, tasks, total value,
            # last quoted, status, notes. (V1.9.29's WON VALUE column
            # was my substitution, not his spec.)
            headers = [DIRECTORY_SINGULAR[self.kind].upper(),
                       "LOCATION", "TASKS", "TOTAL VALUE",
                       "LAST QUOTED", "STATUS", "NOTES"]
        else:
            headers = ["END USER", "LOCATION", "TASKS", "TOTAL VALUE",
                       "LAST QUOTED", "SDC", "NOTES"]
        t.setColumnCount(len(headers))
        t.setHorizontalHeaderLabels(headers)
        # V1.9.34: the header OBJECT is permanent (installed once
        # in __init__ with its dashHeader identity); this method
        # only relabels it and sets section modes -- it must never
        # swap the header again (see the __init__ note).
        hdr = t.horizontalHeader()
        hdr.setSectionsMovable(True)
        notes_col = len(headers) - 1
        for c in range(len(headers)):
            if c == notes_col:
                hdr.setSectionResizeMode(c, QHeaderView.Stretch)
            else:
                hdr.setSectionResizeMode(c, QHeaderView.Interactive)
        hdr.setStretchLastSection(False)
        t.setSortingEnabled(True)
        # V1.9.49: this kind's saved widths come back (and count
        # as user-sized, so refresh's auto-fit leaves them be).
        self._restore_dir_widths()
        # V1.9.50: ...and its saved column order.
        self._restore_dir_order()

    def _restore_dir_order(self):
        """Apply this kind's saved column order at the end of
        _setup_columns (V1.9.50: order persists like widths do --
        his global column rule covers both)."""
        try:
            raw = self.db.get_setting("directory_order_v1", "")
            order = (json.loads(raw) if raw else {}).get(
                self.kind, [])
        except Exception:
            order = []
        if not order:
            return
        t = self._table
        if len(order) != t.columnCount():
            return
        hdr = t.horizontalHeader()
        self._programmatic_resize = True
        try:
            for visual, logical in enumerate(order):
                logical = int(logical)
                if 0 <= logical < t.columnCount():
                    cur = hdr.visualIndex(logical)
                    if cur != visual:
                        hdr.moveSection(cur, visual)
        finally:
            self._programmatic_resize = False

    def refresh(self):
        entries = self.db.directory_list(self.kind)
        if self._filter:
            entries = [e for e in entries if self._filter in e["name"].lower()]
        self._entries = entries
        n = len(entries)
        self.search_count.set_count(
            f"{n} result{'s' if n != 1 else ''}" if self._filter else ""
        )
        self._refresh_kpi(entries)
        t = self._table
        t.setSortingEnabled(False)
        if not entries:
            t.setRowCount(0)
            self._scroll.setVisible(False)
            label = DIRECTORY_LABELS[self.kind].lower()
            if self._filter:
                text = f"No {label} match “{self.search.text().strip()}”."
            else:
                text = (
                    f"No {label} yet.\n"
                    f"Add one above, or save a task with a {DIRECTORY_SINGULAR[self.kind].lower()}."
                )
            self._empty.setText(text)
            self._empty.setVisible(True)
            return
        self._empty.setVisible(False)
        self._scroll.setVisible(True)
        dark = saved_theme() != "light"
        t.setRowCount(len(entries))
        for row, entry in enumerate(entries):
            self._fill_row(row, entry, dark)
        # V1.9.17: one width per column, identical on both tabs (see
        # _union_column_widths) — the old per-kind auto-fit let the
        # same columns land at different widths on the two tabs.
        # User-sized columns keep the width they dragged to.
        self._content_widths = self._union_column_widths()
        self._apply_column_widths()
        # No current-row box on open: nothing is current until the user
        # clicks, so no lone highlighted cell paints on a fresh table.
        t.setCurrentIndex(QModelIndex())
        # V1.9.48 (user: a horizontal scrollbar "as default", columns
        # that cannot be resized or moved, the result count clipped
        # at the window edge): the old code set the table's MINIMUM
        # width to the full content sum, so the outer scroller forced
        # the whole page wider than the window on any narrower
        # machine and header drags fought the scroller's geometry.
        # The minimum is GONE -- columns now FIT the viewport by
        # default (see _apply_column_widths) and only overflow when
        # the user drags them wider himself.
        t.setMinimumWidth(0)
        t.setSortingEnabled(True)

    def _union_column_widths(self):
        """One width per column, identical on both tabs.

        V1.9.17 (user report): distributor and end-user columns sized
        independently, so the same columns landed at different widths.
        Measure header + cell text for BOTH kinds with the table fonts
        and take the max per column; the name column keeps its 380px
        floor. STATUS and SDC share column 5, so they share a width.
        """
        headers = {
            "distributor": ["DISTRIBUTOR", "LOCATION", "TASKS",
                            "TOTAL VALUE", "LAST QUOTED", "STATUS",
                            "NOTES"],
            "customer": ["END USER", "LOCATION", "TASKS", "TOTAL VALUE",
                         "LAST QUOTED", "SDC", "NOTES"],
        }
        hdr_fm = QFontMetrics(_crm_table_font(10, QFont.DemiBold))
        cell_fm = QFontMetrics(_crm_table_font(13))
        name_fm = QFontMetrics(_crm_table_font(13, QFont.DemiBold))
        widths = [0] * 7
        for kind, hdrs in headers.items():
            for c, h in enumerate(hdrs):
                widths[c] = max(widths[c],
                                hdr_fm.horizontalAdvance(h) + 34)
            try:
                entries = self.db.directory_list(kind)
            except Exception:
                entries = []
            for e in entries:
                texts = [
                    e.get("name") or "",
                    format_location(e),
                    str(e.get("task_count") or 0),
                    format_price(e.get("total_value") or 0)
                    if e.get("total_value") else "—",
                    "Sep 23",  # last-quoted shape; header floor covers it
                    "Gone quiet" if kind == "distributor" else "Est. SDC A",
                ]
                for c, txt in enumerate(texts):
                    fm = name_fm if c == 0 else cell_fm
                    widths[c] = max(widths[c],
                                    fm.horizontalAdvance(txt) + 28)
        widths[0] = max(widths[0], _CRM_NAME_MIN_WIDTH)
        if self.kind == "contact":
            # V1.9.34: the COMPANY column (index 1) sizes to the
            # widest linked-company list among the contacts.
            comp_w = hdr_fm.horizontalAdvance("COMPANY") + 34
            try:
                contacts = self.db.directory_list("contact")
            except Exception:
                contacts = []
            for e in contacts:
                try:
                    names = ", ".join(
                        c["name"] for c in
                        self.db.directory_companies(e["id"]))
                except Exception:
                    names = ""
                if names:
                    comp_w = max(comp_w,
                                 cell_fm.horizontalAdvance(names) + 28)
            widths.insert(1, comp_w)
        return widths

    # V1.9.48: per-column floors for the fit pass (a column never
    # auto-shrinks below its floor; the notes column is the stretch
    # column and is handled separately).
    _FIT_FLOORS = {0: 230, 1: 150, 2: 92, 3: 70, 4: 100, 5: 100,
                   6: 100, 7: 110}

    def _apply_column_widths(self):
        """Set the non-notes column widths: content widths by
        default, the user's own dragged widths where he set them --
        then, if the total would overflow the viewport, shrink the
        widest auto columns toward their floors until it fits.
        A horizontal scrollbar by default is a defect, not a
        layout; it may only appear from the user's own widening."""
        t = self._table
        widths = getattr(self, "_content_widths", None)
        if not widths or t.columnCount() == 0:
            return
        notes_col = t.columnCount() - 1
        avail = 0
        try:
            avail = self._scroll.viewport().width()
        except Exception:
            avail = 0
        if avail <= 0:
            avail = t.viewport().width()
        target = {}
        for c in range(t.columnCount()):
            if c == notes_col:
                continue
            if c in self._user_sized:
                target[c] = t.columnWidth(c)
            elif c < len(widths):
                target[c] = widths[c]
        if avail > 0:
            budget = avail - 130  # the notes column's useful minimum
            total = sum(target.values())
            while total > budget:
                # shrink the auto column with the most room above
                # its floor; user-sized columns are never touched
                cand = None
                best = 0
                for c, w in target.items():
                    if c in self._user_sized:
                        continue
                    room = w - self._FIT_FLOORS.get(c, 80)
                    if room > best:
                        best = room
                        cand = c
                if cand is None:
                    break
                take = min(best, total - budget)
                target[cand] -= take
                total -= take
        self._programmatic_resize = True
        try:
            for c, w in target.items():
                t.setColumnWidth(c, w)
        finally:
            self._programmatic_resize = False

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        # A narrower window (or the Surface's smaller screen) must
        # re-fit the auto columns; user-dragged widths stay his.
        if getattr(self, "_content_widths", None):
            QTimer.singleShot(0, self._apply_column_widths)

    def _refresh_kpi(self, entries):
        """v1.4.0 item 13: slim KPI strip.

        'N distributors · M with open work · K gone quiet'. The quiet
        count uses the nudge system (distributors only); end users show
        just totals + open work.
        """
        from .db import DIRECTORY_TASK_COLUMN, OPEN_STATUSES
        total = len(entries)
        label = DIRECTORY_LABELS[self.kind].lower()
        # Names (lowercased) with at least one open-status task.
        col = DIRECTORY_TASK_COLUMN[self.kind]
        placeholders = ", ".join("?" * len(OPEN_STATUSES))
        open_names = set()
        try:
            for r in self.db.conn.execute(
                f"SELECT DISTINCT LOWER({col}) FROM tasks "
                f"WHERE status IN ({placeholders}) "
                f"AND TRIM(COALESCE({col}, '')) <> ''",
                OPEN_STATUSES,
            ).fetchall():
                open_names.add(r[0])
        except Exception:
            pass
        entry_names = { (e["name"] or "").lower() for e in entries }
        with_open = sum(1 for nm in entry_names if nm in open_names)
        bits = [f"{total} {label}", f"{with_open} with open work"]
        self._quiet_names = set()
        if self.kind == "distributor":
            try:
                for nudge in self.db.nudge_candidates():
                    self._quiet_names.add((nudge["name"] or "").lower())
            except Exception:
                pass
            quiet = sum(1 for nm in entry_names if nm in self._quiet_names)
            bits.append(f"{quiet} gone quiet")
        self.kpi_label.setText("  ·  ".join(bits))

    def _fill_row(self, row, entry, dark):
        """One table row: demi-bold name, then location / task count /
        last-quoted / status-or-SDC / notes in plain columns. No monograms,
        no pills — the dashboard Distributor Performance look."""
        from .seismic import parse_location
        t = self._table
        inactive = (entry.get("status") or "active").lower() == "inactive"
        name_item = QTableWidgetItem(entry["name"])
        name_item.setFont(_crm_table_font(13, QFont.DemiBold))
        name_item.setData(Qt.UserRole, entry["id"])
        name_item.setToolTip("View contact details")
        if inactive:
            name_item.setForeground(QColor("#6b7078"))
        t.setItem(row, 0, name_item)

        # V1.9.34: contacts carry a COMPANY column (index 1); every
        # later column shifts by one on that tab.
        off = 1 if self.kind == "contact" else 0
        if off:
            try:
                companies = [c["name"] for c in
                             self.db.directory_companies(entry["id"])]
            except Exception:
                companies = []
            comp_item = QTableWidgetItem(
                ", ".join(companies) if companies else "—")
            if companies:
                comp_item.setToolTip(", ".join(companies))
            t.setItem(row, 1, comp_item)

        loc = format_location(entry)
        if not loc:
            # The address fields were never filled in, but the name itself
            # visibly carries the location ("CAT - Atlanta, GA").
            pc, ps = parse_location(entry.get("name") or "")
            if pc and ps:
                loc = f"{pc}, {ps}"
        if not loc and self.kind == "sales_rep":
            # V1.9.34 (user): reps sit at Speedrack in Walker, MI
            # unless a location of their own says otherwise.
            loc = "Walker, MI"
        t.setItem(row, 1 + off, QTableWidgetItem(loc if loc else "—"))

        n = entry["task_count"]
        task_item = _DirSortItem(str(n), n)
        task_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
        t.setItem(row, 2 + off, task_item)

        # V1.9.16: total quote value across this name's tasks (db
        # directory_list SUMs tasks.quote_value). "—" when nothing was
        # ever quoted; sorts by value, not by display text.
        total = entry.get("total_value") or 0
        if total:
            value_item = _DirSortItem(format_price(total), float(total))
        else:
            value_item = _DirSortItem("—", 0)
        value_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
        t.setItem(row, 3 + off, value_item)

        last = self.db.directory_last_quoted(self.kind, entry["id"])
        if last:
            last_item = _DirSortItem(format_iso_day(last), last)
        else:
            last_item = _DirSortItem("—", "")
        # V1.9.17: TASKS / TOTAL VALUE / LAST QUOTED / STATUS / SDC sit
        # centered under their centered headers (they were left- or
        # right-aligned, so values drifted off the header).
        last_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
        t.setItem(row, 4 + off, last_item)

        if self.kind in ("distributor", "contact", "sales_rep"):
            if inactive:
                status_item = QTableWidgetItem("Inactive")
                status_item.setForeground(QColor("#6b7078"))
                status_item.setToolTip(
                    "Marked inactive — excluded from nudge checks")
            else:
                quiet = self.kind == "distributor" and (
                    (entry["name"] or "").lower() in getattr(
                        self, "_quiet_names", set()))
                status_item = QTableWidgetItem(
                    "Gone quiet" if quiet else "Active")
                if quiet:
                    status_item.setForeground(
                        QColor("#e8b93e" if dark else "#8a5f0b"))
                    status_item.setToolTip(
                        "No quotes lately — past their usual cadence")
            status_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
            t.setItem(row, 5 + off, status_item)
        else:
            sdc_text, _sev = self._sdc_text_for_entry(entry)
            sdc_item = QTableWidgetItem(sdc_text if sdc_text else "—")
            sdc_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
            t.setItem(row, 5 + off, sdc_item)

        notes = (entry.get("notes") or "").strip()
        notes_disp = " ".join(notes.split())
        notes_item = QTableWidgetItem(notes_disp if notes_disp else "—")
        if notes_disp:
            notes_item.setToolTip(notes)
        else:
            # V1.9.16: the empty-notes dash sits centered under NOTES,
            # not parked at the column's left edge.
            notes_item.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
        t.setItem(row, 6 + off, notes_item)

    def _entry_id_at_row(self, row):
        item = self._table.item(row, 0)
        return item.data(Qt.UserRole) if item is not None else None

    def eventFilter(self, obj, event):  # noqa: N802 (Qt virtual)
        if obj is self._table.viewport():
            # V1.9.17: full-row hover — the delegate paints the hover
            # tone across the row the mouse is over.
            if event.type() == QEvent.MouseMove:
                row = self._table.rowAt(event.position().toPoint().y())
                if row != self._dir_delegate._hover_row:
                    self._dir_delegate._hover_row = row
                    self._table.viewport().update()
                return False
            if event.type() == QEvent.Leave:
                if self._dir_delegate._hover_row != -1:
                    self._dir_delegate._hover_row = -1
                    self._table.viewport().update()
                return False
        if obj is self._table and event.type() == QEvent.KeyPress:
            if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
                row = self._table.currentRow()
                entry_id = self._entry_id_at_row(row)
                if entry_id is not None:
                    self.open_detail(entry_id)
                return True
        return super().eventFilter(obj, event)

    def _on_row_activated(self, *args):
        """Double-click (row, col) or Enter/Space (via eventFilter)."""
        if len(args) == 2:
            row = args[0]
        else:
            row = args[0].row()
        entry_id = self._entry_id_at_row(row)
        if entry_id is not None:
            self.open_detail(entry_id)

    def _on_row_menu(self, pos):
        index = self._table.indexAt(pos)
        if not index.isValid():
            return
        entry_id = self._entry_id_at_row(index.row())
        if entry_id is None:
            return
        name = self._table.item(index.row(), 0).text()
        menu = self._row_menu(entry_id, name)
        menu.exec(self._table.viewport().mapToGlobal(pos))

    def _row_menu(self, entry_id, name):
        """Right-click menu: view / merge / edit / remove."""
        menu = themed_menu(self._table)
        view_act = menu.addAction("View contact details")
        view_act.triggered.connect(lambda _=False: self.open_detail(entry_id))
        merge_act = menu.addAction("Merge into another contact")
        merge_act.triggered.connect(
            lambda _=False: self._on_merge(entry_id, name))
        edit_act = menu.addAction("Edit contact details")
        edit_act.triggered.connect(
            lambda _=False: self.open_detail(entry_id, start_editing=True))
        menu.addSeparator()
        del_act = menu.addAction("Remove from directory")
        del_act.triggered.connect(
            lambda _=False: self._on_delete(entry_id, name))
        return menu

    def _sdc_text_for_entry(self, entry):
        """(text, severity) for the end-user SDC estimate, or (None, None).

        Rendered as tinted plain text in the metadata line — no badge.
        """
        if self.kind != "customer":
            return None, None
        try:
            from .seismic import (estimate_for_text, lookup_sdc,
                                  sdc_badge_text, sdc_severity)
        except Exception:
            return None, None
        city = (entry.get("city") or "").strip()
        state = (entry.get("state") or "").strip()
        letter = lookup_sdc(city, state) if (city and state) else None
        if not letter:
            # The address fields were never filled in, but the contact's
            # name visibly carries the location ("CAT - Atlanta, GA") —
            # parse it the same way task end-user text is parsed.
            letter = estimate_for_text(entry.get("name") or "")
        if not letter:
            return None, None
        # No special-casing: an automatic estimate is always labeled
        # "Est. SDC X" per sdc_badge_text's honesty contract. Rendering a
        # bare "A" would read as a manual determination, which it isn't.
        text = sdc_badge_text(letter)
        return text, sdc_severity(letter)

    def _on_add(self):
        # Full contact window in edit mode — not just a name prompt.
        new_win = getattr(self, "_new_window", None)
        if new_win is not None:
            new_win.raise_()
            if QApplication.platformName() != "offscreen":
                new_win.activateWindow()
            return
        win = ContactDetailWindow(
            self.db, None, parent=self, kind=self.kind, start_editing=True
        )
        self._new_window = win
        win.destroyed.connect(lambda _=None: setattr(self, "_new_window", None))
        win.contact_changed.connect(self.refresh)
        win.contact_changed.connect(lambda: self._adopt_new_window(win))
        win.contact_changed.connect(self.directory_changed.emit)
        win.show()
        win.raise_()
        if QApplication.platformName() != "offscreen":
            win.activateWindow()

    def _adopt_new_window(self, win):
        """Once a new contact is saved, track it like a normal detail window."""
        if win.entry_id is not None and win.entry_id not in self._detail_windows:
            self._detail_windows[win.entry_id] = win
            win.destroyed.connect(
                lambda _=None, eid=win.entry_id: self._detail_windows.pop(eid, None)
            )
        if getattr(self, "_new_window", None) is win:
            self._new_window = None

    def _on_delete(self, entry_id, name):
        singular = DIRECTORY_SINGULAR[self.kind]
        if app_confirm(
            self,
            f"Delete {singular}",
            f"Remove “{name}” from your CRM?\nTasks keep their saved text.",
            confirm_label="Delete", danger=True):
            self.db.directory_delete(entry_id)
            self.refresh()

    def _on_merge(self, entry_id, name):
        dlg = MergeContactsDialog(self.db, self.kind, entry_id, name, self)
        if dlg.exec() == QDialog.Accepted:
            self.refresh()

    def open_detail(self, entry_id, start_editing=False):
        """Open (or raise) the CRM detail window for one contact."""
        win = self._detail_windows.get(entry_id)
        if win is not None:
            win.raise_()
            if QApplication.platformName() != "offscreen":
                win.activateWindow()
            if start_editing:
                win.set_editing(True)
            return
        win = ContactDetailWindow(self.db, entry_id, self, start_editing=start_editing)
        self._detail_windows[entry_id] = win
        win.destroyed.connect(
            lambda _=None, eid=entry_id: self._detail_windows.pop(eid, None)
        )
        win.contact_changed.connect(self.refresh)
        win.contact_changed.connect(self.directory_changed.emit)
        win.show()
        win.raise_()
        win.activateWindow()


# ------------------------------------------------------- CRM contact detail
def _format_address(entry):
    """Multi-line street + 'City, ST ZIP' for the contact detail view."""
    street = (entry.get("address") or "").strip()
    loc = format_location(entry)
    return "\n".join(p for p in (street, loc) if p) or "—"


class ContactDetailWindow(QDialog):
    """CRM detail view for one directory entry.

    View mode shows phone / email / address / notes plus the tasks that
    reference this contact. Edit mode edits every field in place.
    """

    contact_changed = Signal()

    def __init__(self, db, entry_id, parent=None, *, kind="distributor",
                 start_editing=False):
        """Detail view for one directory entry.

        When entry_id is None a new contact is being created: the window opens
        in edit mode and the entry is only saved (as ``kind``) when Save is
        pressed.
        """
        super().__init__(parent)
        self.db = db
        self.entry_id = entry_id
        self._is_new = entry_id is None
        self.editing = False
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setMinimumSize(480, 560)
        self.resize(520, 680)

        if self._is_new:
            self.entry = {
                "id": None, "kind": kind, "name": "",
                "phone": "", "email": "", "address": "",
                "city": "", "state": "", "zip_code": "", "notes": "",
                "status": "active",
            }
            title_text = "New " + DIRECTORY_SINGULAR.get(kind, "Contact")
        else:
            self.entry = db.directory_get(entry_id)
            if not self.entry:
                show_toast(
                    self, "warning", "Contact missing",
                    "This contact no longer exists."
                )
                self.close()
                return
            title_text = DIRECTORY_SINGULAR.get(
                self.entry["kind"], "Contact") + " Details"

        layout = install_chrome(self, title_text)
        layout.setSpacing(10)  # uniform rhythm between the field groups below
        # The scrollable body carries the app-wide scroll insets
        # (set_scroll_content_margins, 16/12/16/12); the chrome content
        # margins are zeroed so padding is not doubled. This also gains
        # content width versus the old 24px chrome margins.

        layout.setContentsMargins(0, 0, 0, 0)

        # ---- header: name (above the tabs — the entry's identity) ----
        # (The kind — Distributor / End User — is already in the window title.)
        name_host = QWidget()
        name_lay = QVBoxLayout(name_host)
        name_lay.setContentsMargins(16, 10, 16, 6)
        name_lay.setSpacing(4)
        self.name_title = QLabel()
        self.name_title.setObjectName("title")
        self.name_title.setWordWrap(True)
        name_lay.addWidget(self.name_title)
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Name *")
        name_lay.addWidget(self.name_edit)
        layout.addWidget(name_host)

        # ---- tabs (V1.9.32, user): Details / Contacts / Tasks ----
        # Real attached tabs. The Contacts tab belongs to company
        # entries (distributors / end users) and lists the contact
        # names filed under the company (see db.directory_contacts).
        self.tabs = _AttachedTabs()
        tabs_host = QWidget()
        tabs_lay = QHBoxLayout(tabs_host)
        tabs_lay.setContentsMargins(16, 2, 16, 10)
        tabs_lay.addWidget(self.tabs)
        layout.addWidget(tabs_host, 1)

        # ---- Details page: the scrollable field body ----
        # The field groups + metrics can exceed the window on large
        # fonts; the page scrolls instead of letting Qt overlap or
        # squeeze widgets (same lesson as the New Task dialog). The
        # footer stays fixed below the tabs.
        self.body_scroll = QScrollArea()
        self.body_scroll.setWidgetResizable(True)
        self.body_scroll.setFrameShape(QFrame.NoFrame)
        self.body_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        body_host = QWidget()
        body = QVBoxLayout(body_host)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(10)
        enable_touch_scroll(self.body_scroll)
        self.body_scroll.setWidget(body_host)
        set_scroll_content_margins(self.body_scroll)
        self.tabs.addTab(self.body_scroll, "Details")

        # ---- Contacts page (company entries only) ----
        self._contacts_tab_index = None
        if self.entry.get("kind") in ("distributor", "customer"):
            self.contacts_scroll = QScrollArea()
            self.contacts_scroll.setWidgetResizable(True)
            self.contacts_scroll.setFrameShape(QFrame.NoFrame)
            self.contacts_scroll.setHorizontalScrollBarPolicy(
                Qt.ScrollBarAlwaysOff)
            contacts_host = QWidget()
            self.contacts_box = QVBoxLayout(contacts_host)
            self.contacts_box.setContentsMargins(0, 0, 0, 0)
            self.contacts_box.setSpacing(6)
            self.contacts_box.setAlignment(Qt.AlignTop)
            self.contacts_scroll.setWidget(contacts_host)
            enable_touch_scroll(self.contacts_scroll)
            set_scroll_content_margins(self.contacts_scroll)
            self._contacts_tab_index = self.tabs.addTab(
                self.contacts_scroll, "Contacts")

        # ---- status: view label + edit dropdown ----
        # Editable — the directory table's STATUS column used to be derived
        # only ("Active" / "Gone quiet") with no way to change it.
        status_lab = QLabel("STATUS")
        status_lab.setObjectName("sectionLabel")
        body.addWidget(status_lab)
        self.status_value = QLabel()
        self.status_value.setObjectName("detailValue")
        body.addWidget(self.status_value)
        self.status_edit = SafeComboBox()
        self.status_edit.addItems(["Active", "Inactive"])
        body.addWidget(self.status_edit)
        self._view_widgets = [status_lab, self.status_value]
        self._edit_widgets = [status_lab, self.status_edit]

        # ---- contact info: view labels + edit fields ----
        self.info_box = QVBoxLayout()
        self.info_box.setContentsMargins(0, 0, 0, 0)
        self.info_box.setSpacing(10)
        body.addLayout(self.info_box)

        def add_field(key, label_text, multi=False):
            lab = QLabel(label_text.upper())
            lab.setObjectName("sectionLabel")
            self.info_box.addWidget(lab)
            self._view_widgets.append(lab)
            value = QLabel()
            value.setObjectName("detailValue")
            value.setWordWrap(True)
            value.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.info_box.addWidget(value)
            self._view_widgets.append(value)
            if multi:
                edit = _SanitizedTextEdit()
                edit.setFixedHeight(70)
            else:
                edit = QLineEdit()
                edit.setPlaceholderText(label_text)
            self.info_box.addWidget(edit)
            self._edit_widgets.append(lab)  # label shows in both modes
            self._edit_widgets.append(edit)
            return value, edit

        self.phone_value, self.phone_edit = add_field("phone", "Phone")
        self.email_value, self.email_edit = add_field("email", "Email")

        # ---- address: street + city / state / zip ----
        addr_lab = QLabel("ADDRESS")
        addr_lab.setObjectName("sectionLabel")
        self.info_box.addWidget(addr_lab)
        self._view_widgets.append(addr_lab)
        self._edit_widgets.append(addr_lab)
        self.address_value = QLabel()
        self.address_value.setObjectName("detailValue")
        self.address_value.setWordWrap(True)
        self.address_value.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.info_box.addWidget(self.address_value)
        self._view_widgets.append(self.address_value)
        self.address_edit = QLineEdit()
        self.address_edit.setPlaceholderText("Street address")
        self.info_box.addWidget(self.address_edit)
        self._edit_widgets.append(self.address_edit)
        csz_row = QHBoxLayout()
        csz_row.setContentsMargins(0, 0, 0, 0)
        csz_row.setSpacing(8)
        # Each input carries its own small caps label — placeholders vanish
        # while typing, leaving no way to tell the boxes apart.
        for label_text, attr, stretch in (("CITY", "city_edit", 3),
                                          ("STATE", "state_edit", 2),
                                          ("ZIP", "zip_edit", 2)):
            sub = QWidget()
            sub_lay = QVBoxLayout(sub)
            sub_lay.setContentsMargins(0, 0, 0, 0)
            sub_lay.setSpacing(2)
            sub_lab = QLabel(label_text)
            sub_lab.setObjectName("sectionLabel")
            sub_lay.addWidget(sub_lab)
            edit = QLineEdit()
            sub_lay.addWidget(edit)
            csz_row.addWidget(sub, stretch)
            setattr(self, attr, edit)
            self._edit_widgets.append(sub_lab)
        csz_wrap = QWidget()
        csz_wrap.setLayout(csz_row)
        self.info_box.addWidget(csz_wrap)
        self._edit_widgets.append(csz_wrap)

        self.notes_value, self.notes_edit = add_field("notes", "Notes", multi=True)

        # V1.9.51 (user): the "No contact details yet -- click
        # Edit to add them." note is REMOVED -- no explanatory
        # notes he did not ask for (standing rule). An empty
        # contact simply shows its empty fields. The attribute
        # stays as a hidden, empty label so the two visibility
        # syncs below keep working without a special case.
        self.empty_hint = QLabel("")
        self.empty_hint.setVisible(False)
        body.addWidget(self.empty_hint)

        # ---- Tasks page (V1.9.32: its own tab; the tab names it, so
        # the old in-page TASKS label is gone) ----
        tasks_page = QWidget()
        tasks_lay = QVBoxLayout(tasks_page)
        tasks_lay.setContentsMargins(16, 12, 16, 12)
        tasks_lay.setSpacing(10)
        self.task_search = QLineEdit()
        self.task_search.setPlaceholderText("Search tasks...")
        self.task_search.setClearButtonEnabled(True)
        self.task_search.textChanged.connect(self._on_task_search)
        search_box = QVBoxLayout()
        search_box.setContentsMargins(0, 0, 0, 0)
        search_box.setSpacing(3)
        self.task_search_count = CountLabel()
        search_box.addWidget(self.task_search_count)
        search_box.addWidget(self.task_search)
        tasks_lay.addLayout(search_box)
        self._task_buttons = []
        # Scrollable so a long task list never grows the window; the minimum
        # hugs the buttons (capped) and stretch lets the list claim spare
        # body space instead of leaving dead air under the metrics.
        self.tasks_scroll = QScrollArea()
        self.tasks_scroll.setWidgetResizable(True)
        self.tasks_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        tasks_host = QWidget()
        self.tasks_box = QVBoxLayout(tasks_host)
        self.tasks_box.setSpacing(6)
        self.tasks_box.setAlignment(Qt.AlignTop)
        self.tasks_scroll.setWidget(tasks_host)
        enable_touch_scroll(self.tasks_scroll)
        # App-wide scroll insets: task rows keep clear of the viewport
        # edges and the vertical scrollbar.
        set_scroll_content_margins(self.tasks_scroll)
        tasks_lay.addWidget(self.tasks_scroll, 1)
        self.total_value_label = QLabel()
        self.total_value_label.setObjectName("hint")
        tasks_lay.addWidget(self.total_value_label)
        self._tasks_tab_index = self.tabs.addTab(tasks_page, "Tasks")

        # ---- quote metrics (shared aggregation with the dashboard) ----
        # Read-only block for BOTH distributors and end users. Computed by
        # db.contact_metrics() — the same helper the dashboard uses — so the
        # two surfaces always agree. Hidden when the contact has no quotes,
        # and hidden while editing (visibility managed explicitly in
        # _render_metrics() / set_editing(), not via the _view_widgets
        # lists, so the sectionLabel styling doesn't force it visible).
        self._metrics_available = False
        self.metrics_section = QLabel("QUOTE METRICS")
        self.metrics_section.setObjectName("sectionLabel")
        body.addWidget(self.metrics_section)
        self.metrics_grid_host = QWidget()
        self.metrics_grid = QGridLayout(self.metrics_grid_host)
        self.metrics_grid.setContentsMargins(0, 0, 0, 0)
        self.metrics_grid.setHorizontalSpacing(24)
        self.metrics_grid.setVerticalSpacing(8)
        self._metric_values = {}
        # 2 rows x 4 columns of stacked label-over-value cells: compact
        # enough to fit under TASKS without growing the window, while the
        # 14px values stay legible next to the 11px labels.
        for i, (key, text) in enumerate((
            ("total_quotes", "Total quotes"),
            ("completed", "Completed"),
            ("win_rate", "Win rate"),
            ("total_quoted_value", "Total quoted value"),
            ("won_value", "Won value"),
            ("avg_days", "Avg days"),
            ("avg_est_hours", "Avg est. hours"),
            ("last_quote", "Last quote"),
        )):
            cell = QWidget()
            cell_lay = QVBoxLayout(cell)
            cell_lay.setContentsMargins(0, 0, 0, 0)
            cell_lay.setSpacing(0)
            lab = QLabel(text)
            lab.setObjectName("hint")
            val = QLabel("—")
            val.setObjectName("detailValue")
            val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            cell_lay.addWidget(lab)
            cell_lay.addWidget(val)
            r, c = divmod(i, 4)
            self.metrics_grid.addWidget(cell, r, c)
            self._metric_values[key] = val
        for c in range(4):
            self.metrics_grid.setColumnStretch(c, 1)
        body.addWidget(self.metrics_grid_host)

        # ---- companies (contact entries only, V1.9.32) ----
        # The mirror of the company Contacts tab: the companies this
        # contact is filed under (from its tasks). View-only rows that
        # open the company's card; visibility is managed in _render /
        # set_editing via _companies_rows.
        self._companies_rows = []
        self.companies_lab = QLabel("COMPANIES")
        self.companies_lab.setObjectName("sectionLabel")
        body.addWidget(self.companies_lab)
        self.companies_host = QWidget()
        self.companies_box = QVBoxLayout(self.companies_host)
        self.companies_box.setContentsMargins(0, 0, 0, 0)
        self.companies_box.setSpacing(6)
        body.addWidget(self.companies_host)
        self.companies_lab.setVisible(False)
        self.companies_host.setVisible(False)

        # ---- footer (fixed below the tabs) ----
        footer = QHBoxLayout()
        footer.addStretch(1)
        self.edit_btn = QPushButton("Edit")
        self.edit_btn.clicked.connect(lambda: self.set_editing(True))
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.close)
        self.save_btn = QPushButton("Save")
        self.save_btn.setObjectName("primary")
        self.save_btn.setDefault(True)
        self.save_btn.clicked.connect(self._on_save)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self._on_cancel)
        for b in (self.edit_btn, self.close_btn, self.save_btn, self.cancel_btn):
            footer.addWidget(b)
        # The chrome content margins are zeroed (the body carries the
        # scroll insets), so the footer gets matching margins of its own.
        footer_host = QWidget()
        footer_host.setLayout(footer)
        footer_host.setContentsMargins(16, 0, 16, 12)
        layout.addWidget(footer_host)

        self._render()
        self.set_editing(True if self._is_new else start_editing)
        _chip_font_tree(self)

    # ---- rendering ----
    def _render(self):
        e = self.entry
        self.name_title.setText(e["name"])
        self.name_edit.setText(e["name"])
        status = (e.get("status") or "active").lower()
        if status not in ("active", "inactive"):
            status = "active"
        self.status_value.setText(status.title())
        self.status_edit.setCurrentIndex(0 if status == "active" else 1)
        self._set_contact_link(self.phone_value, self.phone_edit,
                               e["phone"], "tel")
        self._set_contact_link(self.email_value, self.email_edit,
                               e["email"], "mailto")
        self.notes_value.setText(e["notes"] or "—")
        self.notes_edit.setPlainText(e["notes"])
        self.address_value.setText(_format_address(e))
        self.address_edit.setText(e.get("address", ""))
        self.city_edit.setText(e.get("city", ""))
        self.state_edit.setText(e.get("state", ""))
        self.zip_edit.setText(e.get("zip_code", ""))
        has_info = any(e[k] for k in ("phone", "email", "address", "city", "state", "zip_code", "notes"))
        self.empty_hint.setVisible(False)  # V1.9.51: note removed (see __init__)
        # linked tasks
        while self.tasks_box.count():
            item = self.tasks_box.takeAt(0)
            w = item.widget()
            if w is not None:
                w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
                w.setParent(None)
                w.deleteLater()
        tasks = [] if self._is_new else self.db.directory_tasks(self.entry_id)
        self._task_buttons = []
        if not tasks:
            none = QLabel("No tasks reference this contact yet.")
            none.setObjectName("hint")
            self.tasks_box.addWidget(none)
        for t in tasks:
            btn = QPushButton(f"{t['quote_number']}   ·   {t['status'].replace('_', ' ').title()}")
            btn.setObjectName("taskLink")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setProperty(
                "task_search",
                f"{t['quote_number']} {t['status'].replace('_', ' ')}".lower(),
            )
            btn.clicked.connect(
                lambda _=False, tid=t["id"]: self._on_open_task(tid)
            )
            self.tasks_box.addWidget(btn)
            self._task_buttons.append(btn)
        # total quoted value across linked tasks (only where priced)
        priced = 0
        total = 0.0
        for t in tasks:
            full = self.db.get_task(t["id"])
            v = full.get("quote_value") if full else None
            if v is not None:
                priced += 1
                try:
                    total += float(v)
                except (TypeError, ValueError):
                    pass
        if priced:
            self.total_value_label.setText(
                f"Total quoted value: {format_price(total)}"
                + (f" ({priced} of {len(tasks)} priced)"
                   if priced < len(tasks) else ""))
            self.total_value_label.setVisible(True)
        else:
            self.total_value_label.setVisible(False)
        self._size_tasks_scroll()
        self._on_task_search(self.task_search.text())
        self._render_metrics()
        self._render_contacts()
        self._render_companies()
        if self._contacts_tab_index is not None:
            self.tabs.setTabEnabled(self._contacts_tab_index,
                                    not self._is_new)
        self.tabs.setTabEnabled(self._tasks_tab_index, not self._is_new)

    def _render_metrics(self):
        """Populate the quote-metrics block from db.contact_metrics().

        Same aggregation the dashboard uses. Every aggregate that has no
        data renders as "—" (never NaN, never a crash); the whole block is
        hidden when the contact has no quotes.
        """
        # Deferred import: dashboard.py imports this module at its top level.
        from tasklist.dashboard import _days, _hours, _int_fmt, _money

        show = False
        if not self._is_new:
            try:
                m = self.db.contact_metrics(
                    self.entry["kind"], self.entry["name"])
            except Exception:
                m = None
            if m and m.get("total_quotes"):
                show = True
                v = self._metric_values
                v["total_quotes"].setText(_int_fmt(m["total_quotes"]))
                v["completed"].setText(_int_fmt(m["completed"]))
                wr = m.get("win_rate")
                v["win_rate"].setText(
                    f"{wr:.0f}%" if wr is not None else "—")
                v["total_quoted_value"].setText(
                    _money(m.get("total_quoted_value")))
                v["won_value"].setText(_money(m.get("won_value")))
                v["avg_days"].setText(_days(m.get("avg_days")))
                est = m.get("avg_est_hours")
                # Estimated hours are estimated WORK time (not elapsed
                # time), so the old "est / actual" comparison against
                # wall-clock elapsed hours was misleading and has been
                # removed: the cell now shows the average estimate on its
                # own, plainly labeled.
                v["avg_est_hours"].setText(_hours(est))
                last = m.get("last_quote") or ""
                try:
                    # V1.9.54 (audit): dates are MM/DD/YYYY
                    # globally -- this cell still used a prose
                    # format ("Nov 13, 2026").
                    last_txt = fmt_date_mdy(last)
                    if not last_txt:
                        last_txt = "—"
                except (ValueError, TypeError):
                    last_txt = "—"
                v["last_quote"].setText(last_txt)
        self._metrics_available = show
        self.metrics_section.setVisible(show)
        self.metrics_grid_host.setVisible(show and not self.editing)

    def _render_contacts(self):
        """Contacts tab (companies): the contact names filed under
        this company on its tasks. A row opens the contact's card —
        creating its CRM entry first when it only exists on tasks so
        far, which is what files it under the company in the CRM."""
        if self._contacts_tab_index is None:
            return
        while self.contacts_box.count():
            item = self.contacts_box.takeAt(0)
            w = item.widget()
            if w is not None:
                w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
                w.setParent(None)
                w.deleteLater()
        rows = [] if self._is_new else self.db.directory_contacts(
            self.entry_id)
        if not rows:
            hint = QLabel(
                "No contact names yet — a contact appears here when "
                "it's named on one of this company's tasks.")
            hint.setObjectName("hint")
            hint.setWordWrap(True)
            self.contacts_box.addWidget(hint)
            return
        for r in rows:
            entry = self.db.directory_get_by_name("contact", r["name"])
            detail = ""
            if entry:
                detail = (entry.get("phone") or entry.get("email")
                          or "").strip()
            if not detail:
                n = r["task_count"]
                detail = f"{n} task" + ("s" if n != 1 else "")
            btn = QPushButton(f"{r['name']}   ·   {detail}")
            btn.setObjectName("taskLink")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(
                lambda _=False, nm=r["name"]: self._open_entry(
                    "contact", nm))
            self.contacts_box.addWidget(btn)

    def _render_companies(self):
        """Companies group (contacts): the companies this contact is
        filed under, from its tasks. Rows open the company's card."""
        is_contact = self.entry.get("kind") == "contact"
        rows = []
        if is_contact and not self._is_new:
            rows = self.db.directory_companies(self.entry_id)
        self._companies_rows = rows
        while self.companies_box.count():
            item = self.companies_box.takeAt(0)
            w = item.widget()
            if w is not None:
                w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
                w.setParent(None)
                w.deleteLater()
        for r in rows:
            btn = QPushButton(r["name"])
            btn.setObjectName("taskLink")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(
                lambda _=False, k=r["kind"], nm=r["name"]:
                self._open_entry(k, nm))
            self.companies_box.addWidget(btn)
        show = bool(rows) and not self.editing
        self.companies_lab.setVisible(show)
        self.companies_host.setVisible(show)

    def _open_entry(self, kind, name):
        """Open another directory entry's card (contact or company),
        mirroring TaskDetailWindow._open_contact_card's fallbacks."""
        name = (name or "").strip()
        if not name:
            return
        entry_id = self.db.directory_entry_id(kind, name)
        if entry_id is None and kind == "contact":
            entry_id = self.db.remember_contact("contact", name)
        if entry_id is not None:
            win = ContactDetailWindow(self.db, entry_id, self)
        else:
            win = ContactDetailWindow(self.db, None, self, kind=kind,
                                      start_editing=True)
            win.name_edit.setText(name)
        win.contact_changed.connect(self._on_child_changed)
        win.show()
        win.raise_()
        win.activateWindow()

    def _on_child_changed(self):
        self._render()
        self.contact_changed.emit()

    @staticmethod
    def _set_contact_link(value, edit, text, scheme):
        """View label becomes a clickable tel:/mailto: link when set."""
        text = (text or "").strip()
        edit.setText(text)
        if text:
            href = re.sub(r"[^\d+]", "", text) if scheme == "tel" else text
            safe = (text.replace("&", "&amp;").replace("<", "&lt;")
                    .replace(">", "&gt;"))
            value.setText(f'<a href="{scheme}:{href}">{safe}</a>')
            value.setOpenExternalLinks(True)
        else:
            value.setText("—")
            value.setOpenExternalLinks(False)

    def _size_tasks_scroll(self):
        """Hug the task buttons up to a cap.

        A minimum (not fixed) height: the list claims spare body space via
        its layout stretch instead of leaving dead air, while a long list
        scrolls internally instead of growing the window.
        """
        self.tasks_box.activate()
        h = self.tasks_box.totalSizeHint().height()
        self.tasks_scroll.setMinimumHeight(min(max(h, 40), 190))

    def set_editing(self, editing):
        self.editing = editing
        self.name_title.setVisible(not editing)
        self.name_edit.setVisible(editing)
        for w in self._view_widgets:
            # section labels stay visible in both modes; values hide while editing
            w.setVisible(w.objectName() == "sectionLabel" or not editing)
        for w in self._edit_widgets:
            w.setVisible(w.objectName() == "sectionLabel" or editing)
        has_info = any(self.entry[k] for k in ("phone", "email", "address", "city", "state", "zip_code", "notes"))
        self.empty_hint.setVisible(False)  # V1.9.51: note removed
        self.edit_btn.setVisible(not editing)
        self.close_btn.setVisible(not editing)
        self.save_btn.setVisible(editing)
        self.cancel_btn.setVisible(editing)
        # quote-metrics block is view-only and only exists when the contact
        # has quotes (see _render_metrics)
        self.metrics_section.setVisible(
            self._metrics_available and not editing)
        self.metrics_grid_host.setVisible(
            self._metrics_available and not editing)
        # companies group is view-only too (see _render_companies)
        has_companies = bool(getattr(self, "_companies_rows", None))
        self.companies_lab.setVisible(has_companies and not editing)
        self.companies_host.setVisible(has_companies and not editing)
        if editing:
            self.name_edit.setFocus()
            self.name_edit.selectAll()

    def _status_choice(self):
        """'active' / 'inactive' from the edit-mode status dropdown."""
        return "active" if self.status_edit.currentIndex() == 0 else "inactive"

    # ---- actions ----
    def _on_save(self):
        name = self.name_edit.text().strip()
        if not name:
            show_toast(self, "warning", "Missing info",
                       "Please enter a name.")
            self.name_edit.setFocus()
            return
        if self._is_new:
            if self.db.directory_name_taken(self.entry["kind"], name):
                show_toast(
                    self, "warning", "Save contact",
                    "That name is already in use."
                )
                return
            new_id = self.db.remember_contact(self.entry["kind"], name)
            if new_id is None:
                return
            self.db.directory_update(
                new_id,
                phone=self.phone_edit.text(),
                email=self.email_edit.text(),
                address=self.address_edit.text(),
                city=self.city_edit.text(),
                state=self.state_edit.text(),
                zip_code=self.zip_edit.text(),
                notes=self.notes_edit.toPlainText(),
                status=self._status_choice(),
            )
            self.entry_id = new_id
            self.entry = self.db.directory_get(new_id)
            self._is_new = False
        else:
            ok = self.db.directory_update(
                self.entry_id,
                name=name,
                phone=self.phone_edit.text(),
                email=self.email_edit.text(),
                address=self.address_edit.text(),
                city=self.city_edit.text(),
                state=self.state_edit.text(),
                zip_code=self.zip_edit.text(),
                notes=self.notes_edit.toPlainText(),
                status=self._status_choice(),
            )
            if not ok:
                show_toast(
                    self, "warning", "Save contact",
                    "That name is already in use."
                )
                return
            self.entry = self.db.directory_get(self.entry_id)
        self.contact_changed.emit()
        self._render()  # refresh view-mode values from the saved entry
        self.set_editing(False)

    def _on_cancel(self):
        if self._is_new:
            self.close()  # nothing was saved
        else:
            self.set_editing(False)

    def _on_task_search(self, text):
        needle = text.strip().lower()
        visible = 0
        for btn in self._task_buttons:
            hay = btn.property("task_search") or ""
            match = not needle or needle in hay
            btn.setVisible(match)
            visible += match
        total = len(self._task_buttons)
        self.task_search_count.set_count(f"{visible} of {total}" if needle else "")

    def _on_open_task(self, task_id):
        win = TaskDetailWindow(self.db, task_id, parent=self)
        win.task_changed.connect(self._on_task_changed)
        win.show()
        win.raise_()
        if QApplication.platformName() != "offscreen":
            win.activateWindow()

    def _on_task_changed(self):
        if self._is_new:
            self._render()
            return
        self.entry = self.db.directory_get(self.entry_id)
        if not self.entry:
            self.close()
            return
        self._render()
        self.contact_changed.emit()


# ------------------------------------------------------- chip flow layout
#: Minimum width (px) of one queue board column. Columns share the board's
#: available width equally (QHBoxLayout stretch); this floor keeps a column
#: usable on narrow windows instead of squeezing its cards into a sliver.
# V1.9.51 (user screenshots: the Added date clipped to
# "Added 11/12/2" in the queue's side columns): a column could
# shrink to 240px while a card's own content needs ~430 -- the
# footer (date + Hot/Folder/Edit/Delete) alone is ~400px, and
# the date label is the only squeezable element, so it was the
# thing that clipped. The column minimum now covers the card's
# real content width; below that the board scrolls sideways,
# as designed, instead of crushing cards.
QUEUE_COLUMN_MIN_WIDTH = 480


def _enable_height_for_width(widget):
    """Flag a widget's size policy as height-for-width.

    Needed at every level of the chain (chips row -> card body -> card)
    so Qt asks the ChipFlowLayout for the wrapped height instead of using
    a stale size hint. Without it, wrapped chips would be clipped
    vertically when a column narrows.
    """
    policy = widget.sizePolicy()
    policy.setHeightForWidth(True)
    widget.setSizePolicy(policy)


class ChipFlowLayout(QLayout):
    """Left-to-right wrapping layout for the scope chips on a queue card.

    The old QHBoxLayout forced the chips row's minimum width to the *sum*
    of every chip width (~390px for four chips), which became the whole
    card's minimum width: on a narrow window the card could not shrink
    with its column and was clipped by the column viewport instead (the
    column's horizontal scrollbar is forced off). The flow layout wraps
    chips onto additional rows, so the row's minimum width is just the
    widest single chip and the card stays fluid at any column width.
    Height-for-width is supported so the card grows taller -- never
    clips -- when chips wrap onto more rows.
    """

    def __init__(self, parent=None, hspacing=6, vspacing=6):
        super().__init__(parent)
        self._items = []
        self._hspacing = hspacing
        self._vspacing = vspacing

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):
        if 0 <= index < len(self._items):
            return self._items[index]
        return None

    def takeAt(self, index):
        if 0 <= index < len(self._items):
            return self._items.pop(index)
        return None

    def expandingDirections(self):
        return Qt.Orientations(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, max(width, 0), 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        if not self._items:
            return QSize(0, 0)
        left, top, right, bottom = self.getContentsMargins()
        widest = max(item.minimumSize().width() for item in self._items)
        width = widest + left + right
        return QSize(width, self.heightForWidth(width))

    def _do_layout(self, rect, test_only):
        left, top, right, bottom = self.getContentsMargins()
        effective = rect.adjusted(left, top, -right, -bottom)
        x = effective.x()
        y = effective.y()
        line_height = 0
        for item in self._items:
            w = item.widget()
            # Skip explicitly hidden widgets, but NOT widgets that are
            # merely not-yet-visible during construction (isVisibleTo
            # returns False before show()). Check isHidden() instead.
            if w is not None and w.isHidden():
                continue
            hint = item.sizeHint()
            next_x = x + hint.width() + self._hspacing
            if next_x - self._hspacing > effective.right() + 1 and line_height > 0:
                x = effective.x()
                y += line_height + self._vspacing
                line_height = 0
                next_x = x + hint.width() + self._hspacing
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - effective.y() + top + bottom


class FitChipsRow(QWidget):
    """Single-row chip strip that fits as many chips as the width allows.

    v1.4.0 item 11: replaces the fixed ``scopes[:4]`` slice. Pinned chips
    (the amber waiting chip) are always fully visible first; unpinned
    chips fill the remaining width by cached size-hint math. Anything that
    doesn't fit collapses into a ``+N more`` label whose tooltip lists the
    hidden items (raw text — tooltips don't collapse ``&&``, so esc_plain
    must NOT be applied here).

    Only one row is ever visible, so the card height stays uniform. The
    fit is recomputed on resize, but widget visibility is only toggled
    when the visible count actually changes (resize-churn guard).
    """

    def __init__(self, parent=None, spacing=6):
        super().__init__(parent)
        self._spacing = spacing
        self._pinned = []   # [QWidget] always visible, first
        self._chips = []    # [(QWidget, str label)] fit-to-width
        self._more = QLabel(self)
        self._more.setObjectName("queueMeta")
        self._more.setVisible(False)
        # v1.4.0 item 11: NO inner QLayout. A layout's minimum is the
        # sum of its visible items, and qSmartMinSize expands the
        # widget's minimum with it — so visible chips would pin the
        # card's minimum width, blocking the shrink that should hide
        # them (minimum-width circularity). Chips are direct children,
        # positioned by hand in _refit; the widget minimum stays (0,0).
        self._last_visible = -1
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_chips(self, pinned, chips):
        """pinned: [QWidget]; chips: [(QWidget, str)]. Takes ownership."""
        for w in self._pinned:
            w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
            w.setParent(None)
            w.deleteLater()
        for w, _ in self._chips:
            w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
            w.setParent(None)
            w.deleteLater()
        self._pinned = list(pinned)
        self._chips = list(chips)
        for w in self._pinned:
            w.setParent(self)
            w.setVisible(True)
        for w, _ in self._chips:
            w.setParent(self)
            # Start hidden: _refit shows what fits once the real width
            # is known (showEvent/resizeEvent). Starting visible would
            # flash the full row and confuse width math.
            w.setVisible(False)
        self._more.setVisible(False)
        self._last_visible = -1
        # Fixed height: tallest of pinned/fittable/more.
        heights = [w.sizeHint().height() for w in self._pinned]
        heights += [w.sizeHint().height() for w, _ in self._chips]
        heights.append(self._more.sizeHint().height())
        if heights:
            self.setFixedHeight(max(heights))
        # Fit now only if we're on screen with a real width (a live
        # card getting new chips). During construction the width is a
        # stale default; showEvent/resizeEvent fit once it's real.
        if self.isVisible() and self.width() > 0:
            self._refit()
        else:
            self.updateGeometry()

    def showEvent(self, event):  # noqa: N802 (Qt virtual)
        super().showEvent(event)
        # First show: the widget now has a real width — fit the chips.
        self._refit()

    def resizeEvent(self, event):  # noqa: N802 (Qt virtual)
        super().resizeEvent(event)
        self._refit()

    def visible_count(self):
        """How many fittable chips are currently shown (tests)."""
        return max(0, self._last_visible)

    def hidden_labels(self):
        """Labels of the currently-hidden chips (tests)."""
        n = max(0, self._last_visible)
        return [label for _, label in self._chips[n:]]

    def _refit(self):
        avail = self.width()
        if avail <= 0 or not self._chips:
            return
        sp = self._spacing
        # Pinned chips always show; measure them first.
        used = 0
        for w in self._pinned:
            if used:
                used += sp
            used += w.sizeHint().width()
        # Pass 1: try to fit ALL chips with no reservation. If they fit,
        # show them all — no "+N more" needed.
        total_w = used
        for w, _ in self._chips:
            cw = w.sizeHint().width()
            sep = sp if (total_w > 0) else 0
            total_w += sep + cw
        if total_w <= avail:
            n_visible = len(self._chips)
        else:
            # Pass 2: not all fit — reserve room for the "+N more" label.
            # The reservation is measured from the exact candidate text on
            # every iteration. (The label's own sizeHint is stale otherwise:
            # empty on first show, the previous count after a resize — the
            # former clips the label, the latter hides a chip that would
            # fit, which is the "+2 more sticks around" report.)
            n_visible = 0
            temp_used = used
            total_chips = len(self._chips)
            # The loop setTexts the live label to measure each candidate;
            # save the text so the measuring can't leak into the display
            # when the visible count is unchanged below.
            prev_more_text = self._more.text()
            for i, (w, _label) in enumerate(self._chips):
                cw = w.sizeHint().width()
                sep = sp if (temp_used > 0) else 0
                # If chips remain after this one, reserve room for "+N more".
                remaining = total_chips - i - 1
                if remaining:
                    self._more.setText(f"+{remaining} more")
                    reserve = self._more.sizeHint().width() + sp
                else:
                    reserve = 0
                if temp_used + sep + cw + reserve <= avail:
                    temp_used += sep + cw
                    n_visible += 1
                else:
                    break
            if n_visible == self._last_visible:
                self._more.setText(prev_more_text)
        if n_visible != self._last_visible:
            self._last_visible = n_visible
            hidden = [label for _, label in self._chips[n_visible:]]
            if hidden:
                self._more.setText(f"+{len(hidden)} more")
                # Raw text: QToolTip has no mnemonics, so esc_plain's
                # "&&" would render literally as "S&&S".
                self._more.setToolTip("\n".join(hidden))
                self._more.setVisible(True)
            else:
                self._more.setVisible(False)
        # Manual single-row layout (no inner QLayout — see __init__).
        # Positions only change when the visible set changes or the
        # width changes; recompute every refit for simplicity.
        y = 0
        h = self.height()
        x = 0
        for w in self._pinned:
            cw, ch = w.sizeHint().width(), w.sizeHint().height()
            w.setGeometry(x, (h - ch) // 2, cw, ch)
            w.setVisible(True)
            x += cw + sp
        n = max(0, self._last_visible)
        for i, (w, _label) in enumerate(self._chips):
            if i < n:
                cw, ch = w.sizeHint().width(), w.sizeHint().height()
                w.setGeometry(x, (h - ch) // 2, cw, ch)
                w.setVisible(True)
                x += cw + sp
            else:
                w.setVisible(False)
        if self._more.isVisible():
            mw, mh = self._more.sizeHint().width(), self._more.sizeHint().height()
            self._more.setGeometry(x, (h - mh) // 2, mw, mh)

    def sizeHint(self):
        # Preferred width: everything on one row (the layout may give
        # less; _refit collapses the overflow into "+N more").
        sp = self._spacing
        total = 0
        for w in self._pinned:
            if total:
                total += sp

    def sizeHint(self):
        # Preferred width: everything on one row (the layout may give
        # less; _refit collapses the overflow into "+N more").
        sp = self._spacing
        total = 0
        for w in self._pinned:
            if total:
                total += sp
            total += w.sizeHint().width()
        for w, _ in self._chips:
            if total:
                total += sp
            total += w.sizeHint().width()
        heights = [w.sizeHint().height() for w in self._pinned]
        heights += [w.sizeHint().height() for w, _ in self._chips]
        return QSize(total, max(heights) if heights else 0)


# ------------------------------------------------------------------ queue card
def _sdc_letter_for_task(db, task, contacts=None):
    """(letter, is_override) for a task's seismic SDC, or (None, False).

    Shared resolution order (task override, linked CRM city/state,
    parsed field text). _make_sdc_badge and the task table both use it
    so the letter can never differ between modules. When ``contacts``
    (a lowercase-name -> row map from ``directory_customers_by_name``)
    is given, the CRM lookup resolves in memory instead of one query
    per card; without it the lookup queries exactly as before.
    """
    try:
        from .seismic import resolve_sdc
    except Exception:
        return None, False
    if db is None:
        return None, False
    name = (task.get("end_user") or "").strip()
    override = task.get("seismic_override")
    city = state = None
    if name:
        if contacts is not None:
            contact = contacts.get(name.lower())
        else:
            try:
                contact = db.directory_get_by_name("customer", name)
            except Exception:
                contact = None
        if contact:
            city = (contact.get("city") or "").strip() or None
            state = (contact.get("state") or "").strip() or None
    return resolve_sdc(override, city, state, name or None)


def _make_sdc_badge(db, task, contacts=None):
    """Build the seismic SDC badge for a task, or None when unknown.

    Shared by all cards so the indicator is identical in
    every module: same ``Est.``/manual text, same severity styling
    hook. Placement is the caller's job; the badge itself must never
    differ between modules.
    """
    try:
        from .seismic import (sdc_badge_text, sdc_severity, sdc_tooltip)
    except Exception:
        return None
    if db is None:
        return None
    letter, is_override = _sdc_letter_for_task(db, task, contacts)
    if not letter:
        return None
    badge = QLabel(sdc_badge_text(letter, is_override))
    badge.setObjectName("sdcBadge")
    badge.setProperty("sdcSeverity", sdc_severity(letter))
    badge.setToolTip(sdc_tooltip(is_override))
    chip_font(badge)
    return badge


# ---------------------------------------------------------------- queue column
class ElidedLabel(QLabel):
    """QLabel that elides (… ) its full text to the available width.

    v1.4.0 P1c: long renamed queue-column titles elide instead of
    smashing the header. The full text is kept for the tooltip.
    """

    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._full_text = text
        self.setWordWrap(False)
        chip_font(self)
        super().setText(text)

    def setText(self, text):
        self._full_text = text or ""
        self._apply_elision()

    def fullText(self):
        return self._full_text

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._apply_elision()

    def _apply_elision(self):
        w = max(0, self.width() - 4)
        elided = self.fontMetrics().elidedText(
            self._full_text, Qt.ElideRight, w)
        # Bypass our setText override to avoid re-running elision.
        QLabel.setText(self, elided)


def _queue_card_sig(task, sdc_contacts):
    """A queue card's rendered content as a comparable string:
    every task field the card paints, plus the CRM contact data
    its SDC badge resolves from. Two refreshes with equal
    signatures would paint identical cards."""
    try:
        items = tuple(sorted(
            (k, repr(v)) for k, v in task.items()))
    except Exception:
        items = (("id", repr(task.get("id"))),)
    contact = None
    if sdc_contacts:
        try:
            contact = sdc_contacts.get(
                (task.get("end_user") or "").strip().lower())
        except Exception:
            contact = None
    return repr((items, contact))


class QueueColumn(QFrame):
    """One kanban column; accepts card drops at a computed insert index."""

    card_dropped = Signal(int, str, int)  # task_id, column_key, index
    card_open_requested = Signal(int)
    card_remove_requested = Signal(int)
    scope_toggled = Signal(int, str, bool)
    hot_toggled = Signal(int)  # V1.9.5
    status_chosen = Signal(int, str)
    edit_requested = Signal(int)
    delete_requested = Signal(int)

    def __init__(self, column_key, title, parent=None, db=None):
        super().__init__(parent)
        self.column_key = column_key
        self.db = db
        self.setObjectName("queueColumn")
        self.setAcceptDrops(True)
        # Sensible floor so a column stays usable on narrow windows; the
        # board's equal stretch shares any extra width between columns.
        self.setMinimumWidth(QUEUE_COLUMN_MIN_WIDTH)
        # V1.9.10 drag polish state: insertion placeholder + auto-scroll.
        self._drop_ph = None        # placeholder QFrame (created lazily)
        self._drop_index = None     # card index the placeholder marks
        self._drop_ph_height = 0    # current placeholder height (px)
        self._drop_anim = None      # running height animation, if any
        self._drop_hint = None      # "Drop tasks here" label, when shown
        self._drag_pos = None       # last drag position (column coords)
        self._autoscroll_timer = QTimer(self)
        self._autoscroll_timer.setInterval(30)
        self._autoscroll_timer.timeout.connect(self._autoscroll_step)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        head = QHBoxLayout()
        head.setContentsMargins(2, 0, 2, 0)
        self.title_label = ElidedLabel(title)
        self.title_label.setObjectName("colTitle")
        # v1.4.0 P1c: long renamed titles elide instead of smashing the
        # header; full title on hover. Centered in the column, in line
        # with the count badge.
        self.title_label.setSizePolicy(
            QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.title_label.setAlignment(Qt.AlignCenter)
        self.badge = QLabel("0")
        self.badge.setObjectName("countBadge")
        chip_font(self.badge)
        # Mirror spacer (badge width) on the left so the centered title
        # sits at the true column center, badge at the right edge.
        self._title_spacer = QWidget()
        self._title_spacer.setFixedWidth(self.badge.sizeHint().width())
        head.addWidget(self._title_spacer)
        head.addWidget(self.title_label, 1)
        head.addWidget(self.badge)
        layout.addLayout(head)
        self._title = title
        self._count = 0
        self._wip_limit = None

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.cards_host = QWidget()
        self.cards_layout = QVBoxLayout(self.cards_host)
        self.cards_layout.setSpacing(8)
        self.cards_layout.setAlignment(Qt.AlignTop)
        self.scroll.setWidget(self.cards_host)
        # V1.9.65: pen/mouse drag scrolling is ON here too (it
        # was touch-only, so the pen did nothing in the queue).
        # Cards take their own presses for QDrag; the scroller
        # receives the presses that land on empty column area
        # and propagate to the viewport.
        enable_touch_scroll(self.scroll)
        # App-wide scroll insets: cards keep clear of the viewport edges
        # and the vertical scrollbar.
        set_scroll_content_margins(self.scroll)
        layout.addWidget(self.scroll, 1)

    def set_title(self, title):
        self._title = title
        self.title_label.setText(title)
        self.title_label.setToolTip(title)

    def set_tasks(self, tasks, wip_limit=None, sdc_contacts=None):
        # A rebuild invalidates any in-flight drop placeholder.
        self._drop_ph = None
        self._drop_index = None
        self._drop_ph_height = 0
        self._drop_hint = None
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
                w.setParent(None)  # detach now; deleteLater alone leaves it painted
                w.deleteLater()
        for t in tasks:
            card = TaskCard(t, db=self.db, show_remove=True,
                            column_key=self.column_key,
                            sdc_contacts=sdc_contacts)
            card.open_requested.connect(self.card_open_requested.emit)
            card.remove_requested.connect(self.card_remove_requested.emit)
            card.scope_toggled.connect(self.scope_toggled.emit)
            card.hot_toggled.connect(self.hot_toggled.emit)
            card.status_chosen.connect(self.status_chosen.emit)
            card.edit_requested.connect(self.edit_requested.emit)
            card.delete_requested.connect(self.delete_requested.emit)
            self.cards_layout.addWidget(card)
        if not tasks:
            hint = QLabel("Drop tasks here")
            hint.setObjectName("dropHint")
            hint.setAlignment(Qt.AlignCenter)
            self.cards_layout.addWidget(hint)
            self._drop_hint = hint
        self._count = len(tasks)
        self._wip_limit = wip_limit
        self._update_header()

    def _update_header(self):
        if self._wip_limit:
            self.badge.setText(f"{self._count} / {self._wip_limit}")
            over = self._count > self._wip_limit
        else:
            self.badge.setText(str(self._count))
            over = False
        self.badge.setProperty("over", over)
        self.badge.style().unpolish(self.badge)
        self.badge.style().polish(self.badge)

    def _iter_cards(self):
        """Visible task cards in layout order (the hidden drag source and
        the drop placeholder are not cards for positioning purposes)."""
        for i in range(self.cards_layout.count()):
            w = self.cards_layout.itemAt(i).widget()
            if isinstance(w, TaskCard) and w.isVisible():
                yield w

    # -- drag & drop: insertion placeholder, highlight, auto-scroll -------
    def _ensure_placeholder(self):
        if self._drop_ph is None:
            ph = QFrame()
            ph.setObjectName("dropPlaceholder")
            lay = QVBoxLayout(ph)
            lay.setContentsMargins(8, 8, 8, 8)
            lay.addStretch(1)
            lab = QLabel("Release to place here")
            lab.setObjectName("dropPlaceholderText")
            lab.setAlignment(Qt.AlignCenter)
            lay.addWidget(lab)
            lay.addStretch(1)
            ph.setVisible(False)
            self._drop_ph = ph
        return self._drop_ph

    def _set_drop_active(self, on):
        self.setProperty("dropActive", bool(on))
        self.style().unpolish(self)
        self.style().polish(self)

    def _show_drop_placeholder(self, index):
        """Make room at ``index``: a card-size placeholder the other cards
        shift around (animated expansion when it first appears)."""
        ph = self._ensure_placeholder()
        lay = self.cards_layout
        if self._drop_index == index and lay.indexOf(ph) >= 0:
            return
        lay.removeWidget(ph)
        pos = lay.count()
        seen = 0
        for i in range(lay.count()):
            w = lay.itemAt(i).widget()
            if isinstance(w, TaskCard) and w.isVisible():
                if seen == index:
                    pos = i
                    break
                seen += 1
        lay.insertWidget(pos, ph)
        ph.setVisible(True)
        self._drop_index = index
        if self._drop_hint is not None:
            self._drop_hint.setVisible(False)
        target = 288
        for card in self._iter_cards():
            target = card.height()
            break
        if self._drop_ph_height != target:
            self._animate_placeholder_height(target)

    def _animate_placeholder_height(self, target):
        ph = self._drop_ph
        if self._drop_anim is not None:
            self._drop_anim.stop()
            self._drop_anim = None
        start = self._drop_ph_height
        ph.setFixedHeight(start)
        if start == target:
            return
        group = QParallelAnimationGroup(ph)
        for prop in (b"minimumHeight", b"maximumHeight"):
            anim = QPropertyAnimation(ph, prop, ph)
            anim.setDuration(130)
            anim.setStartValue(start)
            anim.setEndValue(target)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            group.addAnimation(anim)
        group.finished.connect(lambda: ph.setFixedHeight(target))
        group.start()
        self._drop_anim = group
        self._drop_ph_height = target

    def _hide_drop_placeholder(self):
        if self._drop_anim is not None:
            self._drop_anim.stop()
            self._drop_anim = None
        if self._drop_ph is not None:
            self.cards_layout.removeWidget(self._drop_ph)
            self._drop_ph.setVisible(False)
            self._drop_ph.setFixedHeight(0)
        self._drop_index = None
        self._drop_ph_height = 0
        if self._drop_hint is not None:
            self._drop_hint.setVisible(True)

    def _autoscroll_step(self):
        """While dragging near the column's top/bottom edge, scroll so
        long columns stay usable mid-drag; the placeholder follows."""
        if self._drag_pos is None:
            return
        vp = self.scroll.viewport()
        local = vp.mapFrom(self, self._drag_pos)
        bar = self.scroll.verticalScrollBar()
        step = 0
        if local.y() < 56:
            step = -16
        elif local.y() > vp.height() - 56:
            step = 16
        if step:
            bar.setValue(bar.value() + step)
            self._show_drop_placeholder(self._index_at(self._drag_pos))

    # -- V1.9.48 manual card drag (see _CardDragSession): the
    # same placeholder/autoscroll machinery, driven directly --
    def _manual_drag_enter(self, global_pos):
        self._set_drop_active(True)
        self._drag_pos = self.mapFromGlobal(global_pos)
        self._show_drop_placeholder(self._index_at(self._drag_pos))
        if not self._autoscroll_timer.isActive():
            self._autoscroll_timer.start()

    def _manual_drag_move(self, global_pos):
        self._drag_pos = self.mapFromGlobal(global_pos)
        self._show_drop_placeholder(self._index_at(self._drag_pos))

    def _manual_drag_leave(self):
        self._autoscroll_timer.stop()
        self._drag_pos = None
        self._hide_drop_placeholder()
        self._set_drop_active(False)

    def _manual_drop_index(self, global_pos):
        return self._index_at(self.mapFromGlobal(global_pos))

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat(TaskCard.MIME):
            event.acceptProposedAction()
            self._set_drop_active(True)
            self._drag_pos = event.position().toPoint()
            self._show_drop_placeholder(self._index_at(self._drag_pos))
            if not self._autoscroll_timer.isActive():
                self._autoscroll_timer.start()

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat(TaskCard.MIME):
            event.acceptProposedAction()
            self._drag_pos = event.position().toPoint()
            self._show_drop_placeholder(self._index_at(self._drag_pos))

    def dragLeaveEvent(self, event):
        self._autoscroll_timer.stop()
        self._drag_pos = None
        self._hide_drop_placeholder()
        self._set_drop_active(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        self._autoscroll_timer.stop()
        self._drag_pos = None
        self._hide_drop_placeholder()
        self._set_drop_active(False)
        if not event.mimeData().hasFormat(TaskCard.MIME):
            return
        try:
            task_id = int(bytes(event.mimeData().data(TaskCard.MIME)).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return
        index = self._index_at(event.position().toPoint())
        self.card_dropped.emit(task_id, self.column_key, index)
        event.acceptProposedAction()

    def _index_at(self, pos):
        """Insert index for a drop at column-local pos (insert before card)."""
        local = self.cards_host.mapFrom(self, pos)
        for i, card in enumerate(self._iter_cards()):
            if local.y() < card.geometry().center().y():
                return i
        return sum(1 for _ in self._iter_cards())


# ------------------------------------------------------------------ queue page
def sort_queue_tasks(tasks, mode):
    """Order queue-card task dicts within a column (v1.4.0 item 5).

    Mirrors the db.SORT_MODES ORDER BY semantics in Python, because the
    queue board works from in-memory task dicts in manual column order.
    "manual" (the default) keeps the stored queue_task_ids order.
    Composed of stable sorts so multi-key precedence matches the SQL.
    """
    tasks = list(tasks)
    if mode == "newest":
        tasks.sort(key=lambda t: t.get("id") or 0, reverse=True)
        tasks.sort(key=lambda t: t.get("created_at") or "", reverse=True)
    elif mode == "oldest":
        tasks.sort(key=lambda t: t.get("id") or 0)
        tasks.sort(key=lambda t: t.get("created_at") or "")
    elif mode == "due_soon":
        tasks.sort(key=lambda t: t.get("id") or 0, reverse=True)
        tasks.sort(key=lambda t: t.get("created_at") or "", reverse=True)
        tasks.sort(key=lambda t: t.get("due_date") or "")
        tasks.sort(key=lambda t: 0 if (t.get("due_date") or "") else 1)
    elif mode == "quote_az":
        tasks.sort(key=lambda t: t.get("id") or 0, reverse=True)
        tasks.sort(key=lambda t: (t.get("quote_number") or "").lower())
    elif mode == "quote_za":
        tasks.sort(key=lambda t: t.get("id") or 0, reverse=True)
        tasks.sort(key=lambda t: (t.get("quote_number") or "").lower(),
                   reverse=True)
    elif mode == "dist_az":
        tasks.sort(key=lambda t: t.get("id") or 0, reverse=True)
        tasks.sort(key=lambda t: (t.get("distributor") or "").lower())
    return tasks


class QueuePage(QWidget):
    """Priority kanban board for open tasks."""

    card_open_requested = Signal(int)
    scope_toggled = Signal(int, str, bool)
    hot_toggled = Signal(int)  # V1.9.5
    status_chosen = Signal(int, str)
    edit_requested = Signal(int)
    delete_requested = Signal(int)

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        header = QHBoxLayout()
        header.setSpacing(12)
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title = QLabel("Queue")
        title.setObjectName("title")
        subtitle = QLabel("Your priority board. Drag cards between columns to plan the work.")
        subtitle.setObjectName("subtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box)
        header.addStretch(1)
        new_btn = QPushButton("+ New Task")
        new_btn.setCursor(Qt.PointingHandCursor)
        new_btn.setToolTip("Create a new task and file it into a queue column")
        new_btn.clicked.connect(self.open_new_task)
        header.addWidget(new_btn)
        add_btn = QPushButton("+ Add Tasks")
        add_btn.setObjectName("primary")
        add_btn.setCursor(Qt.PointingHandCursor)
        add_btn.clicked.connect(self.open_add_dialog)
        header.addWidget(add_btn)
        layout.addLayout(header)

        # ---- queue filter row: text search + "Due this week" chip ----
        controls = QHBoxLayout()
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(10)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter queue…")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(280)
        self.search.textChanged.connect(self._on_filter_text)
        controls.addWidget(self.search)
        self._sort_mode = "manual"
        self._sort_combo = SafeComboBox()
        # Polished popup matching the other sort dropdowns (themes.py
        # QComboBox#sortBox); without the object name it falls back to the
        # generic popup style.
        self._sort_combo.setObjectName("sortBox")
        self._sort_combo.addItem("Manual order", "manual")
        self._sort_combo.addItem("Newest first", "newest")
        self._sort_combo.addItem("Oldest first", "oldest")
        self._sort_combo.addItem("Due soon", "due_soon")
        self._sort_combo.addItem("Quote # A–Z", "quote_az")
        self._sort_combo.addItem("Quote # Z–A", "quote_za")
        self._sort_combo.addItem("Distributor A–Z", "dist_az")
        self._sort_combo.setToolTip("Order cards within each column")
        self._sort_combo.currentIndexChanged.connect(self._on_sort_changed)
        controls.addWidget(self._sort_combo)
        controls.addStretch(1)
        # "Due this week" sits at the right edge, past the stretch — not
        # centered between the differently sized search/sort controls.
        self._due_chip = QPushButton("Due this week")
        self._due_chip.setObjectName("dueChip")
        self._due_chip.setCheckable(True)
        chip_font(self._due_chip)
        self._due_chip.setCursor(Qt.PointingHandCursor)
        self._due_chip.setToolTip(
            "Show only open tasks due within 7 days (or overdue)")
        self._due_chip.toggled.connect(self._on_due_chip)
        controls.addWidget(self._due_chip)
        layout.addLayout(controls)
        self._filter_text = ""
        self._due_only = False

        board_host = QWidget()
        board = QHBoxLayout(board_host)
        # Tightened: 8px inset and gaps give columns/cards more width.
        board.setContentsMargins(8, 8, 8, 8)
        board.setSpacing(8)
        self._board = board
        self._board_host = board_host
        self.columns = {}
        self._build_columns()
        # v1.4.0 item 11: the board scrolls horizontally on narrow windows
        # instead of smashing the columns; each column keeps its sensible
        # minimum width (QUEUE_COLUMN_MIN_WIDTH) and cards stay intact.
        board_scroll = QScrollArea()
        board_scroll.setObjectName("queueBoardScroll")
        board_scroll.setFrameShape(QFrame.NoFrame)
        board_scroll.setWidgetResizable(True)
        board_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        board_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        board_scroll.setWidget(board_host)
        layout.addWidget(board_scroll, 1)
        # V1.9.65: same pen parity as the columns (was touch-only).
        enable_touch_scroll(board_scroll)
        _chip_font_tree(self)

    def _build_columns(self):
        """(Re)build board columns from the configured names."""
        for _key, col in self.columns.items():
            self._board.removeWidget(col)
            col.hide()  # V1.9.50: hide BEFORE detach -- a visible widget unparented becomes a top-level window until deleteLater runs (the queue screen's flashing small window)
            col.setParent(None)
            col.deleteLater()
        self.columns = {}
        for key, label in queue_columns_normalized(self.db):
            col = QueueColumn(key, label, db=self.db)
            col.card_dropped.connect(self._on_card_dropped)
            col.card_open_requested.connect(self.card_open_requested.emit)
            col.card_remove_requested.connect(self._on_card_remove)
            col.scope_toggled.connect(self.scope_toggled.emit)
            col.hot_toggled.connect(self.hot_toggled.emit)
            col.status_chosen.connect(self.status_chosen.emit)
            col.edit_requested.connect(self.edit_requested.emit)
            col.delete_requested.connect(self.delete_requested.emit)
            col.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self._board.addWidget(col, 1)
            self.columns[key] = col

    def refresh(self):
        # V1.9.52 (user: "when i drop it the other cards flash?
        # They should not. none should flash."): updates are
        # frozen while the board rebuilds, so no empty or
        # half-repainted intermediate frame can present -- the
        # board paints exactly once, finished.
        self.setUpdatesEnabled(False)
        try:
            self._refresh_body()
        finally:
            self.setUpdatesEnabled(True)

    def _refresh_body(self):
        self.db.queue_prune()
        cols = queue_columns_normalized(self.db)
        if [k for k, _ in cols] != list(self.columns):
            self._build_columns()
        try:
            wip = self.db.get_queue_wip()
        except Exception:
            wip = {}
        data = self.db.queue_task_ids()
        needle = self._filter_text
        # V1.9.19 (launch): one CRM map for the whole refresh, not one
        # directory query per queue card (same fix as the task list).
        try:
            sdc_contacts = self.db.directory_customers_by_name()
        except Exception:
            sdc_contacts = None
        for key, label in cols:
            col = self.columns[key]
            col.set_title(label)
            tasks = []
            for tid in data.get(key, []):
                t = self.db.get_task(tid)
                if not t or t.get("status") not in OPEN_STATUSES:
                    continue
                if self._due_only and not due_this_week(t.get("due_date")):
                    continue
                if needle and needle not in (
                        f"{t.get('quote_number') or ''} "
                        f"{t.get('distributor') or ''} "
                        f"{t.get('end_user') or ''} "
                        f"{t.get('notes') or ''} "
                        f"{' '.join(t.get('scope') or [])}".lower()):
                    continue
                tasks.append(t)
            tasks = sort_queue_tasks(tasks, self._sort_mode)
            # V1.9.52: a column whose cards would be identical
            # is not rebuilt at all -- recreating unchanged
            # cards was the visible flash on every drop (and
            # most of the cost of every refresh).
            sig = (tuple(_queue_card_sig(t, sdc_contacts)
                         for t in tasks), wip.get(key))
            if getattr(col, "_card_sig", None) == sig:
                continue
            col.set_tasks(tasks, wip.get(key), sdc_contacts)
            col._card_sig = sig

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Column widths changed (window resized) -> wrapped text re-flows
        # to its natural height on its own; no height sync needed.

    def _on_filter_text(self, text):
        self._filter_text = text.strip().lower()
        self.refresh()

    def _on_due_chip(self, checked):
        self._due_only = bool(checked)
        self.refresh()

    def _on_sort_changed(self, index):
        self._sort_mode = self._sort_combo.itemData(index) or "manual"
        self.refresh()

    def _on_card_dropped(self, task_id, column_key, index):
        data = self.db.queue_task_ids()
        src_col = next((k for k, ids in data.items() if task_id in ids), None)
        src_index = data[src_col].index(task_id) if src_col is not None else None
        for ids in data.values():
            if task_id in ids:
                ids.remove(task_id)
        ids = data[column_key]
        # The drop index was computed with the source card still in its
        # column; compensate when moving down within the same column.
        if src_col == column_key and src_index is not None and src_index < index:
            index -= 1
        ids.insert(max(0, min(index, len(ids))), task_id)
        self.db.queue_set(data)
        # B3 (v1.4.0): a manual drag implies manual order — a sort is a
        # view-time override, so dropping a card reverts to Manual order.
        if self._sort_mode != "manual":
            self._sort_combo.blockSignals(True)
            self._sort_combo.setCurrentIndex(0)
            self._sort_combo.blockSignals(False)
            self._sort_mode = "manual"
        self.refresh()
        self._glide_dropped_card(task_id, column_key)

    def _glide_dropped_card(self, task_id, column_key):
        """V1.9.50 (user: dropped cards must glide, not snap):
        after the rebuild, fly a snapshot of the dropped card
        from the release rect to the card's real slot while the
        real card waits hidden, then swap. 180ms OutCubic --
        inside the app's 150-250ms motion language. Any miss
        (card filtered out, same place, tiny hop) just leaves
        the card where the rebuild put it."""
        col = self.columns.get(column_key)
        if col is None:
            return
        src = getattr(col, "_last_drop_rect", None)
        col._last_drop_rect = None
        if src is None:
            return
        card = None
        for i in range(col.cards_layout.count()):
            w = col.cards_layout.itemAt(i).widget()
            if isinstance(w, TaskCard) \
                    and w._task.get("id") == task_id:
                card = w
                break
        if card is None:
            return
        dst_global = QRect(card.mapToGlobal(QPoint(0, 0)), card.size())
        if (src.topLeft() - dst_global.topLeft()).manhattanLength() < 24:
            return
        try:
            pix = card.grab()
        except Exception:
            return
        # V1.9.51: the flyer is a CHILD of this page, not another
        # top-level window -- a new top-level window was the
        # white flash the user kept seeing on drops. Geometry is
        # page coords from here on.
        src = QRect(self.mapFromGlobal(src.topLeft()), src.size())
        dst = QRect(card.mapTo(self, QPoint(0, 0)), card.size())
        fly = QWidget(self)
        fly.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        fly.setAttribute(Qt.WA_TranslucentBackground, True)
        fly.setAttribute(Qt.WA_DeleteOnClose, True)
        lab = QLabel(fly)
        lab.setPixmap(pix)
        lab.setScaledContents(True)
        fly_lay = QVBoxLayout(fly)
        fly_lay.setContentsMargins(0, 0, 0, 0)
        fly_lay.addWidget(lab)
        fly.setGeometry(src)
        card.setVisible(False)
        fly.raise_()
        fly.show()
        anim = QPropertyAnimation(fly, b"geometry", fly)
        anim.setDuration(180)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.setStartValue(QRect(src))
        anim.setEndValue(dst)

        def _land():
            try:
                card.setVisible(True)
            except RuntimeError:
                pass
            fly.close()

        anim.finished.connect(_land)
        self._glide_anim = anim
        anim.start()

    def _on_card_remove(self, task_id):
        self.db.queue_remove(task_id)
        self.refresh()

    def open_new_task(self):
        """Queue header "New task": same New Task window as the Task List
        module, plus a queue-column picker (Now / Next / Later, read live
        from settings so renames are respected). The created task lands in
        the picked column (default: the first column)."""
        cols = queue_columns_normalized(self.db)
        first_key = cols[0][0] if cols else "now"

        def _file_into_column(task_id, _values, dialog):
            key = dialog.queue_column_key() or first_key
            self.db.queue_add(task_id, key)

        task_id = run_new_task_dialog(
            self.db, self,
            queue_columns=cols,
            on_created=_file_into_column,
            open_existing=self.card_open_requested.emit,
            on_settled=self.refresh,
        )
        if task_id:
            self.refresh()

    def open_add_dialog(self):
        queued = set()
        for ids in self.db.queue_task_ids().values():
            queued.update(ids)
        eligible = [
            t for t in self.db.list_tasks(view="all", sort="newest")
            if t["status"] in OPEN_STATUSES and t["id"] not in queued
        ]
        dlg = AddToQueueDialog(self.db, eligible, self)
        if dlg.exec():
            for tid in dlg.selected_ids():
                self.db.queue_add(tid, dlg.column_key())
            self.refresh()


# ------------------------------------------------------ follow-ups widget
class FollowUpRow(QFrame):
    """One follow-up row. Clicking the body opens the task detail window.

    The Open / Snooze buttons keep their own actions: child widgets
    consume their own clicks, so only body clicks reach the row.
    Keyboard: the row is focusable; Enter/Space opens the task.
    """

    open_requested = Signal(int)  # task_id

    def __init__(self, task_id, parent=None):
        super().__init__(parent)
        self._task_id = task_id
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setToolTip("Open task")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.open_requested.emit(self._task_id)
        super().mousePressEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.open_requested.emit(self._task_id)
            event.accept()
            return
        super().keyPressEvent(event)


class FollowUpsWidget(QWidget):
    """'Follow-ups due' section for the dashboard Nudges tab.

    Coordinator wiring (dashboard.py is owned by another worker — do NOT
    reimplement this there, instantiate this class):

        widget = FollowUpsWidget(db)
        nudges_layout.insertWidget(0, widget)  # TOP, above distributor nudges
        widget.open_requested.connect(<open the task detail>)
        widget.reminders_changed.connect(<refresh KPI cards>)
        # call widget.refresh() whenever the Nudges tab is shown.

    In-app only: snooze/dismiss write straight to the db via
    db.set_remind_at(); no OS notifications, no timers.
    """

    open_requested = Signal(int)  # user clicked Open for task_id
    reminders_changed = Signal()  # a snooze/dismiss changed the data

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        head = QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        title = QLabel("FOLLOW-UPS DUE")
        title.setObjectName("sectionLabel")
        head.addWidget(title)
        self._count = QLabel()
        self._count.setObjectName("countBadge")
        head.addWidget(self._count)
        head.addStretch(1)
        layout.addLayout(head)
        self._rows = QVBoxLayout()
        self._rows.setContentsMargins(0, 0, 0, 0)
        self._rows.setSpacing(6)
        layout.addLayout(self._rows)
        self.refresh()

    def refresh(self):
        """Reload from db.follow_ups_due(). Call when the tab is shown."""
        while self._rows.count():
            item = self._rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        try:
            due = self.db.follow_ups_due()
        except Exception:
            due = []
        self._count.setText(str(len(due)))
        if not due:
            none = QLabel("No follow-ups due.")
            none.setObjectName("hint")
            self._rows.addWidget(none)
            return
        for t in due:
            self._rows.addWidget(self._row_widget(t))

    def _row_widget(self, t):
        tid = t["id"]
        row = FollowUpRow(tid)
        row.setObjectName("followRow")
        # Row body click opens the task; buttons keep their own actions.
        row.open_requested.connect(self.open_requested.emit)
        h = QHBoxLayout(row)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(10)
        quote = QLabel(t.get("quote_number") or "—")
        quote.setObjectName("quoteNum")
        h.addWidget(quote)
        dist = QLabel(t.get("distributor") or "—")
        dist.setObjectName("meta")
        h.addWidget(dist, 1)
        h.addWidget(QLabel(self._when_label(t.get("remind_at"))))
        for label, slot in (
            ("Open", lambda _c=False, tid=tid: self.open_requested.emit(tid)),
            ("Snooze 3d", lambda _c=False, tid=tid: self._snooze(tid, 3)),
            ("Snooze 1w", lambda _c=False, tid=tid: self._snooze(tid, 7)),
            ("Dismiss", lambda _c=False, tid=tid: self._dismiss(tid)),
        ):
            b = QPushButton(label)
            b.setObjectName("ghost")
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(slot)
            h.addWidget(b)
        return row

    @staticmethod
    def _when_label(remind_at):
        try:
            d = date.fromisoformat((remind_at or "")[:10])
        except ValueError:
            return "—"
        delta = (d - date.today()).days
        if delta < 0:
            return f"Overdue {-delta}d"
        if delta == 0:
            return "Today"
        return short_date(d.isoformat())

    def _snooze(self, task_id, days):
        new_date = (date.today() + timedelta(days=days)).isoformat()
        self.db.set_remind_at(task_id, new_date)
        self.db.log_activity(task_id, "reminder",
                             f"Follow-up snoozed to {new_date}")
        self.refresh()
        self.reminders_changed.emit()

    def _dismiss(self, task_id):
        self.db.set_remind_at(task_id, None)
        self.db.log_activity(task_id, "reminder", "Follow-up dismissed")
        self.refresh()
        self.reminders_changed.emit()


# ----------------------------------------------------------- add-to-queue dialog
class AddToQueueDialog(QDialog):
    """Pick open tasks to pull into the queue."""

    def __init__(self, db, eligible_tasks, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add Tasks")
        self.setModal(True)
        self.setMinimumSize(460, 480)

        layout = install_chrome(self, "Add Tasks to Queue")

        info = QLabel("Pick open tasks to pull into the queue.")
        info.setObjectName("hint")
        info.setWordWrap(True)
        layout.addWidget(info)

        search_box = QVBoxLayout()
        search_box.setContentsMargins(0, 0, 0, 0)
        search_box.setSpacing(3)
        self.search_count = CountLabel()
        search_box.addWidget(self.search_count)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search quote, distributor, end user…")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._on_search)
        search_box.addWidget(self.search)
        layout.addLayout(search_box)

        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        lab = QLabel("Add to")
        lab.setObjectName("fieldLabel")
        row.addWidget(lab)
        seg = QFrame()
        seg.setObjectName("segBar")
        seg.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        seg_lay = QHBoxLayout(seg)
        seg_lay.setContentsMargins(4, 4, 4, 4)
        seg_lay.setSpacing(2)
        self._col_group = QButtonGroup(self)
        self._col_group.setExclusive(True)
        self._col_buttons = {}
        for key, label in queue_columns_normalized(db):
            b = SegButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            chip_font(b)
            b.setCursor(Qt.PointingHandCursor)
            self._col_group.addButton(b)
            seg_lay.addWidget(b)
            self._col_buttons[key] = b
        first = next(iter(self._col_buttons), None)
        if first is not None:
            self._col_buttons[first].setChecked(True)
        row.addWidget(seg)
        row.addStretch(1)
        layout.addLayout(row)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        host = QWidget()
        checks_layout = QVBoxLayout(host)
        checks_layout.setSpacing(4)
        checks_layout.setAlignment(Qt.AlignTop)
        enable_touch_scroll(scroll)
        self._checks = []
        for t in eligible_tasks:
            who = t["distributor"] or "No distributor"
            cb = QCheckBox(f"{t['quote_number']}  —  {who}")
            cb.setObjectName("queueCheck")
            cb.setProperty("task_id", t["id"])
            cb.setProperty("search_text",
                           f"{t['quote_number']} {t['distributor']} {t['end_user']}".lower())
            checks_layout.addWidget(cb)
            self._checks.append(cb)
        self._no_match = QLabel("No tasks match your search.")
        self._no_match.setObjectName("emptyState")
        self._no_match.setAlignment(Qt.AlignCenter)
        self._no_match.hide()
        checks_layout.addWidget(self._no_match)
        if not eligible_tasks:
            empty = QLabel("Every open task is already in the queue.")
            empty.setObjectName("emptyState")
            empty.setAlignment(Qt.AlignCenter)
            checks_layout.addWidget(empty)
        scroll.setWidget(host)
        # App-wide scroll insets: checkboxes keep clear of the viewport
        # edges and the vertical scrollbar.
        set_scroll_content_margins(scroll)
        layout.addWidget(scroll, 1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        add = QPushButton("Add to Queue")
        add.setObjectName("primary")
        add.setDefault(True)
        add.clicked.connect(self.accept)
        footer.addWidget(cancel)
        footer.addWidget(add)
        layout.addLayout(footer)

    def _on_search(self, text):
        needle = text.strip().lower()
        visible = 0
        for cb in self._checks:
            match = not needle or needle in cb.property("search_text")
            cb.setVisible(match)
            visible += match
        self._no_match.setVisible(bool(self._checks) and visible == 0)
        total = len(self._checks)
        self.search_count.set_count(f"{visible} of {total}" if needle else "")

    def selected_ids(self):
        return [cb.property("task_id") for cb in self._checks if cb.isChecked()]

    def column_key(self):
        for key, btn in self._col_buttons.items():
            if btn.isChecked():
                return key
        return next(iter(self._col_buttons), "now")


# ------------------------------------------------------------------ notes page

def _fmt_note_date(iso):
    """'2026-09-30T08:12:44' -> 'Today' / 'Yesterday' / 'Sep 29, 2026'."""
    try:
        dt = datetime.fromisoformat(str(iso or ""))
    except (ValueError, TypeError):
        return ""
    today = date.today()
    if dt.date() == today:
        return "Today"
    if dt.date() == today - timedelta(days=1):
        return "Yesterday"
    # %-d is not portable (Windows); strip the zero pad manually.
    return dt.strftime("%b %d, %Y").replace(" 0", " ")


NOTE_DRAG_MIME = "application/x-tasklist-note-ids"


class _NoteListWidget(QListWidget):
    """The notes list (V1.9.47): extended selection (Ctrl/Shift
    click -- the standard behaviour the user asked why this app
    lacked) and the drag source for filing notes into notebooks
    by dragging them onto the nav."""

    def mimeData(self, items):  # noqa: N802 (Qt virtual)
        md = QMimeData()
        ids = [str(it.data(Qt.UserRole)) for it in items
               if it.data(Qt.UserRole) is not None]
        md.setData(NOTE_DRAG_MIME, ",".join(ids).encode("utf-8"))
        return md

    def startDrag(self, actions):  # noqa: N802 (Qt virtual)
        items = self.selectedItems()
        if not items:
            return
        drag = QDrag(self)
        drag.setMimeData(self.mimeData(items))
        row = self.itemWidget(self.currentItem())
        if row is not None:
            pm = row.grab()
            if len(items) > 1 and not pm.isNull():
                # A count chip on the drag image says the whole
                # selection is travelling, not just one note.
                p = QPainter(pm)
                p.setRenderHint(QPainter.Antialiasing, True)
                label = str(len(items))
                fm = p.fontMetrics()
                wch = fm.horizontalAdvance(label) + 14
                chip = QRectF(pm.width() - wch - 4, 4, wch, 20)
                p.setPen(Qt.NoPen)
                p.setBrush(QColor("#3b82f6"))
                p.drawRoundedRect(chip, 10, 10)
                p.setPen(QColor("#ffffff"))
                p.drawText(chip, Qt.AlignCenter, label)
                p.end()
            drag.setPixmap(pm)
            drag.setHotSpot(QPoint(12, 12))
        drag.exec(Qt.MoveAction)


class _NotebookDropList(QListWidget):
    """Notebooks list accepting note drags (V1.9.47): drop notes
    on a notebook to file them into it."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.on_notes_dropped = None    # callable(ids, notebook_id)

    def dragEnterEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.mimeData().hasFormat(NOTE_DRAG_MIME):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):  # noqa: N802 (Qt virtual)
        if event.mimeData().hasFormat(NOTE_DRAG_MIME):
            if self.itemAt(event.position().toPoint()) is not None:
                event.acceptProposedAction()
            else:
                event.ignore()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):  # noqa: N802 (Qt virtual)
        md = event.mimeData()
        if md.hasFormat(NOTE_DRAG_MIME):
            item = self.itemAt(event.position().toPoint())
            if item is not None and self.on_notes_dropped:
                raw = bytes(md.data(NOTE_DRAG_MIME)).decode("utf-8")
                ids = [int(x) for x in raw.split(",") if x]
                if ids:
                    self.on_notes_dropped(ids, item.data(Qt.UserRole))
                event.acceptProposedAction()
                return
        super().dropEvent(event)


class _NotebookRow(QWidget):
    """One row in the notes nav: notebook name + note-count badge."""

    def __init__(self, name, count, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 7, 10, 7)
        layout.setSpacing(8)
        icon = QLabel()
        icon.setPixmap(svg_icon("notebook", "#6b7078", 15).pixmap(15, 15))
        layout.addWidget(icon)
        name_label = QLabel(esc_plain(name))
        name_label.setObjectName("noteNavName")
        name_label.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout.addWidget(name_label)
        # V1.9.47 (user: "that box around the 0 needs to be gone"):
        # the count is bare muted text now -- no badge background,
        # no fixed-width box.
        badge = QLabel(str(count))
        badge.setObjectName("noteCount")
        badge.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(badge)


class _NoteRow(QWidget):
    """One row in the notes list: title, snippet, notebook + date footer."""

    def __init__(self, note, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(3)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(6)
        title = QLabel(esc_plain(note.get("title") or "Untitled note"))
        title.setObjectName("noteRowTitle")
        title.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        top.addWidget(title)
        if note.get("pinned"):
            pin = QLabel()
            pin.setPixmap(svg_icon("pin", "#8a919c", 13).pixmap(13, 13))
            pin.setToolTip("Pinned")
            top.addWidget(pin)
        layout.addLayout(top)

        snippet = (note.get("snippet") or "").strip()
        if snippet:
            snip = QLabel(esc_plain(snippet))
            snip.setObjectName("noteSnippet")
            snip.setWordWrap(True)
            layout.addWidget(snip)

        bits = [p for p in (note.get("notebook_name"),
                            _fmt_note_date(note.get("updated_at"))) if p]
        footer = QLabel(esc_plain("  ·  ".join(bits)))
        footer.setObjectName("noteFooter")
        layout.addWidget(footer)


# OneNote/Word paste sanitizer: those apps stamp explicit colors onto
# pasted content — white page-backgrounds (background:#FFFFFF on spans,
# table cells, even the body) AND black default text (color:black,
# color:#000000, Word's color:windowtext which Qt resolves to black).
# Qt keeps them verbatim, so on the dark theme a paste lands as
# black-on-black text, and white-highlight blocks blind text in both
# themes. V1.9.14 strips only EXTREME colors — near-black and near-white
# — so pasted text inherits the theme default and stays readable in
# BOTH themes; intentional colors (orange stars, link blue, real
# highlights) pass through untouched. Word list paragraphs (mso-list)
# are also converted to real <ul>/<ol> items, because Qt ignores
# mso-list and would otherwise flatten them to plain paragraphs.
_EXTREME_DARK_MAX = 0x33   # max channel at/below this counts as near-black
_EXTREME_LIGHT_MIN = 0xE6  # min channel at/above this counts as near-white

_NAMED_COLORS = {
    "black": (0, 0, 0),
    "white": (255, 255, 255),
    # Word's "automatic" color: semantically "use the default", which Qt
    # resolves to explicit black — strip it so the theme default applies.
    "windowtext": (0, 0, 0),
}


def _parse_css_color(value):
    """(r, g, b) for a plain CSS color token, else None.

    Only single color tokens are parsed; compound values (gradients,
    shorthand with images) return None so they are left untouched.
    """
    v = value.strip().lower()
    if v in _NAMED_COLORS:
        return _NAMED_COLORS[v]
    m = re.fullmatch(r"#([0-9a-f]{3}|[0-9a-f]{6})", v)
    if m:
        h = m.group(1)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    m = re.fullmatch(
        r"rgba?\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})"
        r"(?:\s*,\s*[\d.]+)?\s*\)", v)
    if m:
        return tuple(int(x) for x in m.groups())
    return None


def _is_extreme_color(rgb):
    """True for near-black or near-white colors (unreadable on one theme)."""
    if rgb is None:
        return False
    r, g, b = rgb
    return (max(r, g, b) <= _EXTREME_DARK_MAX
            or min(r, g, b) >= _EXTREME_LIGHT_MIN)


def _value_has_color(val, pred):
    """True when a CSS value contains a color satisfying pred.

    V1.9.16: the old check parsed the WHOLE value as one color, so a
    compound shorthand ("background: white url(...)") or an rgb() with
    spaces slipped through — one route pasted white/black backgrounds
    survived by. A value counts when the whole value, any
    whitespace/comma token, or any rgb()/rgba() group in it parses to
    a color satisfying pred; intentional mid-tones still pass.
    """
    test = re.sub(r"\s*!important\s*$", "", val.strip(), flags=re.I)
    if pred(_parse_css_color(test)):
        return True
    for tok in re.split(r"[\s,]+", test):
        if pred(_parse_css_color(tok)):
            return True
    for m in re.finditer(r"rgba?\s*\([^)]*\)", test):
        if pred(_parse_css_color(m.group(0))):
            return True
    return False


def _value_has_extreme_color(val):
    """True when a CSS value contains a near-black/near-white color."""
    return _value_has_color(
        val, lambda rgb: rgb is not None and _is_extreme_color(rgb))


def _value_has_dark_extreme(val):
    return _value_has_color(
        val, lambda rgb: rgb is not None
        and max(rgb) <= _EXTREME_DARK_MAX)


def _value_has_light_extreme(val):
    return _value_has_color(
        val, lambda rgb: rgb is not None
        and min(rgb) >= _EXTREME_LIGHT_MIN)


def _value_has_dark(val):
    """True when a CSS value contains a dark color (any channel <= 0x80)."""
    return _value_has_color(
        val, lambda rgb: rgb is not None and max(rgb) <= 0x80)


def _value_has_light(val):
    """True when a CSS value contains a light color (any channel >= 0x80)."""
    return _value_has_color(
        val, lambda rgb: rgb is not None and min(rgb) >= 0x80)


def _clean_style_value(style, dark=True):
    """Drop pasted color declarations that would be unreadable.

    V1.9.18 (user screenshots, root cause): the old version stripped
    EVERY extreme color on both themes — so white OneNote text pasted
    into the dark editor lost its color and rendered black (the
    editor default), and light-gray answer backgrounds survived as a
    glaring strip. Theme-aware now: foreground keeps the readable
    side (white in dark mode, black in light mode) and drops only the
    invisible side; backgrounds keep the old extreme-stripping and
    additionally drop anything that clashes with the theme (any light
    bg in dark mode, any dark bg in light mode), so pasted blocks can
    never invert the editor. Mid-tones and marker highlights (yellow
    etc.) survive on both themes.
    """
    kept = []
    for decl in style.split(";"):
        decl = decl.strip()
        if not decl:
            continue
        if ":" not in decl:
            kept.append(decl)
            continue
        prop, _, val = decl.partition(":")
        prop = prop.strip().lower()
        val = val.strip()
        if prop == "color":
            if dark and _value_has_dark_extreme(val):
                continue
            if not dark and _value_has_light_extreme(val):
                continue
        elif prop in ("background", "background-color"):
            # Backgrounds keep the old extreme-stripping (black/white
            # blocks on either theme) AND gain clash-stripping: any
            # light bg in dark mode, any dark bg in light mode. The
            # light-gray answer strip that survived before was light
            # but not extreme — the clash half is what catches it.
            if (_value_has_extreme_color(val)
                    or (dark and _value_has_light(val))
                    or (not dark and _value_has_dark(val))):
                continue
        kept.append(decl)
    return "; ".join(kept)


_STYLE_ATTR_RE = re.compile(r"""\sstyle=(["'])(.*?)\1""")
_BGCOLOR_ATTR_RE = re.compile(
    r"""\sbgcolor\s*=\s*("?)([^"'\s>]+)\1""", re.IGNORECASE)
_FONT_COLOR_RE = re.compile(
    r"""\scolor\s*=\s*("?)([^"'\s>]+)\1""", re.IGNORECASE)
_MSO_P_RE = re.compile(r"<p([^>]*)>(.*?)</p>",
                       re.IGNORECASE | re.DOTALL)
_MSO_LIST_ID_RE = re.compile(r"mso-list\s*:\s*([A-Za-z0-9_-]+)",
                             re.IGNORECASE)
_MARKER_RE = r"(?:[·•o§–—\-]|\d+[.)]|[a-zA-Z][.)])"


def _marker_text(txt):
    """Decode bullet entities in a span's text for marker comparison."""
    txt = txt.replace("&nbsp;", " ").replace("\xa0", " ")
    txt = re.sub(r"&#(\d+);",
                 lambda m: chr(int(m.group(1)))
                 if int(m.group(1)) < 0x110000 else "", txt)
    txt = txt.replace("&bull;", "•").replace("&middot;", "·")
    return txt.strip()


_RAW_MARKER_PREFIX = re.compile(
    r"^(?:[·•o§–—\-]|\d+[.)]|[a-zA-Z][.)]|&#\d+;|&bull;|&middot;)"
    r"(?:\s|&nbsp;|\xa0)+")


def _strip_list_marker(inner):
    """Remove a Word list marker from the start of an item's inner HTML.

    Markers arrive as a leading span holding a bullet glyph or a number
    ("·", "1."), optionally followed by a whitespace-only span, plus
    &nbsp; padding — or with the marker at the front of the content
    span itself ("1. Step one"). Only the marker is removed; the item's
    own formatting spans and entities stay byte-identical. Runs a few
    passes because the marker and its padding can span several leading
    nodes.
    """
    s = inner
    for _ in range(5):
        s = re.sub(r"^(?:\s|&nbsp;|\xa0)+", "", s)
        m = re.match(r"<span([^>]*)>([^<]*)</span>", s)
        if m:
            raw_txt = m.group(2)
            txt = _marker_text(raw_txt)
            if txt == "":
                s = s[m.end():]
                continue
            if re.fullmatch(_MARKER_RE, txt):
                s = s[m.end():]
                continue
            pm = _RAW_MARKER_PREFIX.match(raw_txt)
            if pm:
                rest = raw_txt[pm.end():]
                s = f"<span{m.group(1)}>{rest}</span>" + s[m.end():]
                continue
            # Leading padding inside the content span (Word puts the
            # bullet's &nbsp; padding in its own span after the marker
            # span): strip it so items don't start with blank space.
            stripped = re.sub(r"^(?:\s|&nbsp;|\xa0)+", "", raw_txt)
            if stripped != raw_txt:
                s = f"<span{m.group(1)}>{stripped}</span>" + s[m.end():]
                continue
        m = _RAW_MARKER_PREFIX.match(s)
        if m:
            s = s[m.end():]
            continue
        m = re.match(_MARKER_RE + r"\s*", s)
        if m:
            s = s[m.end():]
            continue
        break
    return s


def _mso_item_parts(attrs, inner):
    """(list_id, tag, cleaned_inner) for a Word mso-list paragraph.

    Ordered when the visible text starts with a number/letter marker
    ("1.", "a)"); a bullet when it starts with a bullet glyph.
    Returns None when the paragraph is not a Word list item — and
    V1.9.18: when it carries an mso-list id but NO visible marker at
    all. OneNote exports some plain paragraphs (e.g. a "Question:"
    line) with a list id but an empty bullet, and the old code turned
    every one of them into a bulleted item Qt rendered with a bullet
    OneNote never showed. Plain text with no marker start stays a
    plain paragraph.
    """
    m = _MSO_LIST_ID_RE.search(attrs)
    if not m:
        return None
    text = re.sub(r"<[^>]+>", "", inner)
    text = text.replace("&nbsp;", " ").replace("\xa0", " ").lstrip()
    # V1.9.18 fix: markers arrive as entities (Word/Symbol writes
    # &#183;), and the marker check below must see the decoded glyph —
    # otherwise every entity-marker bullet read as "no marker" and
    # real lists stopped becoming lists.
    text = html.unescape(text)
    ordered = bool(re.match(r"(\d+|[a-zA-Z])[.)]\s", text))
    if not ordered and not re.match(r"[·•o§–—\-]", text):
        return None
    return (m.group(1), ("ol" if ordered else "ul"),
            _strip_leading_empty_span_colors(_strip_list_marker(inner)))


def _strip_leading_empty_span_colors(s):
    """Drop color from leading whitespace-only spans of a list item.

    V1.9.18 (user screenshot: faint list numbers): Qt paints a list
    item's marker with the block's FIRST character format. Word puts
    the marker's gray in a leading span that survives marker stripping
    (padding spans), so the marker renders faint gray while the item
    text renders white. Whitespace-only leading spans carry no visible
    text, so their color is safe to drop; the first real text span
    keeps its color, so intentional item colors survive.
    """
    out = []
    rest = s
    while True:
        m = re.match(r"<span([^>]*)>((?:\s|&nbsp;|\xa0)*)</span>", rest)
        if not m:
            return "".join(out) + rest
        attrs = re.sub(r"\s*color\s*:[^;\"']+;?", "", m.group(1),
                       flags=re.I)
        out.append(f"<span{attrs}>{m.group(2)}</span>")
        rest = rest[m.end():]


def _convert_mso_lists(html):
    """Convert Word mso-list paragraphs to real <ul>/<ol> lists.

    Consecutive items sharing a list id and kind group into one list;
    any real content between items (text, table cells) closes the group.
    Nesting levels are flattened — items keep their order and text,
    which is strictly better than the plain paragraphs Qt produced.
    """
    tokens = []
    pos = 0
    for m in _MSO_P_RE.finditer(html):
        if m.start() > pos:
            tokens.append(("text", html[pos:m.start()]))
        item = _mso_item_parts(m.group(1), m.group(2))
        if item is None:
            tokens.append(("text", m.group(0)))
        else:
            tokens.append(("item", item[0], item[1], item[2]))
        pos = m.end()
    if pos < len(html):
        tokens.append(("text", html[pos:]))
    out = []
    open_tag = None
    for tok in tokens:
        if tok[0] == "text":
            if open_tag is not None and tok[1].strip():
                out.append(f"</{open_tag[1]}>")
                open_tag = None
            out.append(tok[1])
        else:
            _, list_id, tag, cleaned = tok
            if open_tag != (list_id, tag):
                if open_tag is not None:
                    out.append(f"</{open_tag[1]}>")
                out.append(f"<{tag}>")
                open_tag = (list_id, tag)
            out.append(f"<li>{cleaned}</li>")
    if open_tag is not None:
        out.append(f"</{open_tag[1]}>")
    return "".join(out)


_STYLE_BLOCK_RE = re.compile(r"<style[^>]*>(.*?)</style>",
                              re.IGNORECASE | re.DOTALL)
_UNC_START_RE = re.compile(r"\\\\[A-Za-z0-9_.$\-]+\\[^\s<>\"]+")
_UNC_PATHLIKE_RE = re.compile(r"[\\_.\-0-9]")


def _unc_to_file_url(path):
    """A UNC path (\\server\\share\\a b) as a file:// URL for Qt."""
    return "file:" + _url_quote(path.replace("\\", "/"), safe="/:")


def _is_pathlike_token(tok):
    """A space-separated token that reads as path, not prose.

    Path segments are capitalized or carry a path character (backslash,
    dot, digit, underscore, dash); prose words are plain lowercase.
    """
    return tok[:1].isupper() or bool(_UNC_PATHLIKE_RE.search(tok))


def _extend_unc(text, start):
    """The full UNC path starting at `start`, spaces included.

    Paths with spaces ("Samples Dwg Views") must survive, but a path
    followed by prose ("...\\file for details") must not swallow the
    prose: after the first segment, following tokens join only while
    they look like path. Trailing punctuation (.,;:) is cut.
    """
    m = _UNC_START_RE.match(text, start)
    if m is None:
        return None
    end = m.end()
    while end < len(text) and text[end] == " ":
        nxt = re.match(r"[^ \n<>\"']+", text[end + 1:])
        if nxt is None or not _is_pathlike_token(nxt.group(0)):
            break
        end = end + 1 + nxt.end()
    return text[start:end].rstrip(".,;:")


def _linkify_unc_paths(html):
    """Wrap bare UNC paths in text (never inside tags) in real anchors.

    V1.9.16 (user report): OneNote paths pasted as blue underlined
    text that did nothing on Ctrl+click — styled spans, not anchors.
    Only text segments are touched, so existing attributes never gain
    a nested anchor. The visible text stays the original path; only
    the href is added.
    """
    out = []
    pos = 0
    for m in re.finditer(r"<[^>]+>", html):
        if m.start() > pos:
            out.append(_linkify_unc_text(html[pos:m.start()]))
        out.append(m.group(0))
        pos = m.end()
    if pos < len(html):
        out.append(_linkify_unc_text(html[pos:]))
    return "".join(out)


def _linkify_unc_text(text):
    out = []
    pos = 0
    for m in _UNC_START_RE.finditer(text):
        if m.start() < pos:
            continue
        path = _extend_unc(text, m.start())
        if path is None:
            continue
        out.append(text[pos:m.start()])
        out.append(f'<a href="{_unc_to_file_url(path)}">{path}</a>')
        pos = m.start() + len(path)
    out.append(text[pos:])
    return "".join(out)


def _clamp_img_dims(tag, nw, nh, dpr=1.0):
    """Clamp an <img> tag's stated display size (width/height attrs
    AND style px sizes) to the raster's native size — Qt upscales
    to an overstated size, which is exactly the paste blur.

    V1.9.38: the stated sizes are LOGICAL pixels (QTextImageFormat),
    the raster is PHYSICAL pixels. On a scaled display (the user's
    Surface, DPR 1.25-2.0) a size written as the raw raster count
    displays that many logical px = dpr times too many physical
    px, and Qt upscales the raster to fill them — the standing
    "pasted screenshots are blurry" report, even though the stored
    bytes are bit-perfect since V1.9.31. The native limit is
    therefore native/dpr logical px, which paints the raster 1:1.
    """
    lw = max(1, round(nw / dpr)) if dpr and dpr > 0 else nw
    lh = max(1, round(nh / dpr)) if dpr and dpr > 0 else nh

    def _clamp_dim(dm):
        name, _q, digits = dm.group(1), dm.group(2), dm.group(3)
        try:
            v = int(digits)
        except ValueError:
            return dm.group(0)
        limit = lw if name.lower() == "width" else lh
        if v > limit:
            return f'{name}="{limit}"'
        return dm.group(0)

    tag = re.sub(r"""(width|height)\s*=\s*("?)(\d+)\2""",
                 _clamp_dim, tag)

    # V1.9.18: OneNote also sizes images via style="width: Npx"
    # instead of width= attributes — clamp styled px sizes too.
    def _clamp_style(m):
        quote, body = m.group(1), m.group(2)

        def _cd(dm):
            prop, digits = dm.group(1).lower(), dm.group(2)
            try:
                v = int(digits)
            except ValueError:
                return dm.group(0)
            limit = lw if prop == "width" else lh
            if v > limit:
                return f"{prop}: {limit}px"
            return dm.group(0)

        body = re.sub(r"(width|height)\s*:\s*(\d+)px", _cd, body,
                      flags=re.I)
        return f" style={quote}{body}{quote}"

    return re.sub(r"""style=(["'])(.*?)\1""", _clamp_style, tag,
                  flags=re.I)


def _clamp_pasted_img(tag, dpr=1.0):
    """Never let a pasted <img> display larger than its native pixels.

    V1.9.16 (user report): pasted images looked pixelated — OneNote
    writes display sizes larger than the raster it supplies, and Qt
    upscales to the stated size. Data-URI images are decoded here and
    any overstated width/height is clamped to native; anything that
    fails to decode is left exactly as-is.
    """
    if not tag.lower().startswith("<img"):
        return tag
    src_m = re.search(r"""src=(["'])data:([^"']+)\1""", tag, re.I)
    if src_m is None:
        return tag
    data = src_m.group(2)
    if "," not in data or ";base64" not in data.split(",", 1)[0]:
        return tag
    try:
        import base64
        raw = base64.b64decode(data.split(",", 1)[1], validate=False)
        img = QImage()
        if not img.loadFromData(raw):
            return tag
        nw, nh = img.width(), img.height()
        if nw <= 0 or nh <= 0:
            return tag
    except Exception:
        return tag
    return _clamp_img_dims(tag, nw, nh, dpr)


_IMG_TAG_RE = re.compile(r"<img\b[^>]*>", re.I)
_IMG_SRC_RE = re.compile(r"""src\s*=\s*(["'])(.*?)\1""", re.I)


def _sniff_image_mime(raw):
    if raw.startswith(b"\x89PNG"):
        return "image/png"
    if raw.startswith(b"\xff\xd8"):
        return "image/jpeg"
    if raw.startswith((b"GIF8",)):
        return "image/gif"
    if raw.startswith(b"BM"):
        return "image/bmp"
    if raw.startswith(b"RIFF") and raw[8:12] == b"WEBP":
        return "image/webp"
    if raw.startswith((b"II*\x00", b"MM\x00*")):
        return "image/tiff"
    return None


def _embed_pasted_images(html, dpr=1.0):
    """V1.9.31 (user: OneNote pastes are not 1:1, images turn blurry).

    Take ownership of every pasted image BEFORE Qt sees the HTML:

    - ``file://`` / bare-path images (how OneNote supplies them) are
      read and embedded as data URIs with their ORIGINAL bytes — no
      re-encode, no rescale. This also fixes the rot where the saved
      note pointed at a OneNote temp file that later vanished.
    - The display size is clamped to the native raster for EVERY
      image (the old clamp only decoded data URIs, so OneNote's
      file-referenced images — the common case — were never clamped
      and Qt upscaled them into blur).
    - Anything unresolvable (http(s), missing file, undecodable) is
      left byte-for-byte untouched.
    """
    import base64

    def _sub(m):
        tag = m.group(0)
        sm = _IMG_SRC_RE.search(tag)
        if sm is None:
            return tag
        quote, src = sm.group(1), (sm.group(2) or "").strip()
        low = src.lower()
        raw = None
        mime = None
        try:
            if low.startswith("data:"):
                head, _, payload = src.partition(",")
                if ";base64" not in head:
                    return tag
                raw = base64.b64decode(payload, validate=False)
                mime = head[5:].split(";")[0] or None
            elif low.startswith(("http:", "https:")):
                return tag
            else:
                path = None
                if low.startswith("file:"):
                    path = QUrl(src).toLocalFile()
                elif re.match(r"^[a-zA-Z]:[\\/]", src) or \
                        src.startswith("\\\\"):
                    path = src
                if not path:
                    return tag
                with open(path, "rb") as fh:
                    raw = fh.read()
                mime = _sniff_image_mime(raw)
        except Exception:
            return tag
        if not raw:
            return tag
        img = QImage()
        if not img.loadFromData(raw):
            return tag
        nw, nh = img.width(), img.height()
        if nw <= 0 or nh <= 0:
            return tag
        if mime is None:
            # Decodable but unknown container: re-encode losslessly.
            from PySide6.QtCore import QBuffer, QIODevice
            buf = QBuffer()
            buf.open(QIODevice.WriteOnly)
            if not img.save(buf, "PNG"):
                return tag
            raw = bytes(buf.data())
            mime = "image/png"
        if not low.startswith("data:"):
            uri = (f"data:{mime};base64,"
                   + base64.b64encode(raw).decode("ascii"))
            tag = tag[:sm.start()] + f"src={quote}{uri}{quote}" \
                + tag[sm.end():]
        return _clamp_img_dims(tag, nw, nh, dpr)

    return _IMG_TAG_RE.sub(_sub, html)


def _unc_path_at_cursor(cursor):
    """The UNC path under a text cursor, or None.

    V1.9.16: covers already-pasted notes (no re-paste needed) — the
    editor's Ctrl+click falls back to this when anchorAt() finds no
    link at the click. The cursor's block text is scanned for UNC
    paths; the one containing the cursor offset wins.
    """
    try:
        block = cursor.block()
        text = block.text()
        pos = cursor.positionInBlock()
    except Exception:
        return None
    for m in _UNC_START_RE.finditer(text):
        path = _extend_unc(text, m.start())
        if path is None:
            continue
        if m.start() <= pos <= m.start() + len(path):
            return path
    return None


def _sanitize_pasted_html(html, dark=None, dpr=1.0):
    """Clean one pasted HTML string: clashing colors out, lists real.

    Tag-scoped: style/font/bgcolor cleaning runs inside tags only, so
    visible text that happens to mention e.g. `color=black` is never
    touched. V1.9.16 additions, all from the user's OneNote pastes:
    <style> blocks get the same color cleaning (OneNote puts
    table-cell whites and list grays in class rules, which the old
    tag-only pass never saw); bgcolor attributes of ANY clashing value
    are stripped, not just white/black literals; bare UNC paths in text
    become real links; pasted images never display larger than their
    native pixels. V1.9.18: cleaning is theme-aware (see
    _clean_style_value) — `dark` defaults to the saved theme.
    """

    if dark is None:
        try:
            dark = saved_theme() != "light"
        except Exception:
            dark = True

    def _clean_style_block(m):
        body = m.group(1)

        def _clean_decl(dm):
            prop = dm.group(1).lower()
            val = dm.group(2)
            if prop == "color":
                if dark and _value_has_dark_extreme(val):
                    return ""
                if not dark and _value_has_light_extreme(val):
                    return ""
            else:
                if (_value_has_extreme_color(val)
                        or (dark and _value_has_light(val))
                        or (not dark and _value_has_dark(val))):
                    return ""
            return dm.group(0)

        cleaned = re.sub(
            r"(color|background-color|background)\s*:\s*([^;}{]+)",
            _clean_decl, body, flags=re.I)
        if not cleaned.strip():
            return ""
        return f"<style>{cleaned}</style>"

    html = _STYLE_BLOCK_RE.sub(_clean_style_block, html)

    def _clean_tag(m):
        tag = m.group(0)

        def _clean_style(sm):
            style = _clean_style_value(sm.group(2), dark=dark)
            return f' style="{style}"' if style else ""

        tag = _STYLE_ATTR_RE.sub(_clean_style, tag)

        def _clean_font(fm):
            rgb = _parse_css_color(fm.group(2))
            if rgb is not None and (
                    (dark and max(rgb) <= _EXTREME_DARK_MAX)
                    or (not dark and min(rgb) >= _EXTREME_LIGHT_MIN)):
                return ""
            return fm.group(0)

        tag = _FONT_COLOR_RE.sub(_clean_font, tag)

        def _clean_bgcolor(bm):
            rgb = _parse_css_color(bm.group(2))
            if rgb is not None and (
                    _is_extreme_color(rgb)
                    or (dark and min(rgb) >= 0x80)
                    or (not dark and max(rgb) <= 0x80)):
                return ""
            return bm.group(0)

        tag = _BGCOLOR_ATTR_RE.sub(_clean_bgcolor, tag)
        tag = _clamp_pasted_img(tag, dpr)
        return tag

    html = re.sub(r"<[^>]+>", _clean_tag, html)
    html = _linkify_unc_paths(html)
    return _convert_mso_lists(html)


# ---- Notes table formulas (V1.9.15) ----
# A cell whose text starts with "=" is a formula, evaluated like a
# spreadsheet cell: =A1+B2, =SUM(A1:A5), =AVG(B1:B4)*2. Addresses are
# A1-style (columns A..Z, AA.., rows 1-based, first row is row 1).
# The formula string lives on the first character format of the cell
# (custom property below) so it travels with the cell while editing;
# it does NOT survive an HTML round trip, so NotesPage also persists
# formulas in the notes.formulas sidecar column on save and re-applies
# them on load. Displayed values are plain numbers (f"{v:g}").
_FORMULA_PROP = int(QTextFormat.UserProperty) + 1


class _FormulaError(Exception):
    """A formula's display string: '#ERR', '#DIV/0!' or '#CIRC!'."""

    def __init__(self, display):
        super().__init__(display)
        self.display = display


def _col_letters_to_index(letters):
    """'A' -> 0, 'Z' -> 25, 'AA' -> 26 (spreadsheet column order)."""
    idx = 0
    for ch in letters.upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx - 1


def _index_to_col_letters(idx):
    """0 -> 'A', 25 -> 'Z', 26 -> 'AA'."""
    letters = ""
    idx += 1
    while idx > 0:
        idx, rem = divmod(idx - 1, 26)
        letters = chr(ord("A") + rem) + letters
    return letters


_CELL_REF_RE = re.compile(r"^([A-Za-z]+)([0-9]+)$")


def _parse_cell_ref(token):
    """'B3' -> (row, col) 0-based, or None (row 0 is not a cell)."""
    m = _CELL_REF_RE.match(token)
    if not m:
        return None
    row = int(m.group(2))
    if row < 1:
        return None
    return (row - 1, _col_letters_to_index(m.group(1)))


def _parse_literal_number(text):
    """Cell text -> float, or None. '$1,200' and ' 3.5 ' parse; text
    does not. Empty/text cells read as 0 in arithmetic and are skipped
    by SUM/AVG/MIN/MAX/COUNT — see evaluate_formula."""
    if text is None:
        return None
    cleaned = text.strip().replace("$", "").replace(",", "")
    if not cleaned:
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


_FORMULA_FUNCS = ("SUM", "AVG", "AVERAGE", "MIN", "MAX", "COUNT")
_TOKEN_RE = re.compile(
    r"\s*(?:(\d+(?:\.\d*)?|\.\d+)|([A-Za-z]+[0-9]+(?::[A-Za-z]+[0-9]+)?)"
    r"|([A-Za-z]+)|([-+*/(),]))")


def _tokenize_formula(body):
    """Formula body (after the '=') -> token list. Raises _FormulaError
    on anything unrecognized, including a bad cell reference."""
    tokens = []
    pos = 0
    while pos < len(body):
        m = _TOKEN_RE.match(body, pos)
        if not m or m.start() == m.end():
            raise _FormulaError("#ERR")
        num, ref, name, op = m.groups()
        if num is not None:
            tokens.append(("num", float(num)))
        elif ref is not None:
            if ":" in ref:
                a, b = ref.split(":")
                ra, rb = _parse_cell_ref(a), _parse_cell_ref(b)
                if ra is None or rb is None:
                    raise _FormulaError("#ERR")
                tokens.append(("range", ra, rb))
            else:
                r = _parse_cell_ref(ref)
                if r is None:
                    raise _FormulaError("#ERR")
                tokens.append(("ref", r))
        elif name is not None:
            tokens.append(("name", name.upper()))
        else:
            tokens.append(("op", op))
        pos = m.end()
    tokens.append(("end", None))
    return tokens


class _FormulaParser:
    """Recursive-descent parser: expr -> term ((+|-) term)*, term ->
    factor ((*|/) factor)*, factor -> unary | primary, primary ->
    number | ref | func(args) | (expr). Ranges are only valid as
    function arguments; anywhere else they are an error."""

    def __init__(self, tokens):
        self.tokens = tokens
        self.i = 0

    def peek(self):
        return self.tokens[self.i]

    def next(self):
        tok = self.tokens[self.i]
        self.i += 1
        return tok

    def parse(self):
        node = self._expr()
        if self.peek()[0] != "end":
            raise _FormulaError("#ERR")
        return node

    def _expr(self):
        node = self._term()
        while self.peek() == ("op", "+") or self.peek() == ("op", "-"):
            op = self.next()[1]
            node = ("bin", op, node, self._term())
        return node

    def _term(self):
        node = self._factor()
        while self.peek() == ("op", "*") or self.peek() == ("op", "/"):
            op = self.next()[1]
            node = ("bin", op, node, self._factor())
        return node

    def _factor(self):
        tok = self.peek()
        kind = tok[0]
        # Ranges are only valid as function arguments; anywhere else
        # (including a bare "=A1:A3") they are an error, not a crash.
        if kind == "range":
            raise _FormulaError("#ERR")
        val = tok[1] if len(tok) > 1 else None
        if kind == "op" and val in ("+", "-"):
            self.next()
            node = self._factor()
            return node if val == "+" else ("neg", node)
        if kind == "num":
            self.next()
            return ("num", val)
        if kind == "ref":
            self.next()
            return ("ref", val)
        if kind == "name":
            self.next()
            fname = val
            if fname not in _FORMULA_FUNCS:
                raise _FormulaError("#ERR")
            if self.next() != ("op", "("):
                raise _FormulaError("#ERR")
            args = []
            if self.peek() != ("op", ")"):
                args.append(self._arg())
                while self.peek() == ("op", ","):
                    self.next()
                    args.append(self._arg())
            if self.next() != ("op", ")"):
                raise _FormulaError("#ERR")
            return ("func", fname, args)
        if kind == "op" and val == "(":
            self.next()
            node = self._expr()
            if self.next() != ("op", ")"):
                raise _FormulaError("#ERR")
            return node
        raise _FormulaError("#ERR")

    def _arg(self):
        tok = self.peek()
        if tok[0] == "range":
            self.next()
            return ("range", tok[1], tok[2])
        return self._expr()


def _eval_node(node, value_at):
    """value_at(row, col) -> float | None (None = empty/text cell);
    it may raise _FormulaError to propagate an error cell or a cycle.
    Direct references to empty/text cells read as 0."""
    kind = node[0]
    if kind == "num":
        return node[1]
    if kind == "ref":
        val = value_at(*node[1])
        return 0.0 if val is None else val
    if kind == "neg":
        return -_eval_node(node[1], value_at)
    if kind == "bin":
        _, op, left, right = node
        a = _eval_node(left, value_at)
        b = _eval_node(right, value_at)
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        if op == "*":
            return a * b
        if op == "/":
            if b == 0:
                raise _FormulaError("#DIV/0!")
            return a / b
    if kind == "func":
        _, fname, args = node
        values = []
        for arg in args:
            if arg[0] == "range":
                (_, (r1, c1), (r2, c2)) = arg
                for r in range(min(r1, r2), max(r1, r2) + 1):
                    for c in range(min(c1, c2), max(c1, c2) + 1):
                        v = value_at(r, c)
                        if v is not None:
                            values.append(v)
            else:
                values.append(_eval_node(arg, value_at))
        if fname == "SUM":
            return sum(values)
        if fname in ("AVG", "AVERAGE"):
            if not values:
                raise _FormulaError("#DIV/0!")
            return sum(values) / len(values)
        if fname == "MIN":
            return min(values) if values else 0.0
        if fname == "MAX":
            return max(values) if values else 0.0
        if fname == "COUNT":
            return float(len(values))
    raise _FormulaError("#ERR")


def evaluate_formula(formula, value_at):
    """Evaluate a formula string ('=A1+B2') to a float.

    value_at(row, col) -> float | None, raising _FormulaError for an
    error cell or a cycle. Raises _FormulaError on bad syntax."""
    body = formula[1:] if formula.startswith("=") else formula
    if not body.strip():
        raise _FormulaError("#ERR")
    node = _FormulaParser(_tokenize_formula(body)).parse()
    return _eval_node(node, value_at)


def _format_formula_value(value):
    return f"{value:g}"


class _SanitizedTextEdit(QTextEdit):
    """QTextEdit whose pastes go through the OneNote/Word
    sanitizer (V1.9.48): the V1.9.14 fix only ever covered
    the Notes-module editor, so pasting an email into a
    TASK's notes (or a CRM note) still landed as black
    text on the dark theme -- the user hit it again and
    asked why fixed problems come back. Every rich-text
    notes field in the app now shares this one class, so
    the paste behaviour cannot diverge again."""

    def insertFromMimeData(self, source):
        if source is not None and source.hasHtml():
            # V1.9.31: embed pasted images at full native resolution
            # (and clamp their display size) before sanitizing, so a
            # OneNote paste is 1:1 instead of an upscaled blur.
            dpr = self.devicePixelRatioF()
            cleaned = _sanitize_pasted_html(
                _embed_pasted_images(source.html(), dpr), dpr=dpr)
            if cleaned != source.html():
                mime = QMimeData()
                mime.setHtml(cleaned)
                if source.hasText():
                    mime.setText(source.text())
                super().insertFromMimeData(mime)
                return
        if source is not None and not source.hasHtml() \
                and source.hasImage():
            # Bare image copy (no HTML): Qt's default insert registers
            # a session-local resource that the HTML save drops, so the
            # image vanished on reload. Embed it as a data URI at
            # native resolution instead.
            img = QImage(source.imageData())
            if not img.isNull():
                from PySide6.QtCore import QBuffer, QIODevice
                buf = QBuffer()
                buf.open(QIODevice.WriteOnly)
                if img.save(buf, "PNG"):
                    import base64
                    uri = ("data:image/png;base64," + base64.b64encode(
                        bytes(buf.data())).decode("ascii"))
                    dpr = self.devicePixelRatioF()
                    dw = max(1, round(img.width() / dpr))
                    dh = max(1, round(img.height() / dpr))
                    self.textCursor().insertHtml(
                        f'<img src="{uri}" width="{dw}" '
                        f'height="{dh}" />')
                    return
        super().insertFromMimeData(source)


class _NotesPageEditor(_SanitizedTextEdit):
    """Notes-module editor: pasted HTML goes through the OneNote/Word
    sanitizer before Qt inserts it, and Ctrl+click follows links.

    Note: QTextEdit has no anchorClicked signal (that is QTextBrowser
    only), so link following is done via anchorAt() in mouseReleaseEvent.
    """

    def mousePressEvent(self, event):
        """Record a press on a link so release can tell click from drag.

        V1.9.18 (user order: OneNote behavior): a plain click on a
        link opens it — no Ctrl needed. Drag-selecting link text must
        still work, so the press anchor is remembered and release only
        opens when press and release hit the same anchor with no
        drag selection in between.
        """
        try:
            if event.button() == Qt.LeftButton:
                self._press_anchor = self.anchorAt(event.pos())
            else:
                self._press_anchor = ""
        except Exception:
            self._press_anchor = ""
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        """Plain click on a link opens it (OneNote behavior).

        V1.9.14: pasted links kept their href but did nothing on click.
        Opening on every click would hijack editing, so Ctrl+click is
        the follow gesture, matching Word/OneNote conventions.
        V1.9.16: two more routes that looked like links but did nothing
        — a backslash href (OneNote writes href="\\\\server\\share")
        converts to a file:// URL, and bare UNC text with no anchor at
        all falls back to the path under the cursor, so notes pasted
        before linkification still open without re-pasting.
        """
        try:
            if event.button() == Qt.LeftButton:
                ctrl = bool(event.modifiers() & Qt.ControlModifier)
                href = self.anchorAt(event.pos())
                plain_click = (
                    not ctrl and href
                    and getattr(self, "_press_anchor", "") == href
                    and not self.textCursor().hasSelection())
                if (ctrl or plain_click) and href:
                    if href.startswith("\\\\"):
                        href = _unc_to_file_url(href)
                    QDesktopServices.openUrl(QUrl(href))
                    event.accept()
                    return
                if ctrl:
                    path = _unc_path_at_cursor(
                        self.cursorForPosition(event.pos()))
                    if path:
                        QDesktopServices.openUrl(
                            QUrl(_unc_to_file_url(path)))
                        event.accept()
                        return
        except Exception:
            pass
        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
        """Hovering a formula cell shows its formula as a tooltip, so a
        computed value can always be traced back to (and retyped as) its
        formula. Plain cells show no tooltip. V1.9.16: hovering a link
        hints the Ctrl+click gesture, since pasted links that do nothing
        on a plain click read as broken.
        V1.9.18: plain click opens, matching OneNote — the Ctrl
        requirement is gone. Drag-select is preserved: release only
        opens when press and release hit the same anchor with no
        drag selection in between.
        """
        try:
            cur = self.cursorForPosition(event.pos())
            tbl = cur.currentTable()
            formula = None
            if tbl is not None:
                cell = tbl.cellAt(cur)
                prop = cell.firstCursorPosition().charFormat().property(
                    _FORMULA_PROP)
                if isinstance(prop, str) and prop:
                    formula = prop
            if formula:
                QToolTip.showText(event.globalPos(), formula, self)
            elif self.anchorAt(event.pos()):
                self.viewport().setCursor(Qt.PointingHandCursor)
                QToolTip.showText(event.globalPos(),
                                  "Click to open link", self)
            else:
                self.viewport().setCursor(Qt.IBeamCursor)
                QToolTip.hideText()
        except Exception:
            pass
        super().mouseMoveEvent(event)

class _TableGrowHandle(QWidget):
    """Corner grip for Notes tables (V1.9.15): a small floating handle
    parked on the bottom-right corner of the table the cursor is in.
    Dragging it down adds rows, dragging it right adds columns — one
    per ~28px down / per column-width right. It only ever ADDS: dragging
    can never delete a row, column, or cell content. The handle is a
    child of the editor viewport, so it never touches the document or
    the text selection; NotesPage repositions it on cursor moves,
    edits, scrolls and resizes."""

    SIZE = 22
    ROW_STEP = 28

    def __init__(self, viewport, on_grown):
        super().__init__(viewport)
        self._on_grown = on_grown
        self.setFixedSize(self.SIZE, self.SIZE)
        self.setCursor(Qt.SizeFDiagCursor)
        self.setToolTip(
            "Drag to add rows (down) and columns (right)")
        self._dragging = False
        self._start = None
        self._table = None
        self._applied_rows = 0
        self._applied_cols = 0
        self._col_step = 80
        self.hide()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setBrush(QColor(42, 45, 51, 230))
        p.setPen(QPen(QColor(140, 146, 156), 1))
        p.drawRoundedRect(0, 0, self.SIZE - 1, self.SIZE - 1, 3, 3)
        p.setPen(QPen(QColor(200, 205, 212), 1.5))
        for k in range(3):
            off = 6 + k * 4
            p.drawLine(off, self.SIZE - 4, self.SIZE - 4, off)
        p.end()

    def begin_drag(self, table):
        """Arm a drag for this table (called by mousePressEvent; kept
        separate so tests can drive a drag without a mouse grab)."""
        self._table = table
        self._applied_rows = 0
        self._applied_cols = 0
        self._col_step = 80
        try:
            doc = table.document()
            frame = doc.documentLayout().frameBoundingRect(table)
            if table.columns() > 0:
                step = frame.width() / table.columns()
                if step >= 40:
                    self._col_step = step
        except Exception:
            pass

    def apply_drag(self, dx, dy):
        """Grow the armed table by the drag delta. Returns
        (rows_added, cols_added). Only grows; never shrinks."""
        if self._table is None:
            return (0, 0)
        want_rows = max(0, int(dy / self.ROW_STEP))
        want_cols = max(0, int(dx / self._col_step))
        added_rows = added_cols = 0
        try:
            if want_rows > self._applied_rows:
                self._table.appendRows(want_rows - self._applied_rows)
                added_rows = want_rows - self._applied_rows
                self._applied_rows = want_rows
            if want_cols > self._applied_cols:
                self._table.appendColumns(want_cols - self._applied_cols)
                added_cols = want_cols - self._applied_cols
                self._applied_cols = want_cols
        except Exception:
            pass
        return (added_rows, added_cols)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # The table is set by NotesPage whenever it positions the
            # handle on the cursor's table (see _position_table_handle).
            if self._table is not None:
                self.begin_drag(self._table)
                self._dragging = True
                self._start = event.globalPos()
                self.grabMouse()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._dragging and self._start is not None:
            delta = event.globalPos() - self._start
            if self.apply_drag(delta.x(), delta.y()) != (0, 0):
                self._on_grown()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._dragging:
            self._dragging = False
            self._start = None
            self.releaseMouse()
            self._on_grown()
            event.accept()
            return
        super().mouseReleaseEvent(event)


class _DeleteNoteDialog(QDialog):
    """Modern delete confirmation in the app's own dialog chrome.

    V1.9.16 (user report): the stock QMessageBox ("Delete note" with a
    blue question icon and plain Yes/No) looked dated next to the
    app's frameless dialogs. Same question, same answers — Cancel
    (Esc) or Delete — with a red trash mark, the note title, and the
    irreversible warning, using the theme's ghost/danger buttons.
    """

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_DeleteOnClose)
        layout = install_chrome(self, "Delete note")
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(14)
        icon = QLabel()
        icon.setPixmap(svg_icon("trash", "#e5484d", 28).pixmap(28, 28))
        row.addWidget(icon, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setContentsMargins(0, 0, 0, 0)
        texts.setSpacing(4)
        q = QLabel(f"Delete “{title}”?")
        q.setObjectName("dialogTitle")
        texts.addWidget(q)
        sub = QLabel("This cannot be undone.")
        sub.setObjectName("subtitle")
        texts.addWidget(sub)
        row.addLayout(texts, 1)
        layout.addLayout(row)
        btns = QHBoxLayout()
        btns.setContentsMargins(0, 0, 0, 0)
        btns.setSpacing(8)
        btns.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.setObjectName("ghost")
        cancel.setCursor(Qt.PointingHandCursor)
        cancel.clicked.connect(self.reject)
        btns.addWidget(cancel)
        delete = QPushButton("Delete")
        delete.setObjectName("danger")
        delete.setCursor(Qt.PointingHandCursor)
        delete.setDefault(True)
        delete.clicked.connect(self.accept)
        btns.addWidget(delete)
        layout.addLayout(btns)


class NotesPage(QWidget):
    """Notes module: OneNote-style notebooks, full-text search, rich-text
    editor with auto-save, and Markdown/HTML/text export."""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self._scope = "all"          # all | pinned | unfiled | notebook
        self._scope_id = None
        self._search = ""
        self._current_id = None      # note id loaded in the editor
        self._loading = False        # True while populating widgets
        self._dirty = False          # unsaved edits pending
        self._recomputing = False    # True while formula displays rewrite
        # Last computed display per formula cell, keyed (table, row, col).
        # A formula cell's text is its DISPLAY, not its formula — so the
        # scan can only tell "user edited this cell" by comparing the
        # text against both the stored formula and the last display.
        self._formula_displays = {}
        # V1.9.39: table column-border drag state (see eventFilter).
        self._col_drag = None
        self._border_hover = False

        root = QHBoxLayout(self)
        root.setContentsMargins(24, 16, 24, 18)
        root.setSpacing(0)

        # V1.9.38 (user: Notes are crushed on the Surface — fixed
        # 232+300px panes inside a 1220px-minimum window left the
        # editor ~200px and the meta row overflowed). The three
        # panes now ride a splitter: nav and list flex within
        # sane bounds, the editor takes whatever remains, and the
        # split is remembered across launches.
        self._splitter = QSplitter(Qt.Horizontal)
        self._splitter.setHandleWidth(10)
        self._splitter.setChildrenCollapsible(False)
        root.addWidget(self._splitter)

        self._build_nav(self._splitter)
        self._build_list(self._splitter)
        self._build_editor(self._splitter)
        self._splitter.setStretchFactor(0, 0)
        self._splitter.setStretchFactor(1, 0)
        self._splitter.setStretchFactor(2, 1)
        self._splitter.setSizes([232, 300, 760])
        try:
            saved = self.db.get_setting("notes_splitter", "")
            if saved:
                import base64 as _b64
                self._splitter.restoreState(
                    QByteArray(_b64.b64decode(saved)))
        except Exception:
            pass
        self._splitter.splitterMoved.connect(self._save_splitter)

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(900)
        self._save_timer.timeout.connect(self._autosave)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(300)
        self._search_timer.timeout.connect(self._apply_search)

        enable_touch_scroll(self.nb_list, mouse_drag=True)
        enable_touch_scroll(self.note_list, mouse_drag=True)
        # The editor keeps mouse-drag for text selection; finger drags
        # scroll natively via the touch gesture.
        enable_touch_scroll(self.editor, mouse_drag=False)

        self.refresh()
        _chip_font_tree(self)

    def _save_splitter(self, *_a):
        try:
            import base64 as _b64
            self.db.set_setting("notes_splitter", _b64.b64encode(
                bytes(self._splitter.saveState())).decode("ascii"))
        except Exception:
            pass

    # ---- left nav ----
    def _build_nav(self, root):
        nav = QFrame()
        nav.setMinimumWidth(176)
        nav.setMaximumWidth(320)
        layout = QVBoxLayout(nav)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search notes…")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self._search_timer.start())
        layout.addWidget(self.search)

        self._scope_group = QButtonGroup(self)
        self._scope_group.setExclusive(True)
        self._scope_buttons = {}
        for key, label in (("all", "All Notes"), ("pinned", "Pinned"),
                           ("unfiled", "Unfiled")):
            btn = QPushButton(label)
            btn.setObjectName("noteScope")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(
                lambda _=False, k=key: self._set_scope(k, None))
            self._scope_group.addButton(btn)
            layout.addWidget(btn)
            self._scope_buttons[key] = btn
        self._scope_buttons["all"].setChecked(True)
        # V1.9.47: Unfiled doubles as a drop target -- drag notes
        # onto it to unfile them. Its drag events route through
        # the page's event filter (see eventFilter).
        _unf = self._scope_buttons["unfiled"]
        _unf.setAcceptDrops(True)
        _unf.installEventFilter(self)
        # V1.9.18: the scope filters never got the sliding animation
        # (user report) — the pill slides behind All / Pinned /
        # Unfiled instead of flashing between them.
        # V1.9.47 (user): the sliding highlight is an OUTLINE now,
        # not a filled navy rectangle — same outline-only selection
        # treatment as the dropdowns.
        self._scope_pill = _SlidingButtonPill(
            nav, list(self._scope_buttons.values()),
            "#a7aeb9", "#5c636d", radius=8, object_name="noteScope",
            outline=True)

        nb_head = QHBoxLayout()
        nb_head.setContentsMargins(0, 8, 0, 0)
        nb_label = QLabel("NOTEBOOKS")
        nb_label.setObjectName("sectionLabel")
        _track_label(nb_label)
        nb_head.addWidget(nb_label)
        nb_head.addStretch(1)
        add_nb = QPushButton("+ New")
        add_nb.setObjectName("ghost")
        add_nb.setCursor(Qt.PointingHandCursor)
        add_nb.clicked.connect(self._on_add_notebook)
        nb_head.addWidget(add_nb)
        layout.addLayout(nb_head)

        # V1.9.47: accepts note drags -- drop notes on a notebook
        # to file them into it.
        self.nb_list = _NotebookDropList()
        self.nb_list.on_notes_dropped = self._on_notes_dropped
        self.nb_list.setObjectName("noteNav")
        enable_touch_scroll(self.nb_list)
        self.nb_list.setSelectionMode(QListWidget.SingleSelection)
        self.nb_list.itemSelectionChanged.connect(self._on_nb_selected)
        self.nb_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.nb_list.customContextMenuRequested.connect(self._nb_menu)
        layout.addWidget(self.nb_list, 1)

        export_all = QPushButton("Export all notes")
        export_all.setObjectName("ghost")
        export_all.setIcon(svg_icon("download", "#8a919c", 14))
        export_all.setCursor(Qt.PointingHandCursor)
        export_all.clicked.connect(self._on_export_all)
        layout.addWidget(export_all)

        root.addWidget(nav)

    # ---- middle note list ----
    def _build_list(self, root):
        mid = QFrame()
        mid.setMinimumWidth(216)
        mid.setMaximumWidth(440)
        layout = QVBoxLayout(mid)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # V1.9.38 (user): the full-width "+ New Note" bar and the
        # "UNFILED · 0" count label are gone from this pane — New
        # Note is a compact button in the editor's title row now,
        # and the scope filters on the left already say where you
        # are. This pane is just the list.
        # V1.9.47 (user): Ctrl/Shift multi-select is standard --
        # ExtendedSelection -- and the list is the drag source
        # for filing notes into notebooks.
        self.note_list = _NoteListWidget()
        self.note_list.setObjectName("noteList")
        enable_touch_scroll(self.note_list)
        self.note_list.setSelectionMode(
            QAbstractItemView.ExtendedSelection)
        self.note_list.setDragEnabled(True)
        self.note_list.setDragDropMode(QAbstractItemView.DragOnly)
        self.note_list.itemSelectionChanged.connect(self._on_note_selected)
        self.note_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.note_list.customContextMenuRequested.connect(self._note_menu)
        layout.addWidget(self.note_list, 1)

        root.addWidget(mid)

    # ---- editor ----
    def _build_editor(self, root):
        pane = QFrame()
        layout = QVBoxLayout(pane)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # V1.9.38 (user): title row carries a COMPACT "+ New Note"
        # at its right end (it was a full-width bar over the list);
        # the meta row loses its Export button and delete X — both
        # live on the note list's right-click menu already.
        title_row = QHBoxLayout()
        title_row.setSpacing(8)
        self.title_edit = QLineEdit()
        self.title_edit.setObjectName("noteTitle")
        self.title_edit.setPlaceholderText("Note title")
        self.title_edit.textChanged.connect(self._mark_dirty)
        title_row.addWidget(self.title_edit, 1)
        new_note_btn = QPushButton("+ New Note")
        new_note_btn.setObjectName("ghost")
        new_note_btn.setCursor(Qt.PointingHandCursor)
        new_note_btn.setToolTip("New note")
        new_note_btn.clicked.connect(self._on_new_note)
        title_row.addWidget(new_note_btn)
        layout.addLayout(title_row)

        meta = QHBoxLayout()
        meta.setSpacing(8)
        nb_tag = QLabel("Notebook")
        nb_tag.setObjectName("fieldLabel")
        meta.addWidget(nb_tag)
        self.nb_combo = SafeComboBox()
        self.nb_combo.setMinimumWidth(150)
        self.nb_combo.currentIndexChanged.connect(self._on_nb_combo)
        meta.addWidget(self.nb_combo)
        meta.addStretch(1)
        self.saved_label = QLabel("Saved")
        self.saved_label.setObjectName("noteSaved")
        meta.addWidget(self.saved_label)
        layout.addLayout(meta)

        # V1.9.31 (user screenshot): the formatting bar was one long
        # QHBoxLayout; below ~950px of editor width Qt squeezed the
        # fixed-size controls past their hints and they painted OVER
        # each other (the font-size combo smeared across H1/H2). The
        # bar now lives in the app's wrapping ChipFlowLayout: controls
        # keep their full size and the bar wraps to a second row.
        toolbar_host = QWidget()
        toolbar = ChipFlowLayout(toolbar_host, hspacing=4, vspacing=4)
        toolbar.setContentsMargins(0, 0, 0, 0)
        self.bold_btn = self._fmt_btn("B", "Bold", checkable=True)
        self.bold_btn.setStyleSheet("font-weight: 700; padding: 0px;")
        self.bold_btn.clicked.connect(self._toggle_bold)
        self.italic_btn = self._fmt_btn("I", "Italic", checkable=True)
        self.italic_btn.setStyleSheet("font-style: italic; padding: 0px;")
        self.italic_btn.clicked.connect(self._toggle_italic)
        self.under_btn = self._fmt_btn("U", "Underline", checkable=True)
        self.under_btn.setStyleSheet(
            "text-decoration: underline; padding: 0px;")
        self.under_btn.clicked.connect(self._toggle_underline)
        self.strike_btn = self._fmt_btn("S", "Strikethrough", checkable=True)
        self.strike_btn.setStyleSheet(
            "text-decoration: line-through; padding: 0px;")
        self.strike_btn.clicked.connect(self._toggle_strike)
        toolbar.addWidget(self.bold_btn)
        toolbar.addWidget(self.italic_btn)
        toolbar.addWidget(self.under_btn)
        toolbar.addWidget(self.strike_btn)
        toolbar.addWidget(self._fmt_sep())
        # Text color: the button face IS the current color (rounded
        # swatch, the app-wide notes standard) and opens the swatch
        # popup — never the generic OS rectangle color dialog.
        # V1.9.47: painted faces (vector-crisp at any display
        # scaling; the 2x pixmap icons blurred at 125%/150%).
        self.color_btn = _ColorFaceButton("text", "Text color")
        self._set_color_btn_face(NOTES_DEFAULT_COLOR)
        self.color_btn.clicked.connect(self._show_color_popup)
        # Highlighter: "A" over a marker bar in the current marker color.
        self.hl_btn = _ColorFaceButton("hl", "Highlight color")
        self._hl_color = NOTES_HIGHLIGHT_COLORS[0][1]
        self._set_hl_btn_face(self._hl_color)
        self.hl_btn.clicked.connect(self._show_highlight_popup)
        toolbar.addWidget(self.color_btn)
        toolbar.addWidget(self.hl_btn)
        toolbar.addWidget(self._fmt_sep())
        # Font size stepper (headings remain as quick presets).
        self.size_minus = self._fmt_btn("−", "Smaller text")
        self.size_minus.clicked.connect(lambda: self._change_size(-1))
        # Font size: Excel-style editable dropdown (pick or type a size)
        # plus the −/+ steppers. The combo stays in sync with the cursor.
        self.size_combo = SafeComboBox()
        self.size_combo.setObjectName("notesSizeBox")
        self.size_combo.setEditable(True)
        self.size_combo.setInsertPolicy(QComboBox.NoInsert)
        for _s in ("8", "9", "10", "11", "12", "14", "16", "18",
                   "20", "24", "28", "36", "48", "72"):
            self.size_combo.addItem(_s)
        self.size_combo.setCurrentText("14")
        self.size_combo.setFixedWidth(58)
        self.size_combo.setToolTip("Font size — pick or type a size")
        self.size_combo.lineEdit().setValidator(QIntValidator(6, 200, self))
        self.size_combo.lineEdit().setAlignment(Qt.AlignCenter)
        optically_center_combo(self.size_combo)
        self.size_combo.activated.connect(self._on_size_picked)
        self.size_combo.lineEdit().returnPressed.connect(
            self._on_size_typed)
        self.size_plus = self._fmt_btn("+", "Larger text")
        self.size_plus.clicked.connect(lambda: self._change_size(1))
        toolbar.addWidget(self.size_minus)
        toolbar.addWidget(self.size_combo)
        toolbar.addWidget(self.size_plus)
        toolbar.addWidget(self._fmt_sep())
        h1 = self._fmt_btn("H1", "Heading 1")
        h1.clicked.connect(lambda: self._apply_heading(20, True))
        h2 = self._fmt_btn("H2", "Heading 2")
        h2.clicked.connect(lambda: self._apply_heading(16, True))
        body_btn = self._fmt_btn("A", "Normal text")
        body_btn.clicked.connect(lambda: self._apply_heading(14, False))
        toolbar.addWidget(h1)
        toolbar.addWidget(h2)
        toolbar.addWidget(body_btn)
        toolbar.addWidget(self._fmt_sep())
        bullets = self._fmt_btn("", "Bullet list")
        bullets.setIcon(svg_icon("list", "#9ba1ab", 14))
        bullets.clicked.connect(
            lambda: self._toggle_list(QTextListFormat.ListDisc))
        numbered = self._fmt_btn("", "Numbered list")
        numbered.setIcon(svg_icon("list-ordered", "#9ba1ab", 14))
        numbered.clicked.connect(
            lambda: self._toggle_list(QTextListFormat.ListDecimal))
        toolbar.addWidget(bullets)
        toolbar.addWidget(numbered)
        toolbar.addWidget(self._fmt_sep())
        self.align_btns = {}
        for key, icon, tip in (
                ("left", "align-left", "Align left"),
                ("center", "align-center", "Align center"),
                ("right", "align-right", "Align right")):
            ab = self._fmt_btn("", tip, checkable=True)
            ab.setIcon(svg_icon(icon, "#9ba1ab", 14))
            ab.clicked.connect(
                lambda _=False, k=key: self._set_alignment(k))
            self.align_btns[key] = ab
            toolbar.addWidget(ab)
        outdent = self._fmt_btn("", "Decrease indent")
        outdent.setIcon(svg_icon("outdent", "#9ba1ab", 14))
        outdent.clicked.connect(lambda: self._indent(-1))
        indent = self._fmt_btn("", "Increase indent")
        indent.setIcon(svg_icon("indent", "#9ba1ab", 14))
        indent.clicked.connect(lambda: self._indent(1))
        toolbar.addWidget(outdent)
        toolbar.addWidget(indent)
        toolbar.addWidget(self._fmt_sep())
        link_btn = self._fmt_btn("", "Insert link")
        link_btn.setIcon(svg_icon("link", "#9ba1ab", 14))
        link_btn.clicked.connect(self._insert_link)
        table_btn = self._fmt_btn("", "Insert table")
        table_btn.setIcon(svg_icon("table", "#9ba1ab", 14))
        table_btn.clicked.connect(self._insert_table)
        image_btn = self._fmt_btn("", "Insert image")
        image_btn.setIcon(svg_icon("image", "#9ba1ab", 14))
        image_btn.clicked.connect(self._insert_image)
        toolbar.addWidget(link_btn)
        toolbar.addWidget(table_btn)
        toolbar.addWidget(image_btn)
        toolbar.addWidget(self._fmt_sep())
        find_btn = self._fmt_btn("", "Find in note (Ctrl+F)")
        find_btn.setIcon(svg_icon("search", "#9ba1ab", 14))
        find_btn.clicked.connect(lambda: self.find_bar.show_bar())
        clear_btn = self._fmt_btn("", "Clear formatting")
        clear_btn.setIcon(svg_icon("x", "#9ba1ab", 12))
        clear_btn.clicked.connect(self._clear_format)
        toolbar.addWidget(find_btn)
        toolbar.addWidget(clear_btn)
        layout.addWidget(toolbar_host)

        self.editor_stack = QStackedWidget()
        empty = QLabel("Select a note from the list,\nor create a new one to get started.")
        empty.setObjectName("noteEmpty")
        empty.setAlignment(Qt.AlignCenter)
        self.editor_stack.addWidget(empty)
        self.editor = _NotesPageEditor()
        self.editor.setObjectName("noteEditor")
        font = app_font()
        font.setPointSize(14)
        self.editor.setFont(font)
        # Lists need a comfortable indent: markers get room to breathe and
        # stay aligned instead of cramping against the left edge.
        self.editor.document().setIndentWidth(44)
        self.editor.textChanged.connect(self._mark_dirty)
        self.editor.textChanged.connect(self._on_doc_changed)
        self.editor.cursorPositionChanged.connect(self._update_fmt_buttons)
        self.editor.cursorPositionChanged.connect(self._position_table_handle)
        self.editor.document().contentsChanged.connect(
            self._position_table_handle)
        self.editor.verticalScrollBar().valueChanged.connect(
            self._position_table_handle)
        self.editor.horizontalScrollBar().valueChanged.connect(
            self._position_table_handle)
        self.editor.setMouseTracking(True)
        self.editor.setContextMenuPolicy(Qt.CustomContextMenu)
        self.editor.customContextMenuRequested.connect(self._editor_menu)
        self.editor.installEventFilter(self)
        self.editor.viewport().installEventFilter(self)
        # Corner-drag grip for tables (V1.9.15), parked on the editor
        # viewport; positioned by _position_table_handle.
        self._table_handle = _TableGrowHandle(
            self.editor.viewport(), self._position_table_handle)
        self.editor_stack.addWidget(self.editor)
        # In-note find bar (Ctrl+F), parked between toolbar and editor.
        self.find_bar = NotesFindBar(self.editor)
        layout.addWidget(self.editor_stack, 1)
        layout.insertWidget(3, self.find_bar)
        QShortcut(QKeySequence("Ctrl+F"), self,
                  activated=self.find_bar.show_bar)

        root.addWidget(pane)
        self._editor_pane = pane
        self._toolbar_widgets = pane.findChildren(QPushButton)

    def _fmt_btn(self, text, tooltip, checkable=False):
        btn = QPushButton(text)
        btn.setObjectName("fmtBtn")
        btn.setCheckable(checkable)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setToolTip(tooltip)
        btn.setFixedSize(30, 30)
        return btn

    @staticmethod
    def _fmt_sep():
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setObjectName("fmtSep")
        # Explicit seat: the toolbar is a wrapping flow layout (V1.9.31),
        # which places items at their size hints — a bare VLine frame
        # would collapse to a stub.
        sep.setFixedSize(6, 30)
        return sep

    # ---- data -> widgets ----
    def refresh(self):
        """Reload nav, notebooks, and the note list (called on page show)."""
        self._flush()
        self._refresh_nav()
        self._refresh_list(keep_selection=True)

    def _refresh_nav(self):
        notebooks = self.db.notebook_list()
        total = self.db.note_count()
        pinned = len(self.db.note_list(scope="pinned"))
        unfiled = len(self.db.note_list(scope="unfiled"))
        self._scope_buttons["all"].setText(f"All Notes  ({total})")
        self._scope_buttons["pinned"].setText(f"Pinned  ({pinned})")
        self._scope_buttons["unfiled"].setText(f"Unfiled  ({unfiled})")

        self.nb_list.blockSignals(True)
        try:
            self.nb_list.clear()
            for nb in notebooks:
                item = QListWidgetItem()
                row = _NotebookRow(nb["name"], nb["note_count"])
                item.setSizeHint(row.sizeHint())
                item.setData(Qt.UserRole, nb["id"])
                self.nb_list.addItem(item)
                self.nb_list.setItemWidget(item, row)
            # Reselect the active notebook after rebuild.
            if self._scope == "notebook":
                for i in range(self.nb_list.count()):
                    if self.nb_list.item(i).data(Qt.UserRole) == self._scope_id:
                        self.nb_list.setCurrentRow(i)
                        break
        finally:
            self.nb_list.blockSignals(False)

        # Editor notebook picker: Unfiled + notebooks.
        self._loading = True
        try:
            self.nb_combo.blockSignals(True)
            self.nb_combo.clear()
            self.nb_combo.addItem("Unfiled", None)
            for nb in notebooks:
                self.nb_combo.addItem(nb["name"], nb["id"])
            if self._current_id is not None:
                note = self.db.note_get(self._current_id)
                if note:
                    idx = self.nb_combo.findData(note["notebook_id"])
                    self.nb_combo.setCurrentIndex(max(0, idx))
        finally:
            self.nb_combo.blockSignals(False)
            self._loading = False

    def _refresh_list(self, keep_selection=False, select_id=None):
        notes = self.db.note_list(
            scope=self._scope, scope_id=self._scope_id, search=self._search)
        want = select_id if select_id is not None else (
            self._current_id if keep_selection else None)
        self.note_list.blockSignals(True)
        try:
            self.note_list.clear()
            for note in notes:
                item = QListWidgetItem()
                row = _NoteRow(note)
                item.setSizeHint(row.sizeHint())
                item.setData(Qt.UserRole, note["id"])
                self.note_list.addItem(item)
                self.note_list.setItemWidget(item, row)
                if want is not None and note["id"] == want:
                    self.note_list.setCurrentItem(item)
        finally:
            self.note_list.blockSignals(False)

    def _refresh_row(self, note_id):
        """Update one list row in place after an autosave (no full rebuild,
        so typing never flickers the list). Falls back to a full refresh if
        the note no longer belongs in this scope/filter."""
        item = self._row_for(note_id)
        if item is None:
            return
        row_data = next(
            (n for n in self.db.note_list(
                scope=self._scope, scope_id=self._scope_id,
                search=self._search)
             if n["id"] == note_id),
            None,
        )
        if row_data is None:
            self._refresh_list(keep_selection=True)
            return
        new_row = _NoteRow(row_data)
        old = self.note_list.itemWidget(item)
        self.note_list.setItemWidget(item, new_row)
        item.setSizeHint(new_row.sizeHint())
        if old is not None:
            old.deleteLater()

    def _row_for(self, note_id):
        for i in range(self.note_list.count()):
            if self.note_list.item(i).data(Qt.UserRole) == note_id:
                return self.note_list.item(i)
        return None

    # ---- nav events ----
    def _set_scope(self, scope, scope_id):
        self._flush()
        self._scope = scope
        self._scope_id = scope_id
        if scope != "notebook":
            self.nb_list.blockSignals(True)
            self.nb_list.clearSelection()
            self.nb_list.blockSignals(False)
        self._refresh_list()

    def _on_nb_selected(self):
        items = self.nb_list.selectedItems()
        if not items:
            return
        nb_id = items[0].data(Qt.UserRole)
        self._scope = "notebook"
        self._scope_id = nb_id
        for btn in self._scope_buttons.values():
            btn.setChecked(False)
        self._refresh_list()

    def _apply_search(self):
        self._search = self.search.text()
        self._refresh_list()

    # ---- note list events ----
    def _on_note_selected(self):
        # V1.9.47: with extended selection the editor follows the
        # CURRENT row (the one last clicked); the rest of the
        # selection stays selected for drag / menu actions.
        item = self.note_list.currentItem()
        if item is None:
            return
        note_id = item.data(Qt.UserRole)
        if note_id is not None and note_id != self._current_id:
            self._load_note(note_id)

    def _on_notes_dropped(self, ids, notebook_id):
        """Drag-and-drop filing (V1.9.47): every dragged note
        moves to the target notebook (None = Unfiled)."""
        for nid in ids:
            self.db.note_update(nid, notebook_id=notebook_id)
        self._refresh_nav()
        self._refresh_list(keep_selection=True)

    def _on_new_note(self):
        nb = self._scope_id if self._scope == "notebook" else None
        nid = self.db.note_add(nb, "")
        self._refresh_nav()
        self._refresh_list(select_id=nid)
        self._load_note(nid)
        self.title_edit.setFocus()
        self.title_edit.selectAll()

    # ---- editor ----
    def _load_note(self, note_id):
        self._flush()
        self._current_id = note_id
        self._loading = True
        try:
            if note_id is None:
                self.editor_stack.setCurrentIndex(0)
                self.title_edit.clear()
            else:
                note = self.db.note_get(note_id)
                if note is None:
                    self.editor_stack.setCurrentIndex(0)
                    self._current_id = None
                else:
                    self.title_edit.setText(note["title"] or "")
                    self.editor.setHtml(note["body_html"] or "")
                    self._apply_saved_formulas(note.get("formulas") or "")
                    self._recompute_all()
                    idx = self.nb_combo.findData(note["notebook_id"])
                    self.nb_combo.setCurrentIndex(max(0, idx))
                    self.saved_label.setText("Saved")
                    self.editor_stack.setCurrentIndex(1)
                    self._update_fmt_buttons()
            # The flush above may have rebuilt the list around the old note;
            # re-sync the list selection to the note now in the editor.
            self.note_list.blockSignals(True)
            try:
                item = self._row_for(self._current_id) \
                    if self._current_id is not None else None
                if item is not None:
                    self.note_list.setCurrentItem(item)
                else:
                    self.note_list.clearSelection()
            finally:
                self.note_list.blockSignals(False)
        finally:
            self._loading = False
            self._dirty = False

    def _mark_dirty(self):
        if self._loading or self._current_id is None:
            return
        if not self._dirty:
            self.saved_label.setText("Saving…")
        self._dirty = True
        self._save_timer.start()

    def _flush(self):
        if self._dirty and self._current_id is not None:
            self._save_timer.stop()
            self._autosave()

    def _autosave(self):
        if not self._dirty or self._current_id is None:
            return
        try:
            self.db.note_update(
                self._current_id,
                title=self.title_edit.text(),
                body_html=self.editor.toHtml(),
                formulas=self._serialize_formulas(),
            )
            self._dirty = False
            self.saved_label.setText("Saved")
            # Keep counts and the edited row fresh without rebuilding the
            # whole list (no flicker while typing).
            self._refresh_nav_counts_only()
            self._refresh_row(self._current_id)
        except Exception:
            self.saved_label.setText("Save failed")

    def _refresh_nav_counts_only(self):
        total = self.db.note_count()
        pinned = len(self.db.note_list(scope="pinned"))
        unfiled = len(self.db.note_list(scope="unfiled"))
        self._scope_buttons["all"].setText(f"All Notes  ({total})")
        self._scope_buttons["pinned"].setText(f"Pinned  ({pinned})")
        self._scope_buttons["unfiled"].setText(f"Unfiled  ({unfiled})")

    def _on_nb_combo(self, index):
        if self._loading or self._current_id is None or index < 0:
            return
        nb_id = self.nb_combo.itemData(index)
        self.db.note_update(self._current_id, notebook_id=nb_id)
        self.saved_label.setText("Saved")
        self._refresh_nav()
        self._refresh_list(keep_selection=True)

    # ---- formatting ----
    def _toggle_bold(self):
        self.editor.setFontWeight(
            QFont.Bold if self.bold_btn.isChecked() else QFont.Normal)

    def _toggle_italic(self):
        self.editor.setFontItalic(self.italic_btn.isChecked())

    def _toggle_underline(self):
        self.editor.setFontUnderline(self.under_btn.isChecked())

    def _toggle_strike(self):
        fmt = QTextCharFormat()
        fmt.setFontStrikeOut(self.strike_btn.isChecked())
        self.editor.mergeCurrentCharFormat(fmt)
        self.editor.setFocus()

    def _apply_heading(self, size, bold):
        # Restyle the whole current block (word-processor behavior), not
        # just text typed after the click — with no selection the old
        # merge-only version looked broken. Typing continues in the
        # heading style via mergeCurrentCharFormat.
        fmt = QTextCharFormat()
        fmt.setFontPointSize(size)
        fmt.setFontWeight(QFont.Bold if bold else QFont.Normal)
        cur = self.editor.textCursor()
        if cur.hasSelection():
            cur.mergeCharFormat(fmt)
            self.editor.setTextCursor(cur)
        else:
            block_cur = QTextCursor(cur.block())
            block_cur.movePosition(QTextCursor.EndOfBlock,
                                   QTextCursor.KeepAnchor)
            if block_cur.hasSelection():
                block_cur.mergeCharFormat(fmt)
        self.editor.mergeCurrentCharFormat(fmt)
        self.editor.setFocus()
        self._update_fmt_buttons()

    def _toggle_list(self, style):
        # Ordered (decimal) lists use MANUAL left-aligned numbering.
        # Qt's native QTextList right-aligns decimal markers and shifts
        # the gutter when going from 9 to 10+ — the user wants all numbers
        # starting at the same x. Bullets keep the native QTextList
        # (single "•" marker has no alignment issue).
        if style == QTextListFormat.ListDecimal:
            self._toggle_manual_numbers()
            return
        cur = self.editor.textCursor()
        cur.beginEditBlock()
        lst = cur.currentList()
        if lst is not None and lst.format().style() == style:
            plain = QTextBlockFormat()
            for i in range(lst.count()):
                bc = QTextCursor(lst.item(i))
                bc.setBlockFormat(plain)
        else:
            fmt = QTextListFormat()
            fmt.setStyle(style)
            fmt.setIndent(1)
            cur.createList(fmt)
            # Give the list a real left margin so markers sit in a comfortable
            # gutter instead of hugging the edge.
            bf = QTextBlockFormat()
            bf.setLeftMargin(18)
            cur.mergeBlockFormat(bf)
        cur.endEditBlock()
        self.editor.setFocus()

    def _toggle_manual_numbers(self):
        """Toggle left-aligned manual numbering on the selected blocks."""
        import re
        cur = self.editor.textCursor()
        # Check if we're in a manual list (current block has a number)
        block = cur.block()
        text = block.text()
        m = re.match(r"^(\d+)\.\s", text)
        cur.beginEditBlock()
        if m:
            # Remove numbering from all consecutive numbered blocks
            # (walk up and down from current)
            blocks = []
            b = block
            while b.isValid() and re.match(r"^\d+\.\s", b.text()):
                blocks.insert(0, b)
                b = b.previous()
            b = block.next()
            while b.isValid() and re.match(r"^\d+\.\s", b.text()):
                blocks.append(b)
                b = b.next()
            for b in blocks:
                bc = QTextCursor(b)
                bc.movePosition(QTextCursor.StartOfBlock)
                bc.movePosition(QTextCursor.NextCharacter,
                               QTextCursor.KeepAnchor,
                               len(re.match(r"^\d+\.\s", b.text()).group(0)))
                bc.removeSelectedText()
                # Clear the manual-list marker
                bf = bc.blockFormat()
                bf.setProperty(0x1001, 0)
                bc.setBlockFormat(bf)
        else:
            # Number the selected blocks (or current block), starting at 1
            start = cur.selectionStart()
            end = cur.selectionEnd()
            # Collect blocks in selection
            bc = QTextCursor(self.editor.document())
            bc.setPosition(start)
            blocks = []
            while True:
                b = bc.block()
                if not b.isValid():
                    break
                # Skip empty blocks at the end of selection
                if b.position() > end and not b.text().strip():
                    break
                blocks.append(b)
                if b.position() + b.length() >= end:
                    # Include the block containing 'end'
                    break
                if not bc.movePosition(QTextCursor.NextBlock):
                    break
                if bc.position() > end and not blocks[-1].text().strip():
                    break
            # Filter to non-empty or single block
            if len(blocks) == 1 or not cur.hasSelection():
                blocks = [cur.block()]
            for i, b in enumerate(blocks, 1):
                bc = QTextCursor(b)
                bc.movePosition(QTextCursor.StartOfBlock)
                bc.insertText(f"{i}. ")
                bf = bc.blockFormat()
                bf.setLeftMargin(18)
                bf.setProperty(0x1001, i)  # manual list number
                bc.setBlockFormat(bf)
        cur.endEditBlock()
        self.editor.setFocus()

    # ---- color / highlight (rounded swatches; no OS color dialog) ----
    def _set_color_btn_face(self, hex_color):
        # V1.9.38: OneNote-style face — "A" + the color as a bar
        # under it + dropdown chevron (was: the whole button filled
        # with the swatch color, which the user called ugly).
        # V1.9.47: the face is painted by _ColorFaceButton now;
        # the tooltip is re-asserted here so it can never be lost
        # by a face change (user: "you removed the tooltips").
        self._text_color = hex_color
        self.color_btn.set_face_color(hex_color)
        self.color_btn.setToolTip("Text color")

    def _set_hl_btn_face(self, hex_color):
        # None = no highlight under the cursor: plain "A", no band,
        # so the button never implies a highlight that isn't there.
        self.hl_btn.set_face_color(hex_color)
        self.hl_btn.setToolTip("Highlight color")

    def _show_color_popup(self):
        _show_swatch_popup(self.color_btn, NOTES_COLORS,
                           self._apply_text_color)

    def _apply_text_color(self, hex_color):
        if hex_color is None:
            return
        fmt = QTextCharFormat()
        if hex_color.lower() == NOTES_DEFAULT_COLOR.lower():
            # "Default": reset to the theme's editor color. An explicit
            # empty brush (NOT clearForeground): mergeCharFormat ignores
            # cleared properties, so clearForeground() was a no-op on a
            # selection and the old color stayed stuck.
            fmt.setForeground(QBrush())
        else:
            fmt.setForeground(QColor(hex_color))
        cur = self.editor.textCursor()
        if cur.hasSelection():
            cur.mergeCharFormat(fmt)
            self.editor.setTextCursor(cur)
        else:
            self.editor.mergeCurrentCharFormat(fmt)
        self._set_color_btn_face(hex_color)
        self.editor.setFocus()

    def _show_highlight_popup(self):
        _show_swatch_popup(self.hl_btn, NOTES_HIGHLIGHT_COLORS,
                           self._apply_highlight, include_none=True,
                           none_tip="No highlight")

    def _apply_highlight(self, hex_color):
        fmt = QTextCharFormat()
        if hex_color is None:
            # Explicit NoBrush (NOT clearBackground): mergeCharFormat
            # ignores cleared properties, so clearBackground() was a
            # no-op on a selection — highlights got stuck. An explicit
            # NoBrush counts as set and merges cleanly, leaving no
            # background attribute in the saved HTML.
            fmt.setBackground(QBrush(Qt.NoBrush))
            self._set_hl_btn_face(None)
        else:
            fmt.setBackground(QColor(hex_color))
            self._hl_color = hex_color
            self._set_hl_btn_face(hex_color)
        cur = self.editor.textCursor()
        if cur.hasSelection():
            cur.mergeCharFormat(fmt)
            self.editor.setTextCursor(cur)
        else:
            self.editor.mergeCurrentCharFormat(fmt)
        self.editor.setFocus()

    # ---- font size stepper ----
    def _current_size(self):
        size = self.editor.currentCharFormat().fontPointSize()
        if size <= 0:
            size = self.editor.fontPointSize()
        if size <= 0:
            size = 14
        return int(round(size))

    def _change_size(self, delta):
        new_size = max(8, min(36, self._current_size() + delta))
        self._apply_size(new_size)

    def _apply_size(self, size):
        size = max(6, min(200, int(size)))
        fmt = QTextCharFormat()
        fmt.setFontPointSize(size)
        cur = self.editor.textCursor()
        if cur.hasSelection():
            cur.mergeCharFormat(fmt)
            self.editor.setTextCursor(cur)
        else:
            # V1.9.14: with no selection, apply to the whole current
            # block. mergeCurrentCharFormat only set a transient
            # insertion format: it changed no existing text and
            # evaporated on the next cursor move to unstyled text, so
            # repeated "+" recomputed from the surrounding plain size
            # (14) and never got past 15 — and inside table cells the
            # merged size never applied to typed text at all. Applying
            # to the block makes "+" visibly and persistently grow the
            # line the cursor is on; the next press then reads the new
            # size and climbs. Empty blocks fall back to a
            # setCharFormat-based insertion format, which unlike the
            # merge does apply to subsequently typed text in cells.
            block = cur.block()
            bcur = QTextCursor(block)
            bcur.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
            if bcur.hasSelection():
                bcur.mergeCharFormat(fmt)
            else:
                fcur = self.editor.textCursor()
                ffmt = QTextCharFormat(fcur.charFormat())
                ffmt.setFontPointSize(size)
                fcur.setCharFormat(ffmt)
                self.editor.setTextCursor(fcur)
        self.size_combo.blockSignals(True)
        self.size_combo.setCurrentText(str(size))
        self.size_combo.blockSignals(False)
        self.editor.setFocus()

    def _on_size_picked(self, index):
        try:
            self._apply_size(int(self.size_combo.itemText(index)))
        except (TypeError, ValueError):
            pass

    def _on_size_typed(self):
        try:
            self._apply_size(int(self.size_combo.currentText()))
        except (TypeError, ValueError):
            self.size_combo.blockSignals(True)
            self.size_combo.setCurrentText(str(self._current_size()))
            self.size_combo.blockSignals(False)

    # ---- alignment / indent ----
    def _set_alignment(self, key):
        align = {"left": Qt.AlignLeft, "center": Qt.AlignCenter,
                 "right": Qt.AlignRight}[key]
        self.editor.setAlignment(align)
        self.editor.setFocus()
        self._update_fmt_buttons()

    def _indent(self, delta):
        cur = self.editor.textCursor()
        doc = self.editor.document()
        start = doc.findBlock(cur.selectionStart())
        end = doc.findBlock(cur.selectionEnd())
        cur.beginEditBlock()
        block = start
        while True:
            bf = block.blockFormat()
            bf.setIndent(max(0, min(8, bf.indent() + delta)))
            QTextCursor(block).setBlockFormat(bf)
            if block == end or not block.next().isValid():
                break
            block = block.next()
        cur.endEditBlock()
        self.editor.setFocus()

    # ---- insert: link / table / image ----
    def _insert_link(self):
        url, ok = app_get_text(self, "Insert link",
                               "Web address (URL):")
        if not ok or not (url or "").strip():
            return
        url = url.strip()
        if "://" not in url and not url.startswith("mailto:"):
            url = "https://" + url
        cur = self.editor.textCursor()
        fmt = QTextCharFormat()
        fmt.setAnchor(True)
        fmt.setAnchorHref(url)
        fmt.setForeground(QColor("#4f8cff"))
        fmt.setFontUnderline(True)
        if cur.hasSelection():
            cur.mergeCharFormat(fmt)
            self.editor.setTextCursor(cur)
        else:
            cur.insertText(url, fmt)
            plain = QTextCharFormat()
            plain.setAnchor(False)
            plain.setFontUnderline(False)
            plain.clearForeground()
            cur.setCharFormat(plain)
            self.editor.setTextCursor(cur)
        self.editor.setFocus()

    def _insert_table(self):
        # V1.9.38 (user): no Rows/Columns popup — clicking Insert
        # Table drops a 2x2 grid at the cursor, and the table grows
        # from there: drag the corner grip (V1.9.15), press Tab in
        # the last cell for another row, or use the table actions
        # on the editor's right-click menu. Column borders drag to
        # resize, like a spreadsheet.
        rows, cols = 2, 2
        from PySide6.QtGui import QTextTableFormat as _QTTF
        from PySide6.QtGui import QTextLength as _QTL
        fmt = _QTTF()
        fmt.setCellPadding(4)
        fmt.setCellSpacing(0)
        fmt.setBorder(1)
        fmt.setBorderStyle(_QTTF.BorderStyle.BorderStyle_Solid)
        fmt.setBorderBrush(QColor("#8a919c"))
        # V1.9.47 (user): a fresh table must look like a fresh
        # spreadsheet -- uniform, sensible cells -- NOT two
        # stretched columns spanning the whole editor. Fixed
        # 180px columns; the table is exactly as wide as its
        # columns and grows by dragging borders / the corner grip.
        fmt.setWidth(_QTL(_QTL.Type.FixedLength, 180 * cols))
        fmt.setColumnWidthConstraints(
            [_QTL(_QTL.Type.FixedLength, 180) for _ in range(cols)])
        cur = self.editor.textCursor()
        table = cur.insertTable(rows, cols, fmt)
        # Land the cursor in the first cell — inserting through a
        # cursor copy otherwise leaves the editor's own cursor
        # sitting after the table, looking like nothing happened.
        if table is not None:
            self.editor.setTextCursor(table.firstCursorPosition())
        self.editor.setFocus()

    # ---- notes tables: corner-drag growth + formulas (V1.9.15) ----
    def _iter_tables(self, doc=None):
        """All QTextTables in the document, in document order
        (nested tables inside cells included)."""
        doc = doc or self.editor.document()
        tables = []

        def walk(frame):
            for child in frame.childFrames():
                if isinstance(child, QTextTable):
                    tables.append(child)
                walk(child)

        walk(doc.rootFrame())
        return tables

    def _cell_text(self, cell):
        """First line of a cell's text (formulas live on one line)."""
        block = cell.firstCursorPosition().block()
        return block.text() if block.isValid() else ""

    def _cell_formula(self, cell):
        prop = cell.firstCursorPosition().charFormat().property(
            _FORMULA_PROP)
        return prop if isinstance(prop, str) and prop else None

    def _set_cell_formula(self, cell, formula):
        """Attach (or clear, formula=None) a formula property to a cell
        without changing its displayed text."""
        if not cell.isValid():
            return
        cur = cell.firstCursorPosition()
        cur.setPosition(cell.lastCursorPosition().position(),
                        QTextCursor.KeepAnchor)
        fmt = QTextCharFormat(cur.charFormat())
        if formula:
            fmt.setProperty(_FORMULA_PROP, formula)
        else:
            fmt.clearProperty(_FORMULA_PROP)
        cur.setCharFormat(fmt)

    def _set_cell_display(self, cell, text, formula=None):
        """Replace a cell's text with display text, keeping (or
        clearing) its formula property on the new text."""
        if not cell.isValid():
            return
        cur = cell.firstCursorPosition()
        cur.setPosition(cell.lastCursorPosition().position(),
                        QTextCursor.KeepAnchor)
        fmt = QTextCharFormat(cur.charFormat())
        if formula:
            fmt.setProperty(_FORMULA_PROP, formula)
        else:
            fmt.clearProperty(_FORMULA_PROP)
        cur.setCharFormat(fmt)
        cur.insertText(text)

    def _scan_formula_edits(self):
        """Sync formula properties with what the user typed. A formula
        cell's text is its DISPLAY, so a sweep that cleared every
        formula whose text isn't a formula would wipe all of them on
        any unrelated edit. Instead a cell counts as user-edited only
        when its text differs from BOTH its stored formula and its last
        computed display: then a '=' text becomes/updates the formula
        and any other text replaces it (formula cleared). Only from
        the outer recompute entry, never during recompute itself."""
        for ti, tbl in enumerate(self._iter_tables()):
            for r in range(tbl.rows()):
                for c in range(tbl.columns()):
                    cell = tbl.cellAt(r, c)
                    text = self._cell_text(cell)
                    stored = self._cell_formula(cell)
                    if text.startswith("="):
                        if text != stored:
                            self._set_cell_formula(cell, text)
                    elif stored is not None:
                        if text != self._formula_displays.get((ti, r, c)):
                            self._set_cell_formula(cell, None)
                            self._formula_displays.pop((ti, r, c), None)

    def _recompute_all(self):
        """Re-evaluate every formula cell in every table. Runs under
        the _recomputing guard (see _on_doc_changed); only writes cells
        whose display actually changed, so the user's cursor is never
        disturbed by a no-op rewrite."""
        tables = self._iter_tables()
        if not tables:
            return
        memo = {}
        visiting = set()

        def value_at(ti, r, c):
            tbl = tables[ti]
            if r < 0 or r >= tbl.rows() or c < 0 or c >= tbl.columns():
                return None
            key = (ti, r, c)
            if key in memo:
                result = memo[key]
                if isinstance(result, str):
                    raise _FormulaError(result)
                return result
            if key in visiting:
                raise _FormulaError("#CIRC!")
            cell = tbl.cellAt(r, c)
            formula = self._cell_formula(cell)
            if formula is None:
                return _parse_literal_number(self._cell_text(cell))
            visiting.add(key)
            try:
                val = evaluate_formula(
                    formula,
                    lambda rr, cc, _ti=ti: value_at(_ti, rr, cc))
                memo[key] = val
                return val
            except _FormulaError as err:
                memo[key] = err.display
                raise
            finally:
                visiting.discard(key)

        for ti, tbl in enumerate(tables):
            for r in range(tbl.rows()):
                for c in range(tbl.columns()):
                    cell = tbl.cellAt(r, c)
                    formula = self._cell_formula(cell)
                    if formula is None:
                        continue
                    try:
                        display = _format_formula_value(evaluate_formula(
                            formula,
                            lambda rr, cc, _ti=ti: value_at(_ti, rr, cc)))
                    except _FormulaError as err:
                        display = err.display
                    self._formula_displays[(ti, r, c)] = display
                    if self._cell_text(cell) != display:
                        self._set_cell_display(cell, display, formula)

    def _on_doc_changed(self):
        """Text changed in the editor: pick up user-typed formulas and
        recompute. Guarded against recompute's own writes, and skipped
        while a note is loading (load applies formulas explicitly)."""
        if self._loading or self._recomputing:
            return
        self._recomputing = True
        try:
            self._scan_formula_edits()
            self._recompute_all()
        finally:
            self._recomputing = False

    def _serialize_formulas(self):
        """Live formula properties -> JSON for the notes.formulas
        column. Empty string when the note has no formulas."""
        entries = []
        for ti, tbl in enumerate(self._iter_tables()):
            for r in range(tbl.rows()):
                for c in range(tbl.columns()):
                    formula = self._cell_formula(tbl.cellAt(r, c))
                    if formula:
                        entries.append({"t": ti, "r": r, "c": c,
                                        "f": formula})
        return json.dumps(entries) if entries else ""

    def _apply_saved_formulas(self, formulas_json):
        """Re-attach saved formulas (by table order, row, col) after a
        note loads. Bounds-checked: a table that shrank since save
        simply drops the formulas that no longer fit. Displays from
        the previous note are discarded first — the keys are positional
        and a new note's tables are unrelated."""
        self._formula_displays = {}
        if not formulas_json:
            return
        try:
            entries = json.loads(formulas_json)
        except Exception:
            return
        if not isinstance(entries, list):
            return
        tables = self._iter_tables()
        for entry in entries:
            try:
                tbl = tables[entry["t"]]
                cell = tbl.cellAt(entry["r"], entry["c"])
                if cell.isValid():
                    self._set_cell_formula(cell, entry["f"])
            except Exception:
                continue

    def _position_table_handle(self, for_table=None):
        """Park the corner grip on the bottom-right corner of the
        given table (or the table the cursor is in); hide it when
        there is no table or the corner is off-screen."""
        handle = getattr(self, "_table_handle", None)
        if handle is None:
            return
        try:
            cur = self.editor.textCursor()
            tbl = for_table or cur.currentTable()
            if tbl is None:
                handle.hide()
                handle._table = None
                return
            layout = self.editor.document().documentLayout()
            rect = layout.frameBoundingRect(tbl)
            x = rect.right() - self.editor.horizontalScrollBar().value()
            y = rect.bottom() - self.editor.verticalScrollBar().value()
            vp = self.editor.viewport()
            # V1.9.47 (user: the grip sat "off the view/model"):
            # the grip used to CENTRE on the corner, so half of it
            # hung outside the table -- and outside the editor on
            # full-width tables. It now parks INSIDE the corner
            # (its bottom-right 2px inside the table's corner) and
            # is clamped fully inside the viewport.
            size = _TableGrowHandle.SIZE
            # Hide only when the corner is well off-view. A
            # full-width table's frame rect legitimately ends a
            # few px PAST the viewport's right edge (document
            # margins) -- hiding there was the original "grip is
            # off the view" bug wearing a new coat. The clamp
            # below parks the grip at the visible edge instead.
            if x < -4 or y < -4 or x > vp.width() + size \
                    or y > vp.height() + size:
                handle.hide()
                handle._table = None
                return
            gx = max(0, min(int(x - size + 2), vp.width() - size))
            gy = max(0, min(int(y - size + 2), vp.height() - size))
            handle._table = tbl
            handle.move(gx, gy)
            handle.show()
            handle.raise_()
        except Exception:
            try:
                handle.hide()
            except Exception:
                pass

    # ---- notes tables: column border dragging (V1.9.39) ----
    def _table_border_at(self, pos):
        """Hit-test a column border of any table under viewport point
        `pos` (QPoint). Returns (table, border_index) where the
        border sits between column border_index-1 and border_index,
        or None. QTextEdit has no built-in table border dragging
        (verified: no split cursor is ever offered), so the editor
        grows its own, Word/Excel style."""
        try:
            layout = self.editor.document().documentLayout()
            hs = self.editor.horizontalScrollBar().value()
            vs = self.editor.verticalScrollBar().value()
            for tbl in self._iter_tables():
                rect = layout.frameBoundingRect(tbl)
                vx, vy = rect.x() - hs, rect.y() - vs
                if not (vy - 2 <= pos.y() <= vy + rect.height() + 2):
                    continue
                widths = self._table_col_widths(tbl, rect.width())
                x = vx
                for i in range(1, len(widths)):
                    x += widths[i - 1]
                    if abs(pos.x() - x) <= 5:
                        return tbl, i
            return None
        except Exception:
            return None

    def _table_col_widths(self, tbl, total):
        """Current column widths in px, from the table format's
        constraints (percentages of the frame width; fixed lengths
        as-is; variable lengths share what's left equally)."""
        from PySide6.QtGui import QTextLength as _QTL
        cols = tbl.columns()
        try:
            cons = tbl.format().columnWidthConstraints()
        except Exception:
            cons = []
        widths = [None] * cols
        used = 0.0
        for i in range(min(cols, len(cons))):
            c = cons[i]
            if c.type() == _QTL.Type.PercentageLength:
                widths[i] = total * c.rawValue() / 100.0
                used += widths[i]
            elif c.type() == _QTL.Type.FixedLength:
                widths[i] = float(c.rawValue())
                used += widths[i]
        missing = [i for i in range(cols) if widths[i] is None]
        if missing:
            share = max(0.0, (total - used) / len(missing))
            for i in missing:
                widths[i] = share
        return widths

    def _apply_col_drag(self, pos):
        drag = self._col_drag
        if drag is None:
            return
        tbl, idx = drag["table"], drag["index"]
        widths = list(drag["widths"])
        total = sum(widths)
        if total <= 0:
            return
        dx = pos.x() - drag["start_x"]
        lo = -(widths[idx - 1] - 48)
        hi = widths[idx] - 48
        dx = max(lo, min(hi, dx))
        widths[idx - 1] += dx
        widths[idx] -= dx
        from PySide6.QtGui import QTextLength as _QTL
        fmt = tbl.format()
        # V1.9.47: keep the table's own width family. Fixed-width
        # tables (every fresh insert since 1.9.47) stay fixed --
        # rewriting them as percentages made them fluid-width
        # again and the dragged widths only held while the editor
        # kept one exact width.
        try:
            fixed = bool(fmt.columnWidthConstraints()) and \
                fmt.columnWidthConstraints()[0].type() == \
                _QTL.Type.FixedLength
        except Exception:
            fixed = False
        if fixed:
            fmt.setWidth(_QTL(_QTL.Type.FixedLength, sum(widths)))
            fmt.setColumnWidthConstraints([
                _QTL(_QTL.Type.FixedLength, w) for w in widths])
        else:
            fmt.setColumnWidthConstraints([
                _QTL(_QTL.Type.PercentageLength, w / total * 100.0)
                for w in widths])
        tbl.setFormat(fmt)

    def _insert_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Insert image", "",
            "Images (*.png *.jpg *.jpeg *.gif *.bmp *.webp)", "",
            QFileDialog.DontUseNativeDialog)
        if not path:
            return
        from PySide6.QtGui import QImage as _QI
        img = _QI(path)
        if img.isNull():
            return
        # V1.9.31: embed the file's ORIGINAL bytes at native
        # resolution — the old path downscaled the raster itself to
        # 720px wide and re-encoded to JPEG 85, permanently throwing
        # away the detail (the same blur the user reported on paste).
        # Only the DISPLAY width is capped; the stored image is 1:1.
        try:
            with open(path, "rb") as fh:
                raw = fh.read()
        except OSError:
            return
        mime = _sniff_image_mime(raw)
        if mime is None:
            from PySide6.QtCore import QBuffer as _QB, QIODevice as _QIOD
            ba = _QB()
            ba.open(_QIOD.WriteOnly)
            if not img.save(ba, "PNG"):
                return
            raw = bytes(ba.data())
            mime = "image/png"
        import base64 as _b64
        data = _b64.b64encode(raw).decode("ascii")
        # V1.9.38: the 720 cap is LOGICAL px (what the reader sees);
        # the native size converts at the editor's DPR so the raster
        # paints 1:1 on scaled displays instead of upscaling.
        dpr = self.editor.devicePixelRatioF()
        dw = min(round(img.width() / dpr), 720)
        dh = round(img.height() * dw / img.width()) if img.width() else 0
        # Data-URI embedding: survives the HTML save/load cycle (plain
        # insertImage() uses session-local resource ids that are lost
        # on reload — verified by probe).
        self.editor.textCursor().insertHtml(
            f'<img src="data:{mime};base64,{data}" '
            f'width="{dw}" height="{dh}" />')
        self.editor.setFocus()

    def _clear_format(self):
        cur = self.editor.textCursor()
        if cur.hasSelection():
            cur.setCharFormat(QTextCharFormat())
            cur.setBlockFormat(QTextBlockFormat())
        else:
            self.editor.mergeCurrentCharFormat(QTextCharFormat())
        self.editor.setFocus()
        self._update_fmt_buttons()

    def _update_fmt_buttons(self):
        if self._loading:
            return
        fmt = self.editor.currentCharFormat()
        self.bold_btn.setChecked(fmt.fontWeight() >= QFont.Bold)
        self.italic_btn.setChecked(fmt.fontItalic())
        self.under_btn.setChecked(fmt.fontUnderline())
        self.strike_btn.setChecked(fmt.fontStrikeOut())
        # Font-size dropdown follows the cursor (block signals: programmatic
        # sync must not re-apply a size).
        size = fmt.fontPointSize()
        size_txt = str(int(round(size))) if size > 0 else "14"
        if self.size_combo.currentText() != size_txt:
            self.size_combo.blockSignals(True)
            self.size_combo.setCurrentText(size_txt)
            self.size_combo.blockSignals(False)
        # Highlight button face follows the cursor's real background:
        # a highlight color shows that color, otherwise the neutral bar.
        bg = fmt.background()
        if bg.style() != Qt.NoBrush and bg.color().alpha() > 0:
            self._set_hl_btn_face(bg.color().name())
        else:
            self._set_hl_btn_face(None)
        # Color swatch face follows the cursor's explicit color; only
        # standard colors move the face (custom colors keep the last).
        color = fmt.foreground().color().name() \
            if fmt.foreground().style() != Qt.NoBrush else None
        if color and any(c.lower() == color.lower()
                          for _, c in NOTES_COLORS):
            self._set_color_btn_face(color)
        # Alignment state on the current block.
        align = self.editor.textCursor().blockFormat().alignment()
        for key, btn in self.align_btns.items():
            btn.setChecked(
                (key == "center" and bool(align & Qt.AlignHCenter))
                or (key == "right" and bool(align & Qt.AlignRight))
                or (key == "left" and not (
                    align & (Qt.AlignHCenter | Qt.AlignRight))))

    def _editor_menu(self, pos):
        # V1.9.38 (user): the stock Qt menu's Paste stayed greyed
        # for image-only clipboards (a OneNote picture copy), even
        # though Ctrl+V pasted the same clipboard fine. The menu is
        # the app's own now -- same themed look as every other menu
        # in the app -- with Paste wired straight to the editor and
        # enabled whenever the clipboard holds anything insertable
        # (text, HTML, an image, or files).
        ed = self.editor
        menu = themed_menu(self)
        undo_act = menu.addAction("Undo", ed.undo)
        undo_act.setEnabled(ed.document().isUndoAvailable())
        redo_act = menu.addAction("Redo", ed.redo)
        redo_act.setEnabled(ed.document().isRedoAvailable())
        menu.addSeparator()
        has_sel = ed.textCursor().hasSelection()
        cut_act = menu.addAction("Cut", ed.cut)
        cut_act.setEnabled(has_sel)
        copy_act = menu.addAction("Copy", ed.copy)
        copy_act.setEnabled(has_sel)
        md = QGuiApplication.clipboard().mimeData()
        paste_act = menu.addAction("Paste", ed.paste)
        paste_act.setEnabled(bool(md is not None and (
            md.hasText() or md.hasHtml() or md.hasImage()
            or md.hasUrls())))
        menu.addSeparator()
        menu.addAction("Select all", ed.selectAll)
        table = ed.textCursor().currentTable()
        if table is not None:
            # V1.9.38: table shaping lives here (and on the corner
            # grip) now that Insert Table drops a bare 2x2 grid.
            cell = table.cellAt(ed.textCursor())
            r, c = cell.row(), cell.column()
            menu.addSeparator()
            menu.addAction("Insert row above",
                           lambda: table.insertRows(r, 1))
            menu.addAction("Insert row below",
                           lambda: table.insertRows(r + 1, 1))
            menu.addAction("Insert column left",
                           lambda: table.insertColumns(c, 1))
            menu.addAction("Insert column right",
                           lambda: table.insertColumns(c + 1, 1))
            menu.addSeparator()
            menu.addAction("Delete row",
                           lambda: table.removeRows(r, 1))
            menu.addAction("Delete column",
                           lambda: table.removeColumns(c, 1))

            def _delete_table(t=table):
                doc = ed.document()
                sel = QTextCursor(doc)
                sel.setPosition(t.firstCursorPosition().position())
                sel.setPosition(t.lastCursorPosition().position(),
                                QTextCursor.KeepAnchor)
                sel.removeSelectedText()

            menu.addAction("Delete table", _delete_table)
        menu.exec(ed.mapToGlobal(pos))
        ed.setFocus()

    def eventFilter(self, obj, event):
        # V1.9.47: the Unfiled scope button is a drop target for
        # note drags (unfiling by drag).
        _unf = getattr(self, "_scope_buttons", {}).get("unfiled")
        if _unf is not None and obj is _unf and \
                event.type() in (QEvent.DragEnter, QEvent.DragMove,
                                 QEvent.Drop):
            md = event.mimeData()
            if md is not None and md.hasFormat(NOTE_DRAG_MIME):
                if event.type() == QEvent.Drop:
                    raw = bytes(md.data(NOTE_DRAG_MIME)).decode("utf-8")
                    ids = [int(x) for x in raw.split(",") if x]
                    if ids:
                        self._on_notes_dropped(ids, None)
                event.acceptProposedAction()
            else:
                event.ignore()
            return True
        # Everything below needs the editor, which is built AFTER
        # the nav (the Unfiled filter above is installed during
        # _build_nav, so this filter can fire before _build_editor
        # has run -- an AttributeError here recursed through the
        # app's other event filters and took the page down).
        if getattr(self, "editor", None) is None:
            return False
        # V1.9.39: table column-border dragging + grow-grip hover,
        # driven from the editor viewport's mouse events.
        if obj is self.editor.viewport():
            et = event.type()
            if et in (QEvent.MouseMove, QEvent.MouseButtonPress,
                      QEvent.MouseButtonRelease):
                pos = event.position().toPoint()
                if self._col_drag is not None:
                    if et == QEvent.MouseMove:
                        self._apply_col_drag(pos)
                        return True
                    if et == QEvent.MouseButtonRelease:
                        self._col_drag = None
                        self.editor.viewport().releaseMouse()
                        if self._border_hover:
                            QApplication.restoreOverrideCursor()
                            self._border_hover = False
                        self._position_table_handle()
                        return True
                elif et == QEvent.MouseButtonPress and \
                        event.button() == Qt.LeftButton:
                    hit = self._table_border_at(pos)
                    if hit is not None:
                        tbl, idx = hit
                        layout = self.editor.document().documentLayout()
                        rect = layout.frameBoundingRect(tbl)
                        self._col_drag = {
                            "table": tbl, "index": idx,
                            "start_x": pos.x(),
                            "widths": self._table_col_widths(
                                tbl, rect.width()),
                        }
                        self.editor.viewport().grabMouse()
                        if not self._border_hover:
                            QApplication.setOverrideCursor(
                                Qt.SplitHCursor)
                            self._border_hover = True
                        return True
                elif et == QEvent.MouseMove and \
                        not (event.buttons() & Qt.LeftButton):
                    hit = self._table_border_at(pos)
                    if hit is not None and not self._border_hover:
                        QApplication.setOverrideCursor(Qt.SplitHCursor)
                        self._border_hover = True
                    elif hit is None and self._border_hover:
                        QApplication.restoreOverrideCursor()
                        self._border_hover = False
                    # Grow grip also appears when hovering a table,
                    # not only when the cursor is inside one.
                    hov = self.editor.cursorForPosition(pos)
                    self._position_table_handle(hov.currentTable())
        # Table corner grip follows resizes (a wider editor reflows
        # tables, moving their bottom-right corners).
        if obj is self.editor and event.type() == QEvent.Resize:
            self._position_table_handle()
        # Manual ordered-list: Enter continues numbering, Backspace at the
        # start of a numbered item removes it from the list.
        # Excel-style table navigation: Tab / Shift+Tab move between cells;
        # Tab from the last cell appends a new row.
        if obj is self.editor and event.type() == QEvent.KeyPress:
            import re
            key = event.key()
            if key in (Qt.Key_Tab, Qt.Key_Backtab):
                cur = self.editor.textCursor()
                tbl = cur.currentTable()
                if tbl is not None:
                    backwards = (key == Qt.Key_Backtab or
                                 (event.modifiers() & Qt.ShiftModifier))
                    cell = tbl.cellAt(cur)
                    r, c = cell.row(), cell.column()
                    nrows, ncols = tbl.rows(), tbl.columns()
                    if backwards:
                        if c > 0:
                            nc = tbl.cellAt(r, c - 1)
                        elif r > 0:
                            nc = tbl.cellAt(r - 1, ncols - 1)
                        else:
                            return False  # let Qt handle (focus out)
                    else:
                        if c < ncols - 1:
                            nc = tbl.cellAt(r, c + 1)
                        elif r < nrows - 1:
                            nc = tbl.cellAt(r + 1, 0)
                        else:
                            # Last cell: append a row, like Excel/Word
                            tbl.appendRows(1)
                            nc = tbl.cellAt(nrows, 0)
                    # Move cursor to start of target cell
                    ncur = QTextCursor(nc.firstCursorPosition().document())
                    ncur.setPosition(nc.firstPosition() + 1)
                    self.editor.setTextCursor(ncur)
                    return True
                return False  # not in a table: normal Tab behavior
            cur = self.editor.textCursor()
            block = cur.block()
            text = block.text()
            m = re.match(r"^(\d+)\.\s", text)
            if key in (Qt.Key_Return, Qt.Key_Enter) and m:
                # If the item is empty (just "N. "), remove the number
                # and end the list instead of continuing.
                if text.strip() == m.group(0).strip():
                    cur.beginEditBlock()
                    cur.movePosition(QTextCursor.StartOfBlock)
                    cur.movePosition(QTextCursor.NextCharacter,
                                     QTextCursor.KeepAnchor, len(m.group(0)))
                    cur.removeSelectedText()
                    bf = cur.blockFormat()
                    bf.setProperty(0x1001, 0)
                    cur.setBlockFormat(bf)
                    cur.endEditBlock()
                else:
                    # Continue the list with the next number
                    n = int(m.group(1)) + 1
                    cur.beginEditBlock()
                    cur.insertBlock()
                    cur.insertText(f"{n}. ")
                    bf = cur.blockFormat()
                    bf.setLeftMargin(18)
                    bf.setProperty(0x1001, n)
                    cur.setBlockFormat(bf)
                    cur.endEditBlock()
                return True
            if key == Qt.Key_Backspace and m:
                # At the very start (right after "N. "): remove number
                if cur.positionInBlock() <= len(m.group(0)):
                    cur.beginEditBlock()
                    cur.movePosition(QTextCursor.StartOfBlock)
                    cur.movePosition(QTextCursor.NextCharacter,
                                     QTextCursor.KeepAnchor, len(m.group(0)))
                    cur.removeSelectedText()
                    bf = cur.blockFormat()
                    bf.setProperty(0x1001, 0)
                    cur.setBlockFormat(bf)
                    cur.endEditBlock()
                    return True
        return super().eventFilter(obj, event)

    # ---- notebooks: add / rename / delete ----
    def _on_add_notebook(self):
        name, ok = app_get_text(self, "New notebook", "Notebook name:")
        if ok and (name or "").strip():
            nb_id = self.db.notebook_add(name)
            self._refresh_nav()
            self._set_scope("notebook", nb_id)

    def _nb_menu(self, pos):
        item = self.nb_list.itemAt(pos)
        if item is None:
            return
        nb_id = item.data(Qt.UserRole)
        menu = themed_menu(self)
        rename = menu.addAction("Rename notebook")
        delete = menu.addAction("Delete notebook")
        action = menu.exec(self.nb_list.mapToGlobal(pos))
        if action == rename:
            nb = next((n for n in self.db.notebook_list()
                       if n["id"] == nb_id), None)
            name, ok = app_get_text(
                self, "Rename notebook", "Notebook name:",
                text=nb["name"] if nb else "")
            if ok and (name or "").strip():
                self.db.notebook_rename(nb_id, name)
                self._refresh_nav()
        elif action == delete:
            if app_confirm(
                    self, "Delete notebook",
                    "Delete this notebook? Its notes become Unfiled.",
                    confirm_label="Delete", danger=True):
                self.db.notebook_delete(nb_id)
                if self._scope == "notebook" and self._scope_id == nb_id:
                    self._scope, self._scope_id = "all", None
                    self._scope_buttons["all"].setChecked(True)
                self._refresh_nav()
                self._refresh_list()

    # ---- note actions ----
    def _note_menu(self, pos):
        item = self.note_list.itemAt(pos)
        if item is None:
            return
        note_id = item.data(Qt.UserRole)
        note = self.db.note_get(note_id)
        if note is None:
            return
        # V1.9.47: when the right-clicked note is part of a
        # multi-selection, Pin / Move / Delete act on the whole
        # selection -- the standard extended-selection contract.
        selected = [it.data(Qt.UserRole)
                    for it in self.note_list.selectedItems()]
        targets = selected if (note_id in selected
                               and len(selected) > 1) else [note_id]
        menu = themed_menu(self)
        pin_act = menu.addAction(
            "Unpin" if note["pinned"] else "Pin to top")
        move_menu = menu.addMenu("Move to notebook")
        move_actions = {}
        unfiled_act = move_menu.addAction("Unfiled")
        move_actions[unfiled_act] = None
        for nb in self.db.notebook_list():
            act = move_menu.addAction(nb["name"])
            move_actions[act] = nb["id"]
        export_menu = menu.addMenu("Export")
        md_act = export_menu.addAction("Markdown (.md)")
        html_act = export_menu.addAction("HTML (.html)")
        txt_act = export_menu.addAction("Plain text (.txt)")
        docx_act = export_menu.addAction("Word (.docx)")
        menu.addSeparator()
        del_act = menu.addAction(
            "Delete note" if len(targets) == 1
            else f"Delete {len(targets)} notes")
        action = menu.exec(self.note_list.mapToGlobal(pos))
        if action == pin_act:
            for tid in targets:
                self.db.note_update(tid, pinned=not note["pinned"])
            # V1.9.47 (user: pinning never landed in the Pinned
            # section, count stayed 0): the pin branch refreshed
            # only the list -- the nav counts (Pinned (n)) are
            # rebuilt by _refresh_nav, which this branch never
            # called (the Move branch below always did).
            self._refresh_nav()
            self._refresh_list(keep_selection=True)
        elif action in move_actions:
            for tid in targets:
                self.db.note_update(
                    tid, notebook_id=move_actions[action])
            self._refresh_nav()
            self._refresh_list(keep_selection=True)
        elif action == md_act:
            self._export_note(note, "md")
        elif action == html_act:
            self._export_note(note, "html")
        elif action == txt_act:
            self._export_note(note, "txt")
        elif action == docx_act:
            self._export_note(note, "docx")
        elif action == del_act:
            if len(targets) == 1:
                self._delete_note(note_id)
            else:
                self._delete_notes(targets)

    def _on_delete_note(self):
        if self._current_id is not None:
            self._delete_note(self._current_id)

    def _delete_notes(self, ids):
        """Multi-select delete (V1.9.47): one confirmation for
        the whole selection, then the same post-delete state
        _delete_note leaves behind."""
        if _DeleteNoteDialog(f"{len(ids)} notes", self).exec() != \
                QDialog.Accepted:
            return
        if self._current_id in ids:
            self._save_timer.stop()
            self._dirty = False
            self._current_id = None
        for nid in ids:
            self.db.note_delete(nid)
        self._refresh_nav()
        self._refresh_list()
        if self._current_id is None:
            self._loading = True
            self.editor_stack.setCurrentIndex(0)
            self.title_edit.clear()
            self._loading = False

    def _delete_note(self, note_id):
        note = self.db.note_get(note_id)
        title = (note["title"] if note else "") or "Untitled note"
        if _DeleteNoteDialog(title, self).exec() != QDialog.Accepted:
            return
        if note_id == self._current_id:
            self._save_timer.stop()
            self._dirty = False
            self._current_id = None
        self.db.note_delete(note_id)
        self._refresh_nav()
        self._refresh_list()
        if self._current_id is None:
            self._loading = True
            self.editor_stack.setCurrentIndex(0)
            self.title_edit.clear()
            self._loading = False

    # ---- export ----
    def _export_note(self, note, fmt):
        from pathlib import Path as _Path
        base = "".join(
            c for c in (note.get("title") or "note") if c.isalnum()
            or c in (" ", "-", "_")).strip() or "note"
        ext = {"md": ".md", "html": ".html", "txt": ".txt",
               "docx": ".docx"}[fmt]
        default = str(_Path.home() / (base + ext))
        filt = {"md": "Markdown (*.md)", "html": "HTML (*.html)",
                "txt": "Text (*.txt)",
                "docx": "Word (*.docx)"}[fmt]
        path, _ = QFileDialog.getSaveFileName(
            self, "Export note", default, filt, "",
            QFileDialog.DontUseNativeDialog)
        if not path:
            return
        try:
            if fmt == "docx":
                _Path(path).write_bytes(note_to_docx(note))
            else:
                writer = {"md": note_to_markdown, "html": note_to_html_doc,
                          "txt": note_to_text}[fmt]
                _Path(path).write_text(writer(note), encoding="utf-8")
            show_toast(self, "success", "Note exported",
                       f"Saved to {path}")
        except OSError as exc:
            app_message(self, "Export failed", str(exc))

    def _on_export_menu(self):
        if self._current_id is None:
            return
        self._flush()
        note = self.db.note_get(self._current_id)
        if note is None:
            return
        menu = themed_menu(self)
        md_act = menu.addAction("Markdown (.md)")
        html_act = menu.addAction("HTML (.html)")
        txt_act = menu.addAction("Plain text (.txt)")
        docx_act = menu.addAction("Word (.docx)")
        action = menu.exec(QCursor.pos())
        if action == md_act:
            self._export_note(note, "md")
        elif action == html_act:
            self._export_note(note, "html")
        elif action == txt_act:
            self._export_note(note, "txt")
        elif action == docx_act:
            self._export_note(note, "docx")

    def _on_export_all(self):
        from pathlib import Path as _Path
        folder = QFileDialog.getExistingDirectory(
            self, "Export all notes to folder", "",
            QFileDialog.DontUseNativeDialog)
        if not folder:
            return
        notes = [self.db.note_get(n["id"])
                 for n in self.db.note_list()]
        notes = [n for n in notes if n]
        try:
            written = export_notes_to_folder(notes, folder)
            show_toast(self, "success", "Notes exported",
                       f"{len(written)} notes saved to {folder}")
        except OSError as exc:
            app_message(self, "Export failed", str(exc))
