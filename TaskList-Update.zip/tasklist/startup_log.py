"""Startup timing log: append-only markers for diagnosing slow launches.

Each line is ``<ISO-timestamp> - <event name>``, appended to
``<app>/data/startup.log``. The file is rotated to the last
``MAX_LINES`` lines so it stays tiny.

Everything here is total-failure-proof: logging must never break the app
and must cost ~nothing (one guarded append per marker). It is also
import-safe without Qt — the launcher writes its marker before PySide6
is even imported.
"""

from datetime import datetime
from pathlib import Path
import os

MAX_LINES = 300


def _log_path():
    """Where the log lives. Tests monkeypatch this to redirect output.

    V1.9.16: follows TASKLIST_DATA_DIR like default_db_path, so a
    local-mirror launch still logs to the share's data folder (where
    the user actually looks for it).
    """
    try:
        install_data = (Path(__file__).resolve().parent.parent
                        / "data")
        try:
            from tasklist import datahome
            data_dir = datahome.resolve_data_dir(install_data)
        except Exception:
            try:
                from . import datahome
                data_dir = datahome.resolve_data_dir(install_data)
            except Exception:
                data_dir = install_data
                override = os.environ.get(
                    "TASKLIST_DATA_DIR", "").strip()
                if override and Path(override).is_dir():
                    data_dir = Path(override)
        candidate = data_dir / "startup.log"
        if candidate.parent.is_dir():
            return candidate
        return install_data / "startup.log"
    except Exception:
        return None


_crash_file = None


def install_crash_logging():
    """Capture hard crashes and unhandled exceptions to
    ``<data>/crash.log`` (V1.9.48).

    The app runs without a console, so before this a native
    fault closed it with NO trace anywhere -- the 2026-11-12
    crash in the middle of creating a task (adding
    attachments) was undiagnosable for exactly that reason.
    faulthandler catches the native faults (access violations
    and friends); the excepthook records Python tracebacks.
    Never raises: logging must never break the app.
    """
    global _crash_file
    try:
        import faulthandler
        import sys
        import traceback
        path = _log_path()
        if path is None:
            return
        _crash_file = open(path.with_name("crash.log"), "a",
                           encoding="utf-8", buffering=1)
        faulthandler.enable(file=_crash_file, all_threads=True)
        _prev_hook = sys.excepthook

        def _hook(exc_type, exc, tb):
            try:
                _crash_file.write(
                    "\n=== {} unhandled exception ===\n".format(
                        datetime.now().isoformat(timespec="seconds")))
                traceback.print_exception(exc_type, exc, tb,
                                          file=_crash_file)
                _crash_file.flush()
            except Exception:
                pass
            _prev_hook(exc_type, exc, tb)

        sys.excepthook = _hook
    except Exception:
        pass


def log_startup_event(name):
    """Append one timestamped marker line. Never raises."""
    try:
        path = _log_path()
        if path is None:
            return
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            return
        line = (datetime.now().astimezone().isoformat(timespec="milliseconds")
                + f" - {name}\n")
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            return
        # Rotate: keep only the newest lines. Cheap — the file is tiny
        # by design, and a slow launch must never be made slower by logging.
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) > MAX_LINES:
                with open(path, "w", encoding="utf-8") as f:
                    f.writelines(lines[-MAX_LINES:])
        except Exception:
            pass
    except Exception:
        pass
