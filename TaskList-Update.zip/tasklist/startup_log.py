"""Startup timing log: append-only markers for diagnosing slow launches.

Each line is ``<ISO-timestamp> - <event name>``, appended to
``<app>/data/startup.log``. The file is rotated to the last
``MAX_LINES`` lines so it stays tiny.

Everything here is total-failure-proof: logging must never break the app
and must cost ~nothing (one guarded append per marker). It is also
import-safe without Qt — the launcher writes its marker before PySide6
is even imported.
"""

from datetime import datetime
from pathlib import Path
import os

MAX_LINES = 300


def _log_path():
    """Where the log lives. Tests monkeypatch this to redirect output.

    V1.9.16: follows TASKLIST_DATA_DIR like default_db_path, so a
    local-mirror launch still logs to the share's data folder (where
    the user actually looks for it).
    """
    try:
        override = os.environ.get("TASKLIST_DATA_DIR", "").strip()
        if override:
            candidate = Path(override) / "startup.log"
            if candidate.parent.is_dir():
                return candidate
        return Path(__file__).resolve().parent.parent / "data" / "startup.log"
    except Exception:
        return None


def log_startup_event(name):
    """Append one timestamped marker line. Never raises."""
    try:
        path = _log_path()
        if path is None:
            return
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            return
        line = (datetime.now().astimezone().isoformat(timespec="milliseconds")
                + f" - {name}\n")
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            return
        # Rotate: keep only the newest lines. Cheap — the file is tiny
        # by design, and a slow launch must never be made slower by logging.
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) > MAX_LINES:
                with open(path, "w", encoding="utf-8") as f:
                    f.writelines(lines[-MAX_LINES:])
        except Exception:
            pass
    except Exception:
        pass
