"""Export tasks to a formatted Excel workbook."""
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

from .db import STATUS_LABELS

HEADERS = [
    "Quote Number", "Status", "Rack Type", "Distributor", "End User", "Quote Folder", "Scope",
    "Scope Progress", "Notes", "Date Added", "Date Completed", "Attachments",
    "Due Date", "Est. Hours", "Quote Price",
]
WIDTHS = [16, 14, 24, 22, 26, 32, 30, 16, 50, 13, 15, 28, 13, 11, 14]

HEADER_FONT = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
HEADER_FILL = PatternFill("solid", fgColor="2563EB")
TITLE_FONT = Font(name="Calibri", bold=True, size=14, color="1F2937")
THIN = Side(style="thin", color="D1D5DB")
ROW_BORDER = Border(bottom=THIN)


def _scope_progress(task):
    total = len(task.get("scope", []))
    if not total:
        return "—"
    done = len(task.get("scope_done", []))
    return f"{done}/{total}"


def _format_hours(value):
    if value is None:
        return ""
    try:
        return ("%g" % float(value))
    except (TypeError, ValueError):
        return ""


def _format_price(value):
    if value is None:
        return ""
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return ""


def _attachment_names(atts):
    """'3 files: a.pdf; b.png' — filenames, not just a count."""
    names = [a.get("filename", "") for a in atts if a.get("filename")]
    if not names:
        return ""
    return f"{len(names)} file{'s' if len(names) != 1 else ''}: " + "; ".join(names)


def export_tasks_to_excel(tasks, attachments_by_task, filepath):
    wb = Workbook()
    ws = wb.active
    ws.title = "Task List"
    ws.sheet_properties.pageSetUpPr.fitToPage = True

    last_col = chr(ord("A") + len(HEADERS) - 1)
    ws["A1"] = f"Task List Export — {datetime.now():%Y-%m-%d}"
    ws["A1"].font = TITLE_FONT
    ws.merge_cells(f"A1:{last_col}1")

    for col, (header, width) in enumerate(zip(HEADERS, WIDTHS), start=1):
        cell = ws.cell(row=3, column=col, value=header)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(vertical="center")
        ws.column_dimensions[cell.column_letter].width = width
    ws.row_dimensions[3].height = 22

    for r, task in enumerate(tasks, start=4):
        atts = attachments_by_task.get(task["id"], [])
        values = [
            task.get("quote_number", ""),
            STATUS_LABELS.get(task.get("status"), task.get("status", "")),
            ", ".join(task.get("rack_types", [])),
            task.get("distributor", ""),
            task.get("end_user", ""),
            task.get("folder_path", ""),
            ", ".join(task.get("scope", [])),
            _scope_progress(task),
            task.get("notes", ""),
            (task.get("created_at") or "")[:10],
            (task.get("completed_at") or "")[:10],
            _attachment_names(atts),
            (task.get("due_date") or ""),
            _format_hours(task.get("estimated_hours")),
            _format_price(task.get("quote_value")),
        ]
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=r, column=col, value=value)
            cell.border = ROW_BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=(col in (3, 6, 7, 9, 12)))
        if r % 2 == 0:
            for col in range(1, len(HEADERS) + 1):
                ws.cell(row=r, column=col).fill = PatternFill("solid", fgColor="F8FAFC")

    ws.freeze_panes = "A4"
    ws.auto_filter.ref = f"A3:{last_col}{3 + len(tasks)}"
    wb.save(filepath)
