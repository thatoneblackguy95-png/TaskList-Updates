#Requires -Version 5.1
<#
.SYNOPSIS
    Opens a folder as a NEW TAB in an already-open Windows 11 File Explorer window.

.DESCRIPTION
    Bundled with Task List (portable, stdlib-only). Uses the Shell.Application
    COM object to enumerate open Explorer tabs, sends the undocumented
    WM_COMMAND 0xA21B "new tab" command to the window's hidden
    ShellTabWindowClass child, polls for the new tab to appear, then navigates
    it to the requested folder.

    Technique based on aont/explorer-tab-merger (MIT license).

    Exit codes:
        0 - folder opened in a new tab of the existing Explorer window
        1 - failed (caller should fall back to explorer.exe / openUrl)
        2 - no File Explorer window is open (caller should fall back)

.PARAMETER FolderPath
    The folder to open. Mapped-drive paths (Q:\...), UNC paths
    (\\server\share\...) and paths containing spaces are all accepted.
#>
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$FolderPath
)

$ErrorActionPreference = 'Stop'

$WM_COMMAND     = 0x0111
$NEW_TAB_CMD    = 0xA21B   # undocumented Explorer "open new tab" command
$POLL_SECONDS   = 10
$TAB_HOST_CLASS = 'ShellTabWindowClass'

function Fail($msg) {
    # One stderr line so the caller's log can name the failing step.
    [Console]::Error.WriteLine("open_in_tab: $msg")
    exit 1
}

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public delegate bool EnumChildProc(IntPtr hWnd, IntPtr lParam);

public static class ExplorerTabNative {
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool EnumChildWindows(
        IntPtr hWndParent, EnumChildProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern int GetClassName(
        IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern IntPtr SendMessage(
        IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
}
"@

function Get-ExplorerWindows {
    # Real File Explorer windows only; Shell.Application can also list IE.
    $found = @()
    $shell = New-Object -ComObject Shell.Application
    foreach ($w in $shell.Windows()) {
        try {
            if ([string]$w.FullName -match 'explorer\.exe$') { $found += $w }
        } catch { }
    }
    return $found
}

function Get-TabKey($tab) {
    # COM identity of the tab (mirrors the C reference's IUnknown compare).
    try {
        return ([System.Runtime.InteropServices.Marshal]::GetIUnknownForObject($tab)).ToString()
    } catch { return $null }
}

function Get-TabsOfWindow($windows, [long]$hwndValue) {
    $tabs = @()
    foreach ($w in $windows) {
        try {
            if ([long]$w.HWND -eq $hwndValue) { $tabs += $w }
        } catch { }
    }
    return $tabs
}

try {
    $target = $FolderPath.Trim()
    if ([string]::IsNullOrWhiteSpace($target)) { Fail "empty path" }
    # Validate + normalize; keeps mapped-drive and UNC form intact.
    try {
        $item = Get-Item -LiteralPath $target -ErrorAction Stop
        if (-not $item.PSIsContainer) { Fail "not a folder" }
        $target = $item.FullName
    } catch { Fail "Get-Item failed" }

    $windows = Get-ExplorerWindows
    if (-not $windows) { exit 2 }   # no Explorer window: caller falls back

    # V1.9.12: try EVERY open Explorer frame, not just the first one.
    # The first enumerated window is not always a tabbed Explorer frame
    # (a Control Panel / search window hosted by explorer.exe has no
    # ShellTabWindowClass child), and stopping there sent every folder
    # open to the new-window fallback even while a tabbed window was
    # open. The new-tab poll is 10s, not 4s — tab creation on a busy
    # machine can take longer than 4s, and a too-tight poll turned a
    # slow tab into a new window.
    $hwndValues = @()
    foreach ($w in $windows) {
        try {
            $v = [long]$w.HWND
            if ($v -ne 0 -and $hwndValues -notcontains $v) { $hwndValues += $v }
        } catch { }
    }
    if (-not $hwndValues) { Fail "HWND read failed" }

    $lastError = "no Explorer frame accepted a new tab"
    foreach ($hwndValue in $hwndValues) {
        $hwnd = [IntPtr]$hwndValue

        # Baseline the tabs already open in this window, by COM identity.
        $baseline = @{}
        foreach ($t in (Get-TabsOfWindow $windows $hwndValue)) {
            $key = Get-TabKey $t
            if ($key) { $baseline[$key] = $true }
        }

        # Find the hidden tab-host child window.
        $script:tabHost = [IntPtr]::Zero
        $enumProc = {
            param([IntPtr]$child, [IntPtr]$unused)
            $sb = New-Object System.Text.StringBuilder(256)
            if ([ExplorerTabNative]::GetClassName($child, $sb, 256) -gt 0 -and
                $sb.ToString() -eq $TAB_HOST_CLASS) {
                $script:tabHost = $child
                return $false   # stop enumeration
            }
            return $true
        } -as [EnumChildProc]
        if (-not $enumProc) { $lastError = "delegate cast failed"; continue }
        [void][ExplorerTabNative]::EnumChildWindows($hwnd, $enumProc, [IntPtr]::Zero)
        if ($script:tabHost -eq [IntPtr]::Zero) {
            $lastError = "ShellTabWindowClass not found"; continue
        }

        # Ask Explorer to open a new tab.
        [void][ExplorerTabNative]::SendMessage(
            $script:tabHost, $WM_COMMAND, [IntPtr]$NEW_TAB_CMD, [IntPtr]::Zero)

        # Poll for the new tab (the one whose COM identity is not in $baseline).
        $newTab = $null
        $deadline = (Get-Date).AddSeconds($POLL_SECONDS)
        while ((Get-Date) -lt $deadline -and -not $newTab) {
            Start-Sleep -Milliseconds 250
            foreach ($t in (Get-TabsOfWindow (Get-ExplorerWindows) $hwndValue)) {
                $key = Get-TabKey $t
                if ($key -and -not $baseline.ContainsKey($key)) { $newTab = $t; break }
            }
        }
        if (-not $newTab) {
            $lastError = "new tab did not appear after SendMessage"; continue
        }

        try {
            $newTab.Navigate2($target)
        } catch { $lastError = "Navigate2 failed"; continue }

        # Bring the Explorer window forward (best effort, never fatal).
        try { [void][ExplorerTabNative]::SetForegroundWindow($hwnd) } catch { }

        exit 0
    }
    Fail $lastError
} catch {
    Fail "unhandled: $($_.Exception.Message)"
}
