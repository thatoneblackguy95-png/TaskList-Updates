"""SQLite storage for the Task List app. Everything lives in one portable file."""
import html
import json
import os
import re
import shutil
import sqlite3
import statistics
import time
import zipfile
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path

from .startup_log import log_startup_event

# The default multi-select work types for the Scope dropdown.
# Users can customize these in File > Settings; see TaskDatabase.get_scopes().
DEFAULT_SCOPES = ["Quote", "Re-quote", "CAD", "Configura", "Prelims", "Misc"]

# Backwards-compatible alias (used by older code / tests).
SCOPES = DEFAULT_SCOPES

# The default multi-select options for the Rack Type dropdown.
# Users can customize these in File > Settings; see TaskDatabase.get_rack_types().
DEFAULT_RACK_TYPES = [
    "Selective", "Ductile", "Structural", "Beams", "Push-Back", "Palletflow",
    "Drive-In", "Drive-Thru", "Cantilever", "Hybrid Racking", "Shelving",
    "Pick-Podule", "ASRS", "Carton Flow", "Modular", "Accessory's",
]

# V1.9.29 (user-supplied list): the default Sales Rep options for the
# detail window's Sales Rep dropdown. Customizable in Settings ->
# Option Lists, exactly like scopes and rack types. "House Account"
# is a real entry in his list, not a placeholder.
DEFAULT_SALES_REPS = [
    "Cory M", "Craig P", "House Account", "James D", "John L",
    "John O", "Shae S", "Tim B", "Travis S",
]

# Sort modes for the main list. Key -> (label, ORDER BY clause).
# Labels are intentionally terse so the toolbar combo stays compact.
SORT_MODES = {
    "newest": ("Newest first", "created_at DESC, id DESC"),
    "oldest": ("Oldest first", "created_at ASC, id ASC"),
    "quote_az": ("Quote # A–Z", "quote_number COLLATE NOCASE ASC, id DESC"),
    "quote_za": ("Quote # Z–A", "quote_number COLLATE NOCASE DESC, id DESC"),
    "due_soon": (
        "Due soon",
        "CASE WHEN due_date IS NULL OR due_date='' THEN 1 ELSE 0 END, "
        "due_date ASC, created_at DESC, id DESC",
    ),
    "dist_az": (
        "Distributor A–Z",
        "distributor COLLATE NOCASE ASC, id DESC",
    ),
}

STATUSES = ["in_process", "on_hold", "completed", "canceled"]
STATUS_LABELS = {
    "in_process": "In Process",
    "on_hold": "On Hold",
    "completed": "Completed",
    "canceled": "Canceled",
}

# V1.9.9: schema version for the DB-open fast path. Bump this integer every
# time SCHEMA or _migrate() gains a structural change; TaskDatabase skips
# the full executescript+migrate when the stored version matches, turning
# ~20 network round trips into 1 on a network share.
# V1.9.13: bumped 1 -> 2 for the nudge_dismissals table, so existing
# databases take one full schema pass (with its pre-migration backup).
SCHEMA_VERSION = 5  # V1.9.30: task revisions (tasks.revision /
# tasks.att_hidden + the task_revisions snapshot table)

SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_number TEXT NOT NULL,
    distributor TEXT NOT NULL DEFAULT '',
    end_user TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    scope TEXT NOT NULL DEFAULT '[]',
    scope_done TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'in_process',
    created_at TEXT NOT NULL,
    completed_at TEXT
);
CREATE TABLE IF NOT EXISTS attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    stored TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 0,
    added_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS directory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    name TEXT NOT NULL COLLATE NOCASE,
    phone TEXT NOT NULL DEFAULT '',
    email TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    city TEXT NOT NULL DEFAULT '',
    state TEXT NOT NULL DEFAULT '',
    zip_code TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(kind, name)
);
CREATE TABLE IF NOT EXISTS queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL UNIQUE,
    column_key TEXT NOT NULL DEFAULT 'now',
    position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS notebooks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    notebook_id INTEGER REFERENCES notebooks(id),
    title TEXT NOT NULL DEFAULT '',
    body_html TEXT NOT NULL DEFAULT '',
    body_text TEXT NOT NULL DEFAULT '',
    pinned INTEGER NOT NULL DEFAULT 0,
    formulas TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notes_notebook ON notes(notebook_id);
CREATE INDEX IF NOT EXISTS idx_notes_updated ON notes(updated_at);
CREATE TABLE IF NOT EXISTS nudge_dismissals (
    distributor TEXT PRIMARY KEY COLLATE NOCASE,
    dismissed_at TEXT NOT NULL
);
"""

# Saved distributor / end-user names (powers autocomplete + the Directory tab).
DIRECTORY_KINDS = ("distributor", "customer", "contact", "sales_rep")
DIRECTORY_LABELS = {"distributor": "Distributors", "customer": "End Users",
                    "contact": "Contact Names", "sales_rep": "Sales Reps"}
DIRECTORY_SINGULAR = {"distributor": "Distributor", "customer": "End User",
                      "contact": "Contact Name", "sales_rep": "Sales Rep"}
# Distributor/end-user task column backing each directory kind.
# V1.9.29: Contact Name / Sales Rep are directory kinds too -- the CRM
# gains both as filterable tabs, and both self-populate from task
# saves exactly like distributors (user request).
DIRECTORY_TASK_COLUMN = {"distributor": "distributor", "customer": "end_user",
                         "contact": "per", "sales_rep": "sales_rep"}

# Kanban queue columns: key -> label.
QUEUE_COLUMNS = (("now", "Now"), ("next", "Next"), ("later", "Later"))
QUEUE_COLUMN_KEYS = tuple(k for k, _ in QUEUE_COLUMNS)
OPEN_STATUSES = ("in_process", "on_hold")

# Sentinel for update_task(): only columns whose argument is not _UNSET are
# included in the UPDATE, so callers can leave fields untouched.
_UNSET = object()

# Allowed activity-log kinds.
ACTIVITY_KINDS = frozenset(
    {"create", "status", "scope", "note", "cancel", "hold", "duplicate", "price", "edit",
     "outcome", "reminder", "attachment", "quote_folder", "revision"}
)

# Rotating backups: keep this many newest .db snapshots.
# V1.9.37: snapshots now happen at every launch AND every close,
# so 10 would span barely two days -- 20 keeps a working week+.
BACKUP_KEEP = 20


def _is_io_failure(exc):
    """True for the disk-level failures the recovery ladder exists
    for: SQLITE_IOERR (10) and SQLITE_CANTOPEN (14), matched by
    message when the sqlite3 build doesn't expose the code. "database
    is locked" is NOT one of these -- that's the other machine
    writing, and busy_timeout already handles it; quarantining
    sidecars under a live database would be destructive."""
    code = getattr(exc, "sqlite_errorcode", None)
    if code in (10, 14):
        return True
    msg = str(exc).lower()
    return ("disk i/o error" in msg
            or "unable to open database file" in msg
            or "i/o error" in msg)


def _quarantine_sidecar(db_path, suffix):
    """Move a WAL sidecar (``-shm`` / ``-wal``) aside -- renamed with
    a ``.stale-<timestamp>`` suffix, NEVER deleted, so nothing is
    unrecoverable. Returns True when a file was moved. A sidecar
    another process holds open cannot be renamed on Windows, which
    makes this safe to attempt: it only ever moves files nothing is
    using."""
    src = Path(str(db_path) + suffix)
    try:
        if not src.exists():
            return False
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dst = Path(str(db_path) + suffix + f".stale-{stamp}")
        n = 1
        while dst.exists():
            n += 1
            dst = Path(str(db_path) + suffix + f".stale-{stamp}-{n}")
        src.rename(dst)
        log_startup_event(
            f"db recovery: moved {src.name} aside as {dst.name}")
        return True
    except Exception as exc:  # noqa: BLE001 - recovery must not raise
        log_startup_event(
            f"db recovery: could not move {src.name} aside: {exc!r}")
        return False


def _open_connection(path, resilient=False):
    """Open a SQLite connection with the multi-machine settings.

    busy_timeout (plus the connect timeout) makes a writer WAIT for
    the other machine's write to finish instead of failing with
    "database is locked" when both save in the same moment. WAL
    journaling lets readers and the writer coexist; it needs the
    -shm sidecar, which a Windows file share provides -- if the
    filesystem refuses, the pragma quietly leaves the rollback
    journal in place and nothing breaks.

    V1.9.50 (user, 2026-11-13): with ``resilient=True`` an I/O-class
    failure runs a recovery ladder instead of dead-ending startup
    (the "Task List could not start: disk I/O error" dialog he hit
    at home): each attempt is probed with a real read so the failure
    surfaces HERE, while recovery is still possible --

    1. plain open;
    2. move a stale ``-shm`` aside and retry (the ``-wal`` stays, so
       committed work still replays), or, when there is no ``-shm``,
       wait a beat -- the share may still be connecting;
    3. move a stale ``-wal`` aside and retry (loses only the
       uncheckpointed tail of a database that could not open at
       all; the file is renamed, not deleted, and logged);
    4. open with the rollback journal instead of WAL, for
       filesystems that cannot host the ``-shm`` at all.

    Every step is logged to startup.log. A non-I/O error raises
    immediately -- the ladder never masks a real bug.
    """
    if not resilient:
        conn = sqlite3.connect(str(path), timeout=30.0)
        try:
            conn.execute("PRAGMA busy_timeout=30000")
            conn.execute("PRAGMA journal_mode=WAL")
        except Exception:
            pass
        return conn
    last_exc = None
    for attempt in range(4):
        conn = None
        try:
            conn = sqlite3.connect(str(path), timeout=30.0)
            conn.execute("PRAGMA busy_timeout=30000")
            journal = "DELETE" if attempt == 3 else "WAL"
            conn.execute(f"PRAGMA journal_mode={journal}")
            # Probe with a REAL read: connect() is lazy, and the
            # journal pragma alone can succeed against a sidecar
            # state that then fails the first query -- which used to
            # surface as the could-not-start dialog, past the point
            # where recovery was possible.
            conn.execute("SELECT name FROM sqlite_master LIMIT 1"
                         ).fetchone()
            # V1.9.51: the schema probe above was NOT enough. The
            # user's uploaded startup.log (2026-11-13) shows the
            # 1.9.49 failure landing AFTER "db connected", on a
            # real DATA read during window construction -- the
            # sqlite_master pages were readable through the
            # poisoned Offline-Files cache while the WAL data
            # pages were not. Probe the data itself: a COUNT over
            # the tasks table walks its pages through the WAL,
            # and a settings read does the same for the other
            # table every launch touches first. Either failing
            # here is an I/O-class failure the ladder can still
            # heal; failing later is a dead app.
            _tables = {r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()}
            if "tasks" in _tables:
                conn.execute("SELECT COUNT(*) FROM tasks").fetchone()
            if "settings" in _tables:
                conn.execute(
                    "SELECT value FROM settings LIMIT 1").fetchone()
            if attempt:
                log_startup_event(
                    f"db recovery: opened on attempt {attempt + 1} "
                    f"(journal={journal})")
            return conn
        except Exception as exc:  # noqa: BLE001 - ladder classifies it
            last_exc = exc
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
            if not _is_io_failure(exc):
                raise
            log_startup_event(
                f"db recovery: open attempt {attempt + 1} failed "
                f"(I/O): {exc!r}")
            if attempt == 0:
                if not _quarantine_sidecar(path, "-shm"):
                    # No stale -shm: the share may still be coming
                    # up (VPN just connected). One short wait, then
                    # the plain retry.
                    time.sleep(1.5)
            elif attempt == 1:
                _quarantine_sidecar(path, "-wal")
            elif attempt == 2:
                log_startup_event(
                    "db recovery: falling back to the rollback "
                    "journal (WAL sidecars unusable here)")
    raise last_exc


def _monday_iso(today=None):
    """ISO date ("YYYY-MM-DD") of the Monday starting the current week.

    Monday-start matches the dashboard's weekly chart. Pure date math,
    unit-testable.
    """
    t = today or date.today()
    return (t - timedelta(days=t.weekday())).isoformat()


def _next_monday_iso(today=None):
    """ISO date of next Monday — the exclusive upper bound of this week."""
    t = today or date.today()
    return (t - timedelta(days=t.weekday()) + timedelta(days=7)).isoformat()


def compute_nudges(histories, today=None):
    """Pure distributor-nudge algorithm (no DB access).

    histories: {distributor_name: [ISO datetime strings]}.
    Returns a list of dicts for distributors that quoted within the last
    180 days but have now gone quiet longer than twice their usual
    quoting cadence (with a 14-day floor). Sorted by
    days_since_last/cadence ratio, most overdue first.

    V1.9.13: cadence is the median gap between quoting EPISODES, not
    between individual quotes. Quotes falling fewer than 7 days after an
    episode's start belong to that episode — a burst of quotes in one
    busy week is one episode, not five. The old per-quote median let a
    short burst drag a distributor's "usual" cadence down to 1-2 days,
    which then flagged normal monthly silence as overdue (the USSI
    complaint). Episodes anchor at their start date rather than chaining
    quote-to-quote, so a distributor that genuinely quotes every day
    still forms weekly episodes instead of one endless episode. At
    least 3 episodes are needed for a median; fewer is not enough
    baseline to claim a cadence, so one-off bursts never nag.
    """
    if today is None:
        today = date.today()
    elif isinstance(today, datetime):
        today = today.date()
    nudges = []
    for name, stamps in (histories or {}).items():
        if not name or not stamps:
            continue
        dates = []
        for s in stamps:
            try:
                dt = datetime.fromisoformat(s)
            except (ValueError, TypeError):
                continue
            d = dt.date() if isinstance(dt, datetime) else dt
            dates.append(d)
        if not dates:
            continue
        dates.sort()
        # Active relationship only: the latest quote is within 180 days
        # (and not in the future — a future-dated task must not nudge).
        days_since_last = (today - dates[-1]).days
        if days_since_last < 0 or days_since_last > 180:
            continue
        # Cluster into episodes anchored at each episode's start date.
        episodes = [dates[0]]
        for d in dates[1:]:
            if (d - episodes[-1]).days >= 7:
                episodes.append(d)
        if len(episodes) < 3:
            continue
        gaps = [(episodes[i + 1] - episodes[i]).days
                for i in range(len(episodes) - 1)]
        cadence = max(1.0, statistics.median(gaps))
        if days_since_last > max(2 * cadence, 14):
            nudges.append(
                {
                    "name": name,
                    "cadence_days": round(cadence, 1),
                    "days_since_last": days_since_last,
                    "ratio": round(days_since_last / cadence, 1),
                }
            )
    nudges.sort(key=lambda n: n["ratio"], reverse=True)
    return nudges


def format_location(entry):
    """'City, ST ZIP' from a directory entry dict; '' when all blank."""
    city = (entry.get("city") or "").strip()
    state = (entry.get("state") or "").strip()
    zipc = (entry.get("zip_code") or "").strip()
    head = ", ".join(p for p in (city, state) if p)
    return f"{head} {zipc}".strip() if (head or zipc) else ""


def _load_json(value):
    try:
        result = json.loads(value)
        return result if isinstance(result, list) else []
    except Exception:
        return []


def _dir_fingerprint(path):
    """Fast fingerprint of a directory tree: ``count:total_size:max_mtime_ns``.

    Uses os.scandir (cached stat entries) so it costs ~nothing next to
    actually zipping the tree. Used by backup_now() to skip re-zipping the
    attachments dir when nothing changed since the last backup. Never
    raises — returns "" on any error (which forces a re-zip, the safe
    fallback).
    """
    try:
        count = 0
        total = 0
        max_ns = 0
        stack = [os.fspath(path)]
        while stack:
            d = stack.pop()
            try:
                with os.scandir(d) as it:
                    entries = list(it)
            except OSError:
                continue
            for e in entries:
                try:
                    if e.is_dir(follow_symlinks=False):
                        stack.append(e.path)
                    elif e.is_file(follow_symlinks=False):
                        st = e.stat(follow_symlinks=False)
                        count += 1
                        total += st.st_size
                        if st.st_mtime_ns > max_ns:
                            max_ns = st.st_mtime_ns
                except OSError:
                    continue
        return f"{count}:{total}:{max_ns}"
    except Exception:
        return ""


def _write_attachments_zip(backups_dir, stem, att_dir):
    """Zip att_dir -> backups_dir/<stem>-attachments.zip, atomically.

    Writes to a ``.tmp`` name first and renames on success, so a run that
    is killed mid-write (e.g. the app closing during a threaded backup)
    never leaves a half-written zip behind. Stale ``.tmp`` files are
    cleaned by the backup worker on its next run. Returns the zip Path.
    """
    zip_path = backups_dir / (stem + "-attachments.zip")
    tmp = zip_path.with_name(zip_path.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(att_dir.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(att_dir))
    os.replace(tmp, zip_path)
    return zip_path


def _prune_backups(backups_dir):
    """Prune to the newest BACKUP_KEEP snapshots (and their zips)."""
    snaps = sorted(backups_dir.glob("tasks-*.db"), key=lambda p: p.name)
    if len(snaps) > BACKUP_KEEP:
        for old in snaps[:-BACKUP_KEEP]:
            old.unlink(missing_ok=True)
            (backups_dir / (old.stem + "-attachments.zip")).unlink(
                missing_ok=True)


def _backup_worker_main(db_path_str, prev_fp=""):
    """Heavy backup work, run on a QThread worker — never the UI thread.

    Does the DB snapshot copy, the attachments zip build, and BACKUP_KEEP
    pruning. Opens its OWN sqlite connections: a TaskDatabase connection
    must never cross threads (sqlite3 check_same_thread). The online
    backup API is safe while the app's own connection stays open
    (SQLite restarts/retries on lock).

    Returns {"snapshot": <file name>, "fingerprint": <post-zip fp or "">}.
    The caller stores the fingerprint in settings on the main thread.
    Raises on failure — the dispatcher (run_folder_background) converts
    exceptions into an error payload, so nothing ever escapes the worker
    thread into the UI.
    """
    db_path = Path(db_path_str)
    backups = db_path.parent / "backups"
    backups.mkdir(parents=True, exist_ok=True)
    # Stale temp zips from a run killed mid-write: never resume them.
    for stale in backups.glob("*-attachments.zip.tmp"):
        try:
            stale.unlink()
        except OSError:
            pass
    # Microseconds in the stamp keep names unique and chronologically
    # sortable, so pruning "newest N" is just a name sort.
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    snap = backups / f"tasks-{stamp}.db"
    n = 1
    while snap.exists():
        n += 1
        snap = backups / f"tasks-{stamp}-{n}.db"
    src = _open_connection(db_path)
    try:
        dst = sqlite3.connect(str(snap))
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    # V1.9.37: the snapshot above is unconditional (cheap); the
    # attachments zip rebuilds ONLY when the fingerprint moved --
    # most launches change no attachments at all.
    fp = ""
    att_dir = db_path.parent / "attachments"
    if att_dir.is_dir():
        fp = _dir_fingerprint(att_dir)
        if fp != prev_fp:
            _write_attachments_zip(backups, snap.stem, att_dir)
    _prune_backups(backups)
    return {"snapshot": snap.name, "fingerprint": fp}


class TaskDatabase:
    def __init__(self, path):
        self.path = Path(path)
        log_startup_event("db path resolved")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        log_startup_event("db dir ready")
        self.conn = _open_connection(self.path, resilient=True)
        log_startup_event("db connected")
        self.conn.row_factory = sqlite3.Row
        # V1.9.9 fast path: one version lookup instead of re-running the
        # whole schema + migrations on every launch (~20 round trips on a
        # network share). First run (or a version bump) does the full pass
        # and stamps the version.
        try:
            row = self.conn.execute(
                "SELECT value FROM settings WHERE key='schema_version'"
            ).fetchone()
            current = int(row[0]) if row else 0
        except Exception:  # noqa: BLE001 - settings table may not exist yet
            current = 0
        if current >= SCHEMA_VERSION and current != 0:
            log_startup_event("db schema current (fast path)")
        else:
            self.conn.executescript(SCHEMA)
            log_startup_event("db schema ok")
            self._migrate()
            log_startup_event("db migrated")
            try:
                self.conn.execute(
                    "INSERT OR REPLACE INTO settings (key, value)"
                    " VALUES ('schema_version', ?)",
                    (str(SCHEMA_VERSION),),
                )
            except Exception:  # noqa: BLE001
                pass
        self.conn.commit()
        # One-time DATA fills are flag-guarded, not schema-guarded:
        # they must run even on the fast path above, or a fill added
        # in a later version never reaches databases whose schema
        # was already current (V1.9.37: exactly that had silently
        # kept the V1.9.34 House Account fill from ever running on
        # an up-to-date database).
        self._one_time_fills()

    def _one_time_fills(self):
        """Flag-guarded one-time data fills; safe on every open."""
        # V1.9.34 (user): "all entries in task list should revert to
        # House Account as a default, even old entries -- I will go
        # change the few that are not." Every task with NO sales rep
        # gets House Account, once. A rep somebody deliberately set
        # is data, not a default, and is never overwritten.
        try:
            if self.get_setting("sales_rep_house_default_v1", "") != "1":
                self.conn.execute(
                    "UPDATE tasks SET sales_rep='House Account' "
                    "WHERE TRIM(COALESCE(sales_rep, ''))=''")
                self.conn.commit()
                self.set_setting("sales_rep_house_default_v1", "1")
        except Exception:
            pass

    def _migrate(self):
        """Bring older databases up to the current schema."""
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(tasks)")}
        dcols = {r["name"] for r in self.conn.execute("PRAGMA table_info(directory)")}
        tables = {
            r[0]
            for r in self.conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        ncols = {r["name"] for r in
                 self.conn.execute("PRAGMA table_info(notes)")} \
            if "notes" in tables else set()
        # Any structural change coming up? Snapshot first so a failed or
        # unwanted migration can always be rolled back.
        new_task_cols = ("due_date", "estimated_hours", "quote_value",
                         "outcome", "parent_task_id", "remind_at", "waiting_on",
                         "seismic_override")
        new_dir_cols = ("phone", "email", "address", "notes", "city", "state", "zip_code")
        needs_migration = (
            any(c not in cols for c in ("scope_done", "folder_path", "rack_types")
                + new_task_cols)
            or any(c not in dcols for c in new_dir_cols)
            or "activity" not in tables
            or "pending_folders" not in tables
            or "notebooks" not in tables
            or "notes" not in tables
            or "formulas" not in ncols
            or "nudge_dismissals" not in tables
            or "revision" not in cols
            or "att_hidden" not in cols
            or "task_revisions" not in tables
        )
        if needs_migration:
            log_startup_event("db backup starting")
            self.backup_now()
            log_startup_event("db backup done")

        if "scope_done" not in cols:
            self.conn.execute("ALTER TABLE tasks ADD COLUMN scope_done TEXT NOT NULL DEFAULT '[]'")
        if "folder_path" not in cols:
            self.conn.execute("ALTER TABLE tasks ADD COLUMN folder_path TEXT NOT NULL DEFAULT ''")
        if "rack_types" not in cols:
            self.conn.execute("ALTER TABLE tasks ADD COLUMN rack_types TEXT NOT NULL DEFAULT '[]'")
        # v9: due date, time estimate, and quoted value per task.
        if "due_date" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN due_date TEXT NOT NULL DEFAULT ''"
            )
        if "estimated_hours" not in cols:
            self.conn.execute("ALTER TABLE tasks ADD COLUMN estimated_hours REAL")
        if "quote_value" not in cols:
            self.conn.execute("ALTER TABLE tasks ADD COLUMN quote_value REAL")
        # v10: won/lost outcome, re-quote lineage, follow-up reminders.
        if "outcome" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN outcome TEXT NOT NULL DEFAULT 'unknown'"
            )
        if "parent_task_id" not in cols:
            self.conn.execute("ALTER TABLE tasks ADD COLUMN parent_task_id INTEGER")
        if "remind_at" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN remind_at TEXT NOT NULL DEFAULT ''"
            )
        # v1.4.0 item 10: opt-in "waiting on" tag per task. Blank for all
        # existing tasks; existing data untouched.
        if "waiting_on" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN waiting_on TEXT NOT NULL DEFAULT ''"
            )
        # V1.9.29 (user): "Per" (the person a quote came from, typed
        # in the detail window) and "Sales Rep" (dropdown) per task,
        # for commission tracking. Blank on every existing task;
        # existing data untouched.
        if "per" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN per TEXT NOT NULL DEFAULT ''"
            )
        if "sales_rep" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN sales_rep TEXT NOT NULL DEFAULT ''"
            )
        # V1.9.30: revisions. Every task lives at a revision label
        # ("00" until the user moves it); renaming the label freezes
        # a full snapshot of the task under the old label in
        # task_revisions, and the live task carries on as the copy.
        # att_hidden holds attachment ids removed from the CURRENT
        # revision whose files/rows a frozen snapshot still needs.
        if "revision" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN revision TEXT NOT NULL DEFAULT '00'"
            )
        if "att_hidden" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN att_hidden TEXT NOT NULL DEFAULT '[]'"
            )
        if "task_revisions" not in tables:
            self.conn.execute(
                """CREATE TABLE task_revisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER NOT NULL,
                    revision TEXT NOT NULL,
                    snapshot TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(task_id, revision)
                )"""
            )
        # The V1.9.34 House Account one-time fill lives in
        # _one_time_fills() now (called from __init__ on every
        # open): inside _migrate it was unreachable on the schema
        # fast path, so it never ran on current databases.
        # Seed the user's sales-rep list (from his own screenshot) as
        # CRM directory entries the first time: the detail dropdown
        # and the CRM Sales Reps tab both read from there.
        try:
            _n = self.conn.execute(
                "SELECT COUNT(*) FROM directory WHERE kind='sales_rep'"
            ).fetchone()[0]
            if not _n:
                for _rep_name in DEFAULT_SALES_REPS:
                    self.remember_contact("sales_rep", _rep_name)
        except Exception:
            pass
        # v1.4.0 item 15a: manual SDC override per task. NULL = Auto
        # (follow the estimate); a letter A-E pins the badge. NULL for all
        # existing tasks; existing data untouched.
        if "seismic_override" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN seismic_override TEXT DEFAULT NULL"
            )
        # v11: pending folder queue for automatic quote folder creation.
        if "pending_folders" not in tables:
            self.conn.execute(
                """CREATE TABLE pending_folders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER NOT NULL,
                    folder_name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT NOT NULL DEFAULT ''
                )"""
            )
            self.conn.execute(
                """CREATE TABLE activity (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER NOT NULL,
                    at TEXT NOT NULL,
                    kind TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT ''
                )"""
            )
        # CRM contact fields added after the directory table first shipped.
        for col in ("phone", "email", "address", "notes"):
            if col not in dcols:
                self.conn.execute(
                    f"ALTER TABLE directory ADD COLUMN {col} TEXT NOT NULL DEFAULT ''"
                )
        # Split address fields added later; existing street addresses stay in
        # `address` untouched.
        for col in ("city", "state", "zip_code"):
            if col not in dcols:
                self.conn.execute(
                    f"ALTER TABLE directory ADD COLUMN {col} TEXT NOT NULL DEFAULT ''"
                )
        # Contact status added later: 'active' (default) or 'inactive'.
        # Inactive contacts render greyed with an "Inactive" status and are
        # excluded from the gone-quiet nudge feed.
        if "status" not in dcols:
            self.conn.execute(
                "ALTER TABLE directory ADD COLUMN status TEXT NOT NULL DEFAULT 'active'"
            )
        # v28: Notes module — notebooks organize free-form rich-text notes.
        # Additive tables only; existing user data is untouched.
        if "notebooks" not in tables:
            self.conn.execute(
                """CREATE TABLE notebooks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    sort_order INTEGER NOT NULL DEFAULT 0
                )"""
            )
        if "notes" not in tables:
            self.conn.execute(
                """CREATE TABLE notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    notebook_id INTEGER REFERENCES notebooks(id),
                    title TEXT NOT NULL DEFAULT '',
                    body_html TEXT NOT NULL DEFAULT '',
                    body_text TEXT NOT NULL DEFAULT '',
                    pinned INTEGER NOT NULL DEFAULT 0,
                    formulas TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )"""
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_notes_notebook ON notes(notebook_id)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_notes_updated ON notes(updated_at)"
            )
        # V1.9.13: dismissible distributor check-ins (see dismiss_nudge).
        # Additive table only; existing user data is untouched.
        if "nudge_dismissals" not in tables:
            self.conn.execute(
                """CREATE TABLE nudge_dismissals (
                    distributor TEXT PRIMARY KEY COLLATE NOCASE,
                    dismissed_at TEXT NOT NULL
                )"""
            )
        # V1.9.15: notes table formulas persist in a sidecar column —
        # the formula property on a cell's character format does NOT
        # survive the HTML round trip (setHtml/toHtml drops it), so the
        # live property is serialized on save and re-applied on load.
        # Additive column only; existing notes are untouched.
        if "notes" in tables:
            ncols = {r["name"] for r in
                     self.conn.execute("PRAGMA table_info(notes)")}
            if "formulas" not in ncols:
                self.conn.execute(
                    "ALTER TABLE notes ADD COLUMN "
                    "formulas TEXT NOT NULL DEFAULT ''")
        # Backfill the directory from names already on tasks (idempotent:
        # INSERT OR IGNORE + case-insensitive unique keeps the first spelling).
        now = datetime.now().isoformat(timespec="seconds")
        self.conn.execute(
            "INSERT OR IGNORE INTO directory (kind, name, created_at) "
            "SELECT 'distributor', distributor, ? FROM tasks "
            "WHERE TRIM(COALESCE(distributor, '')) <> '' GROUP BY distributor",
            (now,),
        )
        self.conn.execute(
            "INSERT OR IGNORE INTO directory (kind, name, created_at) "
            "SELECT 'customer', end_user, ? FROM tasks "
            "WHERE TRIM(COALESCE(end_user, '')) <> '' GROUP BY end_user",
            (now,),
        )

        # V1.6.0: clean CSS-contaminated note body_text. Older saves stored
        # QTextEdit's <style> block in body_text; html_to_text now strips it,
        # so regenerate from body_html for any note that looks contaminated.
        try:
            tables_now = {
                r[0] for r in self.conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'")
            }
            if "notes" in tables_now:
                for nid, bhtml, btext in self.conn.execute(
                        "SELECT id, body_html, body_text FROM notes"):
                    if btext and ("{" in btext or "::marker" in btext
                                  or "white-space:" in btext):
                        clean = html_to_text(bhtml or "")
                        if clean != btext:
                            self.conn.execute(
                                "UPDATE notes SET body_text=? WHERE id=?",
                                (clean, nid))
                self.conn.commit()
        except Exception:
            pass
        # V1.9.4: task notes are plain text again. The V1.9.x rich-text
        # experiment saved QTextEdit.toHtml() (with <style> blocks) into
        # tasks.notes; cards then showed raw CSS ("p, li { white-space:
        # pre-wrap; } ...") with no way to repair from the UI. Convert any
        # rich task notes back to plain text — the CSS was never user data.
        try:
            for tid, tnotes in self.conn.execute(
                    "SELECT id, notes FROM tasks WHERE notes LIKE '%<%'"):
                if tnotes and re.search(r"</?[a-zA-Z][^>]*>", tnotes):
                    clean = html_to_text(tnotes)
                    if clean != tnotes:
                        self.conn.execute(
                            "UPDATE tasks SET notes=? WHERE id=?",
                            (clean, tid))
            self.conn.commit()
        except Exception:
            pass
        # V1.9.5: hot/attention flag per task + freight/lead-time details
        # (JSON) collected when those scope steps are checked off.
        if "is_hot" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN is_hot INTEGER NOT NULL DEFAULT 0"
            )
        if "freight_info" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN freight_info TEXT NOT NULL DEFAULT ''"
            )
        if "leadtime_info" not in cols:
            self.conn.execute(
                "ALTER TABLE tasks ADD COLUMN leadtime_info TEXT NOT NULL DEFAULT ''"
            )

    # ---- settings ----
    def get_setting(self, key, default=""):
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        self.conn.commit()

    @staticmethod
    def _clean_option_names(values):
        """Normalize an option-list setting's entries: trim
        whitespace, drop empties, de-duplicate case-insensitively
        (first spelling wins). V1.9.30: a trailing period is never
        part of an option name -- "Quote." in a stored list showed
        up verbatim in the scope dropdown -- so entries are also
        stripped of trailing periods BEFORE de-duplication, which
        collapses "Quote." into "Quote"."""
        seen, out = set(), []
        for s in values or []:
            if not isinstance(s, str):
                continue
            n = s.strip().rstrip(".").strip()
            if n and n.lower() not in seen:
                seen.add(n.lower())
                out.append(n)
        return out

    def _get_list_setting(self, key, defaults):
        """Read a JSON list setting, de-duplicated, falling back to defaults."""
        raw = self.get_setting(key, "")
        if raw:
            try:
                out = self._clean_option_names(json.loads(raw))
                if out:
                    return out
            except Exception:
                pass
        return list(defaults)

    def _set_list_setting(self, key, values):
        out = self._clean_option_names(values)
        self.set_setting(key, json.dumps(out))
        return out

    def get_scopes(self):
        """The user's customized scope list (defaults if never customized)."""
        return self._get_list_setting("scopes", DEFAULT_SCOPES)

    def set_scopes(self, scopes):
        return self._set_list_setting("scopes", scopes)

    def get_rack_types(self):
        """The user's customized rack-type list (defaults if never customized)."""
        return self._get_list_setting("rack_types", DEFAULT_RACK_TYPES)

    def set_rack_types(self, rack_types):
        return self._set_list_setting("rack_types", rack_types)

    def rename_task_option(self, field, old, new):
        """V1.9.51 (user: a rename must update everywhere the old
        name appears, instantly -- "that can not happen here or
        any other area"): renaming a Scope of Work or Rack Type
        option in Settings rewrites that exact element in every
        task's stored lists (scope + scope_done for scopes,
        rack_types for rack types), case-insensitively, keeping
        the new name's casing. Frozen revision snapshots are
        history and are NOT touched. Returns how many tasks
        changed."""
        old = (old or "").strip()
        new = (new or "").strip()
        if not old or not new or old == new:
            return 0
        if field == "scope":
            columns = ("scope", "scope_done")
        elif field == "rack_types":
            columns = ("rack_types",)
        else:
            raise ValueError(f"unknown option field: {field!r}")
        changed = 0
        rows = self.conn.execute(
            "SELECT id, " + ", ".join(columns) + " FROM tasks").fetchall()
        for row in rows:
            updates = {}
            for col in columns:
                try:
                    items = json.loads(row[col] or "[]")
                except (TypeError, ValueError):
                    continue
                if not isinstance(items, list):
                    continue
                swapped = [new if isinstance(it, str)
                            and it.strip().lower() == old.lower() else it
                           for it in items]
                if swapped != items:
                    updates[col] = json.dumps(swapped)
            if updates:
                assignments = ", ".join(f"{c} = ?" for c in updates)
                self.conn.execute(
                    f"UPDATE tasks SET {assignments} WHERE id = ?",
                    (*updates.values(), row["id"]))
                changed += 1
        if changed:
            self.conn.commit()
        return changed

    def get_sales_reps(self):
        """Sales reps = the CRM's Sales Rep directory entries.

        V1.9.29: reps live in the directory (kind "sales_rep") like
        every other people list -- one source for the detail-window
        dropdown, the Settings editor, and the CRM tab. The seeded
        defaults answer until the directory has entries.
        """
        names = self.directory_names("sales_rep")
        return names if names else list(DEFAULT_SALES_REPS)

    def set_sales_reps(self, sales_reps):
        """Sync the Sales Rep directory to the given list.

        Adds missing names as entries and removes entries dropped
        from the list (tasks keep their stored rep text either way,
        same rule as scopes). Used by the Settings option-list editor;
        single new reps arrive via remember_contact on task save.
        """
        wanted = [str(r).strip() for r in (sales_reps or []) if str(r).strip()]
        current = {e["name"]: e["id"]
                   for e in self.directory_list("sales_rep")}
        for name, eid in current.items():
            if name.lower() not in [w.lower() for w in wanted]:
                self.directory_delete(eid)
        for name in wanted:
            if name.lower() not in [c.lower() for c in current]:
                self.remember_contact("sales_rep", name)
        return wanted

    # ---- directory (distributors / end users) ----
    def remember_contact(self, kind, name):
        """Save a distributor/end-user name for autocomplete. Idempotent."""
        name = (name or "").strip()
        if not name or kind not in DIRECTORY_KINDS:
            return None
        now = datetime.now().isoformat(timespec="seconds")
        self.conn.execute(
            "INSERT OR IGNORE INTO directory (kind, name, created_at) VALUES (?, ?, ?)",
            (kind, name, now),
        )
        self.conn.commit()
        row = self.conn.execute(
            "SELECT id FROM directory WHERE kind=? AND name=?", (kind, name)
        ).fetchone()
        if row and kind == "sales_rep":
            # V1.9.34 (user): sales reps default to Speedrack's own
            # location — Walker, MI — whenever no location of their
            # own is on file. A rep with a real location keeps it.
            self.conn.execute(
                "UPDATE directory SET city='Walker', state='MI' "
                "WHERE id=? AND TRIM(city)='' AND TRIM(state)=''",
                (row["id"],))
            self.conn.commit()
        return row["id"] if row else None

    def directory_names(self, kind):
        """Alphabetical names for autocomplete."""
        rows = self.conn.execute(
            "SELECT name FROM directory WHERE kind=? ORDER BY name COLLATE NOCASE",
            (kind,),
        ).fetchall()
        # Blank names are never real entries; one reaching a combo
        # renders as an invisible empty row (dead space in the list).
        return [r["name"] for r in rows
                if r["name"] and r["name"].strip()]

    def directory_name_taken(self, kind, name):
        """True when a contact of this kind already has this name."""
        return (
            self.conn.execute(
                "SELECT 1 FROM directory WHERE kind=? AND name=?",
                (kind, (name or "").strip()),
            ).fetchone()
            is not None
        )

    def directory_list(self, kind):
        """Entries with the number of tasks referencing each name."""
        col = DIRECTORY_TASK_COLUMN[kind]
        rows = self.conn.execute(
            f"""SELECT d.id, d.name, d.phone, d.email, d.address, d.city,
                d.state, d.zip_code, d.notes, d.status,
                (SELECT COUNT(*) FROM tasks t WHERE LOWER(t.{col}) = LOWER(d.name)) AS task_count,
                (SELECT COALESCE(SUM(t2.quote_value), 0) FROM tasks t2 WHERE LOWER(t2.{col}) = LOWER(d.name)) AS total_value,
                (SELECT COALESCE(SUM(t3.quote_value), 0) FROM tasks t3 WHERE LOWER(t3.{col}) = LOWER(d.name) AND t3.outcome = 'won') AS won_value
                FROM directory d WHERE d.kind=? ORDER BY d.name COLLATE NOCASE""",
            (kind,),
        ).fetchall()
        return [dict(r) for r in rows]

    def directory_get(self, entry_id):
        """Full contact record for the CRM detail view."""
        row = self.conn.execute(
            "SELECT * FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        return dict(row) if row else None

    def directory_get_by_name(self, kind, name):
        """Full contact record matched by exact name (case-insensitive).

        Used by the seismic SDC lookup to resolve a task's end-user text
        to the linked CRM contact's city/state. Returns None when no
        contact matches.
        """
        if not name or not name.strip():
            return None
        row = self.conn.execute(
            "SELECT * FROM directory WHERE kind=? AND LOWER(name)=LOWER(?)",
            (kind, name.strip()),
        ).fetchone()
        return dict(row) if row else None

    def directory_customers_by_name(self):
        """All customer contacts keyed by lowercase name — ONE query.

        V1.9.19 (launch): every task card resolved its end user via
        directory_get_by_name, one query per card (73 queries at
        startup, each a share round-trip on a network database).
        Callers building many cards load this map once per refresh
        and resolve in memory; it is rebuilt every refresh, so CRM
        edits show on the next refresh, never stale.
        """
        rows = self.conn.execute(
            "SELECT * FROM directory WHERE kind='customer'"
        ).fetchall()
        return {(r["name"] or "").strip().lower(): dict(r) for r in rows}

    def directory_tasks(self, entry_id):
        """Tasks that reference this contact (for the CRM detail view)."""
        row = self.conn.execute(
            "SELECT kind, name FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        if not row:
            return []
        col = DIRECTORY_TASK_COLUMN[row["kind"]]
        rows = self.conn.execute(
            f"""SELECT id, quote_number, status FROM tasks
                WHERE LOWER({col}) = LOWER(?) ORDER BY quote_number""",
            (row["name"],),
        ).fetchall()
        return [dict(r) for r in rows]

    def directory_contacts(self, entry_id):
        """Contact names that belong to a company entry (V1.9.32, user).

        A contact belongs to the company it is named under: the distinct
        Contact Name (tasks.per) values on tasks filed under this
        distributor / end user, each with its task count. Returns [] for
        non-company kinds and missing entries.
        """
        row = self.conn.execute(
            "SELECT kind, name FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        if not row or row["kind"] not in ("distributor", "customer"):
            return []
        col = DIRECTORY_TASK_COLUMN[row["kind"]]
        rows = self.conn.execute(
            f"""SELECT per AS name, COUNT(*) AS task_count FROM tasks
                WHERE LOWER({col}) = LOWER(?)
                  AND TRIM(COALESCE(per, '')) <> ''
                GROUP BY LOWER(per) ORDER BY per COLLATE NOCASE""",
            (row["name"],),
        ).fetchall()
        return [dict(r) for r in rows]

    def directory_companies(self, entry_id):
        """Companies a contact belongs to (V1.9.32, user): the distinct
        distributor / end-user names on tasks carrying this contact's
        name. Distributors first, each tagged with its directory kind."""
        row = self.conn.execute(
            "SELECT kind, name FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        if not row or row["kind"] != "contact":
            return []
        out = []
        seen = set()
        for col, kind in (("distributor", "distributor"),
                          ("end_user", "customer")):
            rows = self.conn.execute(
                f"""SELECT {col} AS name FROM tasks
                    WHERE LOWER(per) = LOWER(?)
                      AND TRIM(COALESCE({col}, '')) <> ''
                    GROUP BY LOWER({col}) ORDER BY {col} COLLATE NOCASE""",
                (row["name"],),
            ).fetchall()
            for r in rows:
                key = r["name"].strip().lower()
                if key not in seen:
                    seen.add(key)
                    out.append({"name": r["name"], "kind": kind})
        return out

    def directory_update(self, entry_id, name=None, phone=None,
                         email=None, address=None, city=None, state=None,
                         zip_code=None, notes=None, status=None):
        """Update contact fields. A name change propagates to tasks like rename.

        Returns False when the entry is missing, the name is blank, or the
        new name collides with another entry of the same kind.
        """
        row = self.conn.execute(
            "SELECT kind, name FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        if not row:
            return False
        kind, old_name = row["kind"], row["name"]
        if name is not None:
            name = name.strip()
            if not name:
                return False
            if name != old_name:
                clash = self.conn.execute(
                    "SELECT id FROM directory WHERE kind=? AND name=? AND id<>?",
                    (kind, name, entry_id),
                ).fetchone()
                if clash:
                    return False
                self.conn.execute(
                    "UPDATE directory SET name=? WHERE id=?", (name, entry_id)
                )
                col = DIRECTORY_TASK_COLUMN[kind]
                self.conn.execute(
                    f"UPDATE tasks SET {col}=? WHERE LOWER({col})=LOWER(?)",
                    (name, old_name),
                )
        fields = {}
        if phone is not None:
            fields["phone"] = phone.strip()
        if email is not None:
            fields["email"] = email.strip()
        if address is not None:
            fields["address"] = address.strip()
        if city is not None:
            fields["city"] = city.strip()
        if state is not None:
            fields["state"] = state.strip()
        if zip_code is not None:
            fields["zip_code"] = zip_code.strip()
        if notes is not None:
            fields["notes"] = notes.strip()
        if status is not None:
            status = status.strip().lower()
            if status in ("active", "inactive"):
                fields["status"] = status
        for key, value in fields.items():
            self.conn.execute(
                f"UPDATE directory SET {key}=? WHERE id=?", (value, entry_id)
            )
        self.conn.commit()
        return True

    def directory_rename(self, entry_id, new_name):
        """Rename an entry and update every task using the old spelling."""
        new_name = (new_name or "").strip()
        if not new_name:
            return False
        row = self.conn.execute(
            "SELECT kind, name FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        if not row:
            return False
        kind, old_name = row["kind"], row["name"]
        clash = self.conn.execute(
            "SELECT id FROM directory WHERE kind=? AND name=? AND id<>?",
            (kind, new_name, entry_id),
        ).fetchone()
        if clash:
            return False
        self.conn.execute("UPDATE directory SET name=? WHERE id=?", (new_name, entry_id))
        col = DIRECTORY_TASK_COLUMN[kind]
        self.conn.execute(
            f"UPDATE tasks SET {col}=? WHERE LOWER({col})=LOWER(?)",
            (new_name, old_name),
        )
        self.conn.commit()
        return True

    def directory_delete(self, entry_id):
        """Remove an entry from the directory. Tasks keep their stored text."""
        self.conn.execute("DELETE FROM directory WHERE id=?", (entry_id,))
        self.conn.commit()

    def directory_merge(self, kind, loser_id, survivor_id):
        """Merge one directory entry into another: re-point every task that
        references the loser's name (case-insensitive) to the survivor's name,
        then delete the loser row. Returns True on success."""
        if kind not in DIRECTORY_KINDS or loser_id == survivor_id:
            return False
        loser = self.conn.execute(
            "SELECT name FROM directory WHERE id=? AND kind=?", (loser_id, kind)
        ).fetchone()
        survivor = self.conn.execute(
            "SELECT name FROM directory WHERE id=? AND kind=?", (survivor_id, kind)
        ).fetchone()
        if not loser or not survivor:
            return False
        col = DIRECTORY_TASK_COLUMN[kind]
        self.conn.execute(
            f"UPDATE tasks SET {col}=? WHERE LOWER({col})=LOWER(?)",
            (survivor["name"], loser["name"]),
        )
        self.conn.execute("DELETE FROM directory WHERE id=?", (loser_id,))
        self.conn.commit()
        return True

    def directory_last_quoted(self, kind, entry_id):
        """Newest created_at (ISO) of tasks referencing this contact, or ''."""
        row = self.conn.execute(
            "SELECT kind, name FROM directory WHERE id=?", (entry_id,)
        ).fetchone()
        if not row or row["kind"] != kind:
            return ""
        col = DIRECTORY_TASK_COLUMN[row["kind"]]
        r = self.conn.execute(
            f"SELECT MAX(created_at) AS m FROM tasks WHERE LOWER({col})=LOWER(?)",
            (row["name"],),
        ).fetchone()
        return r["m"] or ""

    # ---- queue (kanban) ----
    def queue_add(self, task_id, column_key="now"):
        """Append a task to a queue column (no-op if already queued)."""
        if column_key not in QUEUE_COLUMN_KEYS:
            column_key = "now"
        pos = self.conn.execute(
            "SELECT COALESCE(MAX(position), -1) + 1 FROM queue WHERE column_key=?",
            (column_key,),
        ).fetchone()[0]
        self.conn.execute(
            "INSERT OR IGNORE INTO queue (task_id, column_key, position) VALUES (?, ?, ?)",
            (task_id, column_key, pos),
        )
        self.conn.commit()

    def queue_remove(self, task_id):
        self.conn.execute("DELETE FROM queue WHERE task_id=?", (task_id,))
        self.conn.commit()

    def queue_set(self, columns):
        """Rewrite the whole board: {column_key: [task_id, ...]} in order."""
        self.conn.execute("DELETE FROM queue")
        for key, ids in columns.items():
            if key not in QUEUE_COLUMN_KEYS:
                continue
            for pos, task_id in enumerate(ids):
                self.conn.execute(
                    "INSERT OR IGNORE INTO queue (task_id, column_key, position) "
                    "VALUES (?, ?, ?)",
                    (task_id, key, pos),
                )
        self.conn.commit()

    def queue_task_ids(self):
        """{column_key: [task_id, ...]} in board order."""
        out = {k: [] for k in QUEUE_COLUMN_KEYS}
        rows = self.conn.execute(
            "SELECT task_id, column_key FROM queue ORDER BY column_key, position"
        ).fetchall()
        for r in rows:
            if r["column_key"] in out:
                out[r["column_key"]].append(r["task_id"])
        return out

    def queue_prune(self):
        """Drop queued tasks that are deleted, completed or canceled."""
        self.conn.execute(
            "DELETE FROM queue WHERE task_id NOT IN "
            "(SELECT id FROM tasks WHERE status IN ('in_process', 'on_hold'))"
        )
        self.conn.commit()

    # ---- queue board settings (columns + per-column WIP limits) ----
    def get_queue_columns(self):
        """[[key, label], ...] for the queue board columns."""
        default = [list(c) for c in QUEUE_COLUMNS]
        raw = self.get_setting("queue_columns", "")
        if raw:
            try:
                cols = json.loads(raw)
                cleaned = [
                    [str(c[0]), str(c[1])]
                    for c in cols
                    if isinstance(c, (list, tuple)) and len(c) == 2
                ]
                if cleaned:
                    return cleaned
            except Exception:
                pass
        return default

    def set_queue_columns(self, cols):
        cleaned = [
            [str(c[0]), str(c[1])]
            for c in (cols or [])
            if isinstance(c, (list, tuple)) and len(c) == 2
        ]
        self.set_setting("queue_columns", json.dumps(cleaned))
        return cleaned

    def get_queue_wip(self):
        """{column_key: int} WIP limits for queue columns (default {})."""
        raw = self.get_setting("queue_wip", "")
        if raw:
            try:
                mapping = json.loads(raw)
                if isinstance(mapping, dict):
                    return {str(k): int(v) for k, v in mapping.items()}
            except Exception:
                pass
        return {}

    def set_queue_wip(self, mapping):
        cleaned = {str(k): int(v) for k, v in (mapping or {}).items()}
        self.set_setting("queue_wip", json.dumps(cleaned))
        return cleaned

    # ---- tasks ----
    def add_task(self, quote_number, distributor, end_user, notes, scope, scope_done=None,
                 folder_path="", rack_types=None, *, due_date=None, estimated_hours=None,
                 quote_value=None, seismic_override=None, per="", sales_rep="",
                 revision="00", waiting_on=""):
        now = datetime.now().isoformat(timespec="seconds")
        # v1.4.0 item 15a: NULL = Auto; a letter A-E pins the badge.
        ov = (seismic_override or "").strip().upper() or None
        if ov is not None and ov not in ("A", "B", "C", "D", "E"):
            raise ValueError(f"invalid seismic_override: {seismic_override!r}")
        cur = self.conn.execute(
            """INSERT INTO tasks
               (quote_number, distributor, end_user, notes, scope, scope_done, status,
                created_at, folder_path, rack_types, due_date, estimated_hours, quote_value,
                seismic_override, per, sales_rep, revision, waiting_on)
               VALUES (?, ?, ?, ?, ?, ?, 'in_process', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (quote_number, distributor, end_user, notes,
             json.dumps(scope), json.dumps(scope_done or []), now,
             folder_path or "", json.dumps(rack_types or []),
             due_date or "", estimated_hours, quote_value, ov,
             per or "", sales_rep or "", (revision or "00"),
             waiting_on or ""),
        )
        self.conn.commit()
        task_id = cur.lastrowid
        self.remember_contact("distributor", distributor)
        self.remember_contact("customer", end_user)
        # V1.9.29 (user): Contact Name and Sales Rep self-populate
        # exactly like the distributor list -- type a name once and
        # it is saved for next time (completer for Contact Name; the
        # Sales Rep dropdown gains the new entry).
        if per is not _UNSET and per:
            self.remember_contact("contact", per)
        if sales_rep is not _UNSET and sales_rep:
            _reps = self.get_sales_reps()
            if sales_rep.lower() not in [r.lower() for r in _reps]:
                self.set_sales_reps(_reps + [sales_rep])
        return task_id

    def update_task(self, task_id, quote_number, distributor, end_user, notes, scope,
                    scope_done, folder_path=None, rack_types=None, *, due_date=_UNSET,
                    estimated_hours=_UNSET, quote_value=_UNSET,
                    waiting_on=_UNSET, seismic_override=_UNSET,
                    per=_UNSET, sales_rep=_UNSET, revision=_UNSET):
        # drop done-flags for scope items that were removed
        scope_done = [s for s in scope_done if s in scope]
        sets = ["quote_number=?", "distributor=?", "end_user=?",
                "notes=?", "scope=?", "scope_done=?"]
        params = [quote_number, distributor, end_user, notes,
                  json.dumps(scope), json.dumps(scope_done)]
        if folder_path is not None:
            sets.append("folder_path=?")
            params.append(folder_path or "")
        if rack_types is not None:
            sets.append("rack_types=?")
            params.append(json.dumps(rack_types))
        # v9 fields: only touched when the caller passes them explicitly.
        if due_date is not _UNSET:
            sets.append("due_date=?")
            params.append(due_date or "")
        if estimated_hours is not _UNSET:
            sets.append("estimated_hours=?")
            params.append(estimated_hours)
        if quote_value is not _UNSET:
            sets.append("quote_value=?")
            params.append(quote_value)
        # v1.4.0 item 10: only touched when the caller passes it explicitly.
        if waiting_on is not _UNSET:
            sets.append("waiting_on=?")
            params.append(waiting_on or "")
        # V1.9.29: Per / Sales Rep, same explicit-pass rule.
        if per is not _UNSET:
            sets.append("per=?")
            params.append(per or "")
        if sales_rep is not _UNSET:
            sets.append("sales_rep=?")
            params.append(sales_rep or "")
        # V1.9.30: the revision label (freeze happens in freeze_revision
        # BEFORE this update lands -- see the detail window's save).
        if revision is not _UNSET:
            sets.append("revision=?")
            params.append((revision or "00"))
        # v1.4.0 item 15a: manual SDC override; None clears back to Auto.
        if seismic_override is not _UNSET:
            ov = (seismic_override or "").strip().upper() or None
            if ov is not None and ov not in ("A", "B", "C", "D", "E"):
                raise ValueError(f"invalid seismic_override: {seismic_override!r}")
            sets.append("seismic_override=?")
            params.append(ov)
        params.append(task_id)
        self.conn.execute(
            f"UPDATE tasks SET {', '.join(sets)} WHERE id=?", params
        )
        self.conn.commit()
        self.remember_contact("distributor", distributor)
        self.remember_contact("customer", end_user)
        # V1.9.29: same self-population as add_task (see there).
        if per is not _UNSET and per:
            self.remember_contact("contact", per)
        if sales_rep is not _UNSET and sales_rep:
            _reps = self.get_sales_reps()
            if sales_rep.lower() not in [r.lower() for r in _reps]:
                self.set_sales_reps(_reps + [sales_rep])

    def set_quote_value(self, task_id, value):
        """Set (or clear with None) the quoted dollar value of a task."""
        self.conn.execute(
            "UPDATE tasks SET quote_value=? WHERE id=?", (value, task_id)
        )
        self.conn.commit()

    def delete_task(self, task_id):
        self.conn.execute("DELETE FROM attachments WHERE task_id=?", (task_id,))
        self.conn.execute("DELETE FROM queue WHERE task_id=?", (task_id,))
        self.conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        self.conn.commit()

    def set_status(self, task_id, status):
        completed_at = (
            datetime.now().isoformat(timespec="seconds") if status == "completed" else None
        )
        # V1.9.16 (user spec): a completed card must not stay
        # highlighted — completing clears the hot/attention flag in the
        # same write, so no path (card pill, detail window, bulk set,
        # queue) can leave a completed task hot.
        if status == "completed":
            self.conn.execute(
                "UPDATE tasks SET status=?, completed_at=?, is_hot=0 WHERE id=?",
                (status, completed_at, task_id),
            )
        else:
            self.conn.execute(
                "UPDATE tasks SET status=?, completed_at=? WHERE id=?",
                (status, completed_at, task_id),
            )
        self.conn.commit()

    def append_note(self, task_id, line):
        """Append a line to the task's notes (used for cancellation reasons).

        Lines that start with a "*Tag:" marker get today's date inserted,
        e.g. "*Cancelled:* reason" -> "*Cancelled 2026-09-23:* reason".
        """
        line = self._stamp_note_line(line)
        task = self.get_task(task_id)
        notes = (task["notes"] or "").rstrip() if task else ""
        notes = f"{notes}\n{line}" if notes else line
        self.conn.execute("UPDATE tasks SET notes=? WHERE id=?", (notes, task_id))
        self.conn.commit()

    @staticmethod
    def _stamp_note_line(line):
        """Insert today's date into "*Tag:"-style note markers.

        Lines already carrying a YYYY-MM-DD date are left alone so a note is
        never double-stamped.
        """
        if not isinstance(line, str):
            return line
        if re.search(r"\d{4}-\d{2}-\d{2}", line):
            return line
        today = date.today().isoformat()
        return re.sub(r"^(\*[^*:]+):", r"\g<1> " + today + ":", line, count=1)

    # ---- activity log ----
    def log_activity(self, task_id, kind, detail=""):
        """Record an event on a task. Returns the new activity id."""
        if kind not in ACTIVITY_KINDS:
            raise ValueError(f"unknown activity kind: {kind!r}")
        now = datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute(
            "INSERT INTO activity (task_id, at, kind, detail) VALUES (?, ?, ?, ?)",
            (task_id, now, kind, detail or ""),
        )
        self.conn.commit()
        return cur.lastrowid

    def list_activity(self, task_id):
        """Activity entries for a task, oldest first."""
        rows = self.conn.execute(
            "SELECT id, task_id, at, kind, detail FROM activity "
            "WHERE task_id=? ORDER BY at ASC, id ASC",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ---- pending folder queue (automatic quote folder creation) ----
    def add_pending_folder(self, task_id, folder_name):
        """Queue a folder creation attempt. Returns the new row id."""
        now = datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute(
            "INSERT INTO pending_folders (task_id, folder_name, created_at) "
            "VALUES (?, ?, ?)",
            (task_id, folder_name, now),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_pending_folders(self):
        """All queued folders, oldest first."""
        rows = self.conn.execute(
            "SELECT id, task_id, folder_name, created_at, attempts, last_error "
            "FROM pending_folders ORDER BY created_at ASC, id ASC"
        ).fetchall()
        return [dict(r) for r in rows]

    def remove_pending_folder(self, row_id):
        """Drop a queued folder (created successfully, or abandoned)."""
        self.conn.execute("DELETE FROM pending_folders WHERE id=?", (row_id,))
        self.conn.commit()

    def bump_pending_folder(self, row_id, error):
        """Record a failed attempt: attempts+1, last_error=error."""
        self.conn.execute(
            "UPDATE pending_folders SET attempts=attempts+1, last_error=? "
            "WHERE id=?",
            (error or "", row_id),
        )
        self.conn.commit()

    def duplicate_task(self, task_id):
        """Create a re-quote of a task: copies everything except the quote
        number (left blank for the user to fill in), scope check-offs, status,
        and quoted value. Returns the new task id.

        V1.9.51 (user): the duplicate gets NO folder link and no
        folder is created for it -- it used to inherit the source
        task's folder_path, tying the copy to the original's
        quote folder."""
        src = self.get_task(task_id)
        if not src:
            raise ValueError(f"no such task: {task_id}")
        new_id = self.add_task(
            "",
            src["distributor"],
            src["end_user"],
            src["notes"],
            src["scope"],
            scope_done=[],
            folder_path="",
            rack_types=src.get("rack_types") or [],
            due_date=src.get("due_date") or "",
            estimated_hours=src.get("estimated_hours"),
        )
        # add_task leaves quote_value NULL; keep it that way explicitly.
        self.conn.execute("UPDATE tasks SET quote_value=NULL WHERE id=?", (new_id,))
        # Link the re-quote to its parent by id (NOT by quote number: a
        # re-quote usually keeps the number but sometimes gets a new one).
        self.conn.execute(
            "UPDATE tasks SET parent_task_id=? WHERE id=?", (task_id, new_id)
        )
        self.conn.commit()
        self.log_activity(new_id, "duplicate", f"Duplicated from task {task_id}")
        self.log_activity(task_id, "duplicate", f"Duplicated to task {new_id}")
        return new_id

    # ---- won/lost outcome (optional, tri-state) ----
    # V1.9.29 (user): Dead and On Hold join Won/Lost as outcome
    # states (added under Won/Lost in every outcome list). Win rate /
    # won value math is UNCHANGED: "marked" still means won+lost
    # only, so the new states never distort the existing stats.
    OUTCOMES = ("unknown", "won", "lost", "dead", "on_hold")

    def set_outcome(self, task_id, outcome):
        """Set the won/lost outcome. 'unknown' is the default; never a popup."""
        if outcome not in self.OUTCOMES:
            raise ValueError(f"outcome must be one of {self.OUTCOMES}")
        self.conn.execute("UPDATE tasks SET outcome=? WHERE id=?", (outcome, task_id))
        self.conn.commit()
        if outcome != "unknown":
            self.log_activity(task_id, "edit", f"Outcome marked: {outcome}")

    # ---- follow-up reminders ----
    def set_remind_at(self, task_id, iso_date_or_none):
        """Set/clear the follow-up reminder date (ISO YYYY-MM-DD, ''/None clears)."""
        self.conn.execute(
            "UPDATE tasks SET remind_at=? WHERE id=?",
            (iso_date_or_none or "", task_id),
        )
        self.conn.commit()

    def follow_ups_due(self):
        """Tasks with remind_at <= today that are still open, oldest reminder first."""
        today = datetime.now().date().isoformat()
        rows = self.conn.execute(
            "SELECT * FROM tasks WHERE remind_at <> '' AND remind_at <= ?"
            " AND status IN ('in_process', 'on_hold')"
            " ORDER BY remind_at ASC, id ASC",
            (today,),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    # ---- re-quote version chains ----
    def get_version_chain(self, task_id):
        """Full lineage for a task: walk parent_task_id up to the root, then
        collect every descendant. Returns task dicts oldest-first (root first).
        Chains work through re-quotes of re-quotes."""
        seen, root_id, cur = set(), task_id, task_id
        while cur and cur not in seen:
            seen.add(cur)
            row = self.conn.execute(
                "SELECT parent_task_id FROM tasks WHERE id=?", (cur,)
            ).fetchone()
            cur = row["parent_task_id"] if row and row["parent_task_id"] else None
            if cur:
                root_id = cur
        rows = self.conn.execute(
            """WITH RECURSIVE family(id) AS (
                   SELECT ? AS id
                   UNION ALL
                   SELECT t.id FROM tasks t JOIN family f ON t.parent_task_id = f.id
               )
               SELECT * FROM tasks WHERE id IN (SELECT id FROM family)
               ORDER BY created_at ASC, id ASC""",
            (root_id,),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    # ---- distributor scope presets ----
    def distributor_scope_pattern(self, distributor, limit=20):
        """The distributor's most common EXACT scope set over their last `limit`
        quotes. Returns the scope list when it appears in >=60% of >=3 quotes,
        else None. Pure suggestion data — the UI must never auto-apply it."""
        name = (distributor or "").strip()
        if not name:
            return None
        rows = self.conn.execute(
            "SELECT scope FROM tasks WHERE distributor = ?"
            " ORDER BY created_at DESC, id DESC LIMIT ?",
            (name, limit),
        ).fetchall()
        scopes = [tuple(sorted(_load_json(r["scope"]))) for r in rows]
        scopes = [s for s in scopes if s]
        if len(scopes) < 3:
            return None
        top, count = Counter(scopes).most_common(1)[0]
        if count / len(scopes) >= 0.6:
            return list(top)
        return None

    def task_id_for_quote(self, quote_number, ignore_id=None):
        """Id of another task with this quote number (case-insensitive).

        Returns None when no other task uses the number — used to prompt on
        duplicates instead of silently creating/renaming into a collision.
        """
        q = (quote_number or "").strip().lower()
        if not q:
            return None
        rows = self.conn.execute(
            "SELECT id FROM tasks WHERE LOWER(quote_number)=?", (q,)
        ).fetchall()
        for r in rows:
            if ignore_id is None or r["id"] != ignore_id:
                return r["id"]
        return None

    def set_scope_done(self, task_id, scope_done):
        task = self.get_task(task_id)
        scope_done = [s for s in scope_done if s in task["scope"]]
        self.conn.execute(
            "UPDATE tasks SET scope_done=? WHERE id=?", (json.dumps(scope_done), task_id)
        )
        self.conn.commit()
        return scope_done

    def set_hot(self, task_id, hot):
        """V1.9.5: hot/attention flag — red card border + red ! icon."""
        self.conn.execute(
            "UPDATE tasks SET is_hot=? WHERE id=?", (1 if hot else 0, task_id)
        )
        self.conn.commit()

    def set_freight_info(self, task_id, info_json):
        """V1.9.5: JSON {cost_per_truck, num_trucks} for the Freight scope step."""
        self.conn.execute(
            "UPDATE tasks SET freight_info=? WHERE id=?", (info_json or "", task_id)
        )
        self.conn.commit()

    def set_leadtime_info(self, task_id, info_json):
        """V1.9.5: JSON {weeks, ship_weeks} for the Lead-Time scope step."""
        self.conn.execute(
            "UPDATE tasks SET leadtime_info=? WHERE id=?", (info_json or "", task_id)
        )
        self.conn.commit()

    def _row_to_task(self, row):
        """Convert a tasks row to the same dict shape get_task() returns."""
        task = dict(row)
        task["scope"] = _load_json(task["scope"])
        task["scope_done"] = _load_json(task.get("scope_done") or "[]")
        task["scope_done"] = [s for s in task["scope_done"] if s in task["scope"]]
        task["folder_path"] = task.get("folder_path") or ""
        task["rack_types"] = _load_json(task.get("rack_types") or "[]")
        task["due_date"] = task.get("due_date") or ""
        task["estimated_hours"] = task.get("estimated_hours")
        task["quote_value"] = task.get("quote_value")
        task["remind_at"] = task.get("remind_at") or ""
        task["outcome"] = task.get("outcome") or "unknown"
        task["waiting_on"] = task.get("waiting_on") or ""
        task["per"] = task.get("per") or ""
        task["sales_rep"] = task.get("sales_rep") or ""
        task["revision"] = task.get("revision") or "00"
        task["att_hidden"] = _load_json(task.get("att_hidden") or "[]")
        # v1.4.0 item 15a: NULL/blank = Auto (follow the estimate).
        task["seismic_override"] = task.get("seismic_override") or None
        return task

    def get_task(self, task_id):
        row = self.conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        if not row:
            return None
        return self._row_to_task(row)

    def list_tasks(self, view="all", search="", sort="newest",
                   scope_filter=None, has_attachments=False, outcome=None):
        where, params = [], []
        if view in STATUSES:
            where.append("status = ?")
            params.append(view)
        elif view == "overdue":
            where.append(
                "status IN ('in_process', 'on_hold') "
                "AND due_date IS NOT NULL AND due_date <> '' AND due_date < ?"
            )
            params.append(date.today().isoformat())
        elif view == "needs_attention":
            stale_days = int(self.get_setting("stale_days", "14") or 14)
            cutoff = (datetime.now() - timedelta(days=stale_days)).isoformat(
                timespec="seconds"
            )
            # V1.9.16 (user spec): a hot (!-marked) open task needs
            # attention by definition — the old rule only caught stale
            # tasks, so ! cards never appeared in this filter at all.
            # V1.9.30 (user): the separate Overdue chip is gone —
            # overdue tasks are part of Needs Attention now.
            where.append(
                "status IN ('in_process', 'on_hold') "
                "AND (created_at < ? OR is_hot = 1 "
                "OR (due_date IS NOT NULL AND due_date <> '' "
                "AND due_date < ?))")
            params.append(cutoff)
            params.append(date.today().isoformat())
        # V1.9.29: outcome filter (Won / Lost / Unknown toolbar
        # dropdown). None or "all" = no filtering; "unknown" matches
        # the unmarked default every task starts with.
        if outcome in self.OUTCOMES:
            where.append("outcome = ?")
            params.append(outcome)
        if search:
            like = f"%{search}%"
            where.append(
                "(quote_number LIKE ? OR distributor LIKE ? OR end_user LIKE ?"
                " OR notes LIKE ? OR rack_types LIKE ? OR scope LIKE ?)"
            )
            params.extend([like] * 6)
        if scope_filter:
            where.append("scope LIKE ?")
            params.append('%"' + scope_filter + '"%')
        if has_attachments:
            where.append("EXISTS (SELECT 1 FROM attachments WHERE task_id=tasks.id)")
        sql = "SELECT * FROM tasks"
        if where:
            sql += " WHERE " + " AND ".join(where)
        order_by = SORT_MODES.get(sort, SORT_MODES["newest"])[1]
        sql += f" ORDER BY {order_by}"
        rows = self.conn.execute(sql, params).fetchall()
        tasks = []
        for r in rows:
            t = dict(r)
            t["scope"] = _load_json(t["scope"])
            t["scope_done"] = [s for s in _load_json(t.get("scope_done") or "[]") if s in t["scope"]]
            t["folder_path"] = t.get("folder_path") or ""
            t["rack_types"] = _load_json(t.get("rack_types") or "[]")
            t["due_date"] = t.get("due_date") or ""
            t["estimated_hours"] = t.get("estimated_hours")
            t["quote_value"] = t.get("quote_value")
            tasks.append(t)
        return tasks

    def counts(self):
        counts = {"all": self.conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]}
        for s in STATUSES:
            counts[s] = self.conn.execute(
                "SELECT COUNT(*) FROM tasks WHERE status=?", (s,)
            ).fetchone()[0]
        # smart views for the sidebar segmented control
        counts["overdue"] = len(self.list_tasks(view="overdue"))
        counts["needs_attention"] = len(self.list_tasks(view="needs_attention"))
        return counts

    # ---- dashboard ----
    @staticmethod
    def _completion_days(row):
        """Days between created_at and completed_at for a task row."""
        try:
            start = datetime.fromisoformat(row["created_at"])
            end = datetime.fromisoformat(row["completed_at"])
        except (ValueError, TypeError):
            return None
        return (end - start).total_seconds() / 86400.0

    def dashboard_kpis(self):
        """Headline numbers for the Dashboard Overview tab (read-only)."""
        counts = self.status_counts()
        total = sum(counts.values())
        completed = counts.get("completed", 0)
        kpis = {
            "total_completed": completed,
            "in_process": counts.get("in_process", 0),
            "on_hold": counts.get("on_hold", 0),
            "completion_rate": round(completed / total * 100, 1) if total else 0.0,
            "quotes_this_month": self.conn.execute(
                "SELECT COUNT(*) FROM tasks WHERE created_at LIKE ?",
                (date.today().strftime("%Y-%m") + "%",),
            ).fetchone()[0],
            "quotes_this_week": self.conn.execute(
                "SELECT COUNT(*) FROM tasks WHERE substr(created_at, 1, 10) >= ?"
                " AND substr(created_at, 1, 10) < ?",
                (_monday_iso(), _next_monday_iso()),
            ).fetchone()[0],
            "total_quote_value": self.conn.execute(
                "SELECT COALESCE(SUM(quote_value), 0) FROM tasks "
                "WHERE quote_value IS NOT NULL"
            ).fetchone()[0],
            "open_estimated_hours": self.conn.execute(
                "SELECT COALESCE(SUM(estimated_hours), 0) FROM tasks "
                "WHERE status IN ('in_process', 'on_hold') "
                "AND estimated_hours IS NOT NULL"
            ).fetchone()[0],
        }
        done_days = [
            d
            for r in self.conn.execute(
                "SELECT created_at, completed_at FROM tasks "
                "WHERE status='completed' AND completed_at IS NOT NULL "
                "AND completed_at <> ''"
            ).fetchall()
            if (d := self._completion_days(r)) is not None
        ]
        kpis["avg_completion_days"] = (
            round(sum(done_days) / len(done_days), 1) if done_days else 0.0
        )
        est = [
            r[0]
            for r in self.conn.execute(
                "SELECT estimated_hours FROM tasks WHERE status='completed' "
                "AND estimated_hours IS NOT NULL"
            ).fetchall()
        ]
        kpis["avg_estimated_hours"] = (
            round(sum(est) / len(est), 1) if est else 0.0
        )
        main = self.conn.execute(
            "SELECT distributor, COUNT(*) AS c FROM tasks "
            "WHERE TRIM(COALESCE(distributor, '')) <> '' "
            "GROUP BY distributor ORDER BY c DESC, distributor LIMIT 1"
        ).fetchone()
        kpis["main_distributor"] = main["distributor"] if main else ""
        kpis["main_distributor_count"] = main["c"] if main else 0
        # Won/lost tracking is optional: win rate and won value are computed
        # ONLY from marked quotes; when nothing is marked the dashboard hides
        # these cards entirely (marked_count == 0).
        marked = self.conn.execute(
            "SELECT COUNT(*) FROM tasks WHERE outcome IN ('won', 'lost')"
        ).fetchone()[0]
        won = self.conn.execute(
            "SELECT COUNT(*) FROM tasks WHERE outcome = 'won'"
        ).fetchone()[0]
        kpis["marked_count"] = marked
        # V1.9.34 (user): win rate is won / TOTAL quotes — losses
        # are rarely knowable, wins always are, so a marked-only
        # denominator fabricates near-100% rates.
        kpis["win_rate"] = round(won / total * 100, 1) if total else 0.0
        kpis["total_tasks"] = total
        kpis["won_value"] = self.conn.execute(
            "SELECT COALESCE(SUM(quote_value), 0) FROM tasks "
            "WHERE outcome = 'won' AND quote_value IS NOT NULL"
        ).fetchone()[0]
        return kpis

    def _month_keys(self, months):
        """[(yyyy_mm, like_prefix)] oldest -> newest."""
        today = date.today()
        keys = []
        for i in range(months - 1, -1, -1):
            idx = today.year * 12 + today.month - 1 - i
            y, m = divmod(idx, 12)
            keys.append(f"{y:04d}-{m + 1:02d}")
        return keys

    def quotes_per_month(self, months=12):
        """[(yyyy_mm, task count)] oldest -> newest, zero-filled."""
        # V1.9.19 (launch): was one query per month (12 round-trips for
        # the dashboard chart on a network database); one GROUP BY now.
        # created_at starts "YYYY-MM-DD", so substr(...,1,7) is the key.
        keys = self._month_keys(months)
        ph = ",".join("?" * len(keys))
        got = {r[0]: r[1] for r in self.conn.execute(
            f"SELECT substr(created_at, 1, 7) AS m, COUNT(*) FROM tasks "
            f"WHERE substr(created_at, 1, 7) IN ({ph}) GROUP BY m",
            tuple(keys),
        ).fetchall()}
        return [(key, got.get(key, 0)) for key in keys]

    def value_per_month(self, months=12):
        """[(yyyy_mm, summed quote_value)] oldest -> newest, zero-filled."""
        # V1.9.19 (launch): same one-query-per-month loop as above.
        keys = self._month_keys(months)
        ph = ",".join("?" * len(keys))
        got = {r[0]: r[1] for r in self.conn.execute(
            f"SELECT substr(created_at, 1, 7) AS m, "
            f"COALESCE(SUM(quote_value), 0) FROM tasks "
            f"WHERE quote_value IS NOT NULL "
            f"AND substr(created_at, 1, 7) IN ({ph}) GROUP BY m",
            tuple(keys),
        ).fetchall()}
        return [(key, got.get(key, 0)) for key in keys]

    def status_counts(self):
        """{status: n} for every known status."""
        counts = {s: 0 for s in STATUSES}
        for r in self.conn.execute(
            "SELECT status, COUNT(*) AS c FROM tasks GROUP BY status"
        ).fetchall():
            if r["status"] in counts:
                counts[r["status"]] = r["c"]
        return counts

    def task_value_rows(self):
        """[(created_at, outcome, quote_value)] for every priced task
        (V1.9.29 chart outcome-filter source)."""
        return [tuple(r) for r in self.conn.execute(
            "SELECT created_at, outcome, quote_value FROM tasks "
            "WHERE quote_value IS NOT NULL"
        ).fetchall()]

    def quote_creation_rows(self):
        """[(created_at, outcome)] for every task with a created
        stamp (V1.9.29 quotes-chart outcome-filter source)."""
        return [tuple(r) for r in self.conn.execute(
            "SELECT created_at, outcome FROM tasks "
            "WHERE created_at IS NOT NULL AND created_at <> '' "
            "ORDER BY created_at"
        ).fetchall()]

    def outcome_counts(self):
        """{outcome: n} for every known outcome (V1.9.29 By-outcome
        donut). Unmarked tasks carry the 'unknown' default."""
        counts = {o: 0 for o in self.OUTCOMES}
        for r in self.conn.execute(
            "SELECT outcome, COUNT(*) AS c FROM tasks GROUP BY outcome"
        ).fetchall():
            if r["outcome"] in counts:
                counts[r["outcome"]] = r["c"]
        return counts

    def top_distributors(self, n=5):
        """[(name, task count)] by task count desc (blank names excluded)."""
        rows = self.conn.execute(
            "SELECT distributor, COUNT(*) AS c FROM tasks "
            "WHERE TRIM(COALESCE(distributor, '')) <> '' "
            "GROUP BY distributor ORDER BY c DESC, distributor LIMIT ?",
            (n,),
        ).fetchall()
        return [(r["distributor"], r["c"]) for r in rows]

    def distributor_win_rates(self, n=5):
        """[(name, win rate 0..100, won, total)] for the Top
        distributors card's By-win-rate view.

        V1.9.34 (user, correcting the V1.9.29 won/marked formula):
        the rate is won / TOTAL quotes from that distributor --
        "we don't always know if we lost a quote and it's very rare
        to know that, but we do know when we won." Won/marked showed
        7/7 with a full bar for a distributor with tons of quotes
        and only 7 marked. Every distributor with at least one quote
        appears. Ranked by rate desc; ties break on won count, then
        total volume, then name. The won/total counts ride along so
        the view shows the real sample behind each rate.
        """
        rows = self.conn.execute(
            "SELECT distributor, "
            "SUM(CASE WHEN outcome = 'won' THEN 1 ELSE 0 END) AS w, "
            "COUNT(*) AS m FROM tasks "
            "WHERE TRIM(COALESCE(distributor, '')) <> '' "
            "GROUP BY distributor HAVING m > 0 "
            "ORDER BY (CAST(w AS REAL) / m) DESC, w DESC, m DESC, "
            "distributor "
            "LIMIT ?", (n,)).fetchall()
        return [(r["distributor"], 100.0 * r["w"] / r["m"],
                 r["w"], r["m"]) for r in rows]

    def distributor_stats(self):
        """Per-distributor stats sorted by quote count desc (read-only).

        Aggregates come from the same shared path as the CRM metrics
        (_aggregate_task_rows); only the presentation differs (0.0 instead
        of None, completion_pct, and the est average spans every task that
        has an estimate, matching the table's long-standing semantics).
        """
        names = [r[0] for r in self.conn.execute(
            "SELECT DISTINCT distributor FROM tasks "
            "WHERE TRIM(COALESCE(distributor, '')) <> ''"
        ).fetchall()]
        stats = []
        for name in names:
            rows = self.conn.execute(
                "SELECT status, created_at, completed_at, estimated_hours, "
                "quote_value, outcome FROM tasks WHERE distributor=?",
                (name,),
            ).fetchall()
            m = self._aggregate_task_rows(rows, est_scope="all")
            quotes = m["total_quotes"]
            stats.append(
                {
                    "name": name,
                    "quotes": quotes,
                    "completed": m["completed"],
                    "completion_pct": (
                        round(m["completed"] / quotes * 100, 1)
                        if quotes else 0.0
                    ),
                    "avg_days": (
                        m["avg_days"] if m["avg_days"] is not None else 0.0
                    ),
                    "avg_est_hours": (
                        m["avg_est_hours"]
                        if m["avg_est_hours"] is not None else 0.0
                    ),
                    "last_quote": m["last_quote"],
                    "total_value": (
                        m["total_quoted_value"]
                        if m["total_quoted_value"] is not None else 0.0
                    ),
                    # V1.9.30: the Main Distributor metrics view needs
                    # the money/outcome pair per distributor too.
                    "won_value": (
                        m["won_value"]
                        if m["won_value"] is not None else 0.0
                    ),
                    "win_rate": m["win_rate"],
                }
            )
        stats.sort(key=lambda s: (-s["quotes"], s["name"].lower()))
        return stats

    # ---- shared contact metrics (Dashboard + CRM detail) ----
    def _aggregate_task_rows(self, rows, est_scope="completed"):
        """Shared quote aggregates over raw task rows.

        Used by _metrics_for_column (CRM metrics / dashboard KPIs) and by
        distributor_stats (Dashboard Distributors table), so both surfaces
        always compute the same numbers.

        est_scope: "completed" averages estimated hours over completed
        tasks only (CRM metrics); "all" averages over every task that has
        an estimate (Dashboard Distributors table).

        Every aggregate is None when its inputs are missing (callers render
        "—"), never NaN.
        """
        total = len(rows)
        done = [r for r in rows if r["status"] == "completed"]
        days = [
            d
            for r in done
            if r["completed_at"]
            and (d := self._completion_days(r)) is not None
        ]
        est_rows = rows if est_scope == "all" else done
        est = [
            r["estimated_hours"]
            for r in est_rows
            if r["estimated_hours"] is not None
        ]
        # V1.9.34 (user): win rate is won / TOTAL quotes, never
        # won / marked — "we don't always know if we lost a quote
        # and it's very rare to know that, but we do know when we
        # won." A marked-only denominator invents 100% rates out of
        # a sliver of marked quotes.
        won = [r for r in rows if r["outcome"] == "won"]
        prices = [
            r["quote_value"] for r in rows if r["quote_value"] is not None
        ]
        won_prices = [
            r["quote_value"] for r in won if r["quote_value"] is not None
        ]
        return {
            "total_quotes": total,
            "completed": len(done),
            "win_rate": (
                round(len(won) / total * 100, 1) if total else None
            ),
            "total_quoted_value": (
                round(sum(prices), 2) if prices else None
            ),
            "won_value": (
                round(sum(won_prices), 2) if won_prices else None
            ),
            "avg_days": round(sum(days) / len(days), 1) if days else None,
            "avg_est_hours": (
                round(sum(est) / len(est), 1) if est else None
            ),
            "last_quote": (
                max((r["created_at"] or "") for r in rows) if rows else ""
            ),
        }

    def contact_metrics(self, kind, name):
        """Per-contact quote metrics for distributors AND end users.

        ``kind`` is a directory kind ("distributor" or "customer"); the name
        is matched against the backing task column (case-insensitive).
        Shared by the Dashboard and the CRM ContactDetailWindow metrics
        block, so both surfaces always agree.

        Returns a dict; every aggregate is None when its inputs are missing
        (callers render "—"), never NaN:
            total_quotes, completed, win_rate (won / total quotes;
            None when the name has no quotes at all),
            total_quoted_value (None when nothing priced),
            won_value (None when no priced won quote), avg_days (None when
            no timed completion), avg_est_hours (None when unknown),
            last_quote (newest created_at, "" when none).
        """
        col = DIRECTORY_TASK_COLUMN.get(kind)
        if col is None:
            # tolerate the end-user column name as a kind alias
            col = {"end_user": "end_user"}.get(kind)
        if col is None:
            raise ValueError(f"unknown contact kind: {kind!r}")
        return self._metrics_for_column(col, name or "")

    def _metrics_for_column(self, col, name):
        rows = self.conn.execute(
            "SELECT status, created_at, completed_at, estimated_hours, "
            "quote_value, outcome FROM tasks WHERE LOWER(TRIM(COALESCE("
            + col + ", ''))) = LOWER(TRIM(?))",
            (name,),
        ).fetchall()
        return self._aggregate_task_rows(rows)

    def drilldown_tasks(self, mode, name=None):
        """Task rows for a dashboard KPI drill-down (read-only).

        mode: "completed" | "in_process" | "on_hold" | "this_month" |
              "this_week" | "distributor" (requires name) | "workload" (open
              quotes: in_process + on_hold, biggest estimated-hours
              contributors first) | "win_rate" | "won_value" |
              "total_value" | "completion_rate" | "avg_completion_time" |
              "avg_estimate" (the V1.9.29 KPI source sets).
        Returns [dict] newest-first with the columns the drill-down table
        needs. Raises ValueError on an unknown mode.
        """
        where, params = "", []
        order = "created_at DESC, id DESC"
        if mode == "completed":
            where = "status='completed'"
        elif mode == "in_process":
            where = "status='in_process'"
        elif mode == "on_hold":
            where = "status='on_hold'"
        elif mode == "this_month":
            where = "created_at LIKE ?"
            params = [date.today().strftime("%Y-%m") + "%"]
        elif mode == "this_week":
            where = "substr(created_at, 1, 10) >= ? AND substr(created_at, 1, 10) < ?"
            params = [_monday_iso(), _next_monday_iso()]
        elif mode == "distributor":
            if not (name or "").strip():
                raise ValueError("distributor drill-down needs a name")
            where = "LOWER(TRIM(COALESCE(distributor, ''))) = LOWER(TRIM(?))"
            params = [name]
        elif mode == "win_rate":
            # V1.9.34: the Win rate card is won / ALL quotes, so the
            # drill-down is every quote -- the full denominator set.
            where = "1 = 1"
        elif mode == "won_value":
            # The won quotes behind the Won value sum.
            where = "outcome = 'won'"
            order = "quote_value DESC, created_at DESC, id DESC"
        elif mode == "total_value":
            # Every priced quote behind the Total quote value sum.
            where = "quote_value IS NOT NULL AND quote_value > 0"
            order = "quote_value DESC, created_at DESC, id DESC"
        elif mode == "completion_rate":
            where = "status='completed'"
        elif mode == "avg_completion_time":
            where = ("status='completed' AND completed_at IS NOT NULL "
                     "AND completed_at <> ''")
        elif mode == "avg_estimate":
            where = ("status='completed' AND estimated_hours IS NOT NULL")
        elif mode == "workload":
            where = "status IN ('in_process', 'on_hold')"
            # NULLs sort last in SQLite DESC, so unestimated quotes sink to
            # the bottom while the biggest contributors come first.
            order = "estimated_hours DESC, created_at DESC, id DESC"
        else:
            raise ValueError(f"unknown drill-down mode: {mode!r}")
        rows = self.conn.execute(
            "SELECT id, quote_number, distributor, end_user, status, "
            "created_at, completed_at, quote_value, outcome, estimated_hours "
            "FROM tasks WHERE " + where + " ORDER BY " + order,
            params,
        ).fetchall()
        return [dict(r) for r in rows]

    def directory_entry_id(self, kind, name):
        """Directory entry id for a contact name (case-insensitive), or None."""
        if kind not in DIRECTORY_KINDS or not (name or "").strip():
            return None
        row = self.conn.execute(
            "SELECT id FROM directory WHERE kind=? AND LOWER(name)=LOWER(?)",
            (kind, name.strip()),
        ).fetchone()
        return row["id"] if row else None

    def quote_creation_dates(self):
        """All non-empty task created_at stamps (for chart re-bucketing)."""
        return [
            r[0]
            for r in self.conn.execute(
                "SELECT created_at FROM tasks WHERE created_at IS NOT NULL "
                "AND created_at <> '' ORDER BY created_at"
            ).fetchall()
        ]

    def dismiss_nudge(self, name):
        """Dismiss a distributor check-in until that distributor quotes again.

        V1.9.13: stores today's date per distributor. nudge_candidates()
        suppresses the nudge while the distributor's latest quote is no
        newer than the dismissal — a new quote re-arms it, so a dismissed
        check-in can only return after fresh activity goes quiet again.
        Never raises; a failed dismiss just leaves the nudge visible.
        """
        try:
            self.conn.execute(
                "INSERT OR REPLACE INTO nudge_dismissals"
                " (distributor, dismissed_at) VALUES (?, ?)",
                (name, date.today().isoformat()),
            )
            self.conn.commit()
        except Exception:
            pass

    def _nudge_dismissed(self, name, latest_date):
        """True when a dismissal covers the distributor's latest quote."""
        if not name or latest_date is None:
            return False
        try:
            row = self.conn.execute(
                "SELECT dismissed_at FROM nudge_dismissals"
                " WHERE distributor = ?",
                (name,),
            ).fetchone()
        except Exception:
            return False
        if not row or not row[0]:
            return False
        return str(row[0]) >= latest_date.isoformat()

    def nudge_candidates(self):
        """Distributors that have gone quiet past 2x their quoting cadence.

        Builds {distributor: [created_at, ...]} from the DB and runs the pure
        compute_nudges() algorithm over it.
        """
        histories = {}
        for r in self.conn.execute(
            "SELECT distributor, created_at FROM tasks "
            "WHERE TRIM(COALESCE(distributor, '')) <> ''"
        ).fetchall():
            histories.setdefault(r["distributor"], []).append(r["created_at"])
        nudges = compute_nudges(histories)
        # V1.9.13: dismissed check-ins stay hidden until the distributor
        # quotes again (a newer latest quote re-arms the nudge).
        latest = {}
        for dist, stamps in histories.items():
            parsed = []
            for s in stamps:
                try:
                    parsed.append(datetime.fromisoformat(s).date())
                except (ValueError, TypeError):
                    continue
            if parsed:
                latest[dist] = max(parsed)
        nudges = [
            n for n in nudges
            if not self._nudge_dismissed(n.get("name") or "",
                                         latest.get(n.get("name") or ""))
        ]
        # Inactive contacts opted out: never nudge a dead relationship.
        try:
            inactive = {
                r[0].lower()
                for r in self.conn.execute(
                    "SELECT name FROM directory "
                    "WHERE kind='distributor' AND status='inactive'"
                ).fetchall()
            }
        except Exception:
            inactive = set()
        if inactive:
            nudges = [
                n for n in nudges
                if (n.get("name") or "").lower() not in inactive
            ]
        return nudges

    # ---- backups ----
    def _backups_dir(self):
        d = self.path.parent / "backups"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _attachments_dir(self):
        return self.path.parent / "attachments"

    def backup_now(self):
        """Snapshot tasks.db (+ attachments zip) into backups/.

        Uses the sqlite3 online-backup API so it is safe while the DB is open.
        Prunes to the newest BACKUP_KEEP snapshots. Returns the .db Path.

        v1.2.9: the attachments zip is fingerprinted (file count, total
        size, newest mtime) and SKIPPED when nothing changed since the last
        backup — re-zipping hundreds of MB of screenshots on every launch
        is what made startup crawl. The DB snapshot itself still runs every
        time (it is cheap). The deferred startup path no longer calls this
        on the UI thread; see backup_needed() and _backup_worker_main().
        """
        backups = self._backups_dir()
        # Microseconds in the stamp keep names unique and chronologically
        # sortable, so pruning "newest 10" is just a name sort.
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        db_path = backups / f"tasks-{stamp}.db"
        n = 1
        while db_path.exists():
            n += 1
            db_path = backups / f"tasks-{stamp}-{n}.db"
        # Online backup: safe while self.conn is open.
        dst = sqlite3.connect(str(db_path))
        try:
            self.conn.backup(dst)
        finally:
            dst.close()
        # Zip the attachments dir (if any) alongside the snapshot — but
        # only when it changed since the last backup.
        att_dir = self._attachments_dir()
        if att_dir.is_dir():
            fp = _dir_fingerprint(att_dir)
            last_fp = self.get_setting("last_attachments_backup_fp", "")
            if fp and fp == last_fp:
                pass  # unchanged — skip the expensive zip
            else:
                _write_attachments_zip(backups, db_path.stem, att_dir)
                if fp:
                    try:
                        self.set_setting("last_attachments_backup_fp", fp)
                    except Exception:
                        pass
        # Prune to the newest BACKUP_KEEP snapshots (and their zips).
        _prune_backups(backups)
        return db_path

    def backup_needed(self):
        """Cheap UI-thread check: would the deferred backup need to rebuild?

        Compares a stat-walk fingerprint of data/attachments against the
        fingerprint stored by the last successful backup. Costs ~nothing
        next to actually zipping the tree, so it may run on the UI thread;
        the heavy worker is only dispatched when this returns True.
        Never raises — on any error returns True (conservative: do the
        backup). No attachments dir means nothing to rebuild: False.
        """
        try:
            att_dir = self._attachments_dir()
            if not att_dir.is_dir():
                return False
            fp = _dir_fingerprint(att_dir)
            if not fp:
                return True
            return fp != self.get_setting("last_attachments_backup_fp", "")
        except Exception:
            return True

    def list_backups(self):
        """[{name, path, mtime_iso, size_bytes}] newest first."""
        backups = self._backups_dir()
        entries = []
        for p in backups.glob("tasks-*.db"):
            st = p.stat()
            entries.append(
                {
                    "name": p.name,
                    "path": str(p),
                    "mtime_iso": datetime.fromtimestamp(st.st_mtime).isoformat(
                        timespec="seconds"
                    ),
                    "size_bytes": st.st_size,
                }
            )
        entries.sort(key=lambda e: (e["mtime_iso"], e["name"]), reverse=True)
        return entries

    def restore_backup(self, name):
        """Restore a snapshot taken by backup_now().

        Takes a safety backup of the current state first, then replaces
        tasks.db, re-extracts the attachments zip (if present), and reopens
        the connection. Raises ValueError for an unknown backup name.
        """
        backups = self._backups_dir()
        p = Path(name)
        if not p.is_absolute():
            p = backups / p
        if p.suffix != ".db" or p.parent.resolve() != backups.resolve() or not p.is_file():
            raise ValueError(f"unknown backup: {name!r}")
        # Safety snapshot of the current state before touching anything.
        self.backup_now()
        self.conn.close()
        shutil.copy2(str(p), str(self.path))
        # V1.9.37 (WAL): the old database's -wal/-shm sidecars must
        # not survive onto the restored file -- SQLite would replay
        # the OLD write-ahead log onto the restored database.
        for suffix in ("-wal", "-shm"):
            try:
                Path(str(self.path) + suffix).unlink()
            except OSError:
                pass
        # Re-extract attachments over the live dir (if the snapshot has one).
        zip_path = p.parent / (p.stem + "-attachments.zip")
        if zip_path.is_file():
            att_dir = self._attachments_dir()
            att_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zip_path, "r") as z:
                z.extractall(att_dir)
        self.conn = _open_connection(self.path, resilient=True)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._migrate()
        self.conn.commit()

    # ---- attachments ----
    def add_attachment(self, task_id, filename, stored, size):
        now = datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute(
            "INSERT INTO attachments (task_id, filename, stored, size, added_at) VALUES (?,?,?,?,?)",
            (task_id, filename, stored, size, now),
        )
        self.conn.commit()
        return cur.lastrowid

    def list_attachments(self, task_id):
        rows = self.conn.execute(
            "SELECT * FROM attachments WHERE task_id=? ORDER BY added_at", (task_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_attachment(self, att_id):
        row = self.conn.execute("SELECT * FROM attachments WHERE id=?", (att_id,)).fetchone()
        return dict(row) if row else None

    def delete_attachment(self, att_id):
        self.conn.execute("DELETE FROM attachments WHERE id=?", (att_id,))
        self.conn.commit()

    # ---- revisions (V1.9.30, user spec) ----
    def visible_attachments(self, task_id):
        """Attachments belonging to the task's CURRENT revision:
        every row minus the ones removed in this revision that a
        frozen snapshot still references (att_hidden)."""
        task = self.get_task(task_id)
        hidden = set(task.get("att_hidden") or []) if task else set()
        return [a for a in self.list_attachments(task_id)
                if a["id"] not in hidden]

    def detach_attachment(self, task_id, att_id):
        """Remove an attachment from the CURRENT revision. When a
        frozen revision still references it, the row and file are
        KEPT (the frozen revision must not change) and the id is
        hidden from the current revision instead. Returns "soft" or
        "hard" (hard = caller may unlink the file and delete)."""
        referenced = self.conn.execute(
            "SELECT COUNT(*) FROM task_revisions WHERE task_id=?",
            (task_id,)).fetchone()[0]
        if referenced:
            for (snap,) in self.conn.execute(
                    "SELECT snapshot FROM task_revisions WHERE task_id=?",
                    (task_id,)):
                try:
                    data = json.loads(snap)
                except ValueError:
                    continue
                ids = [a.get("id") for a in data.get("attachments", [])]
                if att_id in ids:
                    task = self.get_task(task_id)
                    hidden = list(task.get("att_hidden") or [])
                    if att_id not in hidden:
                        hidden.append(att_id)
                        self.conn.execute(
                            "UPDATE tasks SET att_hidden=? WHERE id=?",
                            (json.dumps(hidden), task_id))
                        self.conn.commit()
                    return "soft"
        return "hard"

    def freeze_revision(self, task_id):
        """Snapshot the task exactly as it is now, under its CURRENT
        revision label. The live task then carries on under the new
        label as the copy -- edits and deletions from here on never
        touch the frozen snapshot. Returns the frozen label."""
        task = self.get_task(task_id)
        if task is None:
            return None
        label = task.get("revision") or "00"
        snapshot = {k: v for k, v in task.items() if k != "att_hidden"}
        snapshot["attachments"] = [
            dict(a) for a in self.visible_attachments(task_id)]
        self.conn.execute(
            "INSERT OR REPLACE INTO task_revisions"
            " (task_id, revision, snapshot, created_at) VALUES (?, ?, ?, ?)",
            (task_id, label, json.dumps(snapshot),
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        self.log_activity(task_id, "revision",
                          f"Revision {label} frozen")
        return label

    def list_revisions(self, task_id):
        """Frozen revisions for a task, oldest first:
        [{revision, created_at}, ...]."""
        rows = self.conn.execute(
            "SELECT revision, created_at FROM task_revisions"
            " WHERE task_id=? ORDER BY id", (task_id,)).fetchall()
        return [dict(r) for r in rows]

    def get_revision(self, task_id, revision):
        """The frozen snapshot dict for (task, revision), or None."""
        row = self.conn.execute(
            "SELECT snapshot FROM task_revisions"
            " WHERE task_id=? AND revision=?",
            (task_id, revision)).fetchone()
        if not row:
            return None
        try:
            return json.loads(row[0])
        except ValueError:
            return None

    # ------------------------------------------------------- notes module
    # Notebooks organize free-form rich-text notes (OneNote-style). Notes
    # store QTextEdit HTML plus a derived plain-text column that powers
    # search and list snippets.

    def notebook_list(self):
        rows = self.conn.execute(
            """SELECT n.id, n.name,
                      (SELECT COUNT(*) FROM notes WHERE notebook_id = n.id) AS note_count
               FROM notebooks n ORDER BY n.sort_order, n.name COLLATE NOCASE"""
        ).fetchall()
        return [dict(r) for r in rows]

    def notebook_add(self, name):
        name = (name or "").strip() or "Untitled notebook"
        now = datetime.now().isoformat(timespec="seconds")
        order = self.conn.execute(
            "SELECT COALESCE(MAX(sort_order), -1) + 1 FROM notebooks"
        ).fetchone()[0]
        cur = self.conn.execute(
            "INSERT INTO notebooks (name, created_at, sort_order) VALUES (?, ?, ?)",
            (name, now, order),
        )
        self.conn.commit()
        return cur.lastrowid

    def notebook_rename(self, notebook_id, name):
        name = (name or "").strip() or "Untitled notebook"
        self.conn.execute(
            "UPDATE notebooks SET name=? WHERE id=?", (name, notebook_id)
        )
        self.conn.commit()

    def notebook_delete(self, notebook_id):
        # Notes survive: they become unfiled (notebook_id NULL).
        self.conn.execute(
            "UPDATE notes SET notebook_id=NULL WHERE notebook_id=?", (notebook_id,)
        )
        self.conn.execute("DELETE FROM notebooks WHERE id=?", (notebook_id,))
        self.conn.commit()

    def note_add(self, notebook_id=None, title=""):
        title = (title or "").strip() or "Untitled note"
        now = datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute(
            """INSERT INTO notes
               (notebook_id, title, body_html, body_text, pinned, created_at, updated_at)
               VALUES (?, ?, '', '', 0, ?, ?)""",
            (notebook_id, title, now, now),
        )
        self.conn.commit()
        return cur.lastrowid

    def note_get(self, note_id):
        row = self.conn.execute(
            """SELECT n.*, nb.name AS notebook_name
               FROM notes n LEFT JOIN notebooks nb ON nb.id = n.notebook_id
               WHERE n.id=?""",
            (note_id,),
        ).fetchone()
        return dict(row) if row else None

    def note_update(self, note_id, title=None, body_html=None,
                    notebook_id=_UNSET, pinned=None, formulas=_UNSET):
        # Only the supplied fields change; updated_at always bumps.
        sets, params = [], []
        if title is not None:
            sets.append("title=?")
            params.append((title or "").strip() or "Untitled note")
        if body_html is not None:
            sets.append("body_html=?")
            params.append(body_html)
            sets.append("body_text=?")
            params.append(html_to_text(body_html))
        if notebook_id is not _UNSET:
            sets.append("notebook_id=?")
            params.append(notebook_id)
        if pinned is not None:
            sets.append("pinned=?")
            params.append(1 if pinned else 0)
        if formulas is not _UNSET:
            sets.append("formulas=?")
            params.append(formulas or "")
        sets.append("updated_at=?")
        params.append(datetime.now().isoformat(timespec="seconds"))
        params.append(note_id)
        self.conn.execute(
            f"UPDATE notes SET {', '.join(sets)} WHERE id=?", params
        )
        self.conn.commit()

    def note_delete(self, note_id):
        self.conn.execute("DELETE FROM notes WHERE id=?", (note_id,))
        self.conn.commit()

    def note_count(self):
        return self.conn.execute("SELECT COUNT(*) FROM notes").fetchone()[0]

    def note_list(self, scope="all", scope_id=None, search=""):
        """Notes for a nav scope, pinned first then most-recently updated.

        scope: "all" | "pinned" | "unfiled" | "notebook".
        Returns id/title/snippet/updated_at/notebook/pinned for list rows.
        """
        where, params = [], []
        if scope == "pinned":
            where.append("n.pinned=1")
        elif scope == "unfiled":
            where.append("n.notebook_id IS NULL")
        elif scope == "notebook":
            where.append("n.notebook_id=?")
            params.append(scope_id)
        q = (search or "").strip()
        if q:
            where.append("(n.title LIKE ? ESCAPE '\\' OR n.body_text LIKE ? ESCAPE '\\')")
            like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            params += [like, like]
        sql = (
            """SELECT n.id, n.title,
                      substr(n.body_text, 1, 140) AS snippet,
                      n.updated_at, n.pinned, n.notebook_id,
                      nb.name AS notebook_name
               FROM notes n LEFT JOIN notebooks nb ON nb.id = n.notebook_id"""
        )
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY n.pinned DESC, n.updated_at DESC, n.id DESC"
        return [dict(r) for r in self.conn.execute(sql, params).fetchall()]


_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t\xa0]+")
# <style>/<script> blocks must go BEFORE tag stripping, or their CSS/JS
# source leaks into note previews and search snippets as visible text.
_STYLE_RE = re.compile(r"<style.*?</style>", re.DOTALL | re.IGNORECASE)
_SCRIPT_RE = re.compile(r"<script.*?</script>", re.DOTALL | re.IGNORECASE)
# _UNSET (defined near the top, shared with update_task) marks "argument not
# supplied" — distinct from an explicit None, which for notebook_id means
# "move the note out of its notebook".


def html_to_text(html_str):
    """Best-effort plain text from QTextEdit HTML, for search + snippets."""
    if not html_str:
        return ""
    text = _STYLE_RE.sub("", html_str)
    text = _SCRIPT_RE.sub("", text)
    text = text.replace("</p>", "\n").replace("<br>", "\n").replace("<br/>", "\n")
    # List items need a separator too, or adjacent <li>s merge into one word
    # ("beamscolumns"). Closing </ul>/</ol> get one for tidiness.
    text = text.replace("</li>", "\n").replace("</ul>", "\n").replace("</ol>", "\n")
    text = _TAG_RE.sub("", text)
    text = html.unescape(text)
    lines = [_WS_RE.sub(" ", ln).strip() for ln in text.splitlines()]
    return "\n".join(ln for ln in lines if ln)


def _md_escape(text):
    return text.replace("\\", "\\\\")


def note_to_markdown(note):
    """A note dict (title/body_html/updated_at) -> Markdown document."""
    from html.parser import HTMLParser

    class _MD(HTMLParser):
        def __init__(self):
            super().__init__()
            self.out = []
            self._li_stack = []

        def handle_starttag(self, tag, attrs):
            if tag in ("h1", "h2", "h3"):
                self.out.append("\n" + "#" * int(tag[1]) + " ")
            elif tag == "p":
                self.out.append("\n")
            elif tag == "br":
                self.out.append("\n")
            elif tag in ("b", "strong"):
                self.out.append("**")
            elif tag in ("i", "em"):
                self.out.append("*")
            elif tag == "u":
                self.out.append("__")
            elif tag == "s":
                self.out.append("~~")
            elif tag == "ul":
                self._li_stack.append("*")
            elif tag == "ol":
                self._li_stack.append("1.")
            elif tag == "li":
                bullet = self._li_stack[-1] if self._li_stack else "*"
                self.out.append(f"\n{bullet} ")

        def handle_endtag(self, tag):
            if tag in ("b", "strong"):
                self.out.append("**")
            elif tag in ("i", "em"):
                self.out.append("*")
            elif tag == "u":
                self.out.append("__")
            elif tag == "s":
                self.out.append("~~")
            elif tag in ("ul", "ol"):
                if self._li_stack:
                    self._li_stack.pop()
                self.out.append("\n")
            elif tag in ("p", "h1", "h2", "h3", "li", "div"):
                self.out.append("\n")

        def handle_data(self, data):
            self.out.append(_md_escape(data))

    conv = _MD()
    conv.feed(note.get("body_html") or "")
    body = re.sub(r"\n{3,}", "\n\n", "".join(conv.out)).strip()
    title = (note.get("title") or "Untitled note").strip()
    updated = (note.get("updated_at") or "")[:10]
    head = f"# {title}\n"
    if updated:
        head += f"\n*Last updated {updated}*\n"
    return head + ("\n" + body + "\n" if body else "\n")


def note_to_text(note):
    """A note dict -> plain-text document."""
    title = (note.get("title") or "Untitled note").strip()
    body = html_to_text(note.get("body_html") or "")
    return f"{title}\n{'=' * len(title)}\n\n{body}\n" if body else f"{title}\n"


def note_to_docx(note):
    """A note dict (title/body_html/updated_at) -> .docx file bytes.

    Dependency-free: builds the Office Open XML package with stdlib zipfile
    only, so it works in the portable bundle with no extra packages.
    Handles headings, paragraphs, bold/italic/underline/strike, text color,
    bullet + numbered lists (real Word numbering), and tables.
    """
    import zipfile
    import io
    from html.parser import HTMLParser
    from xml.sax.saxutils import escape as _xesc

    NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    def _q(tag):
        return f"{{{NS}}}{tag}"

    # --- HTML -> docx model -------------------------------------------------
    class _DocxBuilder(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            # blocks: list of ("p", style, align, runs) or ("tbl", rows)
            # runs: list of dicts {text, b, i, u, strike, color, size}
            self.blocks = []
            self._cur_runs = None
            self._cur_style = None  # None | "Heading1/2/3"
            self._cur_align = None
            self._fmt = []  # stack of active char formats
            self._list_stack = []  # "bullet" | "decimal"
            self._li_num_id = None  # numId for current list level
            self._tbl = None  # current table: list of rows, each list of cells
            self._row = None
            self._cell_runs = None
            self._in_cell = False

        # -- helpers --
        def _push_fmt(self, **kw):
            base = dict(self._fmt[-1]) if self._fmt else {}
            base.update(kw)
            self._fmt.append(base)

        def _pop_fmt(self):
            if self._fmt:
                self._fmt.pop()

        def _cur_fmt(self):
            return dict(self._fmt[-1]) if self._fmt else {}

        def _add_text(self, text):
            if not text:
                return
            fmt = self._cur_fmt()
            run = {"text": text}
            run.update(fmt)
            if self._in_cell:
                if self._cell_runs is not None:
                    self._cell_runs.append(run)
            elif self._cur_runs is not None:
                self._cur_runs.append(run)

        def _new_para(self, style=None, align=None):
            # flush previous
            self._flush_para()
            num_id = None
            if self._list_stack:
                num_id = 1 if self._list_stack[-1] == "bullet" else 2
            self._cur_runs = []
            self._cur_style = style
            self._cur_align = align
            self._cur_num_id = num_id

        def _flush_para(self):
            if self._cur_runs is not None:
                # drop empty paragraphs unless they carry a list marker
                if self._cur_runs or getattr(self, "_cur_num_id", None):
                    self.blocks.append(
                        ("p", self._cur_style, self._cur_align,
                         getattr(self, "_cur_num_id", None), self._cur_runs)
                    )
                self._cur_runs = None
                self._cur_style = None
                self._cur_align = None
                self._cur_num_id = None

        def _parse_style(self, style_attr):
            """Extract color/align/size from a CSS style attribute."""
            out = {}
            for part in (style_attr or "").split(";"):
                if ":" not in part:
                    continue
                k, v = part.split(":", 1)
                k, v = k.strip().lower(), v.strip()
                if k == "color":
                    m = re.match(r"#([0-9a-fA-F]{6})", v)
                    if m:
                        out["color"] = m.group(1).upper()
                elif k == "text-align" and v in ("left", "center", "right", "justify"):
                    out["align"] = v
                elif k == "font-size":
                    m = re.match(r"(\d+(?:\.\d+)?)pt", v)
                    if m:
                        out["size"] = m.group(1)
            return out

        # -- parser hooks --
        def handle_starttag(self, tag, attrs):
            attrs = dict(attrs)
            if tag == "table":
                self._flush_para()
                self._tbl = []
            elif tag == "tr":
                self._row = []
            elif tag in ("td", "th"):
                self._in_cell = True
                self._cell_runs = []
                if tag == "th":
                    self._push_fmt(b=True)
            elif tag in ("h1", "h2", "h3"):
                self._new_para(style="Heading" + tag[1])
            elif tag == "p":
                css = self._parse_style(attrs.get("style", ""))
                self._new_para(align=css.get("align"))
                if css.get("color") or css.get("size"):
                    self._push_fmt(**{k: v for k, v in css.items()
                                      if k in ("color", "size")})
                    self._para_extra_fmt = True
                else:
                    self._para_extra_fmt = False
            elif tag == "br":
                self._add_text("\n")
            elif tag in ("b", "strong"):
                self._push_fmt(b=True)
            elif tag in ("i", "em"):
                self._push_fmt(i=True)
            elif tag == "u":
                self._push_fmt(u=True)
            elif tag in ("s", "strike", "del"):
                self._push_fmt(strike=True)
            elif tag == "span":
                css = self._parse_style(attrs.get("style", ""))
                if css:
                    self._push_fmt(**{k: v for k, v in css.items()
                                      if k in ("color", "size")})
                else:
                    self._push_fmt()
            elif tag == "ul":
                self._list_stack.append("bullet")
            elif tag == "ol":
                self._list_stack.append("decimal")
            elif tag == "li":
                self._new_para()
            elif tag == "div":
                self._new_para()

        def handle_endtag(self, tag):
            if tag == "table":
                if self._tbl is not None:
                    self.blocks.append(("tbl", self._tbl))
                self._tbl = None
            elif tag == "tr":
                if self._tbl is not None and self._row is not None:
                    self._tbl.append(self._row)
                self._row = None
            elif tag in ("td", "th"):
                if self._in_cell and self._row is not None:
                    self._row.append(self._cell_runs or [])
                self._in_cell = False
                self._cell_runs = None
                if tag == "th":
                    self._pop_fmt()
            elif tag in ("h1", "h2", "h3", "p", "li", "div"):
                if tag == "p" and getattr(self, "_para_extra_fmt", False):
                    self._pop_fmt()
                    self._para_extra_fmt = False
                self._flush_para()
            elif tag in ("b", "strong", "i", "em", "u", "s", "strike", "del", "span"):
                self._pop_fmt()
            elif tag in ("ul", "ol"):
                if self._list_stack:
                    self._list_stack.pop()
                self._flush_para()

        def handle_data(self, data):
            # skip pure whitespace between block tags, keep meaningful text
            if not data.strip() and self._cur_runs is not None and not self._in_cell:
                # keep single spaces inside paragraphs
                if self._cur_runs and not self._cur_runs[-1]["text"].endswith((" ", "\n")):
                    self._add_text(" ")
                return
            self._add_text(data)

    # --- XML generation ------------------------------------------------------
    def _run_xml(run):
        t = _xesc(run["text"])
        # Word needs xml:space="preserve" for leading/trailing spaces
        rpr = []
        if run.get("b"):
            rpr.append("<w:b/>")
        if run.get("i"):
            rpr.append("<w:i/>")
        if run.get("u"):
            rpr.append('<w:u w:val="single"/>')
        if run.get("strike"):
            rpr.append("<w:strike/>")
        if run.get("color"):
            rpr.append(f'<w:color w:val="{run["color"]}"/>')
        if run.get("size"):
            try:
                half_pts = int(round(float(run["size"]) * 2))
                rpr.append(f"<w:sz w:val=\"{half_pts}\"/>")
            except (ValueError, TypeError):
                pass
        rpr_xml = f"<w:rPr>{''.join(rpr)}</w:rPr>" if rpr else ""
        # split on newlines -> <w:br/>
        parts = t.split("\n")
        tx = "<w:br/>".join(
            f'<w:t xml:space="preserve">{p}</w:t>' for p in parts
        )
        return f"<w:r>{rpr_xml}{tx}</w:r>"

    def _para_xml(style, align, num_id, runs):
        ppr = []
        if style:
            ppr.append(f'<w:pStyle w:val="{style}"/>')
        if num_id:
            ppr.append(
                "<w:numPr><w:ilvl w:val=\"0\"/>"
                f"<w:numId w:val=\"{num_id}\"/></w:numPr>"
            )
        if align and align != "left":
            jc = {"center": "center", "right": "right",
                  "justify": "both"}.get(align)
            if jc:
                ppr.append(f"<w:jc w:val=\"{jc}\"/>")
        ppr_xml = f"<w:pPr>{''.join(ppr)}</w:pPr>" if ppr else ""
        # Word dislikes truly empty paragraphs; use empty run
        runs_xml = "".join(_run_xml(r) for r in runs) or "<w:r/>"
        return f"<w:p>{ppr_xml}{runs_xml}</w:p>"

    def _table_xml(rows):
        if not rows:
            return ""
        ncols = max((len(r) for r in rows), default=0)
        # even column widths (twips); total ~6 inches
        col_w = 8640 // max(ncols, 1)
        grid = "".join(f'<w:gridCol w:w="{col_w}"/>' for _ in range(ncols))
        borders = (
            "<w:tblBorders>"
            "<w:top w:val=\"single\" w:sz=\"6\" w:color=\"999999\"/>"
            "<w:left w:val=\"single\" w:sz=\"6\" w:color=\"999999\"/>"
            "<w:bottom w:val=\"single\" w:sz=\"6\" w:color=\"999999\"/>"
            "<w:right w:val=\"single\" w:sz=\"6\" w:color=\"999999\"/>"
            "<w:insideH w:val=\"single\" w:sz=\"6\" w:color=\"999999\"/>"
            "<w:insideV w:val=\"single\" w:sz=\"6\" w:color=\"999999\"/>"
            "</w:tblBorders>"
        )
        tbl_pr = (
            "<w:tblPr><w:tblW w:w=\"0\" w:type=\"auto\"/>"
            f"{borders}</w:tblPr><w:tblGrid>{grid}</w:tblGrid>"
        )
        trs = []
        for row in rows:
            tcs = []
            for ci in range(ncols):
                cell_runs = row[ci] if ci < len(row) else []
                cell_ps = "".join(_run_xml(r) for r in cell_runs) or "<w:r/>"
                tcs.append(
                    f"<w:tc><w:tcPr><w:tcW w:w=\"{col_w}\" "
                    f'w:type="dxa"/></w:tcPr><w:p>{cell_ps}</w:p></w:tc>'
                )
            trs.append(f"<w:tr>{''.join(tcs)}</w:tr>")
        return f"<w:tbl>{tbl_pr}{''.join(trs)}</w:tbl>"

    # --- build ---------------------------------------------------------------
    b = _DocxBuilder()
    b.feed(note.get("body_html") or "")
    b._flush_para()

    title = (note.get("title") or "Untitled note").strip()
    updated = (note.get("updated_at") or "")[:10]

    body_parts = [_para_xml("Title", None, None, [{"text": title}])]
    if updated:
        body_parts.append(
            _para_xml(None, None, None,
                      [{"text": f"Last updated {updated}", "i": True,
                        "color": "808080"}])
        )
    for blk in b.blocks:
        if blk[0] == "p":
            _, style, align, num_id, runs = blk
            body_parts.append(_para_xml(style, align, num_id, runs))
        else:
            body_parts.append(_table_xml(blk[1]))

    document_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<w:document xmlns:w="{NS}">'
        f"<w:body>{''.join(body_parts)}"
        '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>'
        '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>'
        "</w:sectPr></w:body></w:document>"
    )

    numbering_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<w:numbering xmlns:w="{NS}">'
        '<w:abstractNum w:abstractNumId="0">'
        '<w:lvl w:ilvl="0"><w:start w:val="1"/>'
        '<w:numFmt w:val="bullet"/><w:lvlText w:val="\u2022"/>'
        '<w:lvlJc w:val="left"/>'
        '<w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr>'
        "</w:lvl></w:abstractNum>"
        '<w:abstractNum w:abstractNumId="1">'
        '<w:lvl w:ilvl="0"><w:start w:val="1"/>'
        '<w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/>'
        '<w:lvlJc w:val="left"/>'
        '<w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr>'
        "</w:lvl></w:abstractNum>"
        '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>'
        '<w:num w:numId="2"><w:abstractNumId w:val="1"/></w:num>'
        "</w:numbering>"
    )

    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>'
        "</Types>"
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        "</Relationships>"
    )
    doc_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>'
        "</Relationships>"
    )

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/_rels/document.xml.rels", doc_rels)
        z.writestr("word/document.xml", document_xml)
        z.writestr("word/numbering.xml", numbering_xml)
    return buf.getvalue()


def note_to_html_doc(note):
    """A note dict -> standalone HTML document."""
    title = (note.get("title") or "Untitled note").strip()
    body = note.get("body_html") or ""
    updated = (note.get("updated_at") or "")[:10]
    return (
        "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
        f"<title>{html.escape(title)}</title></head>"
        "<body style=\"font-family: sans-serif; max-width: 800px; "
        "margin: 2em auto; padding: 0 1em;\">"
        f"<h1>{html.escape(title)}</h1>"
        + (f"<p><em>Last updated {html.escape(updated)}</em></p>" if updated else "")
        + body
        + "</body></html>"
    )


def _safe_filename(title, used):
    base = re.sub(r"[^\w\- ]+", "", title or "note").strip() or "note"
    base = re.sub(r"\s+", "-", base)[:60]
    name, n = base, 1
    while name.lower() in used:
        n += 1
        name = f"{base}-{n}"
    used.add(name.lower())
    return name


def export_notes_to_folder(notes, folder):
    """Write each note dict as a Markdown file; returns [Path, ...]."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    used, written = set(), []
    for note in notes:
        path = folder / (_safe_filename(note.get("title"), used) + ".md")
        path.write_text(note_to_markdown(note), encoding="utf-8")
        written.append(path)
    return written
