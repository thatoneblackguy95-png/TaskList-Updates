"""Task List update helper — launched detached by the app with
the BUNDLED python (which an update never replaces), mirroring
Drawing Finder's helper:

    pythonw.exe apply_update.py --apply-update <app_pid>
        <pending_zip> <install_dir> <data_dir> [relaunch_path]

It waits for the app process to exit, unpacks the staged update
over the install folder (retrying while files settle), clears the
stage ONLY on success, logs every step to <data_dir>/update.log,
and relaunches the user's launcher. V1.9.32: the caller passes the
real launcher path explicitly — the install dir under the mirror
layout is the share's files folder while the exe the user launches
can sit OUTSIDE it, and defaulting to <install>/Task List.exe is
what left the app closed after the 1.9.31 update (no exe exists in
the local mirror the old caller mistook for the install).

Task List differences from the Drawing Finder original, both
load-bearing:
- Entries under data/ or python/ inside the zip are NEVER
  extracted: the user's database lives in the install tree and no
  update may touch it, and the bundled runtime is not update
  payload either (defense in depth — release zips don't carry
  them, but a bad zip must not be able to hurt).
- Zip entries that would escape the install dir are skipped.

Stdlib only; no PySide6 — this runs before the app exists.

V1.9.73 (the 1.9.72 process storm): two structural guards.
- The relaunch target is validated by safe_relaunch_target:
  this helper relaunches ONLY the real launcher (the exe
  outside the files folder, or the one inside it, or the
  retired .bat). A requested target that is anything else --
  above all a path inside the local mirror, whose root exe is
  the HOST, not a launcher -- is substituted with the real
  launcher and the substitution is logged. Starting the mirror
  slot directly is what bypassed the launcher's heal/gate in
  both the 1.9.71 update loop and the storm.
- A single-helper lock (<data_dir>/apply_update.lock, pid +
  staged-zip hash): a second helper for a live first one logs
  and exits, so helpers can never multiply either.
The relaunch also strips TASKLIST_LAUNCH_DEPTH from the
child's environment (the launcher's lineage guard refuses a
launcher that still carries it; this hop is intentional).
"""
import hashlib
import os
import subprocess
import sys
import time
import zipfile


def _upd_log(data_dir, msg):
    try:
        with open(os.path.join(data_dir, "update.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except Exception:
        pass


def _pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x00100000, False, pid)
        if not handle:
            return False
        try:
            # WAIT_OBJECT_0 (0) = signalled = the process exited
            return kernel32.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _extract_update(pending, install):
    """Extract the update zip over the install dir, skipping
    anything under data/ or python/ and anything that would land
    outside the install dir. Returns the count extracted."""
    install_abs = os.path.abspath(install)
    count = 0
    with zipfile.ZipFile(pending) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            parts = [p for p in name.split("/") if p not in ("", ".")]
            if not parts or ".." in parts:
                continue
            if parts[0].lower() in ("data", "python"):
                continue
            dest = os.path.abspath(os.path.join(install_abs, *parts))
            if os.path.commonpath([dest, install_abs]) != install_abs:
                continue
            if info.is_dir():
                os.makedirs(dest, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(info) as src, open(dest, "wb") as out:
                while True:
                    chunk = src.read(1 << 16)
                    if not chunk:
                        break
                    out.write(chunk)
            count += 1
    return count


def _norm(path):
    return os.path.normcase(os.path.abspath(path))


def safe_relaunch_target(requested, install, data_dir):
    """V1.9.73: the ONLY paths this helper will ever relaunch
    are the real launcher candidates -- the exe outside the
    files folder, the exe inside it, then the retired .bat.
    Anything else (a mirror path, the install's host exe, a
    stale or foreign path) is substituted with the first
    candidate that exists, and the substitution is logged:
    relaunching the mirror slot directly is the exact move
    that produced the 1.9.71 update loop and, with launcher
    bytes in the slot, the 1.9.72 process storm."""
    candidates = [
        os.path.join(os.path.dirname(os.path.abspath(install)),
                     "Task List.exe"),
        os.path.join(install, "Task List.exe"),
        os.path.join(install, "Task List.bat"),
    ]
    if requested:
        req = _norm(requested)
        for cand in candidates:
            if _norm(cand) == req and os.path.isfile(cand):
                return requested
    for cand in candidates:
        if os.path.isfile(cand):
            if requested and _norm(cand) != _norm(requested):
                _upd_log(data_dir,
                         "helper: relaunch target "
                         f"{requested} is not the real launcher; "
                         f"substituting {cand}")
            return cand
    return requested


def _acquire_helper_lock(data_dir, pending):
    """V1.9.73 single-helper lock. Returns the lock path when
    this helper owns it, or None when a LIVE helper already
    holds it (the caller then logs and exits -- helpers never
    multiply). A lock whose pid is dead is taken over."""
    lock = os.path.join(data_dir, "apply_update.lock")
    try:
        digest = hashlib.sha256()
        with open(pending, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                digest.update(chunk)
        token = f"{os.getpid()} {digest.hexdigest()}"
    except Exception:
        token = f"{os.getpid()}"
    for _attempt in range(2):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(token)
            return lock
        except FileExistsError:
            try:
                with open(lock, encoding="utf-8") as fh:
                    owner = int(fh.read().split()[0])
            except Exception:
                owner = -1
            if owner != os.getpid() and _pid_alive(owner):
                return None
            try:
                os.remove(lock)
            except OSError:
                return None
        except OSError:
            return lock  # cannot lock (odd fs) -- proceed unlocked
    return None


def apply_update_main(argv):
    """--apply-update <app_pid> <pending_zip> <install_dir>
    <data_dir> [relaunch_path]"""
    pid = int(argv[0])
    pending, install, data_dir = argv[1], argv[2], argv[3]
    relaunch = (argv[4] if len(argv) > 4
                else os.path.join(install, "Task List.exe"))
    lock = _acquire_helper_lock(data_dir, pending)
    if lock is None:
        _upd_log(data_dir,
                 "helper: another live helper holds the lock; "
                 "exiting without acting")
        return 0
    try:
        return _apply_update_locked(pid, pending, install,
                                    data_dir, relaunch)
    finally:
        try:
            os.remove(lock)
        except OSError:
            pass


def _apply_update_locked(pid, pending, install, data_dir,
                         relaunch):
    relaunch = safe_relaunch_target(relaunch, install, data_dir)
    _upd_log(data_dir,
             f"helper: start, waiting for app pid {pid} to exit")
    deadline = time.time() + 180
    while _pid_alive(pid) and time.time() < deadline:
        time.sleep(0.25)
    gone = not _pid_alive(pid)
    _upd_log(data_dir, "helper: app exited" if gone else
             "helper: app still running after 180s; trying anyway")
    ok = False
    for attempt in range(30):
        try:
            n = _extract_update(pending, install)
            _upd_log(data_dir, f"helper: extracted {n} files")
            ok = True
            break
        except Exception as exc:
            _upd_log(data_dir, "helper: extract attempt "
                     f"{attempt + 1} failed: {exc!r}")
            time.sleep(1.0)
    if ok:
        for name in ("pending_update.zip", "pending_update.json",
                     "pending_update.zip.part"):
            try:
                os.remove(os.path.join(data_dir, name))
            except OSError:
                pass
        _upd_log(data_dir, "helper: update applied, relaunching")
    else:
        _upd_log(data_dir, "helper: update NOT applied after 30 "
                 "attempts; the staged zip was kept")
    try:
        flags = 0
        if os.name == "nt":
            flags = 0x00000008 | 0x08000000  # DETACHED | NO_WINDOW
        cmd = [relaunch]
        if relaunch.lower().endswith(".bat"):
            cmd = ["cmd", "/c", relaunch]
        # V1.9.73: strip the lineage token -- this relaunch is
        # intentional, and the launcher refuses a start that
        # still carries it (see taskbar.relaunch_env).
        env = dict(os.environ)
        env.pop("TASKLIST_LAUNCH_DEPTH", None)
        subprocess.Popen(
            cmd, cwd=os.path.dirname(relaunch) or install,
            creationflags=flags, close_fds=True, env=env)
        _upd_log(data_dir, f"helper: relaunched {relaunch}")
    except Exception as exc:
        _upd_log(data_dir, f"helper: relaunch failed: {exc!r}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--apply-update":
        raise SystemExit(apply_update_main(sys.argv[2:7]))
    raise SystemExit("usage: apply_update.py --apply-update "
                     "<pid> <zip> <install_dir> <data_dir> "
                     "[relaunch_path]")
