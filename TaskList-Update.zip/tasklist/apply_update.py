"""Task List update helper — launched detached by the app with
the BUNDLED python (which an update never replaces), mirroring
Drawing Finder's helper:

    pythonw.exe apply_update.py --apply-update <app_pid>
        <pending_zip> <install_dir> <data_dir> [relaunch_path]

It waits for the app process to exit, unpacks the staged update
over the install folder (retrying while files settle), clears the
stage ONLY on success, logs every step to <data_dir>/update.log,
and relaunches the user's launcher. V1.9.32: the caller passes the
real launcher path explicitly — the install dir under the mirror
layout is the share's files folder while the exe the user launches
can sit OUTSIDE it, and defaulting to <install>/Task List.exe is
what left the app closed after the 1.9.31 update (no exe exists in
the local mirror the old caller mistook for the install).

Task List differences from the Drawing Finder original, both
load-bearing:
- Entries under data/ or python/ inside the zip are NEVER
  extracted: the user's database lives in the install tree and no
  update may touch it, and the bundled runtime is not update
  payload either (defense in depth — release zips don't carry
  them, but a bad zip must not be able to hurt).
- Zip entries that would escape the install dir are skipped.

Stdlib only; no PySide6 — this runs before the app exists.

V1.9.73 (the 1.9.72 process storm): two structural guards.
- The relaunch target is validated by safe_relaunch_target:
  this helper relaunches ONLY the real launcher (the exe
  outside the files folder, or the one inside it, or the
  retired .bat). A requested target that is anything else --
  above all a path inside the local mirror, whose root exe is
  the HOST, not a launcher -- is substituted with the real
  launcher and the substitution is logged. Starting the mirror
  slot directly is what bypassed the launcher's heal/gate in
  both the 1.9.71 update loop and the storm.
- A single-helper lock (<data_dir>/apply_update.lock, pid +
  staged-zip hash): a second helper for a live first one logs
  and exits, so helpers can never multiply either.
The relaunch also strips TASKLIST_LAUNCH_DEPTH from the
child's environment (the launcher's lineage guard refuses a
launcher that still carries it; this hop is intentional).

V1.9.84 (the 2026-11-19 desktop failure: the 1.9.82 update
APPLIED but the app never relaunched, and afterwards no launch
route worked at all): through 1.9.83 this helper counted the
files it had written, cleared the stage, fired the launcher
and exited 0 -- it verified NOTHING: not that the bytes it
wrote could be read back (the install lives in a redirected
folder served by Offline Files; an apply over a CSC folder in
an Error/Offline state can "succeed" into a cache whose reads
then block or fail), and not that the relaunched app ever
reached a window. The apply is now a verified transaction:

  1. SNAPSHOT: the program files the update will overwrite
     (plus the root launcher copy / .bat beside the files
     folder, when they exist) are copied to a LOCAL backup
     (%LOCALAPPDATA%\\TaskList\\update_backup) before anything
     is touched. If the snapshot cannot complete, the apply
     aborts with the old install intact.
  2. STAGE + VERIFY: the zip is extracted into
     <install>/.update_staging and every staged file's sha256
     is checked against the zip's content BEFORE the install
     is touched.
  3. COMMIT + READ-BACK: files move into place with
     os.replace (version.txt LAST, so a half-commit still
     reports the old version), the root launcher copy and .bat
     are refreshed from the same verified bytes when they
     exist (never created -- V1.9.73 case D stands: an update
     does not conjure an outside exe from zero), and every
     installed file is read back and hash-verified. A file
     that reads back wrong is re-copied once; a file that
     still fails ROLLS THE WHOLE APPLY BACK to the snapshot
     and relaunches the previous version.
  4. VERIFIED RELAUNCH: the stage is cleared only after the
     commit verifies. The relaunch is then watched: the app
     must append its "window shown" marker to startup.log
     within the route's deadline, or the next route runs --
     the alternate launcher copy, then a direct compatibility
     start (the launcher's own terminal state: pythonw + the
     .pyw with TASKLIST_HOST_UNAVAILABLE set). If no route
     produces a window, the failure is LOUD -- update.log, a
     local log that does not depend on the share, and a
     visible message box -- and the verified-good update
     STAYS (a restart failure is not a reason to trade a
     verified install for an older one). Rollback is reserved
     for the case the brief assigns it: the installed files
     themselves failing verification. A completed apply can
     no longer end in silence.
  5. PHASE WATCHDOG: the apply body runs on a worker thread;
     the main thread enforces a deadline per phase. A phase
     that overruns (a share read that never returns is the
     field shape) kills the helper with a loud local record
     instead of hanging forever holding the lock. Phases are
     ordered so that an abort before the commit leaves the
     old install untouched, and an abort during the commit
     leaves version.txt old (it moves last), so the next
     launch's own verification sees a coherent state.

Exit codes: 0 = applied (or nothing to do) and the relaunched
app reached its window; 2 = the apply was aborted / rolled
back, or the install verified but no relaunch could be
confirmed (all recorded loudly); 3 = watchdog abort or total
failure. Nothing in the chain consumes the code today; it is
recorded for support.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile


def _upd_log(data_dir, msg):
    try:
        with open(os.path.join(data_dir, "update.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except Exception:
        pass


def _pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x00100000, False, pid)
        if not handle:
            return False
        try:
            # WAIT_OBJECT_0 (0) = signalled = the process exited
            return kernel32.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _extract_update(pending, install):
    """Extract the update zip over the install dir, skipping
    anything under data/ or python/ and anything that would land
    outside the install dir. Returns the count extracted."""
    install_abs = os.path.abspath(install)
    count = 0
    with zipfile.ZipFile(pending) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            parts = [p for p in name.split("/") if p not in ("", ".")]
            if not parts or ".." in parts:
                continue
            if parts[0].lower() in ("data", "python"):
                continue
            dest = os.path.abspath(os.path.join(install_abs, *parts))
            if os.path.commonpath([dest, install_abs]) != install_abs:
                continue
            if info.is_dir():
                os.makedirs(dest, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(info) as src, open(dest, "wb") as out:
                while True:
                    chunk = src.read(1 << 16)
                    if not chunk:
                        break
                    out.write(chunk)
            count += 1
    return count


def _norm(path):
    return os.path.normcase(os.path.abspath(path))


def safe_relaunch_target(requested, install, data_dir):
    """V1.9.73: the ONLY paths this helper will ever relaunch
    are the real launcher candidates -- the exe outside the
    files folder, the exe inside it, then the retired .bat.
    Anything else (a mirror path, the install's host exe, a
    stale or foreign path) is substituted with the first
    candidate that exists, and the substitution is logged:
    relaunching the mirror slot directly is the exact move
    that produced the 1.9.71 update loop and, with launcher
    bytes in the slot, the 1.9.72 process storm."""
    candidates = [
        os.path.join(os.path.dirname(os.path.abspath(install)),
                     "Task List.exe"),
        os.path.join(install, "Task List.exe"),
        os.path.join(install, "Task List.bat"),
    ]
    if requested:
        req = _norm(requested)
        for cand in candidates:
            if _norm(cand) == req and os.path.isfile(cand):
                return requested
    for cand in candidates:
        if os.path.isfile(cand):
            if requested and _norm(cand) != _norm(requested):
                _upd_log(data_dir,
                         "helper: relaunch target "
                         f"{requested} is not the real launcher; "
                         f"substituting {cand}")
            return cand
    return requested


def _acquire_helper_lock(data_dir, pending):
    """V1.9.73 single-helper lock. Returns the lock path when
    this helper owns it, or None when a LIVE helper already
    holds it (the caller then logs and exits -- helpers never
    multiply). A lock whose pid is dead is taken over."""
    lock = os.path.join(data_dir, "apply_update.lock")
    try:
        digest = hashlib.sha256()
        with open(pending, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                digest.update(chunk)
        token = f"{os.getpid()} {digest.hexdigest()}"
    except Exception:
        token = f"{os.getpid()}"
    for _attempt in range(2):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(token)
            return lock
        except FileExistsError:
            try:
                with open(lock, encoding="utf-8") as fh:
                    owner = int(fh.read().split()[0])
            except Exception:
                owner = -1
            if owner != os.getpid() and _pid_alive(owner):
                return None
            try:
                os.remove(lock)
            except OSError:
                return None
        except OSError:
            return lock  # cannot lock (odd fs) -- proceed unlocked
    return None


# ------------------------------------------------------------------
# V1.9.84: the verified apply. Everything below is new machinery;
# the functions above keep their exact contracts.
# ------------------------------------------------------------------

# Phase bookkeeping shared between the apply worker thread and
# the watchdog on the main thread.
_PHASE = {"name": "init", "deadline": None}
_PHASE_LOCK = threading.Lock()

# Per-phase deadlines (seconds). The phases are ordered so an
# abort before "commit" leaves the old install untouched.
_PHASE_BUDGETS = {
    "wait for app exit": 240,
    "snapshot": 180,
    "stage": 180,
    "verify staged": 120,
    "commit": 180,
    "verify install": 240,
    "roll back": 240,
    "relaunch": 1500,
}

# Window-watch deadlines per relaunch route (seconds).
_ROUTE_WATCH = (240, 180, 180)


def _set_phase(name):
    with _PHASE_LOCK:
        _PHASE["name"] = name
        budget = _PHASE_BUDGETS.get(name)
        _PHASE["deadline"] = (time.time() + budget
                              if budget else None)


def _phase_state():
    with _PHASE_LOCK:
        return _PHASE["name"], _PHASE["deadline"]


def _local_state_dir():
    """A LOCAL folder for the snapshot and the local loud log:
    %LOCALAPPDATA%\\TaskList, falling back to the temp dir.
    Never the share -- the whole point is that these survive a
    share that cannot be read or written."""
    lad = os.environ.get("LOCALAPPDATA")
    if lad:
        return os.path.join(lad, "TaskList")
    return os.path.join(tempfile.gettempdir(), "TaskList")


def _local_log(msg):
    try:
        d = _local_state_dir()
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "update_last.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except Exception:
        pass


def _loud(data_dir, msg):
    """A record that lands in BOTH update.log (share) and the
    local log: the failure record must exist even when the
    share is the thing that is sick."""
    _upd_log(data_dir, msg)
    _local_log(msg)


def _hash_stream(fh):
    h = hashlib.sha256()
    while True:
        chunk = fh.read(1 << 20)
        if not chunk:
            break
        h.update(chunk)
    return h.hexdigest()


def _hash_file(path):
    with open(path, "rb") as fh:
        return _hash_stream(fh)


def _copy_hashed(src, dst):
    """Copy src to dst, returning the sha256 of the bytes that
    LANDED (hashed from the copy as written, then re-read by
    the caller's verification pass when it matters)."""
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    h = hashlib.sha256()
    with open(src, "rb") as fin, open(dst, "wb") as fout:
        while True:
            chunk = fin.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
            fout.write(chunk)
    return h.hexdigest()


def _zip_payload_hashes(pending):
    """{relpath: sha256} for every entry the extractor would
    write (same skip rules as _extract_update: no data/, no
    python/, no escapes, no directories)."""
    hashes = {}
    with zipfile.ZipFile(pending) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            parts = [p for p in name.split("/") if p not in ("", ".")]
            if not parts or ".." in parts:
                continue
            if parts[0].lower() in ("data", "python"):
                continue
            if info.is_dir():
                continue
            with z.open(info) as src:
                hashes["/".join(parts)] = _hash_stream(src)
    return hashes


def _fs_path(base, rel):
    return os.path.join(base, *rel.split("/"))


def _verify_set(base, hashes, rels=None):
    """The rels whose file under base is missing or whose
    sha256 differs from the expected hash."""
    bad = []
    for rel in (rels if rels is not None else sorted(hashes)):
        path = _fs_path(base, rel)
        try:
            if _hash_file(path) != hashes[rel]:
                bad.append(rel)
        except OSError:
            bad.append(rel)
    return bad


def _snapshot(hashes, install, snap_dir):
    """Copy the current program files the update will
    overwrite into snap_dir, plus the root launcher copy and
    .bat beside the files folder when they exist. Returns
    (manifest, old_hashes): manifest maps a key to
    {"zone": "install"|"root", "rel": rel, "exists": bool};
    old_hashes maps install rels (and root names) to the
    sha256 of the pre-update bytes, for post-rollback
    verification. Raises on any copy failure -- the caller
    aborts the apply with the install untouched."""
    if os.path.isdir(snap_dir):
        shutil.rmtree(snap_dir)
    os.makedirs(snap_dir)
    manifest = {}
    old_hashes = {}
    for rel in sorted(hashes):
        src = _fs_path(install, rel)
        key = "install:" + rel
        if os.path.isfile(src):
            dst = _fs_path(os.path.join(snap_dir, "files"), rel)
            digest = _copy_hashed(src, dst)
            if _hash_file(dst) != digest:
                raise OSError(f"snapshot copy unverifiable: {rel}")
            manifest[key] = {"zone": "install", "rel": rel,
                             "exists": True}
            old_hashes[key] = digest
        else:
            manifest[key] = {"zone": "install", "rel": rel,
                             "exists": False}
    parent = os.path.dirname(os.path.abspath(install))
    for name in ("Task List.exe", "Task List.bat"):
        src = os.path.join(parent, name)
        key = "root:" + name
        if os.path.isfile(src):
            dst = os.path.join(snap_dir, "root", name)
            digest = _copy_hashed(src, dst)
            if _hash_file(dst) != digest:
                raise OSError(f"snapshot copy unverifiable: {name}")
            manifest[key] = {"zone": "root", "rel": name,
                             "exists": True}
            old_hashes[key] = digest
    with open(os.path.join(snap_dir, "snapshot.json"), "w",
              encoding="utf-8") as fh:
        json.dump(manifest, fh)
    return manifest, old_hashes


def _restore_snapshot(manifest, install, snap_dir):
    """Put the snapshot back: files that existed are restored
    (install zone via the snapshot copy, root zone likewise);
    files the update created are removed. Returns the list of
    entries that could not be restored."""
    parent = os.path.dirname(os.path.abspath(install))
    failed = []
    for key, entry in manifest.items():
        rel = entry["rel"]
        if entry["zone"] == "root":
            target = os.path.join(parent, rel)
            kept = os.path.join(snap_dir, "root", rel)
        else:
            target = _fs_path(install, rel)
            kept = _fs_path(os.path.join(snap_dir, "files"), rel)
        try:
            if entry["exists"]:
                tmp = target + ".rollback_tmp"
                shutil.copyfile(kept, tmp)
                os.replace(tmp, target)
            else:
                if os.path.isfile(target):
                    os.remove(target)
        except OSError:
            failed.append(key)
    return failed


def _snapshot_hashes_for(manifest, old_hashes):
    """Split old_hashes into (install hashes, root hashes) for
    post-rollback verification."""
    inst, root = {}, {}
    for key, entry in manifest.items():
        if not entry["exists"]:
            continue
        if entry["zone"] == "root":
            root[entry["rel"]] = old_hashes[key]
        else:
            inst[entry["rel"]] = old_hashes[key]
    return inst, root


def _watch_window(data_dir, seconds, start_size):
    """Watch <data_dir>/startup.log for the app's "window
    shown" marker in the bytes appended after start_size.
    Returns True when the marker lands within the deadline.
    (The log rotates at 300 lines: a size shrink restarts the
    scan from the beginning of the new file.)"""
    log = os.path.join(data_dir, "startup.log")
    pos = start_size
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            size = os.path.getsize(log)
        except OSError:
            size = 0
        if size < pos:
            pos = 0  # rotated; rescan the new file
        if size > pos:
            try:
                with open(log, "rb") as fh:
                    fh.seek(pos)
                    new = fh.read(size - pos)
                if b"window shown" in new:
                    return True
                pos = size
            except OSError:
                pass
        time.sleep(1.0)
    return False


def _log_size(data_dir):
    try:
        return os.path.getsize(os.path.join(data_dir,
                                            "startup.log"))
    except OSError:
        return 0


def _start_process(cmd, cwd, data_dir, env_extra=None):
    """Start one relaunch route's process. Returns True when
    the process started (Popen succeeded)."""
    flags = 0
    if os.name == "nt":
        flags = 0x00000008 | 0x08000000  # DETACHED | NO_WINDOW
    env = dict(os.environ)
    # V1.9.73: strip the lineage token -- this relaunch is
    # intentional, and the launcher refuses a start that
    # still carries it (see taskbar.relaunch_env).
    env.pop("TASKLIST_LAUNCH_DEPTH", None)
    if env_extra:
        env.update(env_extra)
    subprocess.Popen(cmd, cwd=cwd, creationflags=flags,
                     close_fds=True, env=env)
    return True


def _start_launcher_target(target, install, data_dir):
    cmd = [target]
    if target.lower().endswith(".bat"):
        cmd = ["cmd", "/c", target]
    ok = _start_process(cmd, os.path.dirname(target) or install,
                        data_dir)
    if ok:
        _upd_log(data_dir, f"helper: relaunched {target}")
    return ok


def _start_direct_compat(install, data_dir):
    """Route 3: the launcher's own terminal state, started
    directly -- pythonw running the .pyw with the
    compatibility marker set (the mirror's copy first, the
    install's second). Used only when both launcher copies
    failed to produce a window."""
    tries = []
    lad = os.environ.get("LOCALAPPDATA")
    if lad:
        mirror = os.path.join(lad, "TaskListMirror")
        tries.append((os.path.join(mirror, "python",
                                   "pythonw.exe"),
                      os.path.join(mirror, "Task List.pyw")))
    tries.append((os.path.join(install, "python", "pythonw.exe"),
                  os.path.join(install, "Task List.pyw")))
    for pythonw, pyw in tries:
        if os.path.isfile(pythonw) and os.path.isfile(pyw):
            extra = {
                "TASKLIST_DATA_DIR": data_dir,
                "TASKLIST_HOST_UNAVAILABLE": "1",
                "TASKLIST_HOST_STATUS":
                    "update helper relaunch-verification retry",
                "TASKLIST_LAUNCH_DEPTH": "1",
                "PYTHONNOUSERSITE": "1",
            }
            if _start_process([pythonw, pyw],
                              os.path.dirname(pyw), data_dir,
                              env_extra=extra):
                _upd_log(data_dir,
                         "helper: relaunched "
                         f"{pyw} (direct compatibility start)")
                return True
    return False


def _relaunch_routes(requested, install, data_dir):
    """Try each relaunch route in order, watching for the
    app's window after each start. Returns True when a route
    produced the window marker. A route whose process cannot
    even start fails immediately (no watch is burned on it)."""
    first = safe_relaunch_target(requested, install, data_dir)
    candidates = [first]
    for cand in (
            os.path.join(os.path.dirname(os.path.abspath(install)),
                         "Task List.exe"),
            os.path.join(install, "Task List.exe"),
            os.path.join(install, "Task List.bat")):
        if (os.path.isfile(cand)
                and _norm(cand) != _norm(first)
                and cand not in candidates):
            candidates.append(cand)
    routes = []
    for i, cand in enumerate(candidates):
        routes.append((f"launcher copy {cand}",
                       (lambda c: lambda: _start_launcher_target(
                           c, install, data_dir))(cand),
                       _ROUTE_WATCH[min(i, 1)]))
    routes.append(("direct compatibility start",
                   lambda: _start_direct_compat(install, data_dir),
                   _ROUTE_WATCH[2]))
    for idx, (desc, start, watch) in enumerate(routes):
        _upd_log(data_dir,
                 f"helper: relaunch route {idx + 1}: {desc}")
        before = _log_size(data_dir)
        try:
            started = start()
        except Exception as exc:
            _upd_log(data_dir,
                     f"helper: relaunch route {idx + 1} could "
                     f"not start: {exc!r}")
            continue
        if not started:
            _upd_log(data_dir,
                     f"helper: relaunch route {idx + 1} could "
                     "not start")
            continue
        if _watch_window(data_dir, watch, before):
            if idx > 0:
                _loud(data_dir,
                      f"helper: window confirmed after "
                      f"relaunch route {idx + 1} ({desc})")
            else:
                _upd_log(data_dir,
                         "helper: window confirmed after "
                         "relaunch")
            return True
        _loud(data_dir,
              f"helper: relaunch route {idx + 1} ({desc}) "
              f"produced no window within {watch}s")
    return False


def _show_failure_box(text):
    """The last-resort loud record: a visible dialog. Shown
    when an apply ends without a confirmed window -- the
    verified update stayed but could not restart, or a
    rollback could not bring the previous version back; the
    user must never be left guessing why nothing is on
    screen."""
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, "Task List",
                                         0x10)
    except Exception:
        pass


def _rollback_and_relaunch(manifest, old_hashes, install,
                           snap_dir, requested, data_dir, why):
    """Restore the pre-update program files, verify the
    restoration, and relaunch the previous version under the
    same window watch. Returns True when the previous
    version's window is confirmed."""
    _loud(data_dir, f"helper: rolling back ({why})")
    _set_phase("roll back")
    failed = _restore_snapshot(manifest, install, snap_dir)
    if failed:
        _loud(data_dir,
              "helper: rollback could not restore: "
              + ", ".join(failed))
    inst_hashes, root_hashes = _snapshot_hashes_for(manifest,
                                                    old_hashes)
    bad = _verify_set(install, inst_hashes)
    parent = os.path.dirname(os.path.abspath(install))
    bad += [name for name in root_hashes
            if _verify_set(parent, {name: root_hashes[name]})]
    if bad:
        _loud(data_dir,
              "helper: rollback verification failed for: "
              + ", ".join(bad))
    else:
        _loud(data_dir,
              "helper: rollback complete; previous version "
              "restored and verified")
    _set_phase("relaunch")
    return _relaunch_routes(requested, install, data_dir)


def _apply_body(pid, pending, install, data_dir, relaunch):
    """The V1.9.84 verified apply. Runs on the worker thread;
    the main thread enforces the phase deadlines."""
    _set_phase("wait for app exit")
    _upd_log(data_dir,
             f"helper: start, waiting for app pid {pid} to exit")
    deadline = time.time() + 180
    while _pid_alive(pid) and time.time() < deadline:
        time.sleep(0.25)
    gone = not _pid_alive(pid)
    _upd_log(data_dir, "helper: app exited" if gone else
             "helper: app still running after 180s; trying anyway")

    try:
        hashes = _zip_payload_hashes(pending)
    except Exception as exc:
        _loud(data_dir,
              f"helper: staged zip unreadable ({exc!r}); "
              "apply aborted, install untouched")
        return 2
    if not hashes:
        _loud(data_dir,
              "helper: staged zip carries no payload; apply "
              "aborted, install untouched")
        return 2

    # 1. snapshot (abort leaves the old install intact)
    _set_phase("snapshot")
    snap_dir = os.path.join(_local_state_dir(), "update_backup")
    try:
        manifest, old_hashes = _snapshot(hashes, install,
                                         snap_dir)
    except Exception as exc:
        _loud(data_dir,
              f"helper: snapshot failed ({exc!r}); apply "
              "aborted with the previous version intact")
        _set_phase("relaunch")
        _relaunch_routes(relaunch, install, data_dir)
        return 2
    _upd_log(data_dir,
             "helper: snapshot of the current program files "
             "complete")

    # 2. stage + verify (install still untouched)
    _set_phase("stage")
    staging = os.path.join(install, ".update_staging")
    ok = False
    for attempt in range(30):
        try:
            shutil.rmtree(staging, ignore_errors=True)
            n = _extract_update(pending, staging)
            _upd_log(data_dir,
                     f"helper: staged {n} files for verification")
            ok = True
            break
        except Exception as exc:
            _upd_log(data_dir, "helper: stage attempt "
                     f"{attempt + 1} failed: {exc!r}")
            time.sleep(1.0)
    if not ok:
        _loud(data_dir,
              "helper: update could not be staged after 30 "
              "attempts; apply aborted, install untouched")
        shutil.rmtree(staging, ignore_errors=True)
        _set_phase("relaunch")
        _relaunch_routes(relaunch, install, data_dir)
        return 2
    _set_phase("verify staged")
    bad = _verify_set(staging, hashes)
    if bad:
        _loud(data_dir,
              "helper: staged files failed verification: "
              + ", ".join(bad)
              + "; apply aborted, install untouched")
        shutil.rmtree(staging, ignore_errors=True)
        _set_phase("relaunch")
        _relaunch_routes(relaunch, install, data_dir)
        return 2
    _upd_log(data_dir,
             "helper: staged update verified against the "
             "package")

    # 3. commit (version.txt LAST) + root refresh + read-back
    _set_phase("commit")
    order = sorted(hashes,
                   key=lambda r: (r == "version.txt", r))
    commit_failed = []
    for rel in order:
        src = _fs_path(staging, rel)
        dst = _fs_path(install, rel)
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            os.replace(src, dst)
        except OSError:
            try:
                shutil.copyfile(src, dst)
            except OSError:
                commit_failed.append(rel)
    # Refresh the root launcher copy / .bat from the same
    # verified bytes when they already exist beside the files
    # folder (never create them: V1.9.73 case D). The root exe
    # is the one every launch actually runs; an update that
    # left it stale would leave the fixed launcher unused.
    parent = os.path.dirname(os.path.abspath(install))
    root_failed = []
    for name in ("Task List.exe", "Task List.bat"):
        key = "root:" + name
        if key not in manifest or not manifest[key]["exists"]:
            continue
        if name not in hashes:
            continue
        src = _fs_path(staging, name)
        if not os.path.isfile(src):
            # os.replace above already moved the staged copy
            # into the install; use the installed copy (it is
            # read-back-verified below together with the rest).
            src = _fs_path(install, name)
        dst = os.path.join(parent, name)
        done = False
        for _try in range(3):
            try:
                tmp = dst + ".update_tmp"
                shutil.copyfile(src, tmp)
                os.replace(tmp, dst)
                done = True
                break
            except OSError:
                time.sleep(2.0)
        if not done:
            root_failed.append(name)
    _set_phase("verify install")

    def _bad_root():
        return [name for name in ("Task List.exe",
                                  "Task List.bat")
                if ("root:" + name) in manifest
                and manifest["root:" + name]["exists"]
                and name in hashes
                and _verify_set(parent, {name: hashes[name]})]

    bad_inst = _verify_set(install, hashes)
    for rel in commit_failed:
        if rel not in bad_inst:
            bad_inst.append(rel)
    bad_root = _bad_root()
    for name in root_failed:
        if name not in bad_root:
            bad_root.append(name)
    if bad_inst or bad_root:
        # one repair pass: re-stage from the zip and re-copy
        # only the bad files, then verify again
        _loud(data_dir,
              "helper: installed files failed read-back "
              "verification: "
              + ", ".join(bad_inst + bad_root)
              + "; repairing from the package")
        try:
            shutil.rmtree(staging, ignore_errors=True)
            _extract_update(pending, staging)
            for rel in bad_inst:
                src = _fs_path(staging, rel)
                dst = _fs_path(install, rel)
                os.makedirs(os.path.dirname(dst),
                            exist_ok=True)
                shutil.copyfile(src, dst)
            for name in bad_root:
                src = _fs_path(staging, name)
                if not os.path.isfile(src):
                    src = _fs_path(install, name)
                dst = os.path.join(parent, name)
                tmp = dst + ".update_tmp"
                shutil.copyfile(src, tmp)
                os.replace(tmp, dst)
        except Exception as exc:
            _loud(data_dir,
                  f"helper: repair pass failed: {exc!r}")
        bad_inst = _verify_set(install, hashes)
        bad_root = _bad_root()
    shutil.rmtree(staging, ignore_errors=True)
    if bad_inst or bad_root:
        _loud(data_dir,
              "helper: update NOT applied cleanly (failed: "
              + ", ".join(bad_inst + bad_root)
              + "); rolling back")
        ok_back = _rollback_and_relaunch(
            manifest, old_hashes, install, snap_dir, relaunch,
            data_dir, "installed files failed verification")
        return 2 if ok_back else 3

    # 4. verified commit: clear the stage, then relaunch under
    # the window watch
    for name in ("pending_update.zip", "pending_update.json",
                 "pending_update.zip.part"):
        try:
            os.remove(os.path.join(data_dir, name))
        except OSError:
            pass
    _upd_log(data_dir,
             f"helper: update applied and verified "
             f"({len(hashes)} files), relaunching")
    _set_phase("relaunch")
    if _relaunch_routes(relaunch, install, data_dir):
        shutil.rmtree(snap_dir, ignore_errors=True)
        return 0
    # The install is verified good; only the restart failed.
    # That is NEVER silent (the 2026-11-19 failure was exactly
    # this, unrecorded): loud records in both logs and a
    # visible dialog. The update is NOT rolled back -- its
    # files verified; rolling back a good install because
    # its restart could not be confirmed would trade a
    # working state for an older one on a guess. The user
    # starts the app from its icon, and the (V1.9.84) launcher
    # chain he lands on is itself bounded and verified.
    _loud(data_dir,
          "helper: update applied and verified, but no "
          "relaunch route produced a window; the new version "
          "is installed and verified -- start Task List from "
          "its icon")
    _show_failure_box(
        "Task List has been updated, but it could not "
        "restart itself.\n\n"
        "The new version is installed and verified, and your "
        "task data is not touched by updates.\n\n"
        "Please start Task List from its icon. Details are "
        "in the update log.")
    return 2


def apply_update_main(argv):
    """--apply-update <app_pid> <pending_zip> <install_dir>
    <data_dir> [relaunch_path]"""
    pid = int(argv[0])
    pending, install, data_dir = argv[1], argv[2], argv[3]
    relaunch = (argv[4] if len(argv) > 4
                else os.path.join(install, "Task List.exe"))
    lock = _acquire_helper_lock(data_dir, pending)
    if lock is None:
        _upd_log(data_dir,
                 "helper: another live helper holds the lock; "
                 "exiting without acting")
        return 0
    result = {}
    done = threading.Event()

    def _run():
        try:
            result["rc"] = _apply_body(pid, pending, install,
                                       data_dir, relaunch)
        except Exception as exc:  # noqa: BLE001 - recorded, exit 3
            try:
                _loud(data_dir,
                      f"helper: unexpected failure: {exc!r}")
            except Exception:
                pass
            result["rc"] = 3
        finally:
            done.set()

    worker = threading.Thread(target=_run, daemon=True,
                              name="apply-update")
    worker.start()
    # Phase watchdog (V1.9.84): a phase that overruns its
    # deadline means a step is blocked on something that will
    # never answer (the field shape: a share read that never
    # returns). Die loudly instead of hanging forever holding
    # the helper lock; the lock's pid is dead afterwards, so
    # the next attempt takes it over. The install state at
    # any abort is the one the phase ordering guarantees
    # (pre-commit: untouched; commit: version.txt still old).
    while not done.wait(1.0):
        name, deadline = _phase_state()
        if deadline is not None and time.time() > deadline:
            _local_log(
                f"helper: WATCHDOG ABORT -- phase '{name}' "
                f"exceeded its deadline; the helper is "
                f"exiting instead of hanging. Install state: "
                f"see update.log. (data dir: {data_dir})")
            # The share copy of the record is fire-and-forget:
            # a blocked share write must not delay the exit
            # it exists to guarantee.
            threading.Thread(
                target=_upd_log,
                args=(data_dir,
                      f"helper: watchdog abort in phase "
                      f"'{name}'"),
                daemon=True).start()
            time.sleep(0.2)
            os._exit(3)
    try:
        os.remove(lock)
    except OSError:
        pass
    return result.get("rc", 3)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--apply-update":
        raise SystemExit(apply_update_main(sys.argv[2:7]))
    raise SystemExit("usage: apply_update.py --apply-update "
                     "<pid> <zip> <install_dir> <data_dir> "
                     "[relaunch_path]")
