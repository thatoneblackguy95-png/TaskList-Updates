"""Task List update helper — launched detached by the app with
the BUNDLED python (which an update never replaces), mirroring
Drawing Finder's helper:

    pythonw.exe apply_update.py --apply-update <app_pid>
        <pending_zip> <install_dir> <data_dir> [relaunch_path]

It waits for the app process to exit, unpacks the staged update
over the install folder (retrying while files settle), clears the
stage ONLY on success, logs every step to <data_dir>/update.log,
and relaunches the user's launcher. V1.9.32: the caller passes the
real launcher path explicitly — the install dir under the mirror
layout is the share's files folder while the exe the user launches
can sit OUTSIDE it, and defaulting to <install>/Task List.exe is
what left the app closed after the 1.9.31 update (no exe exists in
the local mirror the old caller mistook for the install).

Task List differences from the Drawing Finder original, both
load-bearing:
- Entries under data/ or python/ inside the zip are NEVER
  extracted: the user's database lives in the install tree and no
  update may touch it, and the bundled runtime is not update
  payload either (defense in depth — release zips don't carry
  them, but a bad zip must not be able to hurt).
- Zip entries that would escape the install dir are skipped.

Stdlib only; no PySide6 — this runs before the app exists.
"""
import os
import subprocess
import sys
import time
import zipfile


def _upd_log(data_dir, msg):
    try:
        with open(os.path.join(data_dir, "update.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ")
                     + str(msg) + "\n")
    except Exception:
        pass


def _pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x00100000, False, pid)
        if not handle:
            return False
        try:
            # WAIT_OBJECT_0 (0) = signalled = the process exited
            return kernel32.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _extract_update(pending, install):
    """Extract the update zip over the install dir, skipping
    anything under data/ or python/ and anything that would land
    outside the install dir. Returns the count extracted."""
    install_abs = os.path.abspath(install)
    count = 0
    with zipfile.ZipFile(pending) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            parts = [p for p in name.split("/") if p not in ("", ".")]
            if not parts or ".." in parts:
                continue
            if parts[0].lower() in ("data", "python"):
                continue
            dest = os.path.abspath(os.path.join(install_abs, *parts))
            if os.path.commonpath([dest, install_abs]) != install_abs:
                continue
            if info.is_dir():
                os.makedirs(dest, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(info) as src, open(dest, "wb") as out:
                while True:
                    chunk = src.read(1 << 16)
                    if not chunk:
                        break
                    out.write(chunk)
            count += 1
    return count


def apply_update_main(argv):
    """--apply-update <app_pid> <pending_zip> <install_dir>
    <data_dir> [relaunch_path]"""
    pid = int(argv[0])
    pending, install, data_dir = argv[1], argv[2], argv[3]
    relaunch = (argv[4] if len(argv) > 4
                else os.path.join(install, "Task List.exe"))
    _upd_log(data_dir,
             f"helper: start, waiting for app pid {pid} to exit")
    deadline = time.time() + 180
    while _pid_alive(pid) and time.time() < deadline:
        time.sleep(0.25)
    gone = not _pid_alive(pid)
    _upd_log(data_dir, "helper: app exited" if gone else
             "helper: app still running after 180s; trying anyway")
    ok = False
    for attempt in range(30):
        try:
            n = _extract_update(pending, install)
            _upd_log(data_dir, f"helper: extracted {n} files")
            ok = True
            break
        except Exception as exc:
            _upd_log(data_dir, "helper: extract attempt "
                     f"{attempt + 1} failed: {exc!r}")
            time.sleep(1.0)
    if ok:
        for name in ("pending_update.zip", "pending_update.json",
                     "pending_update.zip.part"):
            try:
                os.remove(os.path.join(data_dir, name))
            except OSError:
                pass
        _upd_log(data_dir, "helper: update applied, relaunching")
    else:
        _upd_log(data_dir, "helper: update NOT applied after 30 "
                 "attempts; the staged zip was kept")
    try:
        flags = 0
        if os.name == "nt":
            flags = 0x00000008 | 0x08000000  # DETACHED | NO_WINDOW
        cmd = [relaunch]
        if relaunch.lower().endswith(".bat"):
            cmd = ["cmd", "/c", relaunch]
        subprocess.Popen(
            cmd, cwd=os.path.dirname(relaunch) or install,
            creationflags=flags, close_fds=True)
        _upd_log(data_dir, f"helper: relaunched {relaunch}")
    except Exception as exc:
        _upd_log(data_dir, f"helper: relaunch failed: {exc!r}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--apply-update":
        raise SystemExit(apply_update_main(sys.argv[2:7]))
    raise SystemExit("usage: apply_update.py --apply-update "
                     "<pid> <zip> <install_dir> <data_dir> "
                     "[relaunch_path]")
