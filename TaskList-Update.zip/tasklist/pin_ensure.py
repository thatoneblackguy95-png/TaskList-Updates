"""Detached shortcut-ensure child (V1.9.88).

Run as a script by the bundled pythonw:

    pythonw.exe tasklist/pin_ensure.py

Spawned by app.py a few seconds AFTER the main window is shown,
detached, once per launch. It runs the Start Menu + Desktop
shortcut ensures (taskbar.ensure_start_menu_shortcut /
ensure_desktop_shortcut) -- a chain of raw shell COM calls against
paths inside the user profile, which on a redirected/network
profile (the user's work account; at home reached over a VPN) can
be arbitrarily slow, can wedge, and can fault natively.

That work used to run in the app process: unbounded on the
startup path in 1.9.85, then on a worker thread with a bounded
join in 1.9.86. Both shapes kept the hazard in-process -- the
join wait WAS the launch freeze on a slow profile, and a native
fault in the COM chain kills the whole process from any thread
(field, 2026-11-24: freeze-then-crash on open at home on the
VPN, fine at work on the LAN). In this child, a wedged ensure
hangs a throwaway process and a faulting one dies alone: the app
never joins, never waits, and shares nothing with the child
beyond startup.log, where the ensures' own read-back verdicts
land exactly as they did when they ran in-process.

Never raises; exits 0 on completion, whatever the ensures found.
"""

import sys
from pathlib import Path


def _main():
    root = Path(__file__).resolve().parent.parent
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        from tasklist.startup_log import log_startup_event
    except Exception:  # noqa: BLE001 - logging must never break us

        def log_startup_event(_msg):
            pass

    try:
        from tasklist.taskbar import (ensure_desktop_shortcut,
                                      ensure_start_menu_shortcut)
    except Exception:  # noqa: BLE001
        log_startup_event("pin: ensure child could not import taskbar")
        return 0
    log_startup_event("pin: ensure child started")
    try:
        _sm_ok = ensure_start_menu_shortcut()
    except Exception:  # noqa: BLE001
        _sm_ok = False
    log_startup_event(
        f"pin: start menu shortcut ensure (child) -> {_sm_ok}")
    try:
        _desk_ok = ensure_desktop_shortcut()
    except Exception:  # noqa: BLE001
        _desk_ok = False
    log_startup_event(
        f"pin: desktop shortcut ensure (child) -> {_desk_ok}")
    return 0


if __name__ == "__main__":
    sys.exit(_main())
