"""Embedded Task List icon (V1.9.12).

A 64x64 PNG rendered from tasklist/assets/tl_icon.ico, stored as base64
so the window/taskbar icon never depends on a file on the network share
being readable at the exact moment of launch. If the share file check
runs before the share has reconnected, the app used to start with NO
window icon at all — Windows then shows a generic taskbar button, and
nothing in the app ever re-set the icon afterward.

app.py tries the share file first (so a future icon update still takes
effect) and falls back to this embedded copy; it also retries the file
a few seconds after the window shows, so a recovered share re-asserts
the file icon on the running window.
"""

_ICON_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAKI0lEQVR4nO1ba4wcxRH+qrtnd3Zn"
    "b3fPDncQGRAmhJBAwAgwJDgLPoSSwJ8kGmNQCFIg5Ecef0yIAkLLin+JIpHIEoEfkcLTeG2CIuEf"
    "CNsYFPEUTyeGgCGYl3z4eb59znRXfsze3t7t42Zvx74z4TvNnW56qqa6uqq6uqYbCAvXlblcToV+"
    "foGQy+UUXFeGfZ7mfiQvgAIDYADYuHGj/P2f/3aqXz18stGcZjZxIuJ5SzwAmJmIRE1ImlB25sNb"
    "f33DB2vWrNGNZgLyBBRMLx69FeC6EsWiBoDzL/rOqnKlep3v1S/Tvr8c4NiC9LoDgk5QXSr1nrJi"
    "TycT9sOvvPjMswBm9KE7bff7fP5FuYtL5VKhXqte6fs+tO+BmQGwQcMqFgEIIEFEkMqCUgqxuP2k"
    "k3Tyr7y443m09KcDYSdmAIj47HNX5svl0h31WlVq32MQaSISAFEX2oUEA8zMbMAspbIoFrd1Munc"
    "tfP1Fwpg7qiE2Z0gAJTP58XGx7Y8UCmX1larZSYiQ0Ry0Yz3XCCAmTUzC9tOUiLpbFjzw+9fXygU"
    "pqy22RPRSua6riAis2HzlgdLk5NrK5WSRyQAkGSeplz0FwMASSKBSqXklSYn127YvOVBIjKu6wq0"
    "DHxTAa7rimKxqM86Z2W+WildU6uVPSGkBTAtHlfvBwyASQhp1Wplr1opXXPWOSvzxWJRN5QAoKEJ"
    "13VlsVjUKy7MXXDo0P4XKqUjhoSQWHx+Pl8wG6MTzpDIZpeufPWlHS9P9XmqgwIgc8Y3zttanphY"
    "rbXWRBQ6mTgewMxaSimTqfS2d3a9NgawAGCEG2RN5rwLLv2WV6ut9n3fgEguuB9HfIFI+r5vPK+2"
    "esWFqy4BYFzXlWp8fJwAoFqr/MTzPIBgGtrpCBIEitgzmLmRW3Tm39o+EAjG8zxRqZZvAPDc+Ph4"
    "MJ/ffPPNauvTz/+rVJo4A4DBzNlhBuq1OgwbBOFhMKEIBGaGZQXJCzOjXp/mT0Bb+4C6NwCE46Tf"
    "+fG1P/h6oVDQCgDv3LnnFF/7p7ExIBI9X7F8+XLYtg1jzOAhkgEpBfbuHcfBgwehlMLpp5+OeDwG"
    "YwLlSikwPv4ZDh44ACklBjQEYjbwtXfaE1tfPgXAewoAyvXqMjArw2wEdTd/Zsbdf7obK1asQKlU"
    "ghBdHw0FrTWGh1O45Zbf4d5778Xo6Cju+cs9OPPMM1GpVMDMGB5O4bbb8li/fj2WLFkCo7um9WFA"
    "QaYIpWsTyzClAI16hpkRZsKXUkJKASnlwAoAACkEiKZNKeAvG6PNbe0RgBkMn3UWABQAkIYVNKG3"
    "CjgYNd/X8H2/owJEQ+BmUCOCMaZjENNaw9cabKbTTGaGMaZJYzqloIOgwWOqz6qtZQ4NOI4Dx5aQ"
    "Mo1OBlCp1GCMaY4aM2DbNiyrPa3QmhGTBMtS4JbFJRE16YO/R0EDDajOt7uACLfffjvS6TS01jNM"
    "k5khpUQ+n8eyZctQr9fBzBhKJXD/gw/j8b8/jqGhoSB4ttBYlsKuXW/BSaWgTXvt4uh2f4YFhMMz"
    "O56BNnrGBDBl5kpZWLduHYQQzbnbUgK7/r0LT/zjMaSzJ8D3vVZKMDMSyQQsZQWucIwxrQDm6asH"
    "UimnLShNK0C1xQUGYMdtJJ0MMpk0fN9v48nM0Fqj5/iGlG9OzOLRtwWYTmbaUEC3aD3VwamrE/1C"
    "YUYM6JkCzoG5/LOtEtEnfVQxYHYdr28X6IombSd6npt/mLaj4AKDZzLHOf7vFdASA6Z/5oNe1ByC"
    "f5i2QeTr9p6WGIDBokwv+jCZzLGKgrN4fOECM/+NwgSA9kJBPyYw3/awmEk/HQOimgWBtv5zCP69"
    "2o/iLPiFC/S5HO6FsOY7nyh4DJbDixlCCCilIGWvbzXcXJN0Wq90w4xpMKoY0CbiAJkwAShNllAt"
    "T2C/NvC71AQJgGEgHo/BcZyuZfTZ2fpRdgHu0B7eBYQQqNR8XHX11TjxxBNhJ+yuNQPDBolEHK+9"
    "9gY2bdoE27bBHS3hOHIBIkK1WsfY2Biu+u5Yz6HRDCgCNj++BQ8/9BCSiQTC1I9nKiACA5hZ1Jwu"
    "boY1gCmaVj8+cuQIDveoNwBBgTWbdTAxcTh4rldW2oLI1wLxeBxJW4KRBGsN1QhghsOtBeLxBJIJ"
    "BVASso+yu+9rJGIKiYQdlOO6vKv7WiAi7N69G0RApVIFs0E2k8K+/fugpJjz+x4zY/fud8FsUK1W"
    "+/ruoLVGJuPg448/atYkwyASBTAHU5DWGj+76cZZrQRjNIYaleS56G+68acDy5JMJkNPhdFVhBrw"
    "Pa/9JoX/ntyRvi8QepYYuxVFo8qziKixiWx6YRD45Hzo+ymWcqh3ze5j5DGAgQ6rovAd4eYvmn03"
    "LHVfiHA5PIsNEcD+wKu3YAeDDJQaSfW8y3I4Mh9owHhVSMuBkGLeUyuBwMZAeyUIFY9Gtm6pcGQx"
    "QEh4lUM45ZJf4itX/AZ+jdHYa9i3pMwGKk5496k/YM9z62ElsmAz0P6AXjEg2oqL0XX49RJ0nQGa"
    "Z9mBDUAEo2uzZBxUvlmzAEvlUUT8WWuo2BA+efmv+PTVh0BCzH9qpcAFWNegYkPgwXaHNARs/JHK"
    "AxoKkBCHg1HiiD7SMYSVCDo+yF4iEyRINMUrGtmISECRPAQ0FJAcyn5Ee/f4DCgO3jS4IqbYDPLh"
    "s7m/O3yBYw4wA0II8p308EdAUBOks8/43h5Lxd4X1HSEqN4X0RWdQIIISsXeH7v0V3sAkMjlcvK+"
    "+37u2XZym1IxsGETmdyL7GLDRqkY7ERya6FwuZ/L5aQYGRlhAEhmM/fH7QSYtVhwSY/SxaxF3E7A"
    "yQ7fDwAjIyPNoCeIyCz/6tlb941/utoEG4A+V5ulwayFlHLJyEnb/vufnWPMjc3SAOC6LjEz0ktH"
    "f+ukMsZoM103+HxcbLRhJ5UxwyecdCszw3VdAlqjfeN01de+eVF+/95P7ixPTnhCKivgcLweGwhk"
    "N9r3kqm0tXT0y3e+9caLhdaTZNMpWrFoXNeVb7/5UiG7dORRO+lYRvseiHihh2/eFxEb7Xt20rGy"
    "wyOPvv3mSwU36HxzXu18aGr7dvHIL9Y9cGD/3rWlySMshDSCSA76bf5YgUAwzNoYLZzUEC1ZOrrh"
    "WveP1xcKl7dtVep6bI6I+KxzV+YP7hu/Y3LisNS+xyRIE4mplc1i8wsGwMzGsAmOzaXSGT38pZG7"
    "dr3+QoFDHpubfZ/P//YVFx/+bG9hcnLiylqlDM+rN7a1tm24WkgQAEEkYFkxxBNJpFLpJzMnjOZf"
    "+edTfR+cbIErgaImIqy45PJVk4cOXVetlC+r16vLjdGxhdjZ2QkkBIQQ9VjMfi+RcLY72cwjrz63"
    "/dmgMhz0oSvt3OxnHp5mZrnqih+dOlk6cLLxTZp9b2EPTyurJpSYSDlLPnz2qc0fEFFfh6fDw3Ul"
    "sPiPzwP9HZ//H+/hAPj67FzAAAAAAElFTkSuQmCC"
)


def embedded_icon():
    """QIcon built from the embedded PNG bytes, or None on failure."""
    try:
        from PySide6.QtGui import QIcon, QPixmap
        import base64
        pix = QPixmap()
        if not pix.loadFromData(base64.b64decode(_ICON_PNG_B64), "PNG"):
            return None
        icon = QIcon(pix)
        return icon if not icon.isNull() else None
    except Exception:
        return None
